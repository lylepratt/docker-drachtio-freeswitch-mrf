#include <cstdlib>
#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <mutex>
#include <string>
#include <sstream>
#include <deque>
#include <memory>
#include <chrono>
#include <atomic>

#include <houndify/houndify.hpp>

#include "mod_houndify_transcribe.h"
#include "simple_buffer.h"

const char ALLOC_TAG[] = "houndify";

// Static variables to cache environment variables
static const char* static_client_id = nullptr;
static const char* static_client_key = nullptr;
static const char* static_user_id = nullptr;

// Forward declaration
extern "C" switch_bool_t houndify_transcribe_frame(switch_media_bug_t *bug, void* user_data);

class GStreamer {
private:
	std::function<void(houndify::Transcript)> createTranscriptCallback() {
		return [this](houndify::Transcript transcript) {
			try {
				if (transcript.text != m_lastTranscript && m_interim && !transcript.text.empty()) {
					m_lastTranscript = transcript.text;
					m_hasNewInterimTranscript.store(true);
				}
			} catch (const std::exception& e) {
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
					"Error in transcript callback: %s\n", e.what());
			}
		};
	}

public:
	GStreamer(
		const char *sessionId,
		const char *bugname,
		u_int16_t channels,
		char *lang,
		int interim,
		uint32_t samples_per_second,
		const char* clientId,
		const char* clientKey,
		const char* userId,
		responseHandler_t responseHandler
	) : m_sessionId(sessionId), m_bugname(bugname), m_finished(false), m_stopped(false), m_interim(interim),
		m_connected(false), m_hasNewInterimTranscript(false),
		m_responseHandler(responseHandler), m_sampleRate(samples_per_second) {

		switch_core_session_t* psession = switch_core_session_locate(sessionId);
		if (!psession) throw std::invalid_argument("session id no longer active");
		switch_channel_t *channel = switch_core_session_get_channel(psession);

		try {
			m_client = std::make_unique<houndify::Client>(clientId, clientKey, userId);
		} catch (const std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
				"Failed to create Houndify client: %s\n", e.what());
			sendErrorNotification(e.what(), "client_creation_failure");
			switch_core_session_rwunlock(psession);
			throw std::runtime_error("Houndify client initialization failed");
		}
		
		try {
			auto& requestInfo = m_client->request_info();
		
		const char* latitude = switch_channel_get_variable(channel, "HOUNDIFY_LATITUDE");
		const char* longitude = switch_channel_get_variable(channel, "HOUNDIFY_LONGITUDE");
		const char* city = switch_channel_get_variable(channel, "HOUNDIFY_CITY");
		const char* state = switch_channel_get_variable(channel, "HOUNDIFY_STATE");
		const char* country = switch_channel_get_variable(channel, "HOUNDIFY_COUNTRY");
		
		if (latitude && longitude) {
			requestInfo["Latitude"] = std::stod(latitude);
			requestInfo["Longitude"] = std::stod(longitude);
		}
		
		if (city) requestInfo["City"] = city;
		if (state) requestInfo["State"] = state;
		if (country) requestInfo["Country"] = country;
		
		const char* timezone = switch_channel_get_variable(channel, "HOUNDIFY_TIMEZONE");
		if (timezone) requestInfo["TimeZone"] = timezone;
		
		if (lang && strlen(lang) > 0) {
			requestInfo["InputLanguageIETFTag"] = lang;
		} else {
			requestInfo["InputLanguageEnglishName"] = "English";
			requestInfo["InputLanguageIETFTag"] = "en-US";
		}
		
		// Voice Activity Detection parameters
		const char* max_silence_seconds = switch_channel_get_variable(channel, "HOUNDIFY_MAX_SILENCE_SECONDS");
		const char* max_silence_after_full = switch_channel_get_variable(channel, "HOUNDIFY_MAX_SILENCE_AFTER_FULL_QUERY_SECONDS");
		const char* max_silence_after_partial = switch_channel_get_variable(channel, "HOUNDIFY_MAX_SILENCE_AFTER_PARTIAL_QUERY_SECONDS");
		const char* vad_sensitivity = switch_channel_get_variable(channel, "HOUNDIFY_VAD_SENSITIVITY");
		const char* vad_timeout = switch_channel_get_variable(channel, "HOUNDIFY_VAD_TIMEOUT");
		
		if (max_silence_seconds || max_silence_after_full || max_silence_after_partial || vad_sensitivity || vad_timeout) {
			nlohmann::json voiceDetectionConfig = nlohmann::json::object();
			if (max_silence_seconds) voiceDetectionConfig["MaxSilenceSeconds"] = std::stod(max_silence_seconds);
			if (max_silence_after_full) voiceDetectionConfig["MaxSilenceAfterFullQuerySeconds"] = std::stod(max_silence_after_full);
			if (max_silence_after_partial) voiceDetectionConfig["MaxSilenceAfterPartialQuerySeconds"] = std::stod(max_silence_after_partial);
			if (vad_sensitivity) voiceDetectionConfig["VadSensitivity"] = std::stod(vad_sensitivity);
			if (vad_timeout) voiceDetectionConfig["VadTimeout"] = std::stod(vad_timeout);
			requestInfo["VoiceActivityDetection"] = voiceDetectionConfig;
		}
		
		requestInfo["ServerDeterminesEndOfAudio"] = true;
		requestInfo["ClientID"] = clientId;
		requestInfo["UserID"] = userId;
		requestInfo["SessionID"] = sessionId;
		requestInfo["AudioFormat"] = "PCM16";
		requestInfo["SampleRate"] = samples_per_second;
		requestInfo["Channels"] = static_cast<int>(channels);
		
		auto now = std::chrono::system_clock::now();
		requestInfo["RequestTimestamp"] = std::chrono::system_clock::to_time_t(now);
		
		const char* domain = switch_channel_get_variable(channel, "HOUNDIFY_DOMAIN");
		if (domain) {
			requestInfo["ConversationState"] = nlohmann::json::object();
			requestInfo["ConversationState"]["Domain"] = domain;
		}
		
		requestInfo["PartialTranscriptsDesired"] = interim > 0;

		// Audio processing parameters
		const char* audio_format = switch_channel_get_variable(channel, "HOUNDIFY_AUDIO_FORMAT");
		if (audio_format) requestInfo["AudioFormat"] = audio_format;
		
		const char* enable_noise_reduction = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_NOISE_REDUCTION");
		if (enable_noise_reduction && switch_true(enable_noise_reduction)) {
			requestInfo["AudioProcessing"] = nlohmann::json::object();
			requestInfo["AudioProcessing"]["NoiseReduction"] = true;
		}
		
		// Recognition control parameters
		const char* enable_profanity_filter = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_PROFANITY_FILTER");
		if (enable_profanity_filter && switch_true(enable_profanity_filter)) {
			requestInfo["ProfanityFilter"] = true;
		}
		
		const char* enable_punctuation = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_PUNCTUATION");
		if (enable_punctuation && switch_true(enable_punctuation)) {
			requestInfo["EnablePunctuation"] = true;
		}
		
		const char* enable_capitalization = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_CAPITALIZATION");
		if (enable_capitalization && switch_true(enable_capitalization)) {
			requestInfo["EnableCapitalization"] = true;
		}
		
		const char* confidence_threshold = switch_channel_get_variable(channel, "HOUNDIFY_CONFIDENCE_THRESHOLD");
		if (confidence_threshold) {
			requestInfo["ConfidenceThreshold"] = std::stod(confidence_threshold);
		}
		
		// Response formatting parameters
		const char* max_results = switch_channel_get_variable(channel, "HOUNDIFY_MAX_RESULTS");
		if (max_results) {
			requestInfo["NumToReturn"] = atoi(max_results);
		}
		
		const char* enable_word_timestamps = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_WORD_TIMESTAMPS");
		if (enable_word_timestamps && switch_true(enable_word_timestamps)) {
			requestInfo["EnableWordTimestamps"] = true;
		}
		
		const char* max_alternatives = switch_channel_get_variable(channel, "HOUNDIFY_MAX_ALTERNATIVES");
		if (max_alternatives) {
			requestInfo["MaxAlternatives"] = atoi(max_alternatives);
		}
		
		// Session management parameters
		const char* session_timeout = switch_channel_get_variable(channel, "HOUNDIFY_SESSION_TIMEOUT");
		if (session_timeout) {
			requestInfo["SessionTimeout"] = atoi(session_timeout);
		}
		
		const char* connection_timeout = switch_channel_get_variable(channel, "HOUNDIFY_CONNECTION_TIMEOUT");
		if (connection_timeout) {
			requestInfo["ConnectionTimeout"] = atoi(connection_timeout);
		}
		
		// Advanced features
		const char* custom_vocabulary = switch_channel_get_variable(channel, "HOUNDIFY_CUSTOM_VOCABULARY");
		if (custom_vocabulary) {
			// Parse comma-separated vocabulary items
			std::string vocab_str(custom_vocabulary);
			nlohmann::json vocab_array = nlohmann::json::array();
			std::stringstream ss(vocab_str);
			std::string item;
			while (std::getline(ss, item, ',')) {
				// Trim whitespace
				item.erase(0, item.find_first_not_of(" \t"));
				item.erase(item.find_last_not_of(" \t") + 1);
				if (!item.empty()) {
					vocab_array.push_back(item);
				}
			}
			if (!vocab_array.empty()) {
				requestInfo["CustomVocabulary"] = vocab_array;
			}
		}
		
		const char* language_model = switch_channel_get_variable(channel, "HOUNDIFY_LANGUAGE_MODEL");
		if (language_model) {
			requestInfo["LanguageModel"] = language_model;
		}
		
		const char* enable_disfluency_filter = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_DISFLUENCY_FILTER");
		if (enable_disfluency_filter && switch_true(enable_disfluency_filter)) {
			requestInfo["DisfluencyFilter"] = true;
		}
		
		// Partial transcript control
		const char* partial_transcript_interval = switch_channel_get_variable(channel, "HOUNDIFY_PARTIAL_TRANSCRIPT_INTERVAL");
		if (partial_transcript_interval) {
			requestInfo["PartialTranscriptInterval"] = atoi(partial_transcript_interval);
		}

		const char* endpoint = switch_channel_get_variable(channel, "HOUNDIFY_AUDIO_ENDPOINT");
		if (endpoint) m_client->set_audio_endpoint(endpoint);
		
		} catch (const std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error configuring client: %s\n", e.what());
			sendErrorNotification(e.what(), "initialization_failure");
			switch_core_session_rwunlock(psession);
			throw std::runtime_error("Houndify client configuration failed");
		}

		switch_core_session_rwunlock(psession);
	}

	~GStreamer() {
		cleanupAudioQuery();
	}

private:
	std::string m_sessionId;
	std::string m_bugname;
	bool m_finished;
	bool m_stopped;
	int m_interim;
	bool m_connected;
	responseHandler_t m_responseHandler;
	uint32_t m_sampleRate;
	
	std::unique_ptr<houndify::Client> m_client;
	std::unique_ptr<houndify::AudioQuery> m_audioQuery;
	std::string m_lastTranscript;
	std::atomic<bool> m_hasNewInterimTranscript;
	
	// Buffer for audio data when not connected yet
	std::deque<std::vector<int16_t>> m_audioBuffer;
	static const size_t MAX_BUFFER_FRAMES = 500;
	


	void processResponse(const houndify::Json& response, bool final = false) {
		try {
			switch_core_session_t* psession = switch_core_session_locate(m_sessionId.c_str());
			if (psession) {
				m_responseHandler(psession, TRANSCRIBE_EVENT_RESULTS, response.dump().c_str(), m_bugname.c_str(), 0);
				switch_core_session_rwunlock(psession);
			}
		} catch (const std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error processing response: %s\n", e.what());
		}
	}

	void sendErrorNotification(const std::string& error_msg, const std::string& reason, bool is_fatal = true, const std::string& type = "error") {
		try {
			switch_core_session_t* psession = switch_core_session_locate(m_sessionId.c_str());
			if (psession) {
				nlohmann::json errorResponse;
				errorResponse["type"] = type;
				errorResponse["error"] = error_msg;
				errorResponse["fatal"] = is_fatal;
				errorResponse["reason"] = reason;
				if (type == "transcription_stopped") errorResponse["final"] = true;
				
				m_responseHandler(psession, TRANSCRIBE_EVENT_ERROR, 
					errorResponse.dump().c_str(), m_bugname.c_str(), is_fatal);
				switch_core_session_rwunlock(psession);
			}
		} catch (...) {
			// Suppress exceptions in error reporting
		}
	}

private:
	bool shouldStop() const {
		return m_finished || m_stopped;
	}

	bool isRecoverableError(const std::string& error_msg) {
		return (error_msg.find("read:") != std::string::npos ||
				error_msg.find("unspecified system error") != std::string::npos ||
				error_msg.find("connection") != std::string::npos ||
				error_msg.find("network") != std::string::npos ||
				error_msg.find("timeout") != std::string::npos);
	}

	void cleanupAudioQuery() {
		if (m_audioQuery) {
			try {
				auto response = m_audioQuery->finish();
				processResponse(response, true);
			} catch (const std::exception& e) {
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error finishing audio query: %s\n", e.what());
			}
			
			try {
				m_audioQuery.reset();
			} catch (...) {
				// Suppress cleanup exceptions
			}
		}
	}

	bool initializeAudioQuery() {
		try {
			auto callback = createTranscriptCallback();
			m_audioQuery = std::make_unique<houndify::AudioQuery>(
				m_client->start_audio_query(m_sampleRate, callback)
			);
			return true;
		} catch (const std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
				"Failed to initialize audio query: %s\n", e.what());
			return false;
		}
	}

public:
	bool connect() {
		std::lock_guard<std::mutex> lock(m_mutex);
		if (m_connected) return true;
		
		if (initializeAudioQuery()) {
			m_connected = true;
			flushBufferedAudio();
			return true;
		} else {
			sendErrorNotification("Failed to initialize audio query", "connection_initialization_failure");
			m_stopped = true;
			m_finished = true;
			return false;
		}
	}

	bool write(void* data, uint32_t datalen) {
		if (shouldStop()) return false;
		if (!m_connected || !m_audioQuery) {
			if (!connect()) return false;
		}

		try {
			int16_t* samples = reinterpret_cast<int16_t*>(data);
			size_t sampleCount = datalen / sizeof(int16_t);
			bool result = false;
			
			try {
				result = m_audioQuery->stream(samples, sampleCount);
					
			} catch (const std::exception& e) {
				const std::string error_msg = e.what();
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
					"Error in Houndify SDK stream operation - Session: %s, Samples: %zu, Error: %s\n", 
					m_sessionId.c_str(), sampleCount, error_msg.c_str());
				
				if (isRecoverableError(error_msg)) {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
						"Detected potentially recoverable network error, attempting graceful recovery\n");
					sendErrorNotification(error_msg, "recoverable_network_error_write", false, "warning");
					m_connected = false;
					try {
						m_audioQuery.reset();
					} catch (...) {
						// Suppress exceptions during cleanup
					}
					return false; // Continue processing, will switch to buffering mode
				} else {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
						"Non-recoverable error detected, stopping transcription\n");
					sendErrorNotification(error_msg, "fatal_sdk_error");
					m_stopped = true;
					m_finished = true;
					return true; // Stop the frame processing loop
				}
			}
			
			// If result is true, server detected end of query - finish and get final response
			if (result) {
				try {
					auto response = m_audioQuery->finish();
					processResponse(response, true);
				} catch (const std::exception& e) {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
						"Error finishing audio query after server detection: %s\n", e.what());
				}
				return true;  // Indicate stream should end
			}
			
			return false;  // Continue streaming
			
		} catch (const std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error writing audio data: %s\n", e.what());
			m_stopped = true;
			return true;
		}
	}

	void disconnect() {
		std::lock_guard<std::mutex> lock(m_mutex);
		cleanupAudioQuery();
		m_connected = false;
		m_stopped = true;
		m_finished = true;
	}

	bool isConnected() {
		std::lock_guard<std::mutex> lock(m_mutex);
		return m_connected;
	}

	bool isStopped() {
		std::lock_guard<std::mutex> lock(m_mutex);
		return m_stopped;
	}

	void finish() {
		if (m_finished) return;
		
		std::lock_guard<std::mutex> lock(m_mutex);
		
		if (m_stopped && !m_finished) {
			sendErrorNotification("Transcription stopped due to error", "error_state", true, "transcription_stopped");
		}
		
		m_finished = true;
		m_stopped = true;
		cleanupAudioQuery();
	}

	void bufferAudio(const std::vector<int16_t>& audioFrame) {
		std::lock_guard<std::mutex> lock(m_mutex);
		m_audioBuffer.push_back(audioFrame);
		while (m_audioBuffer.size() > MAX_BUFFER_FRAMES) {
			m_audioBuffer.pop_front();
		}
	}

	// Write audio if connected, otherwise buffer it
	bool writeOrBufferAudio(const int16_t* audioData, size_t audioLen) {
		std::lock_guard<std::mutex> lock(m_mutex);
		
		if (m_connected && m_audioQuery) {
			// Connected - write directly to stream
			try {
				bool result = m_audioQuery->stream(audioData, audioLen);
				
				if (result) {
					m_connected = false;
					try {
						auto response = m_audioQuery->finish();
						processResponse(response, true);
					} catch (const std::exception& e) {
						switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
							"Error finishing audio query after server detection: %s\n", e.what());
					}
					m_audioQuery.reset();
					return true; // Indicate stream ended
				}
				return false; // Continue streaming
			} catch (const std::exception& e) {
				const std::string error_msg = e.what();
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
					"Error writing audio data in writeOrBufferAudio - Session: %s, Error: %s\n", 
					m_sessionId.c_str(), error_msg.c_str());
				
				if (isRecoverableError(error_msg)) {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
						"Detected potentially recoverable network error, disconnecting and buffering audio\n");
					
					m_connected = false;
					try {
						m_audioQuery.reset();
					} catch (...) {
						// Suppress exceptions during cleanup
					}
					
					sendErrorNotification(error_msg, "recoverable_network_error", false, "warning");
					
					// Buffer the current audio frame
					std::vector<int16_t> audioFrame(audioData, audioData + audioLen);
					m_audioBuffer.push_back(audioFrame);
					
					while (m_audioBuffer.size() > MAX_BUFFER_FRAMES) {
						m_audioBuffer.pop_front();
					}
					
					return false; // Continue processing, but now in buffering mode
				} else {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, 
						"Non-recoverable error detected in writeOrBufferAudio, stopping transcription\n");
					sendErrorNotification(error_msg, "fatal_write_error");
					m_stopped = true;
					m_finished = true;
					return true; // Stop the frame processing loop
				}
			}
		} else {
			// Not connected - buffer the audio
			std::vector<int16_t> audioFrame(audioData, audioData + audioLen);
			m_audioBuffer.push_back(audioFrame);
			
			// Remove old frames if buffer is too large
			while (m_audioBuffer.size() > MAX_BUFFER_FRAMES) {
				m_audioBuffer.pop_front();
			}
			
			return false; // Buffered successfully, no stream end
		}
	}

	void flushBufferedAudio() {
		if (m_connected && m_audioQuery && !m_audioBuffer.empty()) {
			for (const auto& frame : m_audioBuffer) {
				try {
					if (m_audioQuery->stream(frame.data(), frame.size())) break;
				} catch (const std::exception& e) {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
						"Error streaming buffered audio: %s\n", e.what());
					break;
				}
			}
			m_audioBuffer.clear();
		}
	}

	// Process interim transcripts from main FreeSWITCH thread - THREAD SAFE
	void processInterimTranscripts() {
		if (!m_hasNewInterimTranscript.load() || !m_interim) return;
		
		std::unique_lock<std::mutex> lock(m_mutex, std::defer_lock);
		if (!lock.try_lock()) return; // Mutex busy, skip this iteration
		
		if (!m_hasNewInterimTranscript.load() || m_lastTranscript.empty()) return;
		
		m_hasNewInterimTranscript.store(false);
		std::string currentTranscript = m_lastTranscript;
		lock.unlock();
		
		// Create simplified interim response
		houndify::Json interimResponse = {
			{"Disambiguation", {
				{"ChoiceData", {{
					{"ASRConfidence", 0.8},
					{"ConfidenceScore", 0.7},
					{"FixedTranscription", ""},
					{"FormattedTranscription", currentTranscript},
					{"Transcription", currentTranscript}
				}}},
				{"NumToShow", 1}
			}},
			{"ResultsAreFinal", {false}},
			{"Status", "OK"},
			{"Format", "SoundHoundVoiceSearchResult"},
			{"FormatVersion", "1.0"},
			{"NumToReturn", 1}
		};
		
		// Generate query ID
		auto timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
			std::chrono::system_clock::now().time_since_epoch()).count();
		std::string queryId = "interim-" + std::to_string(timestamp);
		interimResponse["QueryID"] = queryId;
		interimResponse["ServerGeneratedId"] = queryId;
		
		switch_core_session_t* psession = switch_core_session_locate(m_sessionId.c_str());
		if (psession) {
			m_responseHandler(psession, TRANSCRIBE_EVENT_RESULTS, 
				interimResponse.dump().c_str(), m_bugname.c_str(), 0);
			switch_core_session_rwunlock(psession);
		}
	}

private:
	std::mutex m_mutex;
};

extern "C" {
	switch_status_t houndify_transcribe_init() {
		// Cache environment variables once during module initialization
		static_client_id = std::getenv("HOUNDIFY_CLIENT_ID");
		static_client_key = std::getenv("HOUNDIFY_CLIENT_KEY");
		static_user_id = std::getenv("HOUNDIFY_USER_ID");
		
		if (NULL == static_client_id || NULL == static_client_key || NULL == static_user_id) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, 
				"\"HOUNDIFY_CLIENT_ID\", \"HOUNDIFY_CLIENT_KEY\" and \"HOUNDIFY_USER_ID\" env vars not set; authentication will expect channel variables of same names to be set\n");
		}
		return SWITCH_STATUS_SUCCESS;
	}
	
	switch_status_t houndify_transcribe_cleanup() {
		return SWITCH_STATUS_SUCCESS;
	}

	// start transcribe on a channel
	switch_status_t houndify_transcribe_session_init(
		switch_core_session_t *session, 
		responseHandler_t responseHandler, 
		uint32_t samples_per_second, 
		uint32_t channels, 
		char* lang, 
		int interim, 
		char* bugname, 
		void **ppUserData
	) {
		switch_channel_t *channel = switch_core_session_get_channel(session);
		auto uuid = switch_core_session_get_uuid(session);
		switch_status_t status = SWITCH_STATUS_SUCCESS;
		switch_media_bug_t *bug;
		switch_media_bug_flag_t flags = SMBF_READ_STREAM;
		uint32_t to_rate = 16000;
		struct cap_cb *cb;
		int err;
		const char* voice_ms;
		const char* mode;
		const char* silence_ms_str;
		const char* vad_debug;

		// Get Houndify credentials from cached environment variables or channel variables
		const char* clientId = static_client_id;
		const char* clientKey = static_client_key;
		const char* userId = static_user_id;
		if (!clientId) clientId = switch_channel_get_variable(channel, "HOUNDIFY_CLIENT_ID");
		if (!clientKey) clientKey = switch_channel_get_variable(channel, "HOUNDIFY_CLIENT_KEY");
		if (!userId) userId = switch_channel_get_variable(channel, "HOUNDIFY_USER_ID");

		if (!clientId || !clientKey || !userId) {
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
				"HOUNDIFY_CLIENT_ID, HOUNDIFY_CLIENT_KEY, and HOUNDIFY_USER_ID must be set in environment or channel variables.\n");
			return SWITCH_STATUS_FALSE;
		}

		if (samples_per_second != to_rate) {
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"houndify_transcribe_session_init:  audio sample rate %u, resampling to %u\n", samples_per_second, to_rate);
		}

		cb = (struct cap_cb *) switch_core_session_alloc(session, sizeof(*cb));
		strncpy(cb->sessionId, uuid, MAX_SESSION_ID);
		strncpy(cb->bugname, bugname, MAX_BUG_LEN);
		strncpy(cb->lang, lang, MAX_LANG);

		cb->interim = interim;
		cb->channels = channels;
		cb->responseHandler = responseHandler;

		// Setup resampler if needed
		if (samples_per_second != to_rate) {
			cb->resampler = speex_resampler_init(channels, samples_per_second, to_rate, SWITCH_RESAMPLE_QUALITY, &err);
			if (0 != err) {
				switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, 
					"Error initializing resampler: %s.\n", speex_resampler_strerror(err));
				status = SWITCH_STATUS_FALSE;
				goto done;
			}
		} else {
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"houndify_transcribe_session_init:  no resampling needed for this call\n");
		}

		switch_mutex_init(&cb->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
		if (status != SWITCH_STATUS_SUCCESS) goto done;

		switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
			"houndify_transcribe_session_init:  allocating streamer\n");

		try {
			GStreamer* streamer = new GStreamer(uuid, bugname, channels, lang, interim, to_rate, clientId, clientKey, userId, responseHandler);
			cb->streamer = streamer;
		} catch (std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, 
				"Error initializing Houndify streamer: %s.\n", e.what());
			status = SWITCH_STATUS_FALSE;
			goto done;
		}

		// Check for VAD settings
		voice_ms = switch_channel_get_variable(channel, "HOUNDIFY_VAD_VOICE_MS");
		mode = switch_channel_get_variable(channel, "HOUNDIFY_VAD_MODE");
		silence_ms_str = switch_channel_get_variable(channel, "HOUNDIFY_VAD_SILENCE_MS");
		vad_debug = switch_channel_get_variable(channel, "HOUNDIFY_VAD_DEBUG");
		
		if (voice_ms && mode) {
			int ms = atoi(voice_ms);
			int vad_mode = atoi(mode);
			int silence_ms = silence_ms_str ? atoi(silence_ms_str) : 0;
			int debug = vad_debug ? atoi(vad_debug) : 0;
			
			if (ms > 0 && vad_mode > 0) {
				if (silence_ms_str) {
					switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
						"(%s) enable vad mode: %s voice_ms: %s silence_ms: %d\n", 
						switch_channel_get_name(channel), mode, voice_ms, silence_ms);
				} else {
					switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
						"(%s) enable vad mode: %s voice_ms: %s\n", 
						switch_channel_get_name(channel), mode, voice_ms);
				}
				cb->vad = switch_vad_init(to_rate, channels);
				if (cb->vad) {
					switch_vad_set_mode(cb->vad, vad_mode);
					switch_vad_set_param(cb->vad, "voice_ms", ms);
					if (silence_ms_str) {
						switch_vad_set_param(cb->vad, "silence_ms", silence_ms);
					}
					if (debug) {
						switch_vad_set_param(cb->vad, "debug", debug);
					}
				}
			}
		}

		// If no VAD, connect immediately for minimal latency
		if (!cb->vad) {
			GStreamer* streamer = (GStreamer *) cb->streamer;
			streamer->connect();
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"No VAD configured - connected immediately\n");
		}

	done:
		*ppUserData = cb;
		cb->transcription_counter = 0;
		return status;
	}

	switch_status_t houndify_transcribe_session_stop(switch_core_session_t *session, int channelIsClosing, char* bugname) {
		switch_channel_t *channel = switch_core_session_get_channel(session);
		switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

		if (bug) {
			struct cap_cb *cb = (struct cap_cb *) switch_core_media_bug_get_user_data(bug);

			switch_mutex_lock(cb->mutex);
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"houndify_transcribe_session_stop: locked session\n");

			switch_channel_set_private(channel, bugname, NULL);
			if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

			GStreamer* streamer = (GStreamer *) cb->streamer;
			if (streamer) {
				streamer->disconnect();
				delete streamer;
				cb->streamer = NULL;
			}

			if (cb->resampler) {
				speex_resampler_destroy(cb->resampler);
				cb->resampler = NULL;
			}

			if (cb->vad) {
				switch_vad_destroy(&cb->vad);
				cb->vad = NULL;
			}

			switch_mutex_unlock(cb->mutex);
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"houndify_transcribe_session_stop: unlocked session\n");

			return SWITCH_STATUS_SUCCESS;
		}

		switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, 
			"%s Bug is not attached.\n", switch_channel_get_name(channel));
		return SWITCH_STATUS_FALSE;
	}
	
	switch_bool_t houndify_transcribe_frame(switch_media_bug_t *bug, void* user_data) {
		switch_core_session_t *session = switch_core_media_bug_get_session(bug);
		uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
		switch_frame_t frame = {};
		struct cap_cb *cb = (struct cap_cb *) user_data;

		frame.data = data;
		frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;

		if (switch_mutex_trylock(cb->mutex) == SWITCH_STATUS_SUCCESS) {
			GStreamer* streamer = (GStreamer *) cb->streamer;
			if (streamer) {
				// Check if we should stop processing
				if (streamer->isStopped()) {
					switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
						"GStreamer is stopped, ending frame processing\n");
					switch_mutex_unlock(cb->mutex);
					return SWITCH_FALSE; // Tell FreeSWITCH to stop processing frames
				}
				
				while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS && !switch_test_flag((&frame), SFF_CNG)) {
					if (frame.datalen) {
						if (cb->vad && !streamer->isConnected()) {
							switch_vad_state_t state = switch_vad_process(cb->vad, (int16_t*) frame.data, frame.samples);
							if (state == SWITCH_VAD_STATE_START_TALKING) {
								switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, 
									"detected speech, connect to Houndify now\n");
								streamer->connect();
								cb->responseHandler(session, "houndify::vad_detected", NULL, cb->bugname, 0);
							}
						}

						// Process audio - resample if needed, then write or buffer
						spx_int16_t* audioData;
						size_t audioLen;
						spx_int16_t resampledBuffer[SWITCH_RECOMMENDED_BUFFER_SIZE];
						
						// Handle resampling if needed
						if (cb->resampler) {
							spx_uint32_t out_len = SWITCH_RECOMMENDED_BUFFER_SIZE;
							spx_uint32_t in_len = frame.samples;
						
							speex_resampler_process_interleaved_int(
								cb->resampler,
								(const spx_int16_t *) frame.data,
								(spx_uint32_t *) &in_len, 
								&resampledBuffer[0],
								&out_len);
								
							audioData = resampledBuffer;
							audioLen = out_len;
						} else {
							audioData = reinterpret_cast<spx_int16_t*>(frame.data);
							audioLen = frame.datalen / sizeof(int16_t);
						}
						
						// Check for audio activity to avoid sending pure silence
						bool hasAudio = false;
						int16_t threshold = 100; // Minimum audio level threshold
						for (size_t i = 0; i < audioLen; i++) {
							if (abs(audioData[i]) > threshold) {
								hasAudio = true;
								break;
							}
						}
						
						// Check if we've stopped during processing
						if (streamer->isStopped()) {
							switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
								"GStreamer stopped during processing, breaking loop\n");
							break; // Exit the frame processing loop
						}
						
						// Only process audio if there's actual sound or we're already connected
						if (hasAudio || streamer->isConnected()) {
							bool streamEnded = streamer->writeOrBufferAudio(audioData, audioLen);
							if (streamEnded) {
								switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
									"Stream ended or failed\n");
								// Stream ended, we should stop processing
								break;
							}
						} else {
							// Pure silence - just buffer if not connected
							if (!streamer->isConnected()) {
								std::vector<int16_t> audioFrame(audioData, audioData + audioLen);
								streamer->bufferAudio(audioFrame);
							}
						}
						
						// Attempt reconnection if we have audio activity and are not connected (recovery mode)
						if (hasAudio && !streamer->isConnected() && !streamer->isStopped()) {
							static int reconnect_counter = 0;
							if (++reconnect_counter % 50 == 0) { // Try every ~1 second at 20ms frames
								switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, 
									"Attempting to reconnect to Houndify (attempt %d)\n", reconnect_counter / 50);
								if (streamer->connect()) {
									switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, 
										"Successfully reconnected to Houndify\n");
									reconnect_counter = 0; // Reset counter on successful reconnection
								}
							}
						}
						streamer->processInterimTranscripts();
					}
				}
			}
			switch_mutex_unlock(cb->mutex);
		}
		return SWITCH_TRUE;
	}
}
