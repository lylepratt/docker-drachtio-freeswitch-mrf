#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>
#include <memory>

#include "mod_elevenlabs_transcribe.h"
#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/

namespace {
  static bool hasDefaultCredentials = false;
  static const char* defaultApiKey = nullptr;
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static const char *requestedNumServiceThreads = std::getenv("MOD_AUDIO_FORK_SERVICE_THREADS");
  static unsigned int idxCallCount = 0;
  static uint32_t playCount = 0;

  static const char* emptyTranscript = 
    "\"is_final\":false,\"speech_final\":false,\"channel\":{\"alternatives\":[{\"transcript\":\"\",\"confidence\":0.0,\"words\":[]}]}";

  // Forward declaration
  static void parseElevenLabsResponse(switch_core_session_t* session, const char* bugname, 
    const char* message, private_t* tech_pvt);

  static bool eventCallback(const char* sessionId, unsigned int id, const char* bugname, 
    elevenlabs::AudioPipe::NotifyEvent_t event, const char* message, bool finished) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt && tech_pvt->pAudioPipe) {
          auto pAp = reinterpret_cast<std::shared_ptr<elevenlabs::AudioPipe>*>(tech_pvt->pAudioPipe);
          
          switch (event) {
            case elevenlabs::AudioPipe::CONNECT_SUCCESS:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection successful\n");
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_SUCCESS, NULL, bugname, 0);
            break;
            case elevenlabs::AudioPipe::CONNECT_FAIL:
            {
              char json[256];
              const char * reason = (*pAp)->getConnectFailReason();
              snprintf(json, 256, "{\"reason\":\"%s\"}", reason);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection failed: %s\n", reason);
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_FAIL, json, bugname, finished);
            }
            break;
            case elevenlabs::AudioPipe::CONNECTION_DROPPED:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection dropped from far end\n");
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_DISCONNECT, NULL, bugname, finished);
            break;
            case elevenlabs::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection closed gracefully\n");
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_DISCONNECT, NULL, bugname, finished);
            break;
            case elevenlabs::AudioPipe::MESSAGE:
              if (message && strlen(message) > 2) {
                if (strstr(message, emptyTranscript)) {
                  // skip empty transcripts for cleaner logs
                } else {
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got message: %s\n", message);
                  
                  // Parse ElevenLabs response format and emit appropriate events
                  parseElevenLabsResponse(session, bugname, message, tech_pvt);
                }
              }
            break;
          }
        }
      }
      switch_core_session_rwunlock(session);
      return true;
    }
    return false;
  }

  static void parseElevenLabsResponse(switch_core_session_t* session, const char* bugname, 
    const char* message, private_t* tech_pvt) {
    cJSON* json = cJSON_Parse(message);
    if (!json) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Failed to parse JSON response\n");
      return;
    }
    
    cJSON* messageType = cJSON_GetObjectItem(json, "message_type");
    if (messageType && cJSON_IsString(messageType)) {
      const char* type = messageType->valuestring;
      
      if (!strcmp(type, "session_started")) {
        // Session started event
        tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_SUCCESS, message, bugname, 0);
      }
      else if (!strcmp(type, "partial_transcript")) {
        // Partial transcript event (interim results)
        tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_RESULTS, message, bugname, 0);
      }
      else if (!strcmp(type, "committed_transcript")) {
        // Final transcript event
        tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_RESULTS, message, bugname, 0);
      }
      else if (!strcmp(type, "committed_transcript_with_timestamps")) {
        // Final transcript with timestamps
        tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_RESULTS, message, bugname, 0);
      }
      else if (!strcmp(type, "scribe_error")) {
        // Error event
        tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_ERROR, message, bugname, 1);
      }
      else if (!strcmp(type, "scribe_auth_error")) {
        // Authentication error
        tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_ERROR, message, bugname, 1);
      }
      else if (!strcmp(type, "scribe_quota_exceeded_error")) {
        // Quota exceeded error
        tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_ERROR, message, bugname, 1);
      }
    }
    
    cJSON_Delete(json);
  }

  static std::shared_ptr<elevenlabs::AudioPipe> getAP(void *pAudioPipe) {
    if (pAudioPipe) {
      auto pAp = reinterpret_cast<std::shared_ptr<elevenlabs::AudioPipe>*>(pAudioPipe);
      return *pAp;
    }
    return nullptr;
  }

  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      if (tech_pvt->pAudioPipe) {
        // Initiate graceful shutdown if connected
        auto pAp = getAP(tech_pvt->pAudioPipe);
        if (pAp && pAp->getLwsState() == elevenlabs::AudioPipe::LWS_CLIENT_CONNECTED) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) initiating graceful close\n", tech_pvt->sessionId, tech_pvt->id);
          pAp->finish();
        }
        // release our shared_ptr
        delete reinterpret_cast<std::shared_ptr<elevenlabs::AudioPipe>*>(tech_pvt->pAudioPipe);
        tech_pvt->pAudioPipe = nullptr;
      }
      if (tech_pvt->resampler) {
        speex_resampler_destroy(tech_pvt->resampler);
        tech_pvt->resampler = NULL;
      }
    }
  }

  std::string encodeURIComponent(std::string decoded)
  {
    std::ostringstream oss;
    std::regex r("[!'\\(\\)*-.0-9A-Za-z_~:]");

    for (char &c : decoded)
    {
      if (c == ' ')
      {
        oss << "+";  // Use + for spaces
      }
      else if (std::regex_match((std::string){c}, r))
      {
        oss << c;
      }
      else
      {
        oss << "%" << std::uppercase << std::hex << (0xff & c);
      }
    }
    return oss.str();
  }

  std::string& constructPath(switch_core_session_t* session, std::string& path, 
    int sampleRate, int channels, const char* language, int interim) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    const char *var;
    std::ostringstream oss;

    oss << "/v1/speech-to-text/realtime?";

    // Model ID (required for ElevenLabs)
    const char *modelId = switch_channel_get_variable(channel, "ELEVENLABS_MODEL_ID");
    if (!modelId) {
      modelId = "eleven_scribe_v2"; // Default model
    }
    oss << "model_id=" << modelId;

    // Language code (optional)
    if (language && strlen(language) > 0) {
      oss << "&language_code=" << language;
    }

    oss << "&audio_format=pcm_8000";

    // Timestamps
    if (switch_true(switch_channel_get_variable(channel, "ELEVENLABS_INCLUDE_TIMESTAMPS"))) {
      oss << "&include_timestamps=true";
    }

    // Commit strategy (manual or vad)
    const char *commitStrategy = switch_channel_get_variable(channel, "ELEVENLABS_COMMIT_STRATEGY");
    if (!commitStrategy) {
      commitStrategy = "vad";
    }
    oss << "&commit_strategy=" << commitStrategy;

    // VAD parameters (only if using vad commit strategy)
    if (commitStrategy && !strcmp(commitStrategy, "vad")) {
      if (var = switch_channel_get_variable(channel, "ELEVENLABS_VAD_SILENCE_THRESHOLD_SECS")) {
        oss << "&vad_silence_threshold_secs=" << var;
      }
      if (var = switch_channel_get_variable(channel, "ELEVENLABS_VAD_THRESHOLD")) {
        oss << "&vad_threshold=" << var;
      }
      if (var = switch_channel_get_variable(channel, "ELEVENLABS_MIN_SPEECH_DURATION_MS")) {
        oss << "&min_speech_duration_ms=" << var;
      }
      if (var = switch_channel_get_variable(channel, "ELEVENLABS_MIN_SILENCE_DURATION_MS")) {
        oss << "&min_silence_duration_ms=" << var;
      }
    }

    // Logging (enterprise feature for zero retention)
    if (switch_false(switch_channel_get_variable(channel, "ELEVENLABS_ENABLE_LOGGING"))) {
      oss << "&enable_logging=false";
    }

    path = oss.str();
    return path;
  }

  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, 
    int sampling, int desiredSampling, int channels, char *lang, int interim, 
    char* bugname, responseHandler_t responseHandler) {

    int err;
    int useTls = true;
    std::string host;
    int port = 443;
    unsigned int id;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * desiredSampling / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_codec_implementation_t read_impl;
    switch_channel_t *channel = switch_core_session_get_channel(session);

    switch_core_session_get_read_impl(session, &read_impl);
  
    std::string path;
    constructPath(session, path, desiredSampling, channels, lang, interim);
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "path: %s\n", path.c_str());

    // ElevenLabs endpoint
    const char* endpoint = switch_channel_get_variable(channel, "ELEVENLABS_URI");
    if (endpoint != nullptr) {
      std::string ep(endpoint);
      useTls = switch_true(switch_channel_get_variable(channel, "ELEVENLABS_USE_TLS"));

      size_t pos = ep.find(':');
      host = ep;
      if (pos != std::string::npos) {
        host = ep.substr(0, pos);
        std::string strPort = ep.substr(pos + 1);
        port = ::atoi(strPort.c_str());
      }
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, 
        "connecting to ElevenLabs custom endpoint %s port %d, using tls? (%s)\n", host.c_str(), port, useTls ? "yes" : "no");
    } else {
      host = "api.elevenlabs.io";
    }

    const char* apiKey = switch_channel_get_variable(channel, "ELEVENLABS_API_KEY");
    if (!apiKey && defaultApiKey) {
      apiKey = defaultApiKey;
    } else if (!apiKey) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no ElevenLabs api key provided\n");
      return SWITCH_STATUS_FALSE;
    }

    // Note: ElevenLabs doesn't support connection reuse, so always create new connection
    if (tech_pvt->pAudioPipe) {
      // Clean up any existing connection
      if (tech_pvt->mutex) {
        switch_mutex_lock(tech_pvt->mutex);
      }
      
      auto pAp = reinterpret_cast<std::shared_ptr<elevenlabs::AudioPipe>*>(tech_pvt->pAudioPipe);
      std::shared_ptr<elevenlabs::AudioPipe> pAudioPipe = *pAp;
      
      // Clean up the old connection
      if (pAudioPipe->getLwsState() == elevenlabs::AudioPipe::LWS_CLIENT_CONNECTED) {
        pAudioPipe->finish();
      }
      
      // Delete the old shared_ptr
      delete reinterpret_cast<std::shared_ptr<elevenlabs::AudioPipe>*>(tech_pvt->pAudioPipe);
      tech_pvt->pAudioPipe = nullptr;
      
      if (tech_pvt->mutex) {
        switch_mutex_unlock(tech_pvt->mutex);
      }
      
      destroy_tech_pvt(tech_pvt);
    }

    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->host, host.c_str(), MAX_WS_URL_LEN);
    tech_pvt->port = port;
    strncpy(tech_pvt->path, path.c_str(), MAX_PATH_LEN);   
    tech_pvt->sampling = desiredSampling;
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->channels = channels;
    tech_pvt->id = id = ++idxCallCount;
    tech_pvt->buffer_overrun_notified = 0;
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    if (!tech_pvt->mutex) {
      switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
    }
    if (!tech_pvt->resampler) {
      if (desiredSampling != sampling) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) resampling from %u to %u\n", id, sampling, desiredSampling);
        tech_pvt->resampler = speex_resampler_init(channels, sampling, desiredSampling, SWITCH_RESAMPLE_QUALITY, &err);
        if (0 != err) {
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing resampler: %s.\n", speex_resampler_strerror(err));
          return SWITCH_STATUS_FALSE;
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) no resampling needed for this call\n", tech_pvt->id);
      }
    }
    tech_pvt->initialized = 1;

    // Create AudioPipe with shared_ptr for proper lifecycle management
    auto apShared = std::make_shared<elevenlabs::AudioPipe>(tech_pvt->sessionId, bugname, tech_pvt->host, tech_pvt->port, tech_pvt->path, 
      buflen, read_impl.decoded_bytes_per_packet, apiKey, useTls, eventCallback, tech_pvt->id);
    if (!apShared) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }

    // Store the shared_ptr itself (not the raw pointer)
    tech_pvt->pAudioPipe = new std::shared_ptr<elevenlabs::AudioPipe>(apShared);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "(%u) connecting to ElevenLabs now\n", apShared->getId());
    apShared->connect();
    
    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}

extern "C" {
  switch_status_t el_transcribe_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_elevenlabs_transcribe: audio buffer (in secs):    %d secs\n", nAudioBufferSecs);
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    elevenlabs::AudioPipe::initialize(logs, lws_logger);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

    const char* apiKey = std::getenv("ELEVENLABS_API_KEY");
    if (NULL == apiKey) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, 
        "\"ELEVENLABS_API_KEY\" env var not set; authentication will expect channel variables of same names to be set\n");
    }
    else {
      hasDefaultCredentials = true;
      defaultApiKey = apiKey;
    }
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t el_transcribe_cleanup() {
    bool cleanup = false;
    cleanup = elevenlabs::AudioPipe::deinitialize();
    if (cleanup == true) {
      return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }
  
  switch_status_t el_transcribe_session_init(switch_core_session_t *session, 
    responseHandler_t responseHandler, uint32_t samples_per_second, uint32_t channels, 
    char* lang, int interim, char* bugname, void **ppUserData)
  {
    // Note: No connection reuse for ElevenLabs - always create new tech_pvt
    private_t* tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    tech_pvt->initialized = 0;
    tech_pvt->pAudioPipe = NULL;
    tech_pvt->mutex = NULL;
    tech_pvt->resampler = NULL;
    
    uint32_t desiredSampling = 8000;

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second, desiredSampling, channels, lang, interim, bugname, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t el_transcribe_session_stop(switch_core_session_t *session, int channelIsClosing, char* bugname)
  {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "el_transcribe_session_stop: no bug\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    if (!tech_pvt) return SWITCH_STATUS_FALSE;
    
    uint32_t id = tech_pvt->id;
    
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "(%u) el_transcribe_session_stop\n", id);
    
    if (!channelIsClosing) {
      switch_channel_set_private(channel, bugname, NULL);
      switch_core_media_bug_remove(session, &bug);
    }
    
    destroy_tech_pvt(tech_pvt);
    
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "(%u) el_transcribe_session_stop: done\n", id);
    return SWITCH_STATUS_SUCCESS;
  }
  
  switch_bool_t el_transcribe_frame(switch_core_session_t *session, switch_media_bug_t *bug, private_t* tech_pvt)
  {
    switch_frame_t frame = { 0 };
    uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
    
    // Skip if not initialized
    if (!tech_pvt || !tech_pvt->initialized) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "el_transcribe_frame: not initialized\n");
      return SWITCH_TRUE;
    }
    
    auto pAp = getAP(tech_pvt->pAudioPipe);
    if (!pAp) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "el_transcribe_frame: no AudioPipe\n");
      return SWITCH_TRUE;
    }
    
    pAp->lockAudioBuffer();
    size_t available = pAp->binarySpaceAvailable();
    if (NULL == tech_pvt->resampler) {
      frame.data = pAp->binaryWritePtr();
      frame.buflen = available;
    }
    else {
      frame.data = data;
      frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;
    }
    
    // Read audio from the bug
    while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
      if (frame.datalen) {
        tech_pvt->frame_count++;
        
        if (NULL != tech_pvt->resampler) {
          spx_uint32_t in_len = frame.samples;
          spx_uint32_t out_len = available >> 1;  // space for samples which are 2 bytes
          
          speex_resampler_process_interleaved_int(tech_pvt->resampler, 
            (const spx_int16_t *) frame.data, 
            (spx_uint32_t *) &in_len, 
            (spx_int16_t *) pAp->binaryWritePtr(),
            &out_len);
          
          if (out_len > 0) {
            // bytes written = num samples * 2 * num channels (but for mono, channels = 1)
            size_t bytes_written = out_len << (tech_pvt->channels == 2 ? 2 : 1);
            pAp->binaryWritePtrAdd(bytes_written);
            available = pAp->binarySpaceAvailable();
          }
          
          if (available < pAp->binaryMinSpace()) {
            if (!tech_pvt->buffer_overrun_notified) {
              tech_pvt->buffer_overrun_notified = 1;
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
            }
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, 
              "(%u) dropping packets due to buffer overrun!\n", tech_pvt->id);
            break;
          }
        }
        else {
          pAp->binaryWritePtrAdd(frame.datalen);
          available = pAp->binarySpaceAvailable();

          if (available < pAp->binaryMinSpace()) {
            if (!tech_pvt->buffer_overrun_notified) {
              tech_pvt->buffer_overrun_notified = 1;
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
            }
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, 
              "(%u) dropping packets due to buffer overrun!\n", tech_pvt->id);
            break;
          }
        }
      }
    }
    pAp->unlockAudioBuffer();
    return SWITCH_TRUE;
  }
}