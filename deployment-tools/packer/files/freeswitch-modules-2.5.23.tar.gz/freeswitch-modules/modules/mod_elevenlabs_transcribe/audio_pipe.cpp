#include "audio_pipe.hpp"
#include <switch.h>

#include <cassert>
#include <iostream>
#include <sstream>
#include <cstring>
#include <cstdlib>

/* discard incoming text messages over the socket that are longer than this */
#define MAX_RECV_BUF_SIZE (65 * 1024 * 10)
#define RECV_BUF_REALLOC_SIZE (8 * 1024)

using namespace elevenlabs;

struct ev_loop *AudioPipe::m_loop = nullptr;
struct ev_async *AudioPipe::m_stop_watcher = nullptr;

namespace {
  static const char *requestedTcpKeepaliveSecs = std::getenv("MOD_AUDIO_FORK_TCP_KEEPALIVE_SECS");
  static int nTcpKeepaliveSecs = requestedTcpKeepaliveSecs ? ::atoi(requestedTcpKeepaliveSecs) : 55;
}

int AudioPipe::lws_callback(struct lws *wsi, 
  enum lws_callback_reasons reason,
  void *user, void *in, size_t len) {

  struct AudioPipe::lws_per_vhost_data *vhd = 
    (struct AudioPipe::lws_per_vhost_data *) lws_protocol_vh_priv_get(lws_get_vhost(wsi), lws_get_protocol(wsi));

  struct lws_vhost* vhost = lws_get_vhost(wsi);
  std::shared_ptr<AudioPipe> ** ppAp = (std::shared_ptr<AudioPipe> **) user;

  switch (reason) {
    case LWS_CALLBACK_PROTOCOL_INIT:
      vhd = (struct AudioPipe::lws_per_vhost_data *) lws_protocol_vh_priv_zalloc(lws_get_vhost(wsi), lws_get_protocol(wsi), sizeof(struct AudioPipe::lws_per_vhost_data));
      vhd->context = lws_get_context(wsi);
      vhd->protocol = lws_get_protocol(wsi);
      vhd->vhost = lws_get_vhost(wsi);
      break;

    case LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER:
      {
        auto ap = findPendingConnect(wsi);
        if (ap) {
          std::string apiKey = ap->getApiKey();
          if (apiKey.length() > 0) {
            unsigned char **p = (unsigned char **)in, *end = (*p) + len;
            // ElevenLabs uses xi-api-key header (no colon in name for lws_add_http_header_by_name)
            if (lws_add_http_header_by_name(wsi, (const unsigned char *)"xi-api-key",
                                            (const unsigned char *)apiKey.c_str(),
                                            apiKey.length(), p, end)) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                                "LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER: failed to add xi-api-key header\n");
              return -1;
            }
          }
        }
      }
      break;

    case LWS_CALLBACK_EVENT_WAIT_CANCELLED:
      processPendingConnects(vhd);
      processPendingDisconnects(vhd);
      processPendingWrites();
      break;
      
    case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
      {
        auto ap = findAndRemovePendingConnect(wsi);
        int rc = lws_http_client_http_response(wsi);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CONNECTION_ERROR: %s, response status %d\n", in ? (char *)in : "(null)", rc); 
        if (ap) {
          ap->m_state = LWS_CLIENT_FAILED;
          ap->m_connect_fail_reason = in ? (char *)in : "unknown error";
          // Session validity doesn't matter for connection failure - just notify
          ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(), elevenlabs::AudioPipe::CONNECT_FAIL, (char *) in, ap->isFinished());
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CONNECTION_ERROR unable to find wsi %p..\n", wsi); 
        }
      }      
      break;

    case LWS_CALLBACK_CLIENT_ESTABLISHED:
      {
        std::shared_ptr<AudioPipe> ap = findAndRemovePendingConnect(wsi);
        if (ap) {
          // allocate a new shared_ptr to the AudioPipe, we will delete it when connection closes
          std::shared_ptr<AudioPipe>* p = new std::shared_ptr<AudioPipe>(ap);
          *ppAp = p;
          ap->m_vhd = vhd;
          ap->m_state = LWS_CLIENT_CONNECTED;
          
          // Check if session is still valid after successful connection
          bool sessionValid = ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(), elevenlabs::AudioPipe::CONNECT_SUCCESS, NULL, ap->isFinished());
          if (!sessionValid) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s: (%u) session gone during connect - closing connection\n", ap->m_uuid.c_str(), ap->m_id);
            ap->m_state = LWS_CLIENT_DISCONNECTING;

            // we will not get a LWS_CALLBACK_CLIENT_CLOSED in this case
            delete *ppAp;
            *ppAp = nullptr;

            return -1; // Close WebSocket
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_ESTABLISHED unable to find wsi %p..\n", wsi); 
        }
      }      
      break;
      
    case LWS_CALLBACK_WS_PEER_INITIATED_CLOSE:
      {
        if (ppAp && *ppAp) {
          std::shared_ptr<AudioPipe> ap = **ppAp;
          if (!ap) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_WS_PEER_INITIATED_CLOSE unable to find AudioPipe for wsi %p\n", wsi);
            return 0;
          }
          // Extract close code and reason
          uint16_t close_code = (in && len >= 2) ? (((unsigned char *)in)[0] << 8) | ((unsigned char *)in)[1] : 0;
          std::string close_reason;
          if (in && len > 2) {
            close_reason = std::string((char *)in + 2, len - 2);
          }
          if (close_code != 1000) {
            ap->setCloseReason(close_code, close_reason.c_str());
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s (%u) WebSocket closed with code: %d, reason: %s\n",
              ap->m_uuid.c_str(), ap->m_id, close_code, close_reason.c_str());
          }
        }
      }
      break;
      
    case LWS_CALLBACK_CLIENT_CLOSED:
      {
        if (!ppAp || !*ppAp) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CLOSED ppAp already null for wsi %p\n", wsi);
          return 0;
        }

        std::shared_ptr<AudioPipe> ap = **ppAp;
        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CLOSED unable to find AudioPipe for wsi %p\n", wsi);
          delete *ppAp;
          return 0;
        }
        if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
          // closed by us
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) socket closed by us\n", ap->m_uuid.c_str(), ap->m_id);
          ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(), elevenlabs::AudioPipe::CONNECTION_CLOSED_GRACEFULLY, NULL, ap->isFinished());
        }
        else if (ap->m_state == LWS_CLIENT_CONNECTED) {
          // closed by far end          
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s (%u) socket closed by far end\n", ap->m_uuid.c_str(), ap->m_id);
          uint16_t close_code = ap->getCloseCode();
          std::string close_reason = ap->getCloseReason();
          if (close_code != 1000 && close_code != 0) {
            std::stringstream json;
            json << "{\"code\": \"" << close_code << "\", \"reason\":\"" << close_reason << "\"}";
            ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(), elevenlabs::AudioPipe::CONNECTION_DROPPED, json.str().c_str(), ap->isFinished());
          }
          else {
            ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(), elevenlabs::AudioPipe::CONNECTION_DROPPED, NULL, ap->isFinished());
          }
        }
        ap->m_state = LWS_CLIENT_DISCONNECTED;

        // delete the shared_ptr we allocated in LWS_CALLBACK_CLIENT_ESTABLISHED
        delete *ppAp;
        *ppAp = nullptr;
      }
      break;

    case LWS_CALLBACK_CLIENT_RECEIVE:
      {
        if (!ppAp || !*ppAp) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE ppAp null for wsi %p\n", wsi);
          return 0;
        }
        std::shared_ptr<AudioPipe> ap = **ppAp;

        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE unable to find AudioPipe for wsi %p\n", wsi);
          return 0;
        }

        if (lws_frame_is_binary(wsi)) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE received binary frame, discarding.\n");
          return 0;
        }

        int first = lws_is_first_fragment(wsi);
        int final = lws_is_final_fragment(wsi);

        if (first && final) {
          // single frame message - most common case for ElevenLabs responses
          ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(), elevenlabs::AudioPipe::MESSAGE, (const char*) in, ap->isFinished());
        }
        else if (first && !final) {
          // start of multi-frame message
          if (ap->m_recv_buf) {
            delete [] ap->m_recv_buf;
            ap->m_recv_buf = nullptr;
          }
          ap->m_recv_buf_len = len;
          ap->m_recv_buf = new uint8_t[RECV_BUF_REALLOC_SIZE];
          memcpy(ap->m_recv_buf, in, len);
          ap->m_recv_buf_ptr = ap->m_recv_buf + len;
        }
        else if (!first && !final) {
          // continuation of multi-frame message
          if (!ap->m_recv_buf) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe: received continuation frame without initial frame\n");
            return -1;
          }
          size_t current_len = ap->m_recv_buf_ptr - ap->m_recv_buf;
          size_t new_len = current_len + len;
          if (new_len > MAX_RECV_BUF_SIZE) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe: message too large, discarding\n");
            delete [] ap->m_recv_buf;
            ap->m_recv_buf = nullptr;
            return 0;
          }
          if (new_len > ap->m_recv_buf_len) {
            ap->m_recv_buf_len = ((new_len / RECV_BUF_REALLOC_SIZE) + 1) * RECV_BUF_REALLOC_SIZE;
            uint8_t* new_buf = new uint8_t[ap->m_recv_buf_len];
            memcpy(new_buf, ap->m_recv_buf, current_len);
            delete [] ap->m_recv_buf;
            ap->m_recv_buf = new_buf;
            ap->m_recv_buf_ptr = ap->m_recv_buf + current_len;
          }
          memcpy(ap->m_recv_buf_ptr, in, len);
          ap->m_recv_buf_ptr += len;
        }
        else if (!first && final) {
          // end of multi-frame message
          if (!ap->m_recv_buf) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe: received final frame without initial frame\n");
            return -1;
          }
          size_t current_len = ap->m_recv_buf_ptr - ap->m_recv_buf;
          size_t new_len = current_len + len;
          if (new_len > MAX_RECV_BUF_SIZE) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe: message too large, discarding\n");
            delete [] ap->m_recv_buf;
            ap->m_recv_buf = nullptr;
            return 0;
          }
          if (new_len > ap->m_recv_buf_len) {
            ap->m_recv_buf_len = new_len;
            uint8_t* new_buf = new uint8_t[ap->m_recv_buf_len + 1];
            memcpy(new_buf, ap->m_recv_buf, current_len);
            delete [] ap->m_recv_buf;
            ap->m_recv_buf = new_buf;
            ap->m_recv_buf_ptr = ap->m_recv_buf + current_len;
          }
          memcpy(ap->m_recv_buf_ptr, in, len);
          ap->m_recv_buf_ptr[len] = '\0';
          
          ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(), elevenlabs::AudioPipe::MESSAGE, (const char*) ap->m_recv_buf, ap->isFinished());
          
          delete [] ap->m_recv_buf;
          ap->m_recv_buf = nullptr;
        }
      }
      break;

    case LWS_CALLBACK_CLIENT_WRITEABLE:
      {
        if (!ppAp || !*ppAp) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE ppAp null for wsi %p\n", wsi);
          return 0;
        }
        std::shared_ptr<AudioPipe> ap = **ppAp;

        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE unable to find AudioPipe for wsi %p\n", wsi);
          return 0;
        }

        if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) sending close\n", ap->m_uuid.c_str(), ap->m_id);
          lws_close_reason(wsi, LWS_CLOSE_STATUS_NORMAL, NULL, 0);
          return -1;
        }

        // Check if we have pending text to send (for control messages)
        if (!ap->m_metadata.empty()) {
          std::lock_guard<std::mutex> guard(ap->m_text_mutex);
          if (!ap->m_metadata.empty()) {
            uint8_t buf[LWS_PRE + ap->m_metadata.size()];
            memcpy(buf + LWS_PRE, ap->m_metadata.c_str(), ap->m_metadata.size());
            int sent = lws_write(wsi, buf + LWS_PRE, ap->m_metadata.size(), LWS_WRITE_TEXT);
            if (sent < ap->m_metadata.size()) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE unable to send text %s (%u)..\n",
                ap->m_uuid.c_str(), ap->m_id);
            }
            ap->m_metadata.clear();
          }
        }

        // Check if we have pending audio to send
        {
          std::lock_guard<std::mutex> guard(ap->m_audio_mutex);
          if (ap->m_audio_buffer_write_offset > LWS_PRE) {
            // For ElevenLabs, we need to send audio as base64-encoded JSON messages
            size_t datalen = ap->m_audio_buffer_write_offset - LWS_PRE;
            
            // Base64 encode the audio data
            size_t base64_len = (datalen * 4 / 3) + 4; // Extra space for padding
            char* base64_buf = new char[base64_len];
            switch_b64_encode((unsigned char*)ap->m_audio_buffer + LWS_PRE, datalen, (unsigned char*)base64_buf, base64_len);
            
            // Create JSON message for ElevenLabs
            std::stringstream json;
            json << "{\"message_type\":\"input_audio_chunk\",\"audio_base_64\":\"" << base64_buf << "\"";
            
            // Check if this is the last chunk and we're finishing
            if (ap->m_finished) {
              json << ",\"commit\":true";
            }
            json << "}";
            
            delete[] base64_buf;
            
            // Send as text frame
            std::string json_str = json.str();
            uint8_t* send_buf = new uint8_t[LWS_PRE + json_str.size()];
            memcpy(send_buf + LWS_PRE, json_str.c_str(), json_str.size());
            
            int sent = lws_write(wsi, send_buf + LWS_PRE, json_str.size(), LWS_WRITE_TEXT);
            delete[] send_buf;
            
            if (sent < json_str.size()) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE unable to send audio data %s (%u) attempted to send %lu only sent %d wsi %p..\n",
                ap->m_uuid.c_str(), ap->m_id, json_str.size(), sent, wsi);
            }
            ap->m_audio_buffer_write_offset = LWS_PRE;
          }
        }

        return 0;
      }
      break;

    default:
      break;
  }
  return lws_callback_http_dummy(wsi, reason, user, in, len);
}

// static members
static const lws_retry_bo_t retry = {
    nullptr,   // retry_ms_table
    0,         // retry_ms_table_count
    0,         // conceal_count
    UINT16_MAX,         // secs_since_valid_ping
    UINT16_MAX,        // secs_since_valid_hangup
    0          // jitter_percent
};

struct lws_context *AudioPipe::context = nullptr;
std::thread AudioPipe::serviceThread;
std::mutex AudioPipe::mutex_connects;
std::mutex AudioPipe::mutex_disconnects;
std::mutex AudioPipe::mutex_writes;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingConnects;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingDisconnects;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingWrites;
AudioPipe::log_emit_function AudioPipe::logger;
std::mutex AudioPipe::mapMutex;
bool AudioPipe::stopFlag;

void AudioPipe::processPendingConnects(lws_per_vhost_data *vhd) {
  std::list<std::shared_ptr<AudioPipe>> connects;
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    for (auto it = pendingConnects.begin(); it != pendingConnects.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_IDLE) {
        connects.push_back(*it);
        (*it)->m_state = LWS_CLIENT_CONNECTING;
      }
    }
  }
  for (auto& ap : connects) {
    ap->connect_client(vhd);   
  }
}

void AudioPipe::processPendingDisconnects(lws_per_vhost_data *vhd) {
  std::list<std::shared_ptr<AudioPipe>> disconnects;
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    for (auto it = pendingDisconnects.begin(); it != pendingDisconnects.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_DISCONNECTING) disconnects.push_back(*it);
    }
    pendingDisconnects.clear();
  }
  for (auto& ap : disconnects) {
    lws_callback_on_writable(ap->m_wsi); 
  }
}

void AudioPipe::processPendingWrites() {
  std::list<std::shared_ptr<AudioPipe>> writes;
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    for (auto it = pendingWrites.begin(); it != pendingWrites.end(); ++it) {
       if ((*it)->m_state == LWS_CLIENT_CONNECTED) writes.push_back(*it);
    }  
    pendingWrites.clear();
  }
  for (auto& ap : writes) {
    lws_callback_on_writable(ap->m_wsi);
  }
}

void AudioPipe::removeFromAllPendingLists(AudioPipe* ap) {
  // Remove from pendingConnects
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    pendingConnects.remove_if([ap](const std::shared_ptr<AudioPipe>& ptr) {
      return ptr.get() == ap;
    });
  }
  
  // Remove from pendingDisconnects
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    pendingDisconnects.remove_if([ap](const std::shared_ptr<AudioPipe>& ptr) {
      return ptr.get() == ap;
    });
  }
  
  // Remove from pendingWrites
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    pendingWrites.remove_if([ap](const std::shared_ptr<AudioPipe>& ptr) {
      return ptr.get() == ap;
    });
  }
}

std::shared_ptr<AudioPipe> AudioPipe::findAndRemovePendingConnect(struct lws *wsi) {
  std::shared_ptr<AudioPipe> ap = nullptr;
  std::lock_guard<std::mutex> guard(mutex_connects);
  std::list<std::shared_ptr<AudioPipe>> toRemove;

  for (auto it = pendingConnects.begin(); it != pendingConnects.end() && !ap; ++it) {
    int state = (*it)->m_state;

    if ((*it)->m_wsi == nullptr)
      toRemove.push_back(*it);

    if ((state == LWS_CLIENT_CONNECTING) &&
      (*it)->m_wsi == wsi) {
      ap = *it; // Keep the shared_ptr
      pendingConnects.erase(it); // Remove from list
      break;
    }
  }

  for (auto& sharedPtr : toRemove)
    pendingConnects.remove(sharedPtr);

  return ap;
}

std::shared_ptr<AudioPipe> AudioPipe::findPendingConnect(struct lws *wsi) {
  std::shared_ptr<AudioPipe> ap = nullptr;
  std::lock_guard<std::mutex> guard(mutex_connects);

  for (auto it = pendingConnects.begin(); it != pendingConnects.end() && !ap; ++it) {
    int state = (*it)->m_state;
    if ((state == LWS_CLIENT_CONNECTING) &&
      (*it)->m_wsi == wsi) ap = *it; // Return the shared_ptr
  }
  return ap;
}

void AudioPipe::addPendingConnect(std::shared_ptr<AudioPipe> ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    pendingConnects.push_back(ap);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) after adding connect there are %lu pending connects\n", 
      ap->m_uuid.c_str(), ap->m_id, pendingConnects.size());
  }
  lws_cancel_service(context);
}

void AudioPipe::addPendingDisconnect(std::shared_ptr<AudioPipe> ap) {
  ap->m_state = LWS_CLIENT_DISCONNECTING;
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    pendingDisconnects.push_back(ap);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) after adding disconnect there are %lu pending disconnects\n",
      ap->m_uuid.c_str(), ap->m_id, pendingDisconnects.size());
  }
  lws_cancel_service(ap->m_vhd->context);
}

void AudioPipe::addPendingWrite(std::shared_ptr<AudioPipe> ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    pendingWrites.push_back(ap);
  }
  lws_cancel_service(ap->m_vhd->context);
}

bool AudioPipe::lws_service_thread() {
  struct lws_context_creation_info info;
  struct ev_loop *loop;
  struct ev_async stop_watcher;
  std::thread::id this_id = std::this_thread::get_id();
  
  const struct lws_protocols protocols[] = {
    {
      "",
      AudioPipe::lws_callback,
      sizeof(std::shared_ptr<AudioPipe>*),
      8192,
    },
    { NULL, NULL, 0, 0 }
  };

  // CREATE YOUR OWN LIBEV LOOP WITHOUT SIGNAL HANDLING
  loop = ev_loop_new(EVFLAG_NOSIGMASK);
  if (!loop) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                     "AudioPipe::lws_service_thread failed to create ev loop\n");
    return false;
  }

  // Store the loop for cleanup
  m_loop = loop;
  m_stop_watcher = &stop_watcher;

  memset(&info, 0, sizeof info);
  info.port = CONTEXT_PORT_NO_LISTEN;
  info.options = LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT;
  info.options |= LWS_SERVER_OPTION_LIBEV;
  info.foreign_loops = (void**)&loop;
  info.ka_time = nTcpKeepaliveSecs;
  info.ka_interval = nTcpKeepaliveSecs;
  info.ka_probes = 3;
  info.protocols = protocols;
  info.gid = -1;
  info.uid = -1;

  AudioPipe::context = lws_create_context(&info);
  
  if (!AudioPipe::context) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread failed to create context\n");
    ev_loop_destroy(loop);
    return false;
  }
  
  // run the event loop
  while (!stopFlag) {
    ev_run(loop, 0);
  }

  lws_context_destroy(AudioPipe::context);
  AudioPipe::context = nullptr;
  
  ev_loop_destroy(loop);
  m_loop = nullptr;
  
  return true;
}

// AudioPipe implementation
AudioPipe::AudioPipe(const char* uuid, const char* bugname, const char* host, unsigned int port, const char* path,
  size_t bufLen, size_t minFreespace, const char* apiKey, int useTls, 
  notifyHandler_t callback, unsigned int id) :
  m_state(LWS_CLIENT_IDLE), m_wsi(nullptr), m_vhd(nullptr), 
  m_audio_buffer(nullptr), m_recv_buf(nullptr),
  m_audio_buffer_max_len(bufLen), m_audio_buffer_write_offset(LWS_PRE), 
  m_audio_buffer_min_freespace(minFreespace),
  m_graceful_close(false), m_close_code(0),
  m_uuid(uuid), m_host(host), m_port(port), m_path(path),
  m_sslFlags(useTls ? LCCSCF_USE_SSL : 0),
  m_callback(callback), m_bugname(bugname), m_id(id), m_finished(false),
  m_connect_fail_reason("unknown") {
  
  m_audio_buffer = new uint8_t[m_audio_buffer_max_len];
  m_apiKey = apiKey;
}

AudioPipe::~AudioPipe() {
  removeFromAllPendingLists(this);
  if (m_audio_buffer) delete [] m_audio_buffer;
  if (m_recv_buf) delete [] m_recv_buf;
  m_audio_buffer = nullptr;
  m_recv_buf = nullptr;
}

void AudioPipe::initialize(int loglevel, log_emit_function logger) {
  stopFlag = false;
  lws_set_log_level(loglevel, logger);
  AudioPipe::logger = logger;
  
  serviceThread = std::thread(&AudioPipe::lws_service_thread);
}

bool AudioPipe::deinitialize() {
  stopFlag = true;
  
  if (m_stop_watcher && m_loop) {
    ev_async_send(m_loop, m_stop_watcher);
  }
  
  if (serviceThread.joinable()) {
    serviceThread.join();
  }
  
  return true;
}

bool AudioPipe::connect_client(lws_per_vhost_data *vhd) {
  struct lws_client_connect_info i;

  memset(&i, 0, sizeof(i));
  i.context = vhd->context;
  i.port = m_port;
  i.address = m_host.c_str();
  i.path = m_path.c_str();
  i.host = i.address;
  i.origin = "freeswitch";
  i.ssl_connection = m_sslFlags;
  i.protocol = "";
  i.local_protocol_name = "";
  i.pwsi = &m_wsi;

  m_state = LWS_CLIENT_CONNECTING;
  m_vhd = vhd;  // Set m_vhd before attempting connection, same as deepgram

  m_wsi = lws_client_connect_via_info(&i);
  
  if (!m_wsi) {
    m_state = LWS_CLIENT_FAILED;
    m_callback(m_uuid.c_str(), m_id, m_bugname.c_str(), CONNECT_FAIL, "failed to connect", isFinished());
    return false;
  }
  
  return true;
}

void AudioPipe::connect() {
  if (m_state != LWS_CLIENT_IDLE) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s (%u) AudioPipe::connect called but state is %d\n", 
      m_uuid.c_str(), m_id, m_state);
    return;
  }
  addPendingConnect(shared_from_this());
}

void AudioPipe::bufferForSending(const char* text) {
  if (m_state != LWS_CLIENT_CONNECTED) return;
  
  {
    std::lock_guard<std::mutex> guard(m_text_mutex);
    m_metadata.append(text);
  }
  addPendingWrite(shared_from_this());
}

void AudioPipe::unlockAudioBuffer() {
  size_t datalen = m_audio_buffer_write_offset - LWS_PRE;
  m_audio_mutex.unlock();
  if (datalen > 0) {
    addPendingWrite(shared_from_this());
  }
}

void AudioPipe::close() {
  if (m_state == LWS_CLIENT_CONNECTED) {
    addPendingDisconnect(shared_from_this());
  }
}

void AudioPipe::finish() {
  if (m_state == LWS_CLIENT_CONNECTED && !m_finished) {
    m_finished = true;
    m_graceful_close = true;
    
    // Send commit message for ElevenLabs
    std::string commit_msg = "{\"message_type\":\"input_audio_chunk\",\"audio_base_64\":\"\",\"commit\":true}";
    bufferForSending(commit_msg.c_str());
    
    // Then close after a short delay
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    close();
  }
}

void AudioPipe::finish_in_silence() {
  // Same as finish for ElevenLabs (no silence detection)
  finish();
}