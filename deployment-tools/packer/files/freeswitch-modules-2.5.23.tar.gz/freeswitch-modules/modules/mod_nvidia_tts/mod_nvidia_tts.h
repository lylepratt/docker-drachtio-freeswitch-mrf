#ifndef __MOD_NVIDIA_TTS_H__
#define __MOD_NVIDIA_TTS_H__

#include <switch.h>

typedef struct nvidia_data {
  char *voice_name;
  char *language;
  char *riva_server_uri;

  /* result data */
  long response_code;
  char *session_id;
  char *cache_filename;
  char *err_msg;

  int rate;
  int draining;
  int reads;
  int cache_audio;
  int flushed;
  int playback_start_sent;

  void *startTime;

  FILE *file;
  void *circularBuffer;
  switch_mutex_t *mutex;
  void *audioPlayer;
  void *playoutBuffer;
  int has_last_byte;
  uint8_t last_byte;
} nvidia_t;

#endif