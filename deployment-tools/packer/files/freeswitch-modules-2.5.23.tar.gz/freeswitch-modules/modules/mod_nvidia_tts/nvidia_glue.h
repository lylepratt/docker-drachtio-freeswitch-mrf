#ifndef __VNIDIA_TTS_GLUE_H__
#define __VNIDIA_TTS_GLUE_H__

switch_status_t nvidia_speech_load();
switch_status_t nvidia_speech_open(nvidia_t* nvidia);
switch_status_t nvidia_speech_feed_tts(nvidia_t* nvidia, char* text, switch_speech_flag_t *flags);
switch_status_t nvidia_speech_read_tts(nvidia_t* nvidia, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t nvidia_speech_flush_tts(nvidia_t* nvidia);
switch_status_t nvidia_speech_close(nvidia_t* nvidia);
switch_status_t nvidia_speech_unload();

#endif