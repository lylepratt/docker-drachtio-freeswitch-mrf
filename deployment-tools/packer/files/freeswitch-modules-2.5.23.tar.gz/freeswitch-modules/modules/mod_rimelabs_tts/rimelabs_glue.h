#ifndef __RIMELABS_GLUE_H__
#define __RIMELABS_GLUE_H__

#include "rimelabs_wrapper.h"

#ifdef __cplusplus
extern "C" {
#endif

switch_status_t rimelabs_speech_load();
switch_status_t rimelabs_speech_open(rimelabs_handle_t handle);
switch_status_t rimelabs_speech_feed_tts(rimelabs_handle_t handle, char* text, switch_speech_flag_t *flags);
switch_status_t rimelabs_speech_read_tts(rimelabs_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t rimelabs_speech_flush_tts(rimelabs_handle_t handle);
switch_status_t rimelabs_speech_close(rimelabs_handle_t handle);
switch_status_t rimelabs_speech_unload();

#ifdef __cplusplus
}
#endif

#endif