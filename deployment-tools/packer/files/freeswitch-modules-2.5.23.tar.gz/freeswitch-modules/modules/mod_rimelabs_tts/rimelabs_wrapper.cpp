#include "rimelabs_wrapper.h"
#include "rimelabs.hpp"
#include <map>
#include <mutex>
#include <atomic>

struct rimelabs_handle {
    std::shared_ptr<RimeLabs> ptr;
    std::atomic<int> ref_count;
    
    rimelabs_handle(std::shared_ptr<RimeLabs> p) : ptr(p), ref_count(1) {}
};

static std::mutex g_handle_mutex;
static std::map<rimelabs_handle_t, std::shared_ptr<rimelabs_handle>> g_handle_map;

extern "C" {

rimelabs_handle_t rimelabs_create(void) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "rimelabs_create\n");
    
    auto rimelabs_obj = RimeLabs::create();
    if (!rimelabs_obj) return nullptr;
    
    auto handle_obj = std::make_shared<rimelabs_handle>(rimelabs_obj);
    rimelabs_handle_t handle = handle_obj.get();
    
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "rimelabs_handle initialized with ref_count %d\n", handle->ref_count.load());
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    g_handle_map[handle] = handle_obj;
    
    return handle;
}

void rimelabs_retain(rimelabs_handle_t handle) {
    if (!handle) return;
    int new_count = handle->ref_count.fetch_add(1) + 1;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "rimelabs_retain, ref count %d\n", new_count);
}

void rimelabs_release(rimelabs_handle_t handle) {
    if (!handle) return;
    
    int old_count = handle->ref_count.fetch_sub(1);
    int new_count = old_count - 1;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "rimelabs_release, ref count %d\n", new_count);
    
    if (old_count == 1) {
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handle_map.erase(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "rimelabs_release, handle erased\n");
    }
}

// Getters
const char* rimelabs_get_voice_name(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getVoiceName().c_str();
}

const char* rimelabs_get_api_key(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getApiKey().c_str();
}

const char* rimelabs_get_model_id(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getModelId().c_str();
}

const char* rimelabs_get_speed_alpha(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getSpeedAlpha().c_str();
}

const char* rimelabs_get_reduce_latency(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getReduceLatency().c_str();
}

const char* rimelabs_get_language(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getLanguage().c_str();
}

const char* rimelabs_get_temperature(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getTemperature().c_str();
}

const char* rimelabs_get_repetition_penalty(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getRepetitionPenalty().c_str();
}

const char* rimelabs_get_top_p(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getTopP().c_str();
}

const char* rimelabs_get_max_tokens(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getMaxTokens().c_str();
}

const char* rimelabs_get_session_id(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getSessionId().c_str();
}

// Result data getters
long rimelabs_get_response_code(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->getResponseCode();
}

const char* rimelabs_get_content_type(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getContentType().c_str();
}

const char* rimelabs_get_name_lookup_time_ms(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getNameLookupTimeMs().c_str();
}

const char* rimelabs_get_connect_time_ms(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getConnectTimeMs().c_str();
}

const char* rimelabs_get_final_response_time_ms(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getFinalResponseTimeMs().c_str();
}

const char* rimelabs_get_error_message(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getErrorMessage().c_str();
}

const char* rimelabs_get_cache_filename(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getCacheFilename().c_str();
}

// State getters
int rimelabs_get_rate(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->getRate();
}

int rimelabs_is_draining(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->isDraining() ? 1 : 0;
}

int rimelabs_get_reads(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->getReads();
}

int rimelabs_is_cache_audio(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->isCacheAudio() ? 1 : 0;
}

int rimelabs_is_playback_start_sent(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->isPlaybackStartSent() ? 1 : 0;
}

int rimelabs_is_arcana(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->isArcana() ? 1 : 0;
}

// Resource getters
void* rimelabs_get_connection(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr->getConnection();
}

FILE* rimelabs_get_file(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr->getFile();
}

const char* rimelabs_get_playback_id(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getPlaybackId().c_str();
}

void* rimelabs_get_audio_player(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr->getAudioPlayer();
}

void* rimelabs_get_playout_buffer(rimelabs_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr->getPlayoutBuffer();
}

// Setters
void rimelabs_set_voice_name(rimelabs_handle_t handle, const char* voice_name) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setVoiceName(voice_name ? voice_name : "");
}

void rimelabs_set_api_key(rimelabs_handle_t handle, const char* api_key) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setApiKey(api_key ? api_key : "");
}

void rimelabs_set_model_id(rimelabs_handle_t handle, const char* model_id) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setModelId(model_id ? model_id : "");
}

void rimelabs_set_speed_alpha(rimelabs_handle_t handle, const char* speed_alpha) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setSpeedAlpha(speed_alpha ? speed_alpha : "");
}

void rimelabs_set_reduce_latency(rimelabs_handle_t handle, const char* reduce_latency) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setReduceLatency(reduce_latency ? reduce_latency : "");
}

void rimelabs_set_language(rimelabs_handle_t handle, const char* language) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setLanguage(language ? language : "");
}

void rimelabs_set_temperature(rimelabs_handle_t handle, const char* temperature) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setTemperature(temperature ? temperature : "");
}

void rimelabs_set_repetition_penalty(rimelabs_handle_t handle, const char* repetition_penalty) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setRepetitionPenalty(repetition_penalty ? repetition_penalty : "");
}

void rimelabs_set_top_p(rimelabs_handle_t handle, const char* top_p) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setTopP(top_p ? top_p : "");
}

void rimelabs_set_max_tokens(rimelabs_handle_t handle, const char* max_tokens) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setMaxTokens(max_tokens ? max_tokens : "");
}

void rimelabs_set_session_id(rimelabs_handle_t handle, const char* session_id) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setSessionId(session_id ? session_id : "");
}

// Result data setters
void rimelabs_set_response_code(rimelabs_handle_t handle, long response_code) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setResponseCode(response_code);
}

void rimelabs_set_content_type(rimelabs_handle_t handle, const char* content_type) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setContentType(content_type ? content_type : "");
}

void rimelabs_set_name_lookup_time_ms(rimelabs_handle_t handle, const char* time_ms) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setNameLookupTimeMs(time_ms ? time_ms : "");
}

void rimelabs_set_connect_time_ms(rimelabs_handle_t handle, const char* time_ms) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setConnectTimeMs(time_ms ? time_ms : "");
}

void rimelabs_set_final_response_time_ms(rimelabs_handle_t handle, const char* time_ms) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setFinalResponseTimeMs(time_ms ? time_ms : "");
}

void rimelabs_set_error_message(rimelabs_handle_t handle, const char* error_msg) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setErrorMessage(error_msg ? error_msg : "");
}

void rimelabs_set_cache_filename(rimelabs_handle_t handle, const char* cache_filename) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setCacheFilename(cache_filename ? cache_filename : "");
}

// State setters
void rimelabs_set_rate(rimelabs_handle_t handle, int rate) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setRate(rate);
}

void rimelabs_set_draining(rimelabs_handle_t handle, int draining) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setDraining(draining != 0);
}

void rimelabs_set_reads(rimelabs_handle_t handle, int reads) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setReads(reads);
}

void rimelabs_set_cache_audio(rimelabs_handle_t handle, int cache_audio) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setCacheAudio(cache_audio != 0);
}

void rimelabs_set_playback_start_sent(rimelabs_handle_t handle, int playback_start_sent) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setPlaybackStartSent(playback_start_sent != 0);
}

void rimelabs_set_is_arcana(rimelabs_handle_t handle, int is_arcana) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setIsArcana(is_arcana != 0);
}

// Resource setters
void rimelabs_set_connection(rimelabs_handle_t handle, void* conn) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setConnection(conn);
}

void rimelabs_set_file(rimelabs_handle_t handle, FILE* file) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setFile(file);
}

void rimelabs_set_playback_id(rimelabs_handle_t handle, const char* playback_id) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setPlaybackId(playback_id ? playback_id : "");
}

void rimelabs_set_audio_player(rimelabs_handle_t handle, void* audio_player) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setAudioPlayer(audio_player);
}

void rimelabs_set_playout_buffer(rimelabs_handle_t handle, void* playout_buffer) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setPlayoutBuffer(playout_buffer);
}


} // extern "C"

// Internal C++ functions
std::shared_ptr<RimeLabs> rimelabs_get_shared_ptr(rimelabs_handle_t handle) {
    if (!handle) return nullptr;
    return handle->ptr;
}

rimelabs_handle_t rimelabs_get_handle_from_shared_ptr(const std::shared_ptr<RimeLabs>& ptr) {
    if (!ptr) return nullptr;
    
    auto handle_obj = std::make_shared<rimelabs_handle>(ptr);
    rimelabs_handle_t handle = handle_obj.get();
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    g_handle_map[handle] = handle_obj;
    
    return handle;
}