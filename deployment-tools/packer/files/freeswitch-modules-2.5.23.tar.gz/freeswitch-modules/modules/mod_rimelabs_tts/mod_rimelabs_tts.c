#include "mod_rimelabs_tts.h"
#include "rimelabs_glue.h"
#include "rimelabs_wrapper.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_rimelabs_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_rimelabs_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_rimelabs_tts, mod_rimelabs_tts_load, mod_rimelabs_tts_shutdown, NULL);


static void clearrimelabs(rimelabs_handle_t handle, int freeAll) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "clearrimelabs\n");
  
  rimelabs_set_api_key(handle, "");
  rimelabs_set_model_id(handle, "");
  rimelabs_set_speed_alpha(handle, "");
  rimelabs_set_reduce_latency(handle, "");
  rimelabs_set_language(handle, "");
  rimelabs_set_repetition_penalty(handle, "");
  rimelabs_set_temperature(handle, "");
  rimelabs_set_top_p(handle, "");
  rimelabs_set_max_tokens(handle, "");

  rimelabs_set_content_type(handle, "");
  rimelabs_set_error_message(handle, "");
  rimelabs_set_name_lookup_time_ms(handle, "");
  rimelabs_set_connect_time_ms(handle, "");
  rimelabs_set_final_response_time_ms(handle, "");
  rimelabs_set_cache_filename(handle, "");

  rimelabs_set_playback_id(handle, "");

  if (freeAll) {
    rimelabs_set_voice_name(handle, "");
    rimelabs_set_session_id(handle, "");
  }
}

static rimelabs_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  rimelabs_handle_t handle = (rimelabs_handle_t) sh->private_info;  
  if (!handle) {
    handle = rimelabs_create();
  	sh->private_info = handle;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "allocated rimelabs handle\n");
  }
  return handle;
}

switch_status_t d_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  rimelabs_handle_t handle = createOrRetrievePrivateData(sh);
  rimelabs_set_voice_name(handle, voice_name);
  rimelabs_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "d_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
  return rimelabs_speech_open(handle);
}

static switch_status_t d_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  rimelabs_handle_t handle = (rimelabs_handle_t) sh->private_info;
  if (handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_speech_close\n");

    /* mutex allocated from session pool - automatically cleaned up */

    rc = rimelabs_speech_close(handle);
    clearrimelabs(handle, 1);
    rimelabs_release(handle);
    return rc;
  }
  return SWITCH_STATUS_SUCCESS;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t d_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  rimelabs_handle_t handle = createOrRetrievePrivateData(sh);
  rimelabs_set_draining(handle, 0);
  rimelabs_set_reads(handle, 0);
  rimelabs_set_response_code(handle, 0);
  rimelabs_set_error_message(handle, "");
  rimelabs_set_playback_start_sent(handle, 0);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_speech_feed_tts\n");

  return rimelabs_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t d_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  rimelabs_handle_t handle = createOrRetrievePrivateData(sh);
  return rimelabs_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void d_speech_flush_tts(switch_speech_handle_t *sh)
{
  rimelabs_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_speech_flush_tts\n");
  rimelabs_speech_flush_tts(handle);

  clearrimelabs(handle, 0);
}

static void d_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  rimelabs_handle_t handle = createOrRetrievePrivateData(sh);
  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_text_param_tts: %s=XXXXX\n", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_text_param_tts: %s=%s\n", param, val);
  }
  if (0 == strcmp(param, "api_key")) {
    rimelabs_set_api_key(handle, val);
  } else if (0 == strcmp(param, "model_id")) {
    rimelabs_set_model_id(handle, val);
    rimelabs_set_is_arcana(handle, strcmp(val, "arcana") == 0);
  } else if (0 == strcmp(param, "language")) {
    rimelabs_set_language(handle, val);
  } else if (0 == strcmp(param, "speed_alpha")) {
    rimelabs_set_speed_alpha(handle, val);
  } else if (0 == strcmp(param, "reduce_latency")) {
    rimelabs_set_reduce_latency(handle, val);
  } else if (0 == strcmp(param, "voice")) {
    rimelabs_set_voice_name(handle, val);
  } else if (0 == strcmp(param, "repetition_penalty")) {
    rimelabs_set_repetition_penalty(handle, val);
  } else if (0 == strcmp(param, "temperature")) {
    rimelabs_set_temperature(handle, val);
  } else if (0 == strcmp(param, "top_p")) {
    rimelabs_set_top_p(handle, val);
  } else if (0 == strcmp(param, "max_tokens")) {
    rimelabs_set_max_tokens(handle, val);
  } else if (0 == strcmp(param, "playback_id")) {
    rimelabs_set_playback_id(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    rimelabs_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    rimelabs_set_cache_audio(handle, 1);
  }
}

static void d_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}
static void d_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_rimelabs_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "rimelabs";
  speech_interface->speech_open = d_speech_open;
  speech_interface->speech_close = d_speech_close;
  speech_interface->speech_feed_tts = d_speech_feed_tts;
  speech_interface->speech_read_tts = d_speech_read_tts;
	speech_interface->speech_flush_tts = d_speech_flush_tts;
	speech_interface->speech_text_param_tts = d_text_param_tts;
	speech_interface->speech_numeric_param_tts = d_numeric_param_tts;
	speech_interface->speech_float_param_tts = d_float_param_tts;
  return rimelabs_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_rimelabs_tts_shutdown)
{
  return rimelabs_speech_unload();
}
