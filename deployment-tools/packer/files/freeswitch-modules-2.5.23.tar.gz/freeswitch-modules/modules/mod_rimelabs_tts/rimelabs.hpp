#ifndef __RIMELABS_HPP__
#define __RIMELABS_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <memory>
#include <string>
#include <mutex>

class RimeLabs {
private:
    std::string voice_name_;
    std::string api_key_;
    std::string model_id_;
    std::string speed_alpha_;
    std::string reduce_latency_;
    std::string language_;
    std::string temperature_;
    std::string repetition_penalty_;
    std::string top_p_;
    std::string max_tokens_;
    std::string session_id_;

    // Result data
    long response_code_;
    std::string content_type_;
    std::string name_lookup_time_ms_;
    std::string connect_time_ms_;
    std::string final_response_time_ms_;
    std::string error_message_;
    std::string cache_filename_;

    // State
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;
    bool is_arcana_;

    // Resources
    void* connection_;
    FILE* file_;
    std::string playback_id_;
    mutable std::mutex mutex_;
    void* audio_player_;
    void* playout_buffer_;

    // Private constructor to enforce shared_ptr usage
    RimeLabs();

public:
    ~RimeLabs();
    
    // Factory method
    static std::shared_ptr<RimeLabs> create();
    
    // Getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getApiKey() const { return api_key_; }
    const std::string& getModelId() const { return model_id_; }
    const std::string& getSpeedAlpha() const { return speed_alpha_; }
    const std::string& getReduceLatency() const { return reduce_latency_; }
    const std::string& getLanguage() const { return language_; }
    const std::string& getTemperature() const { return temperature_; }
    const std::string& getRepetitionPenalty() const { return repetition_penalty_; }
    const std::string& getTopP() const { return top_p_; }
    const std::string& getMaxTokens() const { return max_tokens_; }
    const std::string& getSessionId() const { return session_id_; }
    
    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getContentType() const { return content_type_; }
    const std::string& getNameLookupTimeMs() const { return name_lookup_time_ms_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFinalResponseTimeMs() const { return final_response_time_ms_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    
    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }
    bool isArcana() const { return is_arcana_; }
    
    // Resource getters
    void* getConnection() const { return connection_; }
    FILE* getFile() const { return file_; }
    const std::string& getPlaybackId() const { return playback_id_; }
    std::mutex& getMutex() const { return mutex_; }
    void* getAudioPlayer() const { return audio_player_; }
    void* getPlayoutBuffer() const { return playout_buffer_; }
    
    // Setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setApiKey(const std::string& api_key) { api_key_ = api_key; }
    void setModelId(const std::string& model_id) { model_id_ = model_id; }
    void setSpeedAlpha(const std::string& speed_alpha) { speed_alpha_ = speed_alpha; }
    void setReduceLatency(const std::string& reduce_latency) { reduce_latency_ = reduce_latency; }
    void setLanguage(const std::string& language) { language_ = language; }
    void setTemperature(const std::string& temperature) { temperature_ = temperature; }
    void setRepetitionPenalty(const std::string& repetition_penalty) { repetition_penalty_ = repetition_penalty; }
    void setTopP(const std::string& top_p) { top_p_ = top_p; }
    void setMaxTokens(const std::string& max_tokens) { max_tokens_ = max_tokens; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    
    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setContentType(const std::string& content_type) { content_type_ = content_type; }
    void setNameLookupTimeMs(const std::string& time_ms) { name_lookup_time_ms_ = time_ms; }
    void setConnectTimeMs(const std::string& time_ms) { connect_time_ms_ = time_ms; }
    void setFinalResponseTimeMs(const std::string& time_ms) { final_response_time_ms_ = time_ms; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    
    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setPlaybackStartSent(bool playback_start_sent) { playback_start_sent_ = playback_start_sent; }
    void setIsArcana(bool is_arcana) { is_arcana_ = is_arcana; }
    
    // Resource setters
    void setConnection(void* conn) { connection_ = conn; }
    void setFile(FILE* file) { file_ = file; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }
    void setAudioPlayer(void* audio_player) { audio_player_ = audio_player; }
    void setPlayoutBuffer(void* playout_buffer) { playout_buffer_ = playout_buffer; }
    
};

#endif