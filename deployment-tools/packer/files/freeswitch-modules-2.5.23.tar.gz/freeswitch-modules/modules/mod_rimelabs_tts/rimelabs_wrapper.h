// rimelabs_wrapper.h - C-compatible header
#ifndef __RIMELABS_WRAPPER_H__
#define __RIMELABS_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct rimelabs_handle* rimelabs_handle_t;

#ifdef __cplusplus
#include <memory>
#include <mutex>

// Forward declaration
class RimeLabs;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<RimeLabs> rimelabs_get_shared_ptr(rimelabs_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
rimelabs_handle_t rimelabs_get_handle_from_shared_ptr(const std::shared_ptr<RimeLabs>& ptr);

extern "C" {
#endif

// C API functions
rimelabs_handle_t rimelabs_create(void);
void rimelabs_retain(rimelabs_handle_t handle);
void rimelabs_release(rimelabs_handle_t handle);

// Getters - C-style interface
const char* rimelabs_get_voice_name(rimelabs_handle_t handle);
const char* rimelabs_get_api_key(rimelabs_handle_t handle);
const char* rimelabs_get_model_id(rimelabs_handle_t handle);
const char* rimelabs_get_speed_alpha(rimelabs_handle_t handle);
const char* rimelabs_get_reduce_latency(rimelabs_handle_t handle);
const char* rimelabs_get_language(rimelabs_handle_t handle);
const char* rimelabs_get_temperature(rimelabs_handle_t handle);
const char* rimelabs_get_repetition_penalty(rimelabs_handle_t handle);
const char* rimelabs_get_top_p(rimelabs_handle_t handle);
const char* rimelabs_get_max_tokens(rimelabs_handle_t handle);
const char* rimelabs_get_session_id(rimelabs_handle_t handle);

// Result data getters
long rimelabs_get_response_code(rimelabs_handle_t handle);
const char* rimelabs_get_content_type(rimelabs_handle_t handle);
const char* rimelabs_get_name_lookup_time_ms(rimelabs_handle_t handle);
const char* rimelabs_get_connect_time_ms(rimelabs_handle_t handle);
const char* rimelabs_get_final_response_time_ms(rimelabs_handle_t handle);
const char* rimelabs_get_error_message(rimelabs_handle_t handle);
const char* rimelabs_get_cache_filename(rimelabs_handle_t handle);

// State getters
int rimelabs_get_rate(rimelabs_handle_t handle);
int rimelabs_is_draining(rimelabs_handle_t handle);
int rimelabs_get_reads(rimelabs_handle_t handle);
int rimelabs_is_cache_audio(rimelabs_handle_t handle);
int rimelabs_is_playback_start_sent(rimelabs_handle_t handle);
int rimelabs_is_arcana(rimelabs_handle_t handle);

// Resource getters
void* rimelabs_get_connection(rimelabs_handle_t handle);
FILE* rimelabs_get_file(rimelabs_handle_t handle);
const char* rimelabs_get_playback_id(rimelabs_handle_t handle);
void* rimelabs_get_audio_player(rimelabs_handle_t handle);
void* rimelabs_get_playout_buffer(rimelabs_handle_t handle);

// Setters
void rimelabs_set_voice_name(rimelabs_handle_t handle, const char* voice_name);
void rimelabs_set_api_key(rimelabs_handle_t handle, const char* api_key);
void rimelabs_set_model_id(rimelabs_handle_t handle, const char* model_id);
void rimelabs_set_speed_alpha(rimelabs_handle_t handle, const char* speed_alpha);
void rimelabs_set_reduce_latency(rimelabs_handle_t handle, const char* reduce_latency);
void rimelabs_set_language(rimelabs_handle_t handle, const char* language);
void rimelabs_set_temperature(rimelabs_handle_t handle, const char* temperature);
void rimelabs_set_repetition_penalty(rimelabs_handle_t handle, const char* repetition_penalty);
void rimelabs_set_top_p(rimelabs_handle_t handle, const char* top_p);
void rimelabs_set_max_tokens(rimelabs_handle_t handle, const char* max_tokens);
void rimelabs_set_session_id(rimelabs_handle_t handle, const char* session_id);

// Result data setters
void rimelabs_set_response_code(rimelabs_handle_t handle, long response_code);
void rimelabs_set_content_type(rimelabs_handle_t handle, const char* content_type);
void rimelabs_set_name_lookup_time_ms(rimelabs_handle_t handle, const char* time_ms);
void rimelabs_set_connect_time_ms(rimelabs_handle_t handle, const char* time_ms);
void rimelabs_set_final_response_time_ms(rimelabs_handle_t handle, const char* time_ms);
void rimelabs_set_error_message(rimelabs_handle_t handle, const char* error_msg);
void rimelabs_set_cache_filename(rimelabs_handle_t handle, const char* cache_filename);

// State setters
void rimelabs_set_rate(rimelabs_handle_t handle, int rate);
void rimelabs_set_draining(rimelabs_handle_t handle, int draining);
void rimelabs_set_reads(rimelabs_handle_t handle, int reads);
void rimelabs_set_cache_audio(rimelabs_handle_t handle, int cache_audio);
void rimelabs_set_playback_start_sent(rimelabs_handle_t handle, int playback_start_sent);
void rimelabs_set_is_arcana(rimelabs_handle_t handle, int is_arcana);

// Resource setters
void rimelabs_set_connection(rimelabs_handle_t handle, void* conn);
void rimelabs_set_file(rimelabs_handle_t handle, FILE* file);
void rimelabs_set_playback_id(rimelabs_handle_t handle, const char* playback_id);
void rimelabs_set_audio_player(rimelabs_handle_t handle, void* audio_player);
void rimelabs_set_playout_buffer(rimelabs_handle_t handle, void* playout_buffer);


#ifdef __cplusplus
}
#endif

#endif