#include "rimelabs.hpp"

RimeLabs::RimeLabs() : 
    response_code_(0),
    rate_(0),
    draining_(false),
    reads_(0),
    cache_audio_(false),
    playback_start_sent_(false),
    is_arcana_(false),
    connection_(nullptr),
    file_(nullptr),
    audio_player_(nullptr),
    playout_buffer_(nullptr) {
}

RimeLabs::~RimeLabs() {
    if (file_) {
        fclose(file_);
        file_ = nullptr;
    }
    if (connection_) {
        connection_ = nullptr;
    }
    audio_player_ = nullptr;
    playout_buffer_ = nullptr;
}

std::shared_ptr<RimeLabs> RimeLabs::create() {
    return std::shared_ptr<RimeLabs>(new RimeLabs());
}

