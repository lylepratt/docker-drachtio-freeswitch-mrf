#include "azure.hpp"
#include <switch.h>
#include <speechapi_cxx.h>  // Need full header for SpeechSynthesizer methods

using namespace Microsoft::CognitiveServices::Speech;

AzureTts::AzureTts()
    : response_code_(0),
      rate_(8000),
      draining_(false),
      reads_(0),
      cache_audio_(false),
      flushed_(false),
      playback_start_sent_(false),
      file_(nullptr),
      resampler_(nullptr),
      circular_buffer_(nullptr),
      has_last_byte_(false),
      last_byte_(0),
      synthesis_in_progress_(false) {
    // mutex_ and synthesizer_mutex_ are automatically initialized by their constructors
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s AzureTts::AzureTts() - constructor called, object created at %p\n",
        session_id_.empty() ? "" : session_id_.c_str(), this);
}

AzureTts::~AzureTts() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s AzureTts::~AzureTts() - destructor called, destroying object at %p\n",
        session_id_.empty() ? "" : session_id_.c_str(), this);

    // CRITICAL: Clean up synthesizer first, before other resources
    // This ensures the synthesizer is destroyed on a controlled thread (the one
    // calling the destructor) rather than on a detached thread, which can crash
    cleanupSynthesizer();

    cleanup();
}

std::shared_ptr<AzureTts> AzureTts::create() {
    return std::make_shared<AzureTts>();
}

void AzureTts::setActiveSynthesizer(std::shared_ptr<SpeechSynthesizer> synth) {
    std::lock_guard<std::mutex> lock(synthesizer_mutex_);
    
    // If there's an existing synthesizer, clean it up first
    if (active_synthesizer_) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
            "%s AzureTts::setActiveSynthesizer() - replacing existing synthesizer at %p\n",
            session_id_.empty() ? "" : session_id_.c_str(), active_synthesizer_.get());
        // Don't call cleanupSynthesizer here as it tries to lock the same mutex
        // Just stop the old one inline
        try {
            active_synthesizer_->StopSpeakingAsync().get();
        } catch (const std::exception& e) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
                "%s AzureTts::setActiveSynthesizer() - exception stopping old synthesizer: %s\n",
                session_id_.empty() ? "" : session_id_.c_str(), e.what());
        } catch (...) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
                "%s AzureTts::setActiveSynthesizer() - unknown exception stopping old synthesizer\n",
                session_id_.empty() ? "" : session_id_.c_str());
        }
    }
    
    active_synthesizer_ = std::move(synth);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s AzureTts::setActiveSynthesizer() - stored synthesizer at %p\n",
        session_id_.empty() ? "" : session_id_.c_str(), active_synthesizer_.get());
}

std::shared_ptr<SpeechSynthesizer> AzureTts::getActiveSynthesizer() {
    std::lock_guard<std::mutex> lock(synthesizer_mutex_);
    return active_synthesizer_;
}

void AzureTts::clearActiveSynthesizer() {
    std::shared_ptr<SpeechSynthesizer> synth;
    
    {
        std::lock_guard<std::mutex> lock(synthesizer_mutex_);
        synth = std::move(active_synthesizer_);
        active_synthesizer_.reset();
    }
    
    if (synth) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "%s AzureTts::clearActiveSynthesizer() - stopping synthesizer at %p\n",
            session_id_.empty() ? "" : session_id_.c_str(), synth.get());

        // Gracefully stop the synthesizer before destroying it
        // This flushes pending operations and closes WebSocket cleanly
        try {
            // StopSpeakingAsync returns a future - we wait for it to complete
            auto stopFuture = synth->StopSpeakingAsync();

            // Wait with timeout to avoid hanging forever
            auto status = stopFuture.wait_for(std::chrono::seconds(5));
            if (status == std::future_status::timeout) {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
                    "%s AzureTts::clearActiveSynthesizer() - StopSpeakingAsync timed out after 5s\n",
                    session_id_.empty() ? "" : session_id_.c_str());
            } else {
                stopFuture.get();  // Get result to ensure completion
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
                    "%s AzureTts::clearActiveSynthesizer() - synthesizer stopped successfully\n",
                    session_id_.empty() ? "" : session_id_.c_str());
            }
        } catch (const std::exception& e) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
                "%s AzureTts::clearActiveSynthesizer() - exception during StopSpeakingAsync: %s\n",
                session_id_.empty() ? "" : session_id_.c_str(), e.what());
        } catch (...) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
                "%s AzureTts::clearActiveSynthesizer() - unknown exception during StopSpeakingAsync\n",
                session_id_.empty() ? "" : session_id_.c_str());
        }

        // Now synth goes out of scope and destructor runs on THIS thread (safe)
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "%s AzureTts::clearActiveSynthesizer() - synthesizer shared_ptr releasing\n",
            session_id_.empty() ? "" : session_id_.c_str());
    }
    
    synthesis_in_progress_.store(false);
}

void AzureTts::cleanupSynthesizer() {
    // Called from destructor - clean up synthesizer gracefully
    clearActiveSynthesizer();
}

void AzureTts::reset() {
    // First clean up the synthesizer
    clearActiveSynthesizer();
    
    std::lock_guard<std::mutex> lock(mutex_);

    // Clear strings
    voice_name_.clear();
    api_key_.clear();
    region_.clear();
    language_.clear();
    endpoint_.clear();
    endpoint_id_.clear();
    http_proxy_ip_.clear();
    http_proxy_port_.clear();
    session_id_.clear();
    cache_filename_.clear();
    error_message_.clear();
    playback_id_.clear();

    // Reset values
    response_code_ = 0;
    rate_ = 8000;
    draining_ = false;
    reads_ = 0;
    cache_audio_ = false;
    flushed_ = false;
    playback_start_sent_ = false;
    has_last_byte_ = false;
    last_byte_ = 0;

    // Clean up resources
    cleanup();
}

bool AzureTts::isValid() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return !voice_name_.empty() && !api_key_.empty() && !region_.empty();
}

void AzureTts::cleanup() {
    // Note: This is called from destructor, so mutex may already be locked
    if (file_) {
        fclose(file_);
        file_ = nullptr;
    }

    if (resampler_) {
        speex_resampler_destroy(resampler_);
        resampler_ = nullptr;
    }

    // Note: circular_buffer_ cleanup should be handled by azure_glue.cpp
    // as it knows the actual type
}