# Azure TTS Module Migration Guide

## Overview
This migration addresses a critical race condition where session-allocated memory was being accessed by background threads after the session ended, causing crashes.

## Key Changes

### 1. Memory Management
- **OLD**: Raw `azure_t*` pointer allocated from session memory pool
- **NEW**: Reference-counted `azure_handle_t` with `std::shared_ptr<AzureTts>`

### 2. Thread Safety
- **OLD**: `std::mutex` embedded in session-allocated struct (freed with session)
- **NEW**: `std::mutex` is member of C++ class that lives via shared_ptr

### 3. File Structure
New files added:
- `azure.hpp` - C++ class definition
- `azure.cpp` - C++ class implementation
- `azure_wrapper.h` - C wrapper interface
- `azure_wrapper.cpp` - Reference-counting wrapper implementation

## Migration Steps for mod_azure_tts.c

### Creating the handle
```c
// OLD
azure_t *a = (azure_t *) sh->private_info;
if (!a) {
    a = switch_core_alloc(sh->memory_pool, sizeof(*a));
    sh->private_info = a;
    memset(a, 0, sizeof(*a));
}

// NEW
azure_handle_t handle = (azure_handle_t) sh->private_info;
if (!handle) {
    handle = azure_tts_create();
    sh->private_info = handle;
}
```

### Accessing fields
```c
// OLD
a->voice_name = strdup(voice_name);
a->rate = rate;

// NEW
azure_tts_set_voice_name(handle, voice_name);
azure_tts_set_rate(handle, rate);
```

### Cleanup
```c
// OLD
clearAzure(a, 1);

// NEW
if (handle) {
    azure_tts_release(handle);
    sh->private_info = NULL;
}
```

## Migration Steps for azure_glue.cpp

### Function signatures
```cpp
// OLD
switch_status_t azure_speech_feed_tts(azure_t* azure, char* text, switch_speech_flag_t *flags)

// NEW
switch_status_t azure_speech_feed_tts(azure_handle_t handle, char* text, switch_speech_flag_t *flags)
```

### Getting shared_ptr for async operations
```cpp
// At start of function
std::shared_ptr<AzureTts> azure = azure_get_shared_ptr(handle);
if (!azure) {
    return SWITCH_STATUS_FALSE;
}
```

### Lambda captures - CRITICAL CHANGE
```cpp
// OLD - DANGEROUS! Raw pointer can become dangling
speechSynthesizer->Synthesizing += [a](const SpeechSynthesisEventArgs& e) {
    // Access a->field

// NEW - SAFE! shared_ptr keeps object alive
// First, retain the handle for the lambda's lifetime
azure_tts_retain(handle);

speechSynthesizer->Synthesizing += [handle](const SpeechSynthesisEventArgs& e) {
    auto azure = azure_get_shared_ptr(handle);
    if (!azure) return;
    // Access azure->getField()

    // When done (e.g., in completion callback), release:
    // azure_tts_release(handle);
};
```

### Detached threads - CRITICAL CHANGE
```cpp
// OLD - DANGEROUS!
std::thread(start_synthesis, speechSynthesizer, dupText, a).detach();

// NEW - SAFE!
azure_tts_retain(handle);  // Keep alive for thread
std::thread([handle, speechSynthesizer, dupText]() {
    auto azure = azure_get_shared_ptr(handle);
    if (azure) {
        start_synthesis(speechSynthesizer, dupText, azure);
    }
    azure_tts_release(handle);  // Release when thread completes
}).detach();
```

### Mutex locking
```cpp
// OLD
std::lock_guard<std::mutex> lock(a->mutex);

// NEW
std::lock_guard<std::mutex> lock(azure->getMutex());
```

### Field access
```cpp
// OLD
a->response_code = 200;
if (a->draining) { ... }

// NEW
azure->setResponseCode(200);
if (azure->isDraining()) { ... }
```

## Build System Updates

### Makefile.am
Add the new source files:
```makefile
mod_azure_tts_la_SOURCES = \
    mod_azure_tts.c \
    azure_glue.cpp \
    azure.cpp \
    azure_wrapper.cpp
```

## Testing Recommendations

1. **Stress test session teardown**: Rapidly create/destroy sessions during TTS
2. **Test long-running synthesis**: Ensure background threads complete properly
3. **Monitor memory**: Verify no leaks with valgrind
4. **Test error paths**: Ensure cleanup happens in all error cases

## Key Safety Guarantees

1. **Object lifetime**: The AzureTts object survives until ALL references are released
2. **Thread safety**: Mutex is part of object, not session memory
3. **Clean shutdown**: Background operations complete gracefully
4. **No dangling pointers**: shared_ptr ensures validity