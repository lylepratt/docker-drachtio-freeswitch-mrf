#ifndef __AZURE_HPP__
#define __AZURE_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <string>
#include <memory>
#include <mutex>
#include <chrono>
#include <atomic>
#include <cstdint>

// Forward declaration to avoid including the full Azure SDK header here
namespace Microsoft {
namespace CognitiveServices {
namespace Speech {
    class SpeechSynthesizer;
}
}
}

class AzureTts {
private:
    // Configuration parameters
    std::string voice_name_;
    std::string api_key_;
    std::string region_;
    std::string language_;
    std::string endpoint_;
    std::string endpoint_id_;
    std::string http_proxy_ip_;
    std::string http_proxy_port_;

    // Result data
    long response_code_;
    std::string session_id_;
    std::string cache_filename_;
    std::string error_message_;
    std::string result_id_;

    // State and configuration
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool flushed_;
    bool playback_start_sent_;

    // Timing
    std::chrono::time_point<std::chrono::high_resolution_clock> start_time_;

    // Resources
    FILE* file_;
    SpeexResamplerState* resampler_;
    void* circular_buffer_;
    mutable std::mutex mutex_;  // Now a member object, properly constructed

    // Last byte handling for odd-sized chunks
    bool has_last_byte_;
    uint8_t last_byte_;
    std::string playback_id_;

    // Active synthesizer - stored here to control its lifetime
    // This prevents the synthesizer from being destroyed on a detached thread
    // which can cause crashes in the Azure SDK's async cleanup path
    std::shared_ptr<Microsoft::CognitiveServices::Speech::SpeechSynthesizer> active_synthesizer_;
    mutable std::mutex synthesizer_mutex_;  // Separate mutex for synthesizer access
    std::atomic<bool> synthesis_in_progress_{false};

public:
    // Constructor
    AzureTts();

    // Destructor
    ~AzureTts();

    // Static factory method
    static std::shared_ptr<AzureTts> create();

    // Delete copy operations to prevent accidental copies
    AzureTts(const AzureTts&) = delete;
    AzureTts& operator=(const AzureTts&) = delete;

    // Move operations deleted due to mutex members
    AzureTts(AzureTts&& other) noexcept = delete;
    AzureTts& operator=(AzureTts&& other) noexcept = delete;

    // Configuration getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getApiKey() const { return api_key_; }
    const std::string& getRegion() const { return region_; }
    const std::string& getLanguage() const { return language_; }
    const std::string& getEndpoint() const { return endpoint_; }
    const std::string& getEndpointId() const { return endpoint_id_; }
    const std::string& getHttpProxyIp() const { return http_proxy_ip_; }
    const std::string& getHttpProxyPort() const { return http_proxy_port_; }

    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getSessionId() const { return session_id_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getResultId() const { return result_id_; }

    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isFlushed() const { return flushed_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }

    // Resource getters
    FILE* getFile() const { return file_; }
    SpeexResamplerState* getResampler() const { return resampler_; }
    void* getCircularBuffer() const { return circular_buffer_; }
    std::mutex& getMutex() const { return mutex_; }
    const auto& getStartTime() const { return start_time_; }

    // Last byte handling
    bool hasLastByte() const { return has_last_byte_; }
    uint8_t getLastByte() const { return last_byte_; }
    const std::string& getPlaybackId() const { return playback_id_; }

    // Configuration setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setApiKey(const std::string& api_key) { api_key_ = api_key; }
    void setRegion(const std::string& region) { region_ = region; }
    void setLanguage(const std::string& language) { language_ = language; }
    void setEndpoint(const std::string& endpoint) { endpoint_ = endpoint; }
    void setEndpointId(const std::string& endpoint_id) { endpoint_id_ = endpoint_id; }
    void setHttpProxyIp(const std::string& proxy_ip) { http_proxy_ip_ = proxy_ip; }
    void setHttpProxyPort(const std::string& proxy_port) { http_proxy_port_ = proxy_port; }

    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }
    void setResultId(const std::string& result_id) { result_id_ = result_id; }

    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setFlushed(bool flushed) { flushed_ = flushed; }
    void setPlaybackStartSent(bool sent) { playback_start_sent_ = sent; }

    // Resource setters
    void setFile(FILE* file) { file_ = file; }
    void setResampler(SpeexResamplerState* resampler) { resampler_ = resampler; }
    void setCircularBuffer(void* buffer) { circular_buffer_ = buffer; }
    void setStartTime(const std::chrono::time_point<std::chrono::high_resolution_clock>& time) { start_time_ = time; }

    // Last byte handling
    void setHasLastByte(bool has) { has_last_byte_ = has; }
    void setLastByte(uint8_t byte) { last_byte_ = byte; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }

    // Increment reads atomically
    int incrementReads() {
        std::lock_guard<std::mutex> lock(mutex_);
        return ++reads_;
    }

    // Synthesizer lifecycle management
    // These methods ensure the synthesizer is destroyed safely on a controlled thread
    void setActiveSynthesizer(std::shared_ptr<Microsoft::CognitiveServices::Speech::SpeechSynthesizer> synth);
    std::shared_ptr<Microsoft::CognitiveServices::Speech::SpeechSynthesizer> getActiveSynthesizer();
    void clearActiveSynthesizer();  // Gracefully stops and clears the synthesizer
    
    // Synthesis state
    void setSynthesisInProgress(bool in_progress) { synthesis_in_progress_.store(in_progress); }
    bool isSynthesisInProgress() const { return synthesis_in_progress_.load(); }

    // Utility methods
    void reset();
    bool isValid() const;

private:
    void cleanup();
    void cleanupSynthesizer();  // Internal helper for synthesizer cleanup
};

#endif