#include "mod_azure_tts.h"
#include "azure_glue.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_azure_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_azure_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_azure_tts, mod_azure_tts_load, mod_azure_tts_shutdown, NULL);

static azure_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  azure_handle_t handle = (azure_handle_t) sh->private_info;
  const char* session_id;
  if (!handle) {
    handle = azure_tts_create();
    sh->private_info = handle;
    session_id = azure_tts_get_session_id(handle);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s allocated azure_handle_t\n",
                      session_id ? session_id : "");
  }
  return handle;
}

switch_status_t a_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  azure_handle_t handle;
  const char* session_id;

  handle = createOrRetrievePrivateData(sh);
  azure_tts_set_voice_name(handle, voice_name);
  azure_tts_set_rate(handle, rate);
  session_id = azure_tts_get_session_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s a_speech_open voice: %s, rate %d, channels %d\n",
                    session_id ? session_id : "", voice_name, rate, channels);
  return azure_speech_open(handle);
}

static switch_status_t a_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  azure_handle_t handle = createOrRetrievePrivateData(sh);
  const char* session_id = azure_tts_get_session_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s a_speech_close\n",
                    session_id ? session_id : "");

  rc = azure_speech_close(handle);

  // Release the handle - this triggers cleanup via RAII when ref count reaches 0
  if (handle) {
    azure_tts_release(handle);
    sh->private_info = NULL;
  }

  return rc;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t a_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  azure_handle_t handle = createOrRetrievePrivateData(sh);
  azure_tts_set_draining(handle, 0);
  azure_tts_set_reads(handle, 0);
  azure_tts_set_flushed(handle, 0);
  azure_tts_set_response_code(handle, 0);
  azure_tts_set_error_message(handle, NULL);
  azure_tts_set_has_last_byte(handle, 0);
  azure_tts_set_playback_start_sent(handle, 0);

  return azure_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t a_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  azure_handle_t handle = createOrRetrievePrivateData(sh);
  return azure_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void a_speech_flush_tts(switch_speech_handle_t *sh)
{
  azure_handle_t handle = createOrRetrievePrivateData(sh);
  azure_speech_flush_tts(handle);
}

static void a_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  azure_handle_t handle = createOrRetrievePrivateData(sh);
  const char* session_id = azure_tts_get_session_id(handle);
  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s a_text_param_tts: %s=XXXXX\n",
                      session_id ? session_id : "", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s a_text_param_tts: %s=%s\n",
                      session_id ? session_id : "", param, val);
  }
  if (0 == strcmp(param, "api_key")) {
    azure_tts_set_api_key(handle, val);
  } else if (0 == strcmp(param, "region")) {
    azure_tts_set_region(handle, val);
  } else if (0 == strcmp(param, "voice")) {
    azure_tts_set_voice_name(handle, val);
  } else if (0 == strcmp(param, "language")) {
    azure_tts_set_language(handle, val);
  } else if (0 == strcmp(param, "endpoint")) {
    azure_tts_set_endpoint(handle, val);
  } else if (0 == strcmp(param, "endpointId")) {
    azure_tts_set_endpoint_id(handle, val);
  } else if (0 == strcmp(param, "http_proxy_ip")) {
    azure_tts_set_http_proxy_ip(handle, val);
  } else if (0 == strcmp(param, "http_proxy_port")) {
    azure_tts_set_http_proxy_port(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    azure_tts_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    azure_tts_set_cache_audio(handle, 1);
  } else if (0 == strcmp(param, "playback_id")) {
    azure_tts_set_playback_id(handle, val);
  }
}

static void a_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}
static void a_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_azure_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "microsoft";
  speech_interface->speech_open = a_speech_open;
  speech_interface->speech_close = a_speech_close;
  speech_interface->speech_feed_tts = a_speech_feed_tts;
  speech_interface->speech_read_tts = a_speech_read_tts;
	speech_interface->speech_flush_tts = a_speech_flush_tts;
	speech_interface->speech_text_param_tts = a_text_param_tts;
	speech_interface->speech_numeric_param_tts = a_numeric_param_tts;
	speech_interface->speech_float_param_tts = a_float_param_tts;
  return azure_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_azure_tts_shutdown)
{
  return azure_speech_unload();
}