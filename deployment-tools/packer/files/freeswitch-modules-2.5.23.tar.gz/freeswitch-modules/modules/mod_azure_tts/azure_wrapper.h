// azure_wrapper.h - C-compatible header
#ifndef __AZURE_WRAPPER_H__
#define __AZURE_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct azure_handle* azure_handle_t;

#ifdef __cplusplus
#include <memory>

// Forward declaration
class AzureTts;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<AzureTts> azure_get_shared_ptr(azure_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
azure_handle_t azure_get_handle_from_shared_ptr(const std::shared_ptr<AzureTts>& ptr);

extern "C" {
#endif

// C API functions
azure_handle_t azure_tts_create(void);
void azure_tts_retain(azure_handle_t handle);
void azure_tts_release(azure_handle_t handle);

// Configuration getters
const char* azure_tts_get_voice_name(azure_handle_t handle);
const char* azure_tts_get_api_key(azure_handle_t handle);
const char* azure_tts_get_region(azure_handle_t handle);
const char* azure_tts_get_language(azure_handle_t handle);
const char* azure_tts_get_endpoint(azure_handle_t handle);
const char* azure_tts_get_endpoint_id(azure_handle_t handle);
const char* azure_tts_get_http_proxy_ip(azure_handle_t handle);
const char* azure_tts_get_http_proxy_port(azure_handle_t handle);

// Result data getters
long azure_tts_get_response_code(azure_handle_t handle);
const char* azure_tts_get_session_id(azure_handle_t handle);
const char* azure_tts_get_cache_filename(azure_handle_t handle);
const char* azure_tts_get_error_message(azure_handle_t handle);
const char* azure_tts_get_result_id(azure_handle_t handle);

// State getters
int azure_tts_get_rate(azure_handle_t handle);
int azure_tts_is_draining(azure_handle_t handle);
int azure_tts_get_reads(azure_handle_t handle);
int azure_tts_is_cache_audio(azure_handle_t handle);
int azure_tts_is_flushed(azure_handle_t handle);
int azure_tts_is_playback_start_sent(azure_handle_t handle);

// Resource getters
FILE* azure_tts_get_file(azure_handle_t handle);
void* azure_tts_get_resampler(azure_handle_t handle);
void* azure_tts_get_circular_buffer(azure_handle_t handle);
void* azure_tts_get_start_time(azure_handle_t handle);

// Last byte handling
int azure_tts_has_last_byte(azure_handle_t handle);
uint8_t azure_tts_get_last_byte(azure_handle_t handle);
const char* azure_tts_get_playback_id(azure_handle_t handle);

// Configuration setters
void azure_tts_set_voice_name(azure_handle_t handle, const char* voice_name);
void azure_tts_set_api_key(azure_handle_t handle, const char* api_key);
void azure_tts_set_region(azure_handle_t handle, const char* region);
void azure_tts_set_language(azure_handle_t handle, const char* language);
void azure_tts_set_endpoint(azure_handle_t handle, const char* endpoint);
void azure_tts_set_endpoint_id(azure_handle_t handle, const char* endpoint_id);
void azure_tts_set_http_proxy_ip(azure_handle_t handle, const char* proxy_ip);
void azure_tts_set_http_proxy_port(azure_handle_t handle, const char* proxy_port);

// Result data setters
void azure_tts_set_response_code(azure_handle_t handle, long response_code);
void azure_tts_set_session_id(azure_handle_t handle, const char* session_id);
void azure_tts_set_cache_filename(azure_handle_t handle, const char* cache_filename);
void azure_tts_set_error_message(azure_handle_t handle, const char* error_msg);
void azure_tts_set_result_id(azure_handle_t handle, const char* result_id);

// State setters
void azure_tts_set_rate(azure_handle_t handle, int rate);
void azure_tts_set_draining(azure_handle_t handle, int draining);
void azure_tts_set_reads(azure_handle_t handle, int reads);
void azure_tts_set_cache_audio(azure_handle_t handle, int cache_audio);
void azure_tts_set_flushed(azure_handle_t handle, int flushed);
void azure_tts_set_playback_start_sent(azure_handle_t handle, int sent);

// Resource setters
void azure_tts_set_file(azure_handle_t handle, FILE* file);
void azure_tts_set_resampler(azure_handle_t handle, void* resampler);
void azure_tts_set_circular_buffer(azure_handle_t handle, void* buffer);
void azure_tts_set_start_time_now(azure_handle_t handle);

// Last byte handling
void azure_tts_set_has_last_byte(azure_handle_t handle, int has);
void azure_tts_set_last_byte(azure_handle_t handle, uint8_t byte);
void azure_tts_set_playback_id(azure_handle_t handle, const char* playback_id);

// Utility
int azure_tts_increment_reads(azure_handle_t handle);

#ifdef __cplusplus
}
#endif

#endif