#ifndef __MOD_AZURE_TTS_H__
#define __MOD_AZURE_TTS_H__

#include <switch.h>
#include <speex/speex_resampler.h>

/*
 * We now use an opaque handle type for thread safety.
 * The old azure_t structure is replaced by azure_handle_t
 * which provides reference counting and shared_ptr protection.
 */
#include "azure_wrapper.h"

/* Legacy typedef for compatibility during transition */
typedef azure_handle_t azure_t;

#endif