#include "azure_wrapper.h"
#include "azure.hpp"
#include <memory>
#include <mutex>
#include <unordered_map>
#include <chrono>

// Internal handle structure
struct azure_handle {
    std::shared_ptr<AzureTts> instance;
    int ref_count;
    std::mutex ref_mutex;

    azure_handle(std::shared_ptr<AzureTts> inst)
        : instance(std::move(inst)), ref_count(1) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
                "azure_handle initialized with ref_count %d\n", ref_count);
        }
};

// Thread-safe handle management
static std::mutex g_handle_mutex;
static std::unordered_map<azure_handle_t, std::unique_ptr<azure_handle>> g_handles;

// Helper function to validate handle
static azure_handle* get_handle(azure_handle_t handle) {
    if (!handle) return nullptr;

    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second.get() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
std::shared_ptr<AzureTts> azure_get_shared_ptr(azure_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance : nullptr;
}

// Private internal function to get handle from shared_ptr
azure_handle_t azure_get_handle_from_shared_ptr(const std::shared_ptr<AzureTts>& ptr) {
    if (!ptr) return nullptr;

    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->instance == ptr) {
            return pair.first;
        }
    }
    return nullptr;
}

// C API Implementation
extern "C" {

azure_handle_t azure_tts_create(void) {
    try {
        auto instance = AzureTts::create();
        auto handle = std::make_unique<azure_handle>(instance);
        azure_handle_t handle_ptr = handle.get();

        size_t map_size;
        {
            std::lock_guard<std::mutex> lock(g_handle_mutex);
            g_handles[handle_ptr] = std::move(handle);
            map_size = g_handles.size();
        }

        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "azure_tts_create: created handle=%p, AzureTts object=%p, initial ref_count=1, global_map_size=%zu\n",
            handle_ptr, instance.get(), map_size);

        return handle_ptr;
    } catch (...) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "azure_tts_create: failed to create handle\n");
        return nullptr;
    }
}

void azure_tts_retain(azure_handle_t handle) {
    auto* h = get_handle(handle);
    if (h) {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "azure_tts_retain: handle=%p, ref_count=%d, AzureTts object=%p\n",
            handle, h->ref_count, h->instance.get());
    }
}

void azure_tts_release(azure_handle_t handle) {
    auto* h = get_handle(handle);
    if (!h) return;

    bool should_delete = false;
    void* azure_ptr = nullptr;
    {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count--;
        should_delete = (h->ref_count <= 0);
        azure_ptr = h->instance.get();
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "azure_tts_release: handle=%p, ref_count=%d, AzureTts object=%p%s\n",
            handle, h->ref_count, azure_ptr, should_delete ? " (will delete)" : "");
    }

    if (should_delete) {
        size_t map_size;
        {
            std::lock_guard<std::mutex> lock(g_handle_mutex);
            g_handles.erase(handle);
            map_size = g_handles.size();
        }
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "azure_tts_release: erased handle=%p from global map, triggering destructor for AzureTts=%p, global_map_size=%zu\n",
            handle, azure_ptr, map_size);
    }
}

// Configuration getters
const char* azure_tts_get_voice_name(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getVoiceName().c_str() : "";
}

const char* azure_tts_get_api_key(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getApiKey().c_str() : "";
}

const char* azure_tts_get_region(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getRegion().c_str() : "";
}

const char* azure_tts_get_language(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getLanguage().c_str() : "";
}

const char* azure_tts_get_endpoint(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getEndpoint().c_str() : "";
}

const char* azure_tts_get_endpoint_id(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getEndpointId().c_str() : "";
}

const char* azure_tts_get_http_proxy_ip(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getHttpProxyIp().c_str() : "";
}

const char* azure_tts_get_http_proxy_port(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getHttpProxyPort().c_str() : "";
}

// Result data getters
long azure_tts_get_response_code(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getResponseCode() : 0;
}

const char* azure_tts_get_session_id(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getSessionId().c_str() : "";
}

const char* azure_tts_get_cache_filename(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getCacheFilename().c_str() : "";
}

const char* azure_tts_get_error_message(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getErrorMessage().c_str() : "";
}

const char* azure_tts_get_result_id(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getResultId().c_str() : "";
}

// State getters
int azure_tts_get_rate(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getRate() : 8000;
}

int azure_tts_is_draining(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? (p->isDraining() ? 1 : 0) : 0;
}

int azure_tts_get_reads(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getReads() : 0;
}

int azure_tts_is_cache_audio(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? (p->isCacheAudio() ? 1 : 0) : 0;
}

int azure_tts_is_flushed(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? (p->isFlushed() ? 1 : 0) : 0;
}

int azure_tts_is_playback_start_sent(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? (p->isPlaybackStartSent() ? 1 : 0) : 0;
}

// Resource getters
FILE* azure_tts_get_file(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getFile() : nullptr;
}

void* azure_tts_get_resampler(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getResampler() : nullptr;
}

void* azure_tts_get_circular_buffer(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getCircularBuffer() : nullptr;
}

void* azure_tts_get_start_time(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    if (!p) return nullptr;
    // Return a pointer to the start time (for compatibility with existing code)
    return const_cast<void*>(static_cast<const void*>(&p->getStartTime()));
}

// Last byte handling
int azure_tts_has_last_byte(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? (p->hasLastByte() ? 1 : 0) : 0;
}

uint8_t azure_tts_get_last_byte(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getLastByte() : 0;
}

const char* azure_tts_get_playback_id(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->getPlaybackId().c_str() : "";
}

// Configuration setters
void azure_tts_set_voice_name(azure_handle_t handle, const char* voice_name) {
    auto p = azure_get_shared_ptr(handle);
    if (p && voice_name) p->setVoiceName(voice_name);
}

void azure_tts_set_api_key(azure_handle_t handle, const char* api_key) {
    auto p = azure_get_shared_ptr(handle);
    if (p && api_key) p->setApiKey(api_key);
}

void azure_tts_set_region(azure_handle_t handle, const char* region) {
    auto p = azure_get_shared_ptr(handle);
    if (p && region) p->setRegion(region);
}

void azure_tts_set_language(azure_handle_t handle, const char* language) {
    auto p = azure_get_shared_ptr(handle);
    if (p && language) p->setLanguage(language);
}

void azure_tts_set_endpoint(azure_handle_t handle, const char* endpoint) {
    auto p = azure_get_shared_ptr(handle);
    if (p && endpoint) p->setEndpoint(endpoint);
}

void azure_tts_set_endpoint_id(azure_handle_t handle, const char* endpoint_id) {
    auto p = azure_get_shared_ptr(handle);
    if (p && endpoint_id) p->setEndpointId(endpoint_id);
}

void azure_tts_set_http_proxy_ip(azure_handle_t handle, const char* proxy_ip) {
    auto p = azure_get_shared_ptr(handle);
    if (p && proxy_ip) p->setHttpProxyIp(proxy_ip);
}

void azure_tts_set_http_proxy_port(azure_handle_t handle, const char* proxy_port) {
    auto p = azure_get_shared_ptr(handle);
    if (p && proxy_port) p->setHttpProxyPort(proxy_port);
}

// Result data setters
void azure_tts_set_response_code(azure_handle_t handle, long response_code) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setResponseCode(response_code);
}

void azure_tts_set_session_id(azure_handle_t handle, const char* session_id) {
    auto p = azure_get_shared_ptr(handle);
    if (p && session_id) p->setSessionId(session_id);
}

void azure_tts_set_cache_filename(azure_handle_t handle, const char* cache_filename) {
    auto p = azure_get_shared_ptr(handle);
    if (p && cache_filename) p->setCacheFilename(cache_filename);
}

void azure_tts_set_error_message(azure_handle_t handle, const char* error_msg) {
    auto p = azure_get_shared_ptr(handle);
    if (p && error_msg) p->setErrorMessage(error_msg);
}

void azure_tts_set_result_id(azure_handle_t handle, const char* result_id) {
    auto p = azure_get_shared_ptr(handle);
    if (p && result_id) p->setResultId(result_id);
}

// State setters
void azure_tts_set_rate(azure_handle_t handle, int rate) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setRate(rate);
}

void azure_tts_set_draining(azure_handle_t handle, int draining) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setDraining(draining != 0);
}

void azure_tts_set_reads(azure_handle_t handle, int reads) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setReads(reads);
}

void azure_tts_set_cache_audio(azure_handle_t handle, int cache_audio) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setCacheAudio(cache_audio != 0);
}

void azure_tts_set_flushed(azure_handle_t handle, int flushed) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setFlushed(flushed != 0);
}

void azure_tts_set_playback_start_sent(azure_handle_t handle, int sent) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setPlaybackStartSent(sent != 0);
}

// Resource setters
void azure_tts_set_file(azure_handle_t handle, FILE* file) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setFile(file);
}

void azure_tts_set_resampler(azure_handle_t handle, void* resampler) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setResampler(static_cast<SpeexResamplerState*>(resampler));
}

void azure_tts_set_circular_buffer(azure_handle_t handle, void* buffer) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setCircularBuffer(buffer);
}

void azure_tts_set_start_time_now(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    if (p) {
        p->setStartTime(std::chrono::high_resolution_clock::now());
    }
}

// Last byte handling
void azure_tts_set_has_last_byte(azure_handle_t handle, int has) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setHasLastByte(has != 0);
}

void azure_tts_set_last_byte(azure_handle_t handle, uint8_t byte) {
    auto p = azure_get_shared_ptr(handle);
    if (p) p->setLastByte(byte);
}

void azure_tts_set_playback_id(azure_handle_t handle, const char* playback_id) {
    auto p = azure_get_shared_ptr(handle);
    if (p && playback_id) p->setPlaybackId(playback_id);
}

// Utility
int azure_tts_increment_reads(azure_handle_t handle) {
    auto p = azure_get_shared_ptr(handle);
    return p ? p->incrementReads() : 0;
}

} // extern "C"