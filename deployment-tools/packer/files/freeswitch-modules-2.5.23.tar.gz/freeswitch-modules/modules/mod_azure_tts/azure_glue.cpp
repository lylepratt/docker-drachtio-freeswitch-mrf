#include "mod_azure_tts.h"
#include "azure_wrapper.h"
#include "azure.hpp"
#include <switch.h>
#include <speechapi_cxx.h>

#include <boost/circular_buffer.hpp>

#include <cstdlib>
#include <string>
#include <chrono>
#include <thread>
#include <mutex>

#define BUFFER_SIZE 8129

typedef boost::circular_buffer<uint16_t> CircularBuffer_t;

using namespace Microsoft::CognitiveServices::Speech;

static const char* audioLogFile= std::getenv("AZURE_AUDIO_LOGGING");
static const char* frameTimeoutInterval = std::getenv("AZURE_SPEECH_SYNTHESIS_FRAME_TIMEOUT_INTERVAL");
static const char* rtfTimeoutThreshold = std::getenv("AZURE_SPEECH_SYNTHESIS_RTF_TIMEOUT_THRESHOLD");

static std::string fullDirPath;

static void start_synthesis(std::shared_ptr<AzureTts> azure, const char* text) {
    const char* session_id = azure->getSessionId().c_str();
    auto speechSynthesizer = azure->getActiveSynthesizer();
    if (!speechSynthesizer) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "%s start_synthesis: no active synthesizer\n",
            session_id ? session_id : "");
        azure->setResponseCode(500);
        azure->setErrorMessage("No active synthesizer");
        azure->setDraining(true);
        free((void*) text);
        return;
    }

    try {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s start_synthesis calling, text %s\n",
                        session_id ? session_id : "", text);
      auto result = std::strncmp(text, "<speak", 6) == 0 ?
        speechSynthesizer->SpeakSsmlAsync(text).get() :
        speechSynthesizer->SpeakTextAsync(text).get();

      if (result->Reason == ResultReason::SynthesizingAudioCompleted) {
        azure->setResponseCode(200);
        azure->setResultId(result->ResultId);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s start_synthesis completed id %s, audio data - bytes: %u, duration: %ldms\n",
          session_id ? session_id : "", result->ResultId.c_str(), result->GetAudioLength(), result->AudioDuration.count());
      } else if (result->Reason == ResultReason::Canceled) {
        auto cancellation = SpeechSynthesisCancellationDetails::FromResult(result);
        azure->setResponseCode(static_cast<long int>(cancellation->ErrorCode));
        azure->setErrorMessage(cancellation->ErrorDetails);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error synthesizing text %d with error string: %s.\n",
          session_id ? session_id : "", static_cast<int>(cancellation->ErrorCode), cancellation->ErrorDetails.c_str());
      } else {
        azure->setResponseCode(500);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error synthsize text %s (%d).\n",
                          session_id ? session_id : "", text, static_cast<int>(result->Reason));
      }
    } catch (const std::exception& e) {
        azure->setResponseCode(500);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s Exception in start_synthesis %s\n",
                          session_id ? session_id : "", e.what());
    }
    azure->setDraining(true);
    azure->setSynthesisInProgress(false);

    free((void*) text);
}

static void send_playback_start_event(azure_handle_t handle, switch_channel_t *channel, const char* time_to_first_byte_ms) {
    const char* session_id = azure_tts_get_session_id(handle);
    if (!channel) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s send_playback_start_event: channel is null\n",
                          session_id ? session_id : "");
        return;
    }

    switch_event_t *event;
    if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) != SWITCH_STATUS_SUCCESS) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s send_playback_start_event: failed to create event\n",
                          session_id ? session_id : "");
        return;
    }

    switch_channel_event_set_data(channel, event);
    const char* playback_id = azure_tts_get_playback_id(handle);
    const char* result_id = azure_tts_get_result_id(handle);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s send_playback_start_event: firing playback-started %s\n",
                      session_id ? session_id : "", playback_id ? playback_id : "no-playback-id");
    
    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
    if (playback_id) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
    }
    if (result_id) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_azure_result_id", result_id);
    }
    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms);
    
    // Only add cache filename if Synthesizing callback was called (reads > 0)
    if (azure_tts_get_reads(handle) > 0) {
        const char* cache_filename = azure_tts_get_cache_filename(handle);
        if (cache_filename) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);
        }
    }
    
    switch_event_fire(&event);
    azure_tts_set_playback_start_sent(handle, 1);
}

extern "C" {
  switch_status_t azure_speech_load() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "azure_speech_loading..\n");

    /* create temp folder for cache files */
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) {
      baseDir = "/tmp/";
    }
    if (strcmp(baseDir, "/") == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", baseDir);
      return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    // Create the directory with read, write, and execute permissions for everyone
    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);
    if (result != 0) {
      if (errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", fullDirPath.c_str());
        fullDirPath = "";
      }
      else switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "folder %s already exists\n", fullDirPath.c_str());
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "created folder %s\n", fullDirPath.c_str());
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "azure_speech_loaded..\n");

    return SWITCH_STATUS_SUCCESS;
  }

    switch_status_t azure_speech_open(azure_handle_t handle) {
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t azure_speech_feed_tts(azure_handle_t handle, char* text, switch_speech_flag_t *flags) {
    auto azure = azure_get_shared_ptr(handle);
    const char* session_id = azure_tts_get_session_id(handle);
    if (!azure) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s azure_speech_feed_tts: invalid handle\n",
                        session_id ? session_id : "");
      return SWITCH_STATUS_FALSE;
    }
    const int MAX_CHARS = 20;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s azure_speech_feed_tts %s\n",
                      session_id ? session_id : "", text);

    /* open cache file */
    if (azure_tts_is_cache_audio(handle) && fullDirPath.length() > 0) {
      switch_uuid_t uuid;
      char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
      char outfile[512] = "";
      int fd;

      switch_uuid_get(&uuid);
      switch_uuid_format(uuid_str, &uuid);

      switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
      azure_tts_set_cache_filename(handle, outfile);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s writing audio cache file to %s\n",
                        session_id ? session_id : "", azure_tts_get_cache_filename(handle));

      mode_t oldMask = umask(0);
      fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
      umask(oldMask);
      if (fd == -1 ) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error opening cache file %s: %s\n",
                          session_id ? session_id : "", outfile, strerror(errno));
      }
      else {
        FILE* file = fdopen(fd, "wb");
        azure_tts_set_file(handle, file);
        if (!file) {
          close(fd);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error opening cache file %s: %s\n",
                            session_id ? session_id : "", outfile, strerror(errno));
        }
      }
    }

    const char* api_key = azure_tts_get_api_key(handle);
    if (!api_key || strlen(api_key) == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s azure_speech_feed_tts: no api_key provided\n",
                        session_id ? session_id : "");
      return SWITCH_STATUS_FALSE;
    }

    const char* language = azure_tts_get_language(handle);
    if (!language || strlen(language) == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s azure_speech_feed_tts: no language provided\n",
                        session_id ? session_id : "");
      return SWITCH_STATUS_FALSE;
    }

    int rate = azure_tts_get_rate(handle);
    if (rate != 8000 /*Hz*/) {
      int err;
      SpeexResamplerState* resampler = speex_resampler_init(1, 8000, rate, SWITCH_RESAMPLE_QUALITY, &err);
      if (0 != err) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error initializing resampler: %s.\n",
                          session_id ? session_id : "", speex_resampler_strerror(err));
        return SWITCH_STATUS_FALSE;
      }
      azure_tts_set_resampler(handle, resampler);
    }

    azure_tts_set_start_time_now(handle);

    azure_tts_set_circular_buffer(handle, (void *) new CircularBuffer_t(BUFFER_SIZE));

    const char* endpoint = azure_tts_get_endpoint(handle);
    const char* region = azure_tts_get_region(handle);
    auto speechConfig = (endpoint && strlen(endpoint) > 0) ?
			((api_key && strlen(api_key) > 0) ?
				SpeechConfig::FromEndpoint(endpoint, api_key) :
				SpeechConfig::FromEndpoint(endpoint)) :
			SpeechConfig::FromSubscription(api_key, (region && strlen(region) > 0) ? region : "");

    speechConfig->SetSpeechSynthesisOutputFormat(SpeechSynthesisOutputFormat::Raw8Khz16BitMonoPcm);
    speechConfig->SetSpeechSynthesisLanguage(language);
    const char* voice_name = azure_tts_get_voice_name(handle);
    speechConfig->SetSpeechSynthesisVoiceName(voice_name);
    const char* http_proxy_ip = azure_tts_get_http_proxy_ip(handle);
    if (http_proxy_ip && strlen(http_proxy_ip) > 0) {
      const char* http_proxy_port = azure_tts_get_http_proxy_port(handle);
      uint32_t port = (http_proxy_port && strlen(http_proxy_port) > 0) ? static_cast<uint32_t>(std::stoul(http_proxy_port)) : 80;
      speechConfig->SetProxy(http_proxy_ip, port);
    }

    const char* endpoint_id = azure_tts_get_endpoint_id(handle);
    if (endpoint_id && strlen(endpoint_id) > 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s azure_speech_feed_tts setting endpoint id: %s\n",
                        session_id ? session_id : "", endpoint_id);
			speechConfig->SetEndpointId(endpoint_id);
		}

    if (audioLogFile) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s azure_speech_feed_tts enabling audio logging to %s\n",
                        session_id ? session_id : "", audioLogFile);
      speechConfig->SetProperty(PropertyId::Speech_LogFilename, audioLogFile);
      speechConfig->EnableAudioLogging();
    }

    // Set SpeechSynthesis timeout parameters from environment variables if provided
    if (frameTimeoutInterval && strlen(frameTimeoutInterval) > 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s azure_speech_feed_tts setting SpeechSynthesis_FrameTimeoutInterval to %s ms\n",
                        session_id ? session_id : "", frameTimeoutInterval);
      speechConfig->SetProperty(static_cast<PropertyId>(14101), frameTimeoutInterval);
    }

    if (rtfTimeoutThreshold && strlen(rtfTimeoutThreshold) > 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s azure_speech_feed_tts setting SpeechSynthesis_RtfTimeoutThreshold to %s\n",
                        session_id ? session_id : "", rtfTimeoutThreshold);
      speechConfig->SetProperty(static_cast<PropertyId>(14102), rtfTimeoutThreshold);
    }

    try {
      auto speechSynthesizer = SpeechSynthesizer::FromConfig(speechConfig, nullptr);

      // CRITICAL: Store synthesizer in the AzureTts object to control its lifetime
      // This prevents the synthesizer from being destroyed on a detached thread
      // which can cause crashes in the Azure SDK's async cleanup path
      azure->setActiveSynthesizer(speechSynthesizer);
      azure->setSynthesisInProgress(true);

      // CRITICAL: Single retain for ALL lambda callbacks
      azure_tts_retain(handle);

      speechSynthesizer->SynthesisStarted += [handle](const SpeechSynthesisEventArgs& e) {
          auto azure = azure_get_shared_ptr(handle);
          if (azure) {
            const char* session_id = azure_tts_get_session_id(handle);
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s azure_speech_feed_tts SynthesisStarted\n",
                              session_id ? session_id : "");
          }
      };

      speechSynthesizer->Synthesizing += [handle](const SpeechSynthesisEventArgs& e) {
        auto azure = azure_get_shared_ptr(handle);
        if (!azure || azure_tts_is_flushed(handle)) {
          return;
        }

        // Store the result ID if available and not already set
        if (e.Result && !e.Result->ResultId.empty()) {
            const char* current_result_id = azure_tts_get_result_id(handle);
            if (!current_result_id || strlen(current_result_id) == 0) {
                azure_tts_set_result_id(handle, e.Result->ResultId.c_str());
            }
        }

        bool fireEvent = false;
        size_t total_bytes_to_process;

        auto audioData = e.Result->GetAudioData();
        auto bytes_received = audioData->size();
        // Buffer to hold combined data if there is unprocessed byte from the last call.
        std::unique_ptr<uint8_t[]> combinedData;
        if (azure_tts_has_last_byte(handle)) {
          azure_tts_set_has_last_byte(handle, 0);  // We'll handle the last_byte now, so toggle the flag off

          // Allocate memory for the new data array
          combinedData.reset(new uint8_t[bytes_received + 1]);

          // Prepend the last byte from previous call
          combinedData[0] = azure_tts_get_last_byte(handle);

          // Copy the new data following the prepended byte
          memcpy(combinedData.get() + 1, audioData->data(), bytes_received);

          total_bytes_to_process = bytes_received + 1;
        } else {
          // Allocate memory for the new data array
          combinedData.reset(new uint8_t[bytes_received]);
          memcpy(combinedData.get(), audioData->data(), bytes_received);
          total_bytes_to_process = bytes_received;
        }

        // If we now have an odd total, save the last byte for next time
        auto data = combinedData.get();
        if ((total_bytes_to_process % sizeof(int16_t)) != 0) {
          azure_tts_set_last_byte(handle, data[total_bytes_to_process - 1]);
          azure_tts_set_has_last_byte(handle, 1);
          total_bytes_to_process--;
        }

        FILE* file = azure_tts_get_file(handle);
        if (file) {
          fwrite(data, 1, total_bytes_to_process, file);
        }

        /**
         * this sort of reinterpretation can be dangerous as a general rule, but in this case we know that the data
         * is 16-bit PCM, so it's safe to do this and its much faster than copying the data byte by byte
         */
        const uint16_t* begin = reinterpret_cast<const uint16_t*>(data);
        const uint16_t* end = reinterpret_cast<const uint16_t*>(data + total_bytes_to_process);

        /* lock as briefly as possible */
        {
          std::lock_guard<std::mutex> lock(azure->getMutex());
          // CRITICAL: Must re-fetch buffer pointer after acquiring lock to avoid race with flush
          // The flush function may have set this to nullptr while we were processing audio data
          CircularBuffer_t *cBuffer = (CircularBuffer_t *) azure_tts_get_circular_buffer(handle);
          if (!cBuffer) {
            // Buffer was deleted by flush, silently discard this audio data
            return;
          }
          if (cBuffer->capacity() - cBuffer->size() < total_bytes_to_process) {
            cBuffer->set_capacity(cBuffer->size() + std::max( total_bytes_to_process, (size_t)BUFFER_SIZE));
          }
          cBuffer->insert(cBuffer->end(), begin, end);
        }

        // the counter increase then reads, so value is 1 on first read
        if (1 == azure_tts_increment_reads(handle)) {
          fireEvent = true;
        }

        const char* session_id = azure_tts_get_session_id(handle);
        if (fireEvent && session_id) {
          auto endTime = std::chrono::high_resolution_clock::now();
          auto startTime = azure->getStartTime();
          auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
          auto time_to_first_byte_ms = std::to_string(duration.count());
          switch_core_session_t* session = switch_core_session_locate(session_id);
          if (session) {
            switch_channel_t *channel = switch_core_session_get_channel(session);
            switch_core_session_rwunlock(session);
            if (channel) {
              send_playback_start_event(handle, channel, time_to_first_byte_ms.c_str());
            }else {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s speechSynthesizer->Synthesizing: channel not found\n",
                                session_id ? session_id : "");
            }
          }
        }
        // NOTE: Do not release here! Lambda may be called multiple times during synthesis
      };

      // CRITICAL: Completion callbacks release the handle but do NOT clear the synthesizer
      // The synthesizer will be cleared by flush_tts or close, which runs on the main thread
      speechSynthesizer->SynthesisCompleted += [handle](const SpeechSynthesisEventArgs& e) {
        const char* session_id = azure_tts_get_session_id(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "%s SynthesisCompleted: synthesis finished, releasing lambda handle\n",
            session_id ? session_id : "");
        auto azure = azure_get_shared_ptr(handle);
        if (azure) {
            azure->setSynthesisInProgress(false);
        }
        azure_tts_release(handle);  // Release the single handle retained for all lambdas
      };

      speechSynthesizer->SynthesisCanceled += [handle](const SpeechSynthesisEventArgs& e) {
        const char* session_id = azure_tts_get_session_id(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "%s SynthesisCanceled: synthesis canceled, releasing lambda handle\n",
            session_id ? session_id : "");
        auto azure = azure_get_shared_ptr(handle);
        if (azure) {
            azure->setSynthesisInProgress(false);
        }
        azure_tts_release(handle);  // Release the single handle retained for all lambdas
      };

      const char* dupText = strdup(text); // text will be freed in the thread

      // CRITICAL: Retain handle for detached thread safety
      // The thread does NOT capture speechSynthesizer - it gets it from the azure object
      // This ensures the synthesizer is destroyed on a controlled thread (flush/close)
      // rather than when this detached thread ends
      azure_tts_retain(handle);
      std::thread([handle, dupText]() {
        auto azure = azure_get_shared_ptr(handle);
        if (azure) {
          start_synthesis(azure, dupText);
        } else {
          free((void*)dupText);
        }
        azure_tts_release(handle);  // Release when thread completes
      }).detach();
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s azure_speech_feed_tts sent synthesize request\n",
                        session_id ? session_id : "");
    } catch (const std::exception& e) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Exception: %s\n",
                        session_id ? session_id : "", e.what());
      return SWITCH_STATUS_FALSE;
    }
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t azure_speech_read_tts(azure_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    auto azure = azure_get_shared_ptr(handle);
    if (!azure) {
      return SWITCH_STATUS_FALSE;
    }

    CircularBuffer_t *cBuffer = (CircularBuffer_t *) azure_tts_get_circular_buffer(handle);
    std::vector<uint16_t> pcm_data;

    long response_code = azure_tts_get_response_code(handle);
    if (response_code > 0 && response_code != 200) {
      const char* session_id = azure_tts_get_session_id(handle);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s azure_speech_read_tts, returning failure\n",
                        session_id ? session_id : "");
      return SWITCH_STATUS_FALSE;
    }
    if (azure_tts_is_flushed(handle)) {
      return SWITCH_STATUS_BREAK;
    }

    size_t bufSize;
    {
      std::lock_guard<std::mutex> lock(azure->getMutex());
      bufSize = cBuffer->size();
      if (cBuffer->empty()) {
        if (azure_tts_is_draining(handle)) {
          return SWITCH_STATUS_BREAK;
        }
        /* no audio available yet so send silence */
        memset(data, 255, *datalen);
        return SWITCH_STATUS_SUCCESS;
      }
      // azure returned 8000hz 16 bit data, we have to take enough data based on call sample rate.
      int rate = azure_tts_get_rate(handle);
      size_t size = std::min((*datalen/(2 * rate / 8000)), bufSize);
      pcm_data.insert(pcm_data.end(), cBuffer->begin(), cBuffer->begin() + size);
      cBuffer->erase(cBuffer->begin(), cBuffer->begin() + size);
    }

    size_t data_size = pcm_data.size();

    void* resampler = azure_tts_get_resampler(handle);
    if (resampler) {
        std::vector<int16_t> in(pcm_data.begin(), pcm_data.end());

        std::vector<int16_t> out((*datalen));
        spx_uint32_t in_len = data_size;
        spx_uint32_t out_len = out.size();

        speex_resampler_process_interleaved_int((SpeexResamplerState*)resampler, in.data(), &in_len, out.data(), &out_len);

        if (out_len > out.size()) {
          const char* session_id = azure_tts_get_session_id(handle);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_CRIT, "%s Resampler output exceeded maximum buffer size!\n",
                            session_id ? session_id : "");
          return SWITCH_STATUS_FALSE;
        }

        memcpy(data, out.data(), out_len * sizeof(int16_t));
        *datalen = out_len * sizeof(int16_t);
    } else {
        memcpy(data, pcm_data.data(), data_size * sizeof(int16_t));
        *datalen = data_size * sizeof(int16_t);
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t azure_speech_flush_tts(azure_handle_t handle) {
    auto azure = azure_get_shared_ptr(handle);
    if (!azure) {
      return SWITCH_STATUS_FALSE;
    }

    const char* session_id = azure_tts_get_session_id(handle);
    long response_code = azure_tts_get_response_code(handle);
    bool download_complete = response_code == 200;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s azure_speech_flush_tts, download complete? %s\n",
                      session_id ? session_id : "", download_complete ? "yes" : "no");

    // CRITICAL: Clear the synthesizer FIRST, on this thread (not a detached thread)
    // This ensures StopSpeakingAsync is called and the synthesizer destructor runs safely
    azure->clearActiveSynthesizer();

    // CRITICAL: Must hold mutex when accessing/deleting the circular buffer
    // to prevent race with Synthesizing callback which may be inside set_capacity()
    CircularBuffer_t *cBuffer = nullptr;
    {
      std::lock_guard<std::mutex> lock(azure->getMutex());
      cBuffer = (CircularBuffer_t *) azure_tts_get_circular_buffer(handle);
      if (cBuffer) {
        // Nullify the pointer while holding the lock so callback sees it's gone
        azure_tts_set_circular_buffer(handle, nullptr);
      }
    }
    // Delete outside the lock to avoid holding mutex during deallocation
    if (cBuffer) {
      delete cBuffer;
    }

    azure_tts_set_flushed(handle, 1);
    if (!download_complete) {
      FILE* file = azure_tts_get_file(handle);
      if (file) {
        //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s closing audio cache file %s because download was interrupted\n", session_id ? session_id : "", azure_tts_get_cache_filename(handle));
        if (fclose(file) != 0) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s error closing audio cache file\n",
                            session_id ? session_id : "");
        }
        azure_tts_set_file(handle, nullptr);
      }
    }
    // If playback_start has not been sent, delete the file
    const char* cache_filename = azure_tts_get_cache_filename(handle);
    if (cache_filename && !azure_tts_is_playback_start_sent(handle)) {
      //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s removing audio cache file %s because download was interrupted\n", session_id ? session_id : "", cache_filename);
      if (unlink(cache_filename) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s cleanupConn: error removing audio cache file %s: %d:%s\n",
          session_id ? session_id : "", cache_filename, errno, strerror(errno));
      }
      azure_tts_set_cache_filename(handle, nullptr);
    }
    if (session_id) {
      switch_core_session_t* session = switch_core_session_locate(session_id);
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);

        /* unlock as quickly as possible */
        switch_core_session_rwunlock(session);
        if (channel) {
          // Check if PLAYBACK_START was never sent and send it now if needed
          if (!azure_tts_is_playback_start_sent(handle)) {

            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s azure_speech_flush_tts: Synthesizing callback was never called, sending delayed playback-started event\n",
                              session_id ? session_id : "");
            send_playback_start_event(handle, channel, "0");

            // Add 100ms delay before sending PLAYBACK_STOP
            switch_yield(100000);
          }

          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);
            const char* playback_id = azure_tts_get_playback_id(handle);
            const char* result_id = azure_tts_get_result_id(handle);
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s azure_speech_flush_tts: firing playback-stopped %s\n",
                            session_id ? session_id : "", playback_id ? playback_id : "no-playback-id");
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (playback_id) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
            }
            if (result_id) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_azure_result_id", result_id);
            }
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_azure_response_code", std::to_string(response_code).c_str());
            if (cache_filename && download_complete && azure_tts_get_reads(handle) > 0) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);
            }
            const char* error_message = azure_tts_get_error_message(handle);
            if (!download_complete && error_message) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", error_message);
            }
            switch_event_fire(&event);
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: failed to create event\n",
                              session_id ? session_id : "");
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: channel not found\n",
                            session_id ? session_id : "");
        }
      }
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t azure_speech_close(azure_handle_t handle) {
    auto azure = azure_get_shared_ptr(handle);
    if (!azure) {
      return SWITCH_STATUS_FALSE;
    }

    const char* session_id = azure_tts_get_session_id(handle);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s azure_speech_close\n",
                      session_id ? session_id : "");

    // CRITICAL: Ensure synthesizer is cleaned up on close as well
    // In case flush wasn't called or synthesis is still in progress
    azure->clearActiveSynthesizer();

    void* resampler = azure_tts_get_resampler(handle);
    if (resampler) {
      speex_resampler_destroy((SpeexResamplerState*)resampler);
      azure_tts_set_resampler(handle, nullptr);
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t azure_speech_unload() {
    return SWITCH_STATUS_SUCCESS;
  }

}