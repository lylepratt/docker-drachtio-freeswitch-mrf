#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>

#include "mod_openai_transcribe.h"
#include "parser.hpp"
#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/

namespace {
  static const char* emptyTranscript = "\"results\":[]";
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static const char* defaultApiKey = nullptr;
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static const char *requestedNumServiceThreads = std::getenv("MOD_AUDIO_FORK_SERVICE_THREADS");
  static unsigned int idxCallCount = 0;
  static uint32_t playCount = 0;


  static void reaper(private_t *tech_pvt) {
    std::string sessionId(tech_pvt->sessionId);
    unsigned int id = tech_pvt->id;
    std::shared_ptr<openai::AudioPipe> pAp;

    pAp.reset((openai::AudioPipe *)tech_pvt->pAudioPipe);
    tech_pvt->pAudioPipe = nullptr;

    std::thread t([pAp, sessionId, id]{
      pAp->finish();
      pAp->waitForClose();
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) got remote close\n", sessionId.c_str(), id);
    });
    t.detach();
  }

  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      if (tech_pvt->resampler) {
        speex_resampler_destroy(tech_pvt->resampler);
        tech_pvt->resampler = nullptr;
      }
      if (tech_pvt->pAudioPipe) {
        openai::AudioPipe* p = (openai::AudioPipe *) tech_pvt->pAudioPipe;
        delete p;
        tech_pvt->pAudioPipe = nullptr;
      }
      if (tech_pvt->prompt) {
        free(tech_pvt->prompt);
      }

      // NB: do not destroy the mutex here, that is caller responsibility

      /*
      if (tech_pvt->vad) {
        switch_vad_destroy(&tech_pvt->vad);
        tech_pvt->vad = nullptr;
      }
      */
    }
  }

  static cJSON *build_start_recognition_request(switch_channel_t *channel, const char *language, int interim, int sampling, const char *prompt) {
    const char* model = switch_channel_get_variable(channel, "OPENAI_MODEL");
    const char* turn_detection_type = switch_channel_get_variable(channel, "OPENAI_TURN_DETECTION_TYPE");
    const char* turn_detection_threshold = switch_channel_get_variable(channel, "OPENAI_TURN_DETECTION_THRESHOLD");
    const char* turn_detection_prefix_padding_ms = switch_channel_get_variable(channel, "OPENAI_TURN_DETECTION_PREFIX_PADDING_MS");
    const char* turn_detection_silence_duration_ms = switch_channel_get_variable(channel, "OPENAI_TURN_DETECTION_SILENCE_DURATION_MS");
    const char* turn_detection_eagerness = switch_channel_get_variable(channel, "OPENAI_TURN_DETECTION_EAGERNESS");
    const char* input_audio_noise_reduction = switch_channel_get_variable(channel, "OPENAI_INPUT_AUDIO_NOISE_REDUCTION");

    // Create the root object
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "type", "transcription_session.update");

    cJSON *session = cJSON_CreateObject();
    cJSON_AddItemToObject(root, "session", session);

    cJSON_AddStringToObject(session, "input_audio_format", "pcm16");

    // "input_audio_transcription"
    cJSON *input_audio_transcription = cJSON_CreateObject();
    cJSON_AddStringToObject(input_audio_transcription, "model", model ? model : "whisper-1");
    if (prompt) {
      cJSON_AddStringToObject(input_audio_transcription, "prompt", prompt);
    }
    if (language && 0 != strcmp(language, "auto")) {
      cJSON_AddStringToObject(input_audio_transcription, "language", language);
    }
    cJSON_AddItemToObject(session, "input_audio_transcription", input_audio_transcription);

    // "turn_detection"
    cJSON *turn_detection = cJSON_CreateObject();
    cJSON_AddStringToObject(turn_detection, "type", turn_detection_type ? turn_detection_type : "server_vad");
    if (!turn_detection_type || 0 != strcmp(turn_detection_type, "none")) {
      if (turn_detection_threshold) {
        cJSON_AddNumberToObject(turn_detection, "threshold", atof(turn_detection_threshold));
      }
      if (turn_detection_prefix_padding_ms) {
        cJSON_AddNumberToObject(turn_detection, "prefix_padding_ms", atoi(turn_detection_prefix_padding_ms));
      }
      if (turn_detection_silence_duration_ms) {
        cJSON_AddNumberToObject(turn_detection, "silence_duration_ms", atoi(turn_detection_silence_duration_ms));
      }
      // eagerness is only valid for semantic_vad type
      if (turn_detection_eagerness && turn_detection_type && 0 == strcmp(turn_detection_type, "semantic_vad")) {
        cJSON_AddStringToObject(turn_detection, "eagerness", turn_detection_eagerness);
      }
    }
    cJSON_AddItemToObject(session, "turn_detection", turn_detection);

    // "input_audio_noise_reduction"
    if (input_audio_noise_reduction) {
      cJSON *obj = cJSON_CreateObject();
      cJSON_AddStringToObject(obj, "type", input_audio_noise_reduction);
      cJSON_AddItemToObject(session, "input_audio_noise_reduction", obj);
    }

    // "include"
    cJSON *include = cJSON_CreateArray();
    cJSON_AddItemToArray(include, cJSON_CreateString("item.input_audio_transcription.logprobs"));
    cJSON_AddItemToObject(session, "include", include);

    return root;  // caller is responsible for deleting this object using cJSON_Delete
  }

  static void sendStartRecognitionRequest(switch_channel_t *channel, openai::AudioPipe* pAudioPipe, private_t* tech_pvt) {
    cJSON *json = build_start_recognition_request(channel, tech_pvt->lang, tech_pvt->interim, tech_pvt->sampling, tech_pvt->prompt);
    const char* jsonStr = cJSON_PrintUnformatted(json);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s sendStartRecognitionRequest %s.\n", tech_pvt->sessionId, jsonStr);
    pAudioPipe->bufferForSending(jsonStr);
    free((void*)jsonStr);
    cJSON_Delete(json);
  }

  static void eventCallback(const char* sessionId, const char* bugname, 
    openai::AudioPipe::NotifyEvent_t event, const char* message, bool finished) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case openai::AudioPipe::CONNECT_SUCCESS:
            {
              auto *pAudioPipe = static_cast<openai::AudioPipe*>(tech_pvt->pAudioPipe);
              tech_pvt->state = SESSION_STATE_WS_CONNECTED;
              sendStartRecognitionRequest(channel, pAudioPipe, tech_pvt);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) successful\n", tech_pvt->bugname);
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_SUCCESS, NULL, tech_pvt->bugname, finished);
            }
            break;
            case openai::AudioPipe::CONNECT_FAIL:
            tech_pvt->state = SESSION_STATE_NONE;
            {
              // first thing: we can no longer access the AudioPipe
              std::stringstream json;
              json << "{\"reason\":\"" << message << "\"}";
              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_FAIL, (char *) json.str().c_str(), tech_pvt->bugname, finished);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
            }
            break;
            case openai::AudioPipe::CONNECTION_DROPPED:
              // first thing: we can no longer access the AudioPipe

              /**
               * this is a bit tricky.  If we just closed a previos connection it may be returning final transcripts
               * and then a close event here as it is shutting down (in the reaper thread above).
               * In this scenario, the fact that the connection is dropped is not significant.
               */
              if (finished) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "old connection (%s) gracefully closed by Openai\n", tech_pvt->bugname);
              }
              else {
                tech_pvt->state = SESSION_STATE_NONE;
                tech_pvt->pAudioPipe = nullptr;
                tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_DISCONNECT, NULL, tech_pvt->bugname, finished);
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) dropped from far end\n", tech_pvt->bugname);
              }
            break;
            case openai::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              tech_pvt->state = SESSION_STATE_NONE;
              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
            break;
            case openai::AudioPipe::MESSAGE:
            {
              bool notify = false;
              std::string eventType;
              cJSON *msg = cJSON_Parse(message);
              if (!msg) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error parsing message from openai %s\n", message);
                return;
              }
              else {
                const char* msgType = cJSON_GetStringValue(cJSON_GetObjectItem(msg, "type"));
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "openai message (%s): %s\n", tech_pvt->bugname, message);

                if (msgType && 0 == strcmp(msgType, "transcription_session.created")) {
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "start sending audio\n");
                  tech_pvt->state = SESSION_STATE_CONVERSATION_STARTED;
                }
                else if (msgType && 0 == strcmp(msgType, "conversation.item.input_audio_transcription.completed")) {
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "input audio transcription completed\n");
                  eventType = TRANSCRIBE_EVENT_RESULTS;
                  notify = true;
                }
                else if (msgType && 0 == strcmp(msgType, "input_audio_buffer.speech_started")) {
                  eventType = TRANSCRIBE_EVENT_SPEECH_STARTED;
                  notify = true;
                }
                else if (msgType && 0 == strcmp(msgType, "input_audio_buffer.speech_stopped")) {
                  eventType = TRANSCRIBE_EVENT_SPEECH_STOPPED;
                  notify = true;
                }
                else if (switch_true(switch_channel_get_variable(channel, "OPENAI_WANT_PARTIALS")) &&
                  msgType && 0 == strcmp(msgType, "conversation.item.input_audio_transcription.delta")) {
                  eventType = TRANSCRIBE_EVENT_PARTIAL_TRANSCRIPT;
                  notify = true;
                }
                
                if (notify) {
                  tech_pvt->responseHandler(session, eventType.c_str(), message, tech_pvt->bugname, finished);
                }

                cJSON_Delete(msg);
              }
            }
                  
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from openai %d:%s\n", event, message);
              break;
          }
        }
      }
      switch_core_session_rwunlock(session);
    }
  }
  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, 
    int sampling, int desiredSampling, int channels, char* lang, int interim, 
    char* bugname, char* prompt, responseHandler_t responseHandler) {

    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_codec_implementation_t read_impl;
    int err;

    const char* api_key = switch_channel_get_variable(channel, "OPENAI_API_KEY");
    if (!api_key) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no openai api key provided!\n");
      return SWITCH_STATUS_FALSE;
    }
    const char* host = "api.openai.com";
    const char* path = "v1/realtime?intent=transcription";  //TODO: support translation

    int port = 443;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * desiredSampling / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "fork_data_init: api key %s\n", api_key);

    switch_core_session_get_read_impl(session, &read_impl);
  
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->host, host, MAX_WS_URL_LEN);
    tech_pvt->port = port;
    strncpy(tech_pvt->path, path, MAX_PATH_LEN);   
    tech_pvt->sampling = sampling;
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->channels = channels;
    tech_pvt->id = ++idxCallCount;
    tech_pvt->buffer_overrun_notified = 0;
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    strncpy(tech_pvt->lang, lang, MAX_LANG);
    tech_pvt->interim = interim;
    if (prompt) tech_pvt->prompt = strdup(prompt);

    if (desiredSampling != sampling) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) resampling user audio from %u to %u\n", tech_pvt->id, sampling, desiredSampling);
      tech_pvt->resampler = speex_resampler_init(1, sampling, desiredSampling, SWITCH_RESAMPLE_QUALITY, &err);
      if (0 != err) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing resampler: %s.\n", speex_resampler_strerror(err));
        return SWITCH_STATUS_FALSE;
      }
    }

    openai::AudioPipe* ap = new openai::AudioPipe(tech_pvt->sessionId, bugname, tech_pvt->host, tech_pvt->port, tech_pvt->path, 
      buflen, read_impl.decoded_bytes_per_packet, api_key, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }

    tech_pvt->pAudioPipe = static_cast<void *>(ap);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now\n");
    ap->connect();
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");

    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
    
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) fork_data_init\n", tech_pvt->id);

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {
  switch_status_t openai_transcribe_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_openai_transcribe: audio buffer (in secs):    %d secs\n", nAudioBufferSecs);
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    openai::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t openai_transcribe_cleanup() {
    bool cleanup = false;
    cleanup = openai::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }
	
  switch_status_t openai_transcribe_session_init(switch_core_session_t *session, 
    responseHandler_t responseHandler, uint32_t samples_per_second, uint32_t channels, 
    char* lang, int interim, char* bugname, char* prompt, void **ppUserData)
  {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    private_t* tech_pvt;

    tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }
    memset(tech_pvt, 0, sizeof(private_t));

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second, 24000, channels,
      lang, interim, bugname, prompt, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;

    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t openai_transcribe_session_stop(switch_core_session_t *session,int channelIsClosing, char* bugname) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "openai_transcribe_session_stop: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    uint32_t id = tech_pvt->id;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) openai_transcribe_session_stop\n", id);

    if (!tech_pvt) return SWITCH_STATUS_FALSE;
      
    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);
    switch_channel_set_private(channel, bugname, NULL);
    if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

    openai::AudioPipe *pAudioPipe = static_cast<openai::AudioPipe *>(tech_pvt->pAudioPipe);
    if (pAudioPipe) reaper(tech_pvt);
    destroy_tech_pvt(tech_pvt);
    switch_mutex_unlock(tech_pvt->mutex);
    /* mutex allocated from session pool - automatically cleaned up */
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) openai_transcribe_session_stop\n", id);
    return SWITCH_STATUS_SUCCESS;
  }
	
	switch_bool_t openai_transcribe_frame(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    size_t inuse = 0;
    bool dirty = false;
    char *p = (char *) "{\"msg\": \"buffer overrun\"}";

    if (!tech_pvt) return SWITCH_TRUE;
        
    /* dont send audio until initial response.created is received */
    if (tech_pvt->state != SESSION_STATE_CONVERSATION_STARTED) {
      return SWITCH_TRUE;
    }

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      if (!tech_pvt->pAudioPipe) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      openai::AudioPipe *pAudioPipe = static_cast<openai::AudioPipe *>(tech_pvt->pAudioPipe);
      if (pAudioPipe->getLwsState() != openai::AudioPipe::LWS_CLIENT_CONNECTED) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      pAudioPipe->lockAudioBuffer();
      size_t available = pAudioPipe->binarySpaceAvailable();

      if (NULL == tech_pvt->resampler) {
        switch_frame_t frame = { 0 };
        frame.data = pAudioPipe->binaryWritePtr();
        frame.buflen = available;
        while (true) {

          // check if buffer would be overwritten; dump packets if so
          if (available < pAudioPipe->binaryMinSpace()) {
            if (!tech_pvt->buffer_overrun_notified) {
              tech_pvt->buffer_overrun_notified = 1;
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
            }
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n", 
              tech_pvt->id);
            pAudioPipe->binaryWritePtrResetToZero();

            frame.data = pAudioPipe->binaryWritePtr();
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          }

          switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
          if (rv != SWITCH_STATUS_SUCCESS) break;
          if (frame.datalen) {
            pAudioPipe->binaryWritePtrAdd(frame.datalen);
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
            frame.data = pAudioPipe->binaryWritePtr();
            dirty = true;
          }
        }
      }
      else {
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = { 0 };
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;
        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
          if (frame.datalen) {
            spx_uint32_t out_len = available >> 1;  // space for samples which are 2 bytes
            spx_uint32_t in_len = frame.samples;

            speex_resampler_process_int(tech_pvt->resampler, 0,
              (const spx_int16_t *) frame.data, 
              (spx_uint32_t *) &in_len, 
              (spx_int16_t *) ((char *) pAudioPipe->binaryWritePtr()),
              &out_len);

            if (out_len > 0) {
              size_t bytes_written = out_len << 1;
              pAudioPipe->binaryWritePtrAdd(bytes_written);
              available = pAudioPipe->binarySpaceAvailable();
              dirty = true;
            }
            if (available < pAudioPipe->binaryMinSpace()) {
              if (!tech_pvt->buffer_overrun_notified) {
                tech_pvt->buffer_overrun_notified = 1;
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n", 
                  tech_pvt->id);
                tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
              }
              break;
            }
          }
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}
