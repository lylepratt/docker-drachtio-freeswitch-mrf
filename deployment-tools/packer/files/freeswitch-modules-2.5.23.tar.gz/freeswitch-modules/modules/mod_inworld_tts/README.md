# mod_inworld_tts

A Freeswitch module that allows speak text to speech audio from inworld stream.