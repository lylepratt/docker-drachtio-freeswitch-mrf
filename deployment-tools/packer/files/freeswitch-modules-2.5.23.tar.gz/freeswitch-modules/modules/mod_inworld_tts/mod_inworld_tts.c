#include "inworld_wrapper.h"
#include "inworld_glue.h"
#include <stdatomic.h>

SWITCH_MODULE_LOAD_FUNCTION(mod_inworld_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_inworld_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_inworld_tts, mod_inworld_tts_load, mod_inworld_tts_shutdown, NULL);

static void clearInWorld(inworld_handle_t handle, int freeAll) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "clearInWorld\n");
  
  // Clear all string properties
  inworld_set_api_key(handle, NULL);
  inworld_set_model_id(handle, NULL);
  inworld_set_temperature(handle, NULL);
  inworld_set_pitch(handle, NULL);
  inworld_set_speakingRate(handle, NULL);

  // Clear result data
  inworld_set_content_type(handle, NULL);
  inworld_set_error_message(handle, NULL);
  inworld_set_name_lookup_time_ms(handle, NULL);
  inworld_set_connect_time_ms(handle, NULL);
  inworld_set_final_response_time_ms(handle, NULL);
  inworld_set_cache_filename(handle, NULL);
  inworld_set_x_envoy_upstream_service_time(handle, NULL);

  if (freeAll) {
    inworld_set_voice_name(handle, NULL);
    inworld_set_session_id(handle, NULL);
  }
}

static inworld_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  inworld_handle_t handle = (inworld_handle_t) sh->private_info;  
  if (!handle) {
    handle = inworld_create();
    if (handle) {
      // Mutex initialization removed - std::mutex is now managed internally by InWorld class
      sh->private_info = handle;
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "allocated inworld_handle_t\n");
    }
  }
  return handle;
}

switch_status_t p_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  inworld_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to create inworld handle\n");
    return SWITCH_STATUS_FALSE;
  }
  
  inworld_set_voice_name(handle, voice_name);
  inworld_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "p_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
  return inworld_speech_open(handle);
}

static switch_status_t p_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  inworld_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_close\n");

  rc = inworld_speech_close(handle);
  clearInWorld(handle, 1);
  
  // Release the handle
  if (handle) {
    inworld_release(handle);
    sh->private_info = NULL;
  }
  
  return rc;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t p_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  inworld_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "No inworld handle available\n");
    return SWITCH_STATUS_FALSE;
  }
  
  inworld_set_draining(handle, 0);
  inworld_set_reads(handle, 0);
  inworld_set_response_code(handle, 0);
  inworld_set_error_message(handle, NULL);
  inworld_set_playback_start_sent(handle, 0);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_feed_tts\n");

  return inworld_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t p_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  inworld_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "No inworld handle available\n");
    return SWITCH_STATUS_FALSE;
  }
  
  return inworld_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void p_speech_flush_tts(switch_speech_handle_t *sh)
{
  inworld_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_flush_tts\n");
  inworld_speech_flush_tts(handle);

  clearInWorld(handle, 0);
}

static void p_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  inworld_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "No inworld handle available\n");
    return;
  }

  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_text_param_tts: %s=XXXXX\n", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_text_param_tts: %s=%s\n", param, val);
  }

  if (0 == strcmp(param, "api_key")) {
    inworld_set_api_key(handle, val);
  } else if (0 == strcmp(param, "model_id")) {
    inworld_set_model_id(handle, val);
  } else if (0 == strcmp(param, "temperature")) {
    inworld_set_temperature(handle, val);
  } else if (0 == strcmp(param, "pitch")) {
    inworld_set_pitch(handle, val);
  } else if (0 == strcmp(param, "speakingRate")) {
    inworld_set_speakingRate(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    inworld_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    inworld_set_cache_audio(handle, 1);
  } else if (0 == strcmp(param, "playback_id")) {
    inworld_set_playback_id(handle, val);
  }

}

static void p_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}

static void p_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_inworld_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "inworld";
  speech_interface->speech_open = p_speech_open;
  speech_interface->speech_close = p_speech_close;
  speech_interface->speech_feed_tts = p_speech_feed_tts;
  speech_interface->speech_read_tts = p_speech_read_tts;
	speech_interface->speech_flush_tts = p_speech_flush_tts;
	speech_interface->speech_text_param_tts = p_text_param_tts;
	speech_interface->speech_numeric_param_tts = p_numeric_param_tts;
	speech_interface->speech_float_param_tts = p_float_param_tts;
  return inworld_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_inworld_tts_shutdown)
{
  return inworld_speech_unload();
}