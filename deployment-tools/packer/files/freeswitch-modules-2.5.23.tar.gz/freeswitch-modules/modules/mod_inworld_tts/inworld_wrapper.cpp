#include "inworld_wrapper.h"
#include "inworld.hpp" // Your C++ class header
#include <memory>
#include <mutex>
#include <unordered_map>

// Internal handle structure
struct inworld_handle {
    std::shared_ptr<InWorld> instance;
    int ref_count;
    std::mutex ref_mutex;
    
    inworld_handle(std::shared_ptr<InWorld> inst) 
        : instance(std::move(inst)), ref_count(1) {
             switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "inworld_handle initialized with ref_count %d\n", ref_count);
        }
};

// Thread-safe handle management
static std::mutex g_handle_mutex;
static std::unordered_map<inworld_handle_t, std::unique_ptr<inworld_handle>> g_handles;

// Helper function to validate handle
static inworld_handle* get_handle(inworld_handle_t handle) {
    if (!handle) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second.get() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
// Mutex getter function removed - std::mutex is now managed internally by InWorld class

// Private internal function for C++ code only (not exposed to C)
std::shared_ptr<InWorld> inworld_get_shared_ptr(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance : nullptr;
}

// Private internal function to get handle from shared_ptr
inworld_handle_t inworld_get_handle_from_shared_ptr(const std::shared_ptr<InWorld>& ptr) {
    if (!ptr) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->instance == ptr) {
            return pair.first;
        }
    }
    return nullptr;
}

// C API Implementation
extern "C" {

inworld_handle_t inworld_create(void) {
    try {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "inworld_create\n");

        auto instance = InWorld::create();
        auto handle = std::make_unique<inworld_handle>(instance);
        inworld_handle_t handle_ptr = handle.get();
        
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles[handle_ptr] = std::move(handle);
        
        return handle_ptr;
    } catch (...) {
        return nullptr;
    }
}

void inworld_retain(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    if (h) {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "inworld_retain, ref count %d\n", h->ref_count);
    }
}

void inworld_release(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    if (!h) return;
    
    bool should_delete = false;
    {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count--;
        should_delete = (h->ref_count <= 0);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "inworld_release, ref count %d\n", h->ref_count);
 }
    
    if (should_delete) {
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles.erase(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "inworld_release, handle erased\n");
    }
}

// Getters
const char* inworld_get_voice_name(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceName().c_str() : nullptr;
}

const char* inworld_get_api_key(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getApiKey().c_str() : nullptr;
}

const char* inworld_get_model_id(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getModelId().c_str() : nullptr;
}

const char* inworld_get_temperature(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getTemperature().c_str() : nullptr;
}

const char* inworld_get_pitch(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPitch().c_str() : nullptr;
}

const char* inworld_get_speakingRate(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSpeakingRate().c_str() : nullptr;
}

// Result data getters
long inworld_get_response_code(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getResponseCode() : 0;
}

const char* inworld_get_content_type(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getContentType().c_str() : nullptr;
}

const char* inworld_get_name_lookup_time_ms(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getNameLookupTimeMs().c_str() : nullptr;
}

const char* inworld_get_connect_time_ms(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnectTimeMs().c_str() : nullptr;
}

const char* inworld_get_final_response_time_ms(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFinalResponseTimeMs().c_str() : nullptr;
}

const char* inworld_get_error_message(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getErrorMessage().c_str() : nullptr;
}

const char* inworld_get_cache_filename(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCacheFilename().c_str() : nullptr;
}

const char* inworld_get_session_id(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSessionId().c_str() : nullptr;
}

const char* inworld_get_x_envoy_upstream_service_time(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getXEnvoyUpstreamServiceTime().c_str() : nullptr;
}

// State getters
int inworld_get_rate(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRate() : 0;
}

int inworld_is_draining(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isDraining() ? 1 : 0) : 0;
}

int inworld_get_reads(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReads() : 0;
}

int inworld_is_cache_audio(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isCacheAudio() ? 1 : 0) : 0;
}

int inworld_is_playback_start_sent(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isPlaybackStartSent() ? 1 : 0) : 0;
}

// Resource getters
void* inworld_get_connection(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnection() : nullptr;
}

void* inworld_get_audio_player(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getAudioPlayer() : nullptr;
}

void* inworld_get_playout_buffer(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlayoutBuffer() : nullptr;
}

FILE* inworld_get_file(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFile() : nullptr;
}

char* inworld_get_line_buffer(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getLineBuffer() : nullptr;
}

size_t inworld_get_line_buffer_size(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getLineBufferSize() : 0;
}

const char* inworld_get_playback_id(inworld_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlaybackId().c_str() : nullptr;
}

// Setters
void inworld_set_voice_name(inworld_handle_t handle, const char* voice_name) {
    auto* h = get_handle(handle);
    if (h && voice_name) {
        h->instance->setVoiceName(voice_name);
    }
}

void inworld_set_api_key(inworld_handle_t handle, const char* api_key) {
    auto* h = get_handle(handle);
    if (h && api_key) {
        h->instance->setApiKey(api_key);
    }
}

void inworld_set_model_id(inworld_handle_t handle, const char* model_id) {
    auto* h = get_handle(handle);
    if (h && model_id) {
        h->instance->setModelId(model_id);
    }
}

void inworld_set_temperature(inworld_handle_t handle, const char* temperature) {
    auto* h = get_handle(handle);
    if (h && temperature) {
        h->instance->setTemperature(temperature);
    }
}

void inworld_set_pitch(inworld_handle_t handle, const char* pitch) {
    auto* h = get_handle(handle);
    if (h && pitch) {
        h->instance->setPitch(pitch);
    }
}

void inworld_set_speakingRate(inworld_handle_t handle, const char* speakingRate) {
    auto* h = get_handle(handle);
    if (h && speakingRate) {
        h->instance->setSpeakingRate(speakingRate);
    }
}

// Result data setters
void inworld_set_response_code(inworld_handle_t handle, long response_code) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setResponseCode(response_code);
    }
}

void inworld_set_content_type(inworld_handle_t handle, const char* content_type) {
    auto* h = get_handle(handle);
    if (h && content_type) {
        h->instance->setContentType(content_type);
    }
}

void inworld_set_name_lookup_time_ms(inworld_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) {
        h->instance->setNameLookupTimeMs(time_ms);
    }
}

void inworld_set_connect_time_ms(inworld_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) {
        h->instance->setConnectTimeMs(time_ms);
    }
}

void inworld_set_final_response_time_ms(inworld_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) {
        h->instance->setFinalResponseTimeMs(time_ms);
    }
}

void inworld_set_error_message(inworld_handle_t handle, const char* error_msg) {
    auto* h = get_handle(handle);
    if (h && error_msg) {
        h->instance->setErrorMessage(error_msg);
    }
}

void inworld_set_cache_filename(inworld_handle_t handle, const char* cache_filename) {
    auto* h = get_handle(handle);
    if (h && cache_filename) {
        h->instance->setCacheFilename(cache_filename);
    }
}

void inworld_set_x_envoy_upstream_service_time(inworld_handle_t handle, const char* service_time) {
    auto* h = get_handle(handle);
    if (h && service_time) {
        h->instance->setXEnvoyUpstreamServiceTime(service_time);
    }
}

void inworld_set_session_id(inworld_handle_t handle, const char* session_id) {
    auto* h = get_handle(handle);
    if (h && session_id) {
        h->instance->setSessionId(session_id);
    }
}

// State setters
void inworld_set_rate(inworld_handle_t handle, int rate) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setRate(rate);
    }
}

void inworld_set_draining(inworld_handle_t handle, int draining) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setDraining(draining != 0);
    }
}

void inworld_set_reads(inworld_handle_t handle, int reads) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReads(reads);
    }
}

void inworld_set_cache_audio(inworld_handle_t handle, int cache_audio) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCacheAudio(cache_audio != 0);
    }
}

void inworld_set_playback_start_sent(inworld_handle_t handle, int playback_start_sent) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackStartSent(playback_start_sent != 0);
    }
}

// Resource setters
void inworld_set_connection(inworld_handle_t handle, void* conn) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setConnection(conn);
    }
}

void inworld_set_audio_player(inworld_handle_t handle, void* audio_player) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setAudioPlayer(audio_player);
    }
}

void inworld_set_playout_buffer(inworld_handle_t handle, void* playout_buffer) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlayoutBuffer(playout_buffer);
    }
}

void inworld_set_file(inworld_handle_t handle, FILE* file) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setFile(file);
    }
}

void inworld_set_line_buffer(inworld_handle_t handle, char* line_buffer) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setLineBuffer(line_buffer);
    }
}

void inworld_set_line_buffer_size(inworld_handle_t handle, size_t line_buffer_size) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setLineBufferSize(line_buffer_size);
    }
}

void inworld_set_playback_id(inworld_handle_t handle, const char* playback_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackId(playback_id ? playback_id : "");
    }
}

// Mutex initialization
// Mutex initialization function removed - std::mutex is now managed internally by InWorld class

} // extern "C"