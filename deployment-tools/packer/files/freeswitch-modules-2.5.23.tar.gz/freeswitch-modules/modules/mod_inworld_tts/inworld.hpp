#ifndef __INWORLD_HPP__
#define __INWORLD_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <string>
#include <memory>
#include <mutex>

class InWorld {
private:
    // Configuration parameters
    std::string voice_name_;
    std::string api_key_;
    std::string model_id_;
    std::string temperature_;
    std::string pitch_;
    std::string speakingRate_;

    // Result data
    long response_code_;
    std::string content_type_;
    std::string name_lookup_time_ms_;
    std::string connect_time_ms_;
    std::string final_response_time_ms_;
    std::string error_message_;
    std::string cache_filename_;
    std::string session_id_;
    std::string x_envoy_upstream_service_time;

    // State and configuration
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;

    // Pointers and resources
    void* conn_;
    void* audio_player_;
    void* playout_buffer_;
    mutable std::mutex mutex_;  // Now a member object, not a pointer
    FILE* file_;
    std::string playback_id_;

    // Line buffer for streaming JSON parsing
    char* line_buffer_;
    size_t line_buffer_size_;

public:
    // Constructor
    InWorld();
    
    // Destructor
    ~InWorld();
    
    // Static factory method
    static std::shared_ptr<InWorld> create();
    
    // Copy constructor and assignment are now safe with shared_ptr
    InWorld(const InWorld& other) = default;
    InWorld& operator=(const InWorld& other) = default;
    
    // Move constructor and assignment
    InWorld(InWorld&& other) noexcept = default;
    InWorld& operator=(InWorld&& other) noexcept = default;

    // Getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getApiKey() const { return api_key_; }
    const std::string& getModelId() const { return model_id_; }
    const std::string& getTemperature() const { return temperature_; }
    const std::string& getPitch() const { return pitch_; }
    const std::string& getSpeakingRate() const { return speakingRate_; }
    
    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getContentType() const { return content_type_; }
    const std::string& getNameLookupTimeMs() const { return name_lookup_time_ms_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFinalResponseTimeMs() const { return final_response_time_ms_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    const std::string& getSessionId() const { return session_id_; }
    const std::string& getXEnvoyUpstreamServiceTime() const { return x_envoy_upstream_service_time; }
    
    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }
    
    // Resource getters
    void* getConnection() const { return conn_; }
    void* getAudioPlayer() const { return audio_player_; }
    void* getPlayoutBuffer() const { return playout_buffer_; }
    std::mutex& getMutex() const { return mutex_; }  // Return reference to mutex
    FILE* getFile() const { return file_; }
    char* getLineBuffer() const { return line_buffer_; }
    size_t getLineBufferSize() const { return line_buffer_size_; }
    const std::string& getPlaybackId() const { return playback_id_; }

    // Setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setApiKey(const std::string& api_key) { api_key_ = api_key; }
    void setModelId(const std::string& model_id) { model_id_ = model_id; }
    void setTemperature(const std::string& temperature) { temperature_ = temperature; }
    void setPitch(const std::string& pitch) { pitch_ = pitch; }
    void setSpeakingRate(const std::string& speakingRate) { speakingRate_ = speakingRate; }
    
    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setContentType(const std::string& content_type) { content_type_ = content_type; }
    void setNameLookupTimeMs(const std::string& time_ms) { name_lookup_time_ms_ = time_ms; }
    void setConnectTimeMs(const std::string& time_ms) { connect_time_ms_ = time_ms; }
    void setFinalResponseTimeMs(const std::string& time_ms) { final_response_time_ms_ = time_ms; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    void setXEnvoyUpstreamServiceTime(const std::string& time) { x_envoy_upstream_service_time = time; }
    
    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setPlaybackStartSent(bool playback_start_sent) { playback_start_sent_ = playback_start_sent; }
    
    // Resource setters
    void setConnection(void* conn) { conn_ = conn; }
    void setAudioPlayer(void* audio_player) { audio_player_ = audio_player; }
    void setPlayoutBuffer(void* playout_buffer) { playout_buffer_ = playout_buffer; }
    void setFile(FILE* file) { file_ = file; }
    void setLineBuffer(char* line_buffer) { line_buffer_ = line_buffer; }
    void setLineBufferSize(size_t line_buffer_size) { line_buffer_size_ = line_buffer_size; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }

    // Mutex initialization (call this when you have access to a memory pool)
    // Mutex initialization removed - std::mutex doesn't need explicit initialization

    // Utility methods
    void reset();
    bool isValid() const;
    
private:
    void cleanup();
};

#endif