#ifndef __INWORLD_GLUE_H__
#define __INWORLD_GLUE_H__

#include "inworld_wrapper.h"
#include <switch.h>

#ifdef __cplusplus
#include <mutex>
// RAII wrapper for switch_mutex_t
class SwitchMutexLock {
private:
    switch_mutex_t* fs_mutex_;
    std::mutex* std_mutex_;
    std::unique_lock<std::mutex> std_lock_;

public:
    // Constructor for FreeSWITCH mutex
    SwitchMutexLock(switch_mutex_t* mutex)
        : fs_mutex_(mutex), std_mutex_(nullptr) {
        if (fs_mutex_) {
            switch_mutex_lock(fs_mutex_);
        }
    }

    // Constructor for std::mutex
    SwitchMutexLock(std::mutex& mutex)
        : fs_mutex_(nullptr), std_mutex_(&mutex), std_lock_(mutex) {
    }

    ~SwitchMutexLock() {
        if (fs_mutex_) {
            switch_mutex_unlock(fs_mutex_);
        }
        // std_lock_ destructor handles std::mutex unlock automatically
    }

    // Disable copying
    SwitchMutexLock(const SwitchMutexLock&) = delete;
    SwitchMutexLock& operator=(const SwitchMutexLock&) = delete;
};

// Mutex getter function removed - std::mutex is now managed internally by InWorld class
#endif

#ifdef __cplusplus
extern "C" {
#endif

switch_status_t inworld_speech_load();
switch_status_t inworld_speech_open(inworld_handle_t inworld);
switch_status_t inworld_speech_feed_tts(inworld_handle_t inworld, char* text, switch_speech_flag_t *flags);
switch_status_t inworld_speech_read_tts(inworld_handle_t inworld, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t inworld_speech_flush_tts(inworld_handle_t inworld);
switch_status_t inworld_speech_close(inworld_handle_t inworld);
switch_status_t inworld_speech_unload();

#ifdef __cplusplus
}
#endif

#endif