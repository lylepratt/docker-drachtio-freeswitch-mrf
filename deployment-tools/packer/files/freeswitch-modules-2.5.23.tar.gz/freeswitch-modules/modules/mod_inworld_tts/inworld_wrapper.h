// inworld_wrapper.h - C-compatible header
#ifndef __INWORLD_WRAPPER_H__
#define __INWORLD_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct inworld_handle* inworld_handle_t;

#ifdef __cplusplus
#include <memory>

// Forward declaration
class InWorld;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<InWorld> inworld_get_shared_ptr(inworld_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
inworld_handle_t inworld_get_handle_from_shared_ptr(const std::shared_ptr<InWorld>& ptr);

extern "C" {
#endif

// C API functions
inworld_handle_t inworld_create(void);
void inworld_retain(inworld_handle_t handle);
void inworld_release(inworld_handle_t handle);

// Getters - C-style interface
const char* inworld_get_voice_name(inworld_handle_t handle);
const char* inworld_get_api_key(inworld_handle_t handle);
const char* inworld_get_model_id(inworld_handle_t handle);
const char* inworld_get_temperature(inworld_handle_t handle);
const char* inworld_get_pitch(inworld_handle_t handle);
const char* inworld_get_speakingRate(inworld_handle_t handle);

// Result data getters
long inworld_get_response_code(inworld_handle_t handle);
const char* inworld_get_content_type(inworld_handle_t handle);
const char* inworld_get_name_lookup_time_ms(inworld_handle_t handle);
const char* inworld_get_connect_time_ms(inworld_handle_t handle);
const char* inworld_get_final_response_time_ms(inworld_handle_t handle);
const char* inworld_get_error_message(inworld_handle_t handle);
const char* inworld_get_cache_filename(inworld_handle_t handle);
const char* inworld_get_session_id(inworld_handle_t handle);
const char* inworld_get_x_envoy_upstream_service_time(inworld_handle_t handle);

// State getters
int inworld_get_rate(inworld_handle_t handle);
int inworld_is_draining(inworld_handle_t handle);
int inworld_get_reads(inworld_handle_t handle);
int inworld_is_cache_audio(inworld_handle_t handle);
int inworld_is_playback_start_sent(inworld_handle_t handle);

// Resource getters
void* inworld_get_connection(inworld_handle_t handle);
void* inworld_get_audio_player(inworld_handle_t handle);
void* inworld_get_playout_buffer(inworld_handle_t handle);
FILE* inworld_get_file(inworld_handle_t handle);
uint16_t inworld_get_id(inworld_handle_t handle);
char* inworld_get_line_buffer(inworld_handle_t handle);
size_t inworld_get_line_buffer_size(inworld_handle_t handle);
const char* inworld_get_playback_id(inworld_handle_t handle);

// Setters
void inworld_set_voice_name(inworld_handle_t handle, const char* voice_name);
void inworld_set_api_key(inworld_handle_t handle, const char* api_key);
void inworld_set_model_id(inworld_handle_t handle, const char* model_id);
void inworld_set_temperature(inworld_handle_t handle, const char* temerature);
void inworld_set_pitch(inworld_handle_t handle, const char* pitch);
void inworld_set_speakingRate(inworld_handle_t handle, const char* speakingRate);
// Result data setters
void inworld_set_response_code(inworld_handle_t handle, long response_code);
void inworld_set_content_type(inworld_handle_t handle, const char* content_type);
void inworld_set_name_lookup_time_ms(inworld_handle_t handle, const char* time_ms);
void inworld_set_connect_time_ms(inworld_handle_t handle, const char* time_ms);
void inworld_set_final_response_time_ms(inworld_handle_t handle, const char* time_ms);
void inworld_set_error_message(inworld_handle_t handle, const char* error_msg);
void inworld_set_cache_filename(inworld_handle_t handle, const char* cache_filename);
void inworld_set_session_id(inworld_handle_t handle, const char* session_id);
void inworld_set_x_envoy_upstream_service_time(inworld_handle_t handle, const char* service_time);

// State setters
void inworld_set_rate(inworld_handle_t handle, int rate);
void inworld_set_draining(inworld_handle_t handle, int draining);
void inworld_set_reads(inworld_handle_t handle, int reads);
void inworld_set_cache_audio(inworld_handle_t handle, int cache_audio);
void inworld_set_playback_start_sent(inworld_handle_t handle, int playback_start_sent);

// Resource setters
void inworld_set_connection(inworld_handle_t handle, void* conn);
void inworld_set_audio_player(inworld_handle_t handle, void* audio_player);
void inworld_set_playout_buffer(inworld_handle_t handle, void* playout_buffer);
void inworld_set_file(inworld_handle_t handle, FILE* file);
void inworld_set_line_buffer(inworld_handle_t handle, char* line_buffer);
void inworld_set_line_buffer_size(inworld_handle_t handle, size_t line_buffer_size);
void inworld_set_playback_id(inworld_handle_t handle, const char* playback_id);

// Mutex initialization
// Mutex initialization removed - std::mutex is now managed internally by InWorld class

#ifdef __cplusplus
}
#endif

#endif