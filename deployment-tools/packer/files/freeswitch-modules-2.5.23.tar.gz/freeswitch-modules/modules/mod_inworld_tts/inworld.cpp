// inworld.cpp - Implementation file
#include "inworld.hpp"
#include <iostream>

// Constructor
InWorld::InWorld()
    : response_code_(0)
    , rate_(0)
    , draining_(false)
    , reads_(0)
    , cache_audio_(false)
    , playback_start_sent_(false)
    , conn_(nullptr)
    , audio_player_(nullptr)
    , playout_buffer_(nullptr)
    // mutex_ is automatically initialized by std::mutex default constructor
    , file_(nullptr)
    , line_buffer_(nullptr)
    , line_buffer_size_(0)
{
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "InWorld constructor\n");
}

// Destructor
InWorld::~InWorld() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "InWorld destructor\n");
    cleanup();
    
    /* mutex allocated from session pool - automatically cleaned up */
}

// Factory method for creating shared_ptr instances
std::shared_ptr<InWorld> InWorld::create() {
    return std::make_shared<InWorld>();
}

// Mutex initialization (call this when you have access to a memory pool)
// Mutex initialization removed - std::mutex is automatically initialized in constructor

// Reset method - clears all data to initial state
void InWorld::reset() {
    // Clear configuration strings
    voice_name_.clear();
    api_key_.clear();
    model_id_.clear();
    temperature_.clear();
    pitch_.clear();
    speakingRate_.clear();

    // Clear result data strings
    content_type_.clear();
    name_lookup_time_ms_.clear();
    connect_time_ms_.clear();
    final_response_time_ms_.clear();
    error_message_.clear();
    cache_filename_.clear();
    session_id_.clear();

    // Reset numeric and boolean values
    response_code_ = 0;
    rate_ = 0;
    draining_ = false;
    reads_ = 0;
    cache_audio_ = false;
    playback_start_sent_ = false;

    // Clean up resources
    cleanup();
    
    // Reset line buffer
    line_buffer_size_ = 0;
}

// Validation method
bool InWorld::isValid() const {
    // Basic validation - you can customize this based on your requirements
    return !api_key_.empty() && !voice_name_.empty();
}

// Private cleanup method
void InWorld::cleanup() {
    // Close file if open
    if (file_ != nullptr) {
        fclose(file_);
        file_ = nullptr;
    }
    
    // Clean up line buffer
    if (line_buffer_ != nullptr) {
        free(line_buffer_);
        line_buffer_ = nullptr;
    }

    // Note: For other pointers (conn_, audio_player_, playout_buffer_)
    // we don't clean them up here as they are likely managed by external
    // libraries (FreeSWITCH). You should clean these up according to
    // your application's resource management strategy.
    
    // Reset pointers to nullptr for safety
    conn_ = nullptr;
    audio_player_ = nullptr;
    playout_buffer_ = nullptr;
}
