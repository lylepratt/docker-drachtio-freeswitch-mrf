// playht_wrapper.h - C-compatible header
#ifndef __PLAYHT_WRAPPER_H__
#define __PLAYHT_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct playht_handle* playht_handle_t;

#ifdef __cplusplus
#include <memory>

// Forward declaration
class PlayHT;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<PlayHT> playht_get_shared_ptr(playht_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
playht_handle_t playht_get_handle_from_shared_ptr(const std::shared_ptr<PlayHT>& ptr);

extern "C" {
#endif

// C API functions
playht_handle_t playht_create(void);
void playht_retain(playht_handle_t handle);
void playht_release(playht_handle_t handle);

// Getters - C-style interface
const char* playht_get_voice_name(playht_handle_t handle);
const char* playht_get_playback_id(playht_handle_t handle);
const char* playht_get_api_key(playht_handle_t handle);
const char* playht_get_user_id(playht_handle_t handle);
const char* playht_get_quality(playht_handle_t handle);
const char* playht_get_speed(playht_handle_t handle);
const char* playht_get_seed(playht_handle_t handle);
const char* playht_get_temperature(playht_handle_t handle);
const char* playht_get_voice_engine(playht_handle_t handle);
const char* playht_get_synthesize_url(playht_handle_t handle);
const char* playht_get_language(playht_handle_t handle);
const char* playht_get_emotion(playht_handle_t handle);
const char* playht_get_voice_guidance(playht_handle_t handle);
const char* playht_get_style_guidance(playht_handle_t handle);
const char* playht_get_text_guidance(playht_handle_t handle);
const char* playht_get_top_p(playht_handle_t handle);
const char* playht_get_repetition_penalty(playht_handle_t handle);

// Result data getters
long playht_get_response_code(playht_handle_t handle);
const char* playht_get_content_type(playht_handle_t handle);
const char* playht_get_request_id(playht_handle_t handle);
const char* playht_get_name_lookup_time_ms(playht_handle_t handle);
const char* playht_get_connect_time_ms(playht_handle_t handle);
const char* playht_get_final_response_time_ms(playht_handle_t handle);
const char* playht_get_error_message(playht_handle_t handle);
const char* playht_get_cache_filename(playht_handle_t handle);
const char* playht_get_session_id(playht_handle_t handle);

// State getters
int playht_get_rate(playht_handle_t handle);
int playht_is_draining(playht_handle_t handle);
int playht_get_reads(playht_handle_t handle);
int playht_is_cache_audio(playht_handle_t handle);
int playht_is_playback_start_sent(playht_handle_t handle);

// Resource getters
void* playht_get_connection(playht_handle_t handle);
void* playht_get_audio_player(playht_handle_t handle);
void* playht_get_playout_buffer(playht_handle_t handle);
FILE* playht_get_file(playht_handle_t handle);
uint16_t playht_get_id(playht_handle_t handle);

// Setters
void playht_set_voice_name(playht_handle_t handle, const char* voice_name);
void playht_set_api_key(playht_handle_t handle, const char* api_key);
void playht_set_user_id(playht_handle_t handle, const char* user_id);
void playht_set_quality(playht_handle_t handle, const char* quality);
void playht_set_speed(playht_handle_t handle, const char* speed);
void playht_set_seed(playht_handle_t handle, const char* seed);
void playht_set_temperature(playht_handle_t handle, const char* temperature);
void playht_set_voice_engine(playht_handle_t handle, const char* voice_engine);
void playht_set_synthesize_url(playht_handle_t handle, const char* synthesize_url);
void playht_set_language(playht_handle_t handle, const char* language);
void playht_set_emotion(playht_handle_t handle, const char* emotion);
void playht_set_voice_guidance(playht_handle_t handle, const char* voice_guidance);
void playht_set_style_guidance(playht_handle_t handle, const char* style_guidance);
void playht_set_text_guidance(playht_handle_t handle, const char* text_guidance);
void playht_set_top_p(playht_handle_t handle, const char* top_p);
void playht_set_repetition_penalty(playht_handle_t handle, const char* repetition_penalty);

// Result data setters
void playht_set_response_code(playht_handle_t handle, long response_code);
void playht_set_content_type(playht_handle_t handle, const char* content_type);
void playht_set_request_id(playht_handle_t handle, const char* request_id);
void playht_set_name_lookup_time_ms(playht_handle_t handle, const char* time_ms);
void playht_set_connect_time_ms(playht_handle_t handle, const char* time_ms);
void playht_set_final_response_time_ms(playht_handle_t handle, const char* time_ms);
void playht_set_error_message(playht_handle_t handle, const char* error_msg);
void playht_set_cache_filename(playht_handle_t handle, const char* cache_filename);
void playht_set_session_id(playht_handle_t handle, const char* session_id);

// State setters
void playht_set_rate(playht_handle_t handle, int rate);
void playht_set_draining(playht_handle_t handle, int draining);
void playht_set_reads(playht_handle_t handle, int reads);
void playht_set_cache_audio(playht_handle_t handle, int cache_audio);
void playht_set_playback_start_sent(playht_handle_t handle, int playback_start_sent);

// Resource setters
void playht_set_connection(playht_handle_t handle, void* conn);
void playht_set_audio_player(playht_handle_t handle, void* audio_player);
void playht_set_playout_buffer(playht_handle_t handle, void* playout_buffer);
void playht_set_file(playht_handle_t handle, FILE* file);
void playht_set_id(playht_handle_t handle, uint16_t id);

// Mutex initialization
switch_status_t playht_init_mutex(playht_handle_t handle, switch_memory_pool_t* pool);

#ifdef __cplusplus
}
#endif

#endif