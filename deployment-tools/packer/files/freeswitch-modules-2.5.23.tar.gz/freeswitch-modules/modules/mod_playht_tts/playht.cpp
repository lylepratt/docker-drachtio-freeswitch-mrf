// playht.cpp - Implementation file
#include "playht.hpp"
#include <iostream>

// Constructor
PlayHT::PlayHT() 
    : response_code_(0)
    , rate_(0)
    , draining_(false)
    , reads_(0)
    , cache_audio_(false)
    , playback_start_sent_(false)
    , conn_(nullptr)
    , audio_player_(nullptr)
    , playout_buffer_(nullptr)
    , mutex_(nullptr)
    , file_(nullptr)
{
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "PlayHT constructor\n");
    
    // Initialize any other default values as needed
    // For example, if you have specific defaults:
    // quality_ = "medium";
    // voice_engine_ = "PlayHT2.0";
}

// Destructor
PlayHT::~PlayHT() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "PlayHT destructor\n");
    cleanup();
    
    /* mutex allocated from session pool - automatically cleaned up */
}

// Factory method for creating shared_ptr instances
std::shared_ptr<PlayHT> PlayHT::create() {
    return std::make_shared<PlayHT>();
}

// Mutex initialization (call this when you have access to a memory pool)
switch_status_t PlayHT::initMutex(switch_memory_pool_t* pool) {
    if (!pool) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "PlayHT::initMutex: pool is NULL\n");
        return SWITCH_STATUS_FALSE;
    }
    
    if (mutex_) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "PlayHT::initMutex: mutex already initialized\n");
        return SWITCH_STATUS_SUCCESS;
    }
    
    switch_status_t status = switch_mutex_init(&mutex_, SWITCH_MUTEX_NESTED, pool);
    if (status == SWITCH_STATUS_SUCCESS) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "PlayHT::initMutex: mutex initialized successfully\n");
    } else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "PlayHT::initMutex: failed to initialize mutex\n");
    }
    
    return status;
}

// Reset method - clears all data to initial state
void PlayHT::reset() {
    // Clear configuration strings
    voice_name_.clear();
    playback_id_.clear();
    api_key_.clear();
    user_id_.clear();
    quality_.clear();
    speed_.clear();
    seed_.clear();
    temperature_.clear();
    voice_engine_.clear();
    synthesize_url_.clear();
    language_.clear();
    emotion_.clear();
    voice_guidance_.clear();
    style_guidance_.clear();
    text_guidance_.clear();
    top_p_.clear();
    repetition_penalty_.clear();

    // Clear result data strings
    content_type_.clear();
    request_id_.clear();
    name_lookup_time_ms_.clear();
    connect_time_ms_.clear();
    final_response_time_ms_.clear();
    error_message_.clear();
    cache_filename_.clear();
    session_id_.clear();

    // Reset numeric and boolean values
    response_code_ = 0;
    rate_ = 0;
    draining_ = false;
    reads_ = 0;
    cache_audio_ = false;
    playback_start_sent_ = false;

    // Clean up resources
    cleanup();
}

// Validation method
bool PlayHT::isValid() const {
    // Basic validation - you can customize this based on your requirements
    return !api_key_.empty() && !voice_name_.empty();
}

// Private cleanup method
void PlayHT::cleanup() {
    // Close file if open
    if (file_ != nullptr) {
        fclose(file_);
        file_ = nullptr;
    }

    // Note: For other pointers (conn_, audio_player_, playout_buffer_)
    // we don't clean them up here as they are likely managed by external
    // libraries (FreeSWITCH). You should clean these up according to
    // your application's resource management strategy.
    
    // Reset pointers to nullptr for safety
    conn_ = nullptr;
    audio_player_ = nullptr;
    playout_buffer_ = nullptr;
}
