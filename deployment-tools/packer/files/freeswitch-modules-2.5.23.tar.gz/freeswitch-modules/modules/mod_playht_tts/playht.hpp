#ifndef __PLAYHT_HPP__
#define __PLAYHT_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <string>
#include <memory>
#include <mutex>
#include <cstdint>

class PlayHT {
private:
    // Configuration parameters
    std::string voice_name_;
    std::string playback_id_;
    std::string api_key_;
    std::string user_id_;
    std::string quality_;
    std::string speed_;
    std::string seed_;
    std::string temperature_;
    std::string voice_engine_;
    std::string synthesize_url_;
    std::string language_;
    std::string emotion_;
    std::string voice_guidance_;
    std::string style_guidance_;
    std::string text_guidance_;
    std::string top_p_;
    std::string repetition_penalty_;

    // Result data
    long response_code_;
    std::string content_type_;
    std::string request_id_;
    std::string name_lookup_time_ms_;
    std::string connect_time_ms_;
    std::string final_response_time_ms_;
    std::string error_message_;
    std::string cache_filename_;
    std::string session_id_;

    // State and configuration
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;

    // Pointers and resources
    void* conn_;
    void* audio_player_;
    void* playout_buffer_;
    switch_mutex_t* mutex_;
    FILE* file_;
    uint16_t id;

public:
    // Constructor
    PlayHT();
    
    // Destructor
    ~PlayHT();
    
    // Static factory method
    static std::shared_ptr<PlayHT> create();
    
    // Copy constructor and assignment are now safe with shared_ptr
    PlayHT(const PlayHT& other) = default;
    PlayHT& operator=(const PlayHT& other) = default;
    
    // Move constructor and assignment
    PlayHT(PlayHT&& other) noexcept = default;
    PlayHT& operator=(PlayHT&& other) noexcept = default;

    // Getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getPlaybackId() const { return playback_id_; }
    const std::string& getApiKey() const { return api_key_; }
    const std::string& getUserId() const { return user_id_; }
    const std::string& getQuality() const { return quality_; }
    const std::string& getSpeed() const { return speed_; }
    const std::string& getSeed() const { return seed_; }
    const std::string& getTemperature() const { return temperature_; }
    const std::string& getVoiceEngine() const { return voice_engine_; }
    const std::string& getSynthesizeUrl() const { return synthesize_url_; }
    const std::string& getLanguage() const { return language_; }
    const std::string& getEmotion() const { return emotion_; }
    const std::string& getVoiceGuidance() const { return voice_guidance_; }
    const std::string& getStyleGuidance() const { return style_guidance_; }
    const std::string& getTextGuidance() const { return text_guidance_; }
    const std::string& getTopP() const { return top_p_; }
    const std::string& getRepetitionPenalty() const { return repetition_penalty_; }
    
    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getContentType() const { return content_type_; }
    const std::string& getRequestId() const { return request_id_; }
    const std::string& getNameLookupTimeMs() const { return name_lookup_time_ms_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFinalResponseTimeMs() const { return final_response_time_ms_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    const std::string& getSessionId() const { return session_id_; }
    
    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }
    
    // Resource getters
    void* getConnection() const { return conn_; }
    void* getAudioPlayer() const { return audio_player_; }
    void* getPlayoutBuffer() const { return playout_buffer_; }
    switch_mutex_t* getMutex() const { return mutex_; }
    FILE* getFile() const { return file_; }
    uint16_t getId() const { return id; }

    // Setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }
    void setApiKey(const std::string& api_key) { api_key_ = api_key; }
    void setUserId(const std::string& user_id) { user_id_ = user_id; }
    void setQuality(const std::string& quality) { quality_ = quality; }
    void setSpeed(const std::string& speed) { speed_ = speed; }
    void setSeed(const std::string& seed) { seed_ = seed; }
    void setTemperature(const std::string& temperature) { temperature_ = temperature; }
    void setVoiceEngine(const std::string& voice_engine) { voice_engine_ = voice_engine; }
    void setSynthesizeUrl(const std::string& synthesize_url) { synthesize_url_ = synthesize_url; }
    void setLanguage(const std::string& language) { language_ = language; }
    void setEmotion(const std::string& emotion) { emotion_ = emotion; }
    void setVoiceGuidance(const std::string& voice_guidance) { voice_guidance_ = voice_guidance; }
    void setStyleGuidance(const std::string& style_guidance) { style_guidance_ = style_guidance; }
    void setTextGuidance(const std::string& text_guidance) { text_guidance_ = text_guidance; }
    void setTopP(const std::string& top_p) { top_p_ = top_p; }
    void setRepetitionPenalty(const std::string& repetition_penalty) { repetition_penalty_ = repetition_penalty; }
    
    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setContentType(const std::string& content_type) { content_type_ = content_type; }
    void setRequestId(const std::string& request_id) { request_id_ = request_id; }
    void setNameLookupTimeMs(const std::string& time_ms) { name_lookup_time_ms_ = time_ms; }
    void setConnectTimeMs(const std::string& time_ms) { connect_time_ms_ = time_ms; }
    void setFinalResponseTimeMs(const std::string& time_ms) { final_response_time_ms_ = time_ms; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    
    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setPlaybackStartSent(bool playback_start_sent) { playback_start_sent_ = playback_start_sent; }
    
    // Resource setters
    void setConnection(void* conn) { conn_ = conn; }
    void setAudioPlayer(void* audio_player) { audio_player_ = audio_player; }
    void setPlayoutBuffer(void* playout_buffer) { playout_buffer_ = playout_buffer; }
    void setMutex(switch_mutex_t* mutex) { mutex_ = mutex; }
    void setFile(FILE* file) { file_ = file; }
    void setId(uint16_t id) { this->id = id; }

    // Mutex initialization (call this when you have access to a memory pool)
    switch_status_t initMutex(switch_memory_pool_t* pool);

    // Utility methods
    void reset();
    bool isValid() const;
    
private:
    void cleanup();
};

#endif