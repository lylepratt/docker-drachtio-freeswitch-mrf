#include "playht_wrapper.h"
#include "playht_glue.h"
#include <stdatomic.h>

SWITCH_MODULE_LOAD_FUNCTION(mod_playht_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_playht_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_playht_tts, mod_playht_tts_load, mod_playht_tts_shutdown, NULL);

static atomic_uint_least16_t currentId = 0;

static void clearPlayht(playht_handle_t handle, int freeAll) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "clearPlayht\n");
  
  // Clear all string properties
  playht_set_api_key(handle, NULL);
  playht_set_user_id(handle, NULL);
  playht_set_quality(handle, NULL);
  playht_set_speed(handle, NULL);
  playht_set_seed(handle, NULL);
  playht_set_temperature(handle, NULL);
  playht_set_voice_engine(handle, NULL);
  playht_set_synthesize_url(handle, NULL);
  playht_set_language(handle, NULL);
  playht_set_top_p(handle, NULL);
  playht_set_repetition_penalty(handle, NULL);
  playht_set_emotion(handle, NULL);
  playht_set_voice_guidance(handle, NULL);
  playht_set_style_guidance(handle, NULL);
  playht_set_text_guidance(handle, NULL);

  // Clear result data
  playht_set_request_id(handle, NULL);
  playht_set_content_type(handle, NULL);
  playht_set_error_message(handle, NULL);
  playht_set_name_lookup_time_ms(handle, NULL);
  playht_set_connect_time_ms(handle, NULL);
  playht_set_final_response_time_ms(handle, NULL);
  playht_set_cache_filename(handle, NULL);

  if (freeAll) {
    playht_set_voice_name(handle, NULL);
    playht_set_session_id(handle, NULL);
  }
}

static playht_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  playht_handle_t handle = (playht_handle_t) sh->private_info;  
  if (!handle) {
    handle = playht_create();
    if (handle) {
      // Get the memory pool from the speech handle
      switch_memory_pool_t* pool = sh->memory_pool;
      if (pool) {
        switch_status_t status = playht_init_mutex(handle, pool);
        if (status != SWITCH_STATUS_SUCCESS) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to initialize mutex for playht handle\n");
          playht_release(handle);
          return NULL;
        }
      } else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "No memory pool available for mutex initialization\n");
      }
      sh->private_info = handle;
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "allocated playht_handle_t\n");
    }
  }
  return handle;
}

switch_status_t p_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  playht_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to create playht handle\n");
    return SWITCH_STATUS_FALSE;
  }
  
  playht_set_voice_name(handle, voice_name);
  playht_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "p_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
  return playht_speech_open(handle);
}

static switch_status_t p_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  playht_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_close\n");

  rc = playht_speech_close(handle);
  clearPlayht(handle, 1);
  
  // Release the handle
  if (handle) {
    playht_release(handle);
    sh->private_info = NULL;
  }
  
  return rc;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t p_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  playht_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "No playht handle available\n");
    return SWITCH_STATUS_FALSE;
  }
  
  playht_set_draining(handle, 0);
  playht_set_reads(handle, 0);
  playht_set_response_code(handle, 0);
  playht_set_error_message(handle, NULL);
  playht_set_playback_start_sent(handle, 0);
  playht_set_id(handle, ++currentId);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_feed_tts\n");

  return playht_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t p_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  playht_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "No playht handle available\n");
    return SWITCH_STATUS_FALSE;
  }
  
  return playht_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void p_speech_flush_tts(switch_speech_handle_t *sh)
{
  playht_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_flush_tts\n");
  playht_speech_flush_tts(handle);

  clearPlayht(handle, 0);
}

static void p_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  playht_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "No playht handle available\n");
    return;
  }
  
  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_text_param_tts: %s=XXXXX\n", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_text_param_tts: %s=%s\n", param, val);
  }
  
  if (0 == strcmp(param, "api_key")) {
    playht_set_api_key(handle, val);
  } else if (0 == strcmp(param, "user_id")) {
    playht_set_user_id(handle, val);
  } else if (0 == strcmp(param, "quality")) {
    playht_set_quality(handle, val);
  } else if (0 == strcmp(param, "speed")) {
    playht_set_speed(handle, val);
  } else if (0 == strcmp(param, "seed")) {
    playht_set_seed(handle, val);
  } else if (0 == strcmp(param, "temperature")) {
    playht_set_temperature(handle, val);
  } else if (0 == strcmp(param, "voice_engine")) {
    playht_set_voice_engine(handle, val);
  } else if (0 == strcmp(param, "synthesize_url")) {
    playht_set_synthesize_url(handle, val);
  } else if (0 == strcmp(param, "language")) {
    playht_set_language(handle, val);
  } else if (0 == strcmp(param, "top_p")) {
    playht_set_top_p(handle, val);
  } else if (0 == strcmp(param, "repetition_penalty")) {
    playht_set_repetition_penalty(handle, val);
  } else if (0 == strcmp(param, "emotion")) {
    playht_set_emotion(handle, val);
  } else if (0 == strcmp(param, "voice_guidance")) {
    playht_set_voice_guidance(handle, val);
  } else if (0 == strcmp(param, "style_guidance")) {
    playht_set_style_guidance(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    playht_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    playht_set_cache_audio(handle, 1);
  }
}

static void p_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}

static void p_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_playht_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "playht";
  speech_interface->speech_open = p_speech_open;
  speech_interface->speech_close = p_speech_close;
  speech_interface->speech_feed_tts = p_speech_feed_tts;
  speech_interface->speech_read_tts = p_speech_read_tts;
	speech_interface->speech_flush_tts = p_speech_flush_tts;
	speech_interface->speech_text_param_tts = p_text_param_tts;
	speech_interface->speech_numeric_param_tts = p_numeric_param_tts;
	speech_interface->speech_float_param_tts = p_float_param_tts;
  return playht_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_playht_tts_shutdown)
{
  return playht_speech_unload();
}