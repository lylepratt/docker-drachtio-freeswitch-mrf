#ifndef __PLAYHT_GLUE_H__
#define __PLAYHT_GLUE_H__

#include "playht_wrapper.h"
#include <switch.h>

#ifdef __cplusplus
// RAII wrapper for switch_mutex_t
class SwitchMutexLock {
private:
    switch_mutex_t* mutex_;
    
public:
    SwitchMutexLock(switch_mutex_t* mutex) : mutex_(mutex) {
        if (mutex_) {
            switch_mutex_lock(mutex_);
        }
    }
    
    ~SwitchMutexLock() {
        if (mutex_) {
            switch_mutex_unlock(mutex_);
        }
    }
    
    // Disable copying
    SwitchMutexLock(const SwitchMutexLock&) = delete;
    SwitchMutexLock& operator=(const SwitchMutexLock&) = delete;
};

// Forward declaration of internal mutex function
extern switch_mutex_t* playht_get_mutex_internal(playht_handle_t handle);
#endif

#ifdef __cplusplus
extern "C" {
#endif

switch_status_t playht_speech_load();
switch_status_t playht_speech_open(playht_handle_t playht);
switch_status_t playht_speech_feed_tts(playht_handle_t playht, char* text, switch_speech_flag_t *flags);
switch_status_t playht_speech_read_tts(playht_handle_t playht, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t playht_speech_flush_tts(playht_handle_t playht);
switch_status_t playht_speech_close(playht_handle_t playht);
switch_status_t playht_speech_unload();

#ifdef __cplusplus
}
#endif

#endif