#include "playht_wrapper.h"
#include "playht.hpp" // Your C++ class header
#include <memory>
#include <mutex>
#include <unordered_map>

// Internal handle structure
struct playht_handle {
    std::shared_ptr<PlayHT> instance;
    int ref_count;
    std::mutex ref_mutex;
    
    playht_handle(std::shared_ptr<PlayHT> inst) 
        : instance(std::move(inst)), ref_count(1) {
             switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_handle initialized with ref_count %d\n", ref_count);
        }
};

// Thread-safe handle management
static std::mutex g_handle_mutex;
static std::unordered_map<playht_handle_t, std::unique_ptr<playht_handle>> g_handles;

// Helper function to validate handle
static playht_handle* get_handle(playht_handle_t handle) {
    if (!handle) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second.get() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
switch_mutex_t* playht_get_mutex_internal(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getMutex() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
std::shared_ptr<PlayHT> playht_get_shared_ptr(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance : nullptr;
}

// Private internal function to get handle from shared_ptr
playht_handle_t playht_get_handle_from_shared_ptr(const std::shared_ptr<PlayHT>& ptr) {
    if (!ptr) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->instance == ptr) {
            return pair.first;
        }
    }
    return nullptr;
}

// C API Implementation
extern "C" {

playht_handle_t playht_create(void) {
    try {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_create\n");

        auto instance = PlayHT::create();
        auto handle = std::make_unique<playht_handle>(instance);
        playht_handle_t handle_ptr = handle.get();
        
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles[handle_ptr] = std::move(handle);
        
        return handle_ptr;
    } catch (...) {
        return nullptr;
    }
}

void playht_retain(playht_handle_t handle) {
    auto* h = get_handle(handle);
    if (h) {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_retain, ref count %d\n", h->ref_count);
    }
}

void playht_release(playht_handle_t handle) {
    auto* h = get_handle(handle);
    if (!h) return;
    
    bool should_delete = false;
    {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count--;
        should_delete = (h->ref_count <= 0);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_release, ref count %d\n", h->ref_count);
 }
    
    if (should_delete) {
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles.erase(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_release, handle erased\n");
    }
}

// Getters
const char* playht_get_voice_name(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceName().c_str() : nullptr;
}
const char* playht_get_playback_id(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlaybackId().c_str() : nullptr;
}

const char* playht_get_api_key(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getApiKey().c_str() : nullptr;
}

const char* playht_get_user_id(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getUserId().c_str() : nullptr;
}

const char* playht_get_quality(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getQuality().c_str() : nullptr;
}

const char* playht_get_speed(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSpeed().c_str() : nullptr;
}

const char* playht_get_seed(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSeed().c_str() : nullptr;
}

const char* playht_get_temperature(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getTemperature().c_str() : nullptr;
}

const char* playht_get_voice_engine(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceEngine().c_str() : nullptr;
}

const char* playht_get_synthesize_url(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSynthesizeUrl().c_str() : nullptr;
}

const char* playht_get_language(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getLanguage().c_str() : nullptr;
}

const char* playht_get_emotion(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getEmotion().c_str() : nullptr;
}

const char* playht_get_voice_guidance(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceGuidance().c_str() : nullptr;
}

const char* playht_get_style_guidance(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getStyleGuidance().c_str() : nullptr;
}

const char* playht_get_text_guidance(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getTextGuidance().c_str() : nullptr;
}

const char* playht_get_top_p(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getTopP().c_str() : nullptr;
}

const char* playht_get_repetition_penalty(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRepetitionPenalty().c_str() : nullptr;
}

// Result data getters
long playht_get_response_code(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getResponseCode() : 0;
}

const char* playht_get_content_type(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getContentType().c_str() : nullptr;
}

const char* playht_get_request_id(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRequestId().c_str() : nullptr;
}

const char* playht_get_name_lookup_time_ms(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getNameLookupTimeMs().c_str() : nullptr;
}

const char* playht_get_connect_time_ms(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnectTimeMs().c_str() : nullptr;
}

const char* playht_get_final_response_time_ms(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFinalResponseTimeMs().c_str() : nullptr;
}

const char* playht_get_error_message(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getErrorMessage().c_str() : nullptr;
}

const char* playht_get_cache_filename(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCacheFilename().c_str() : nullptr;
}

const char* playht_get_session_id(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSessionId().c_str() : nullptr;
}

// State getters
int playht_get_rate(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRate() : 0;
}

int playht_is_draining(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isDraining() ? 1 : 0) : 0;
}

int playht_get_reads(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReads() : 0;
}

int playht_is_cache_audio(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isCacheAudio() ? 1 : 0) : 0;
}

int playht_is_playback_start_sent(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isPlaybackStartSent() ? 1 : 0) : 0;
}

// Resource getters
void* playht_get_connection(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnection() : nullptr;
}

void* playht_get_audio_player(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getAudioPlayer() : nullptr;
}

void* playht_get_playout_buffer(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlayoutBuffer() : nullptr;
}

FILE* playht_get_file(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFile() : nullptr;
}

uint16_t playht_get_id(playht_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getId() : 0;
}

// Setters
void playht_set_voice_name(playht_handle_t handle, const char* voice_name) {
    auto* h = get_handle(handle);
    if (h && voice_name) {
        h->instance->setVoiceName(voice_name);
    }
}

void playht_set_playback_id(playht_handle_t handle, const char* playback_id) {
    auto* h = get_handle(handle);
    if (h && playback_id) {
        h->instance->setPlaybackId(playback_id);
    }
}

void playht_set_api_key(playht_handle_t handle, const char* api_key) {
    auto* h = get_handle(handle);
    if (h && api_key) {
        h->instance->setApiKey(api_key);
    }
}

void playht_set_user_id(playht_handle_t handle, const char* user_id) {
    auto* h = get_handle(handle);
    if (h && user_id) {
        h->instance->setUserId(user_id);
    }
}

void playht_set_quality(playht_handle_t handle, const char* quality) {
    auto* h = get_handle(handle);
    if (h && quality) {
        h->instance->setQuality(quality);
    }
}

void playht_set_speed(playht_handle_t handle, const char* speed) {
    auto* h = get_handle(handle);
    if (h && speed) {
        h->instance->setSpeed(speed);
    }
}

void playht_set_seed(playht_handle_t handle, const char* seed) {
    auto* h = get_handle(handle);
    if (h && seed) {
        h->instance->setSeed(seed);
    }
}

void playht_set_temperature(playht_handle_t handle, const char* temperature) {
    auto* h = get_handle(handle);
    if (h && temperature) {
        h->instance->setTemperature(temperature);
    }
}

void playht_set_voice_engine(playht_handle_t handle, const char* voice_engine) {
    auto* h = get_handle(handle);
    if (h && voice_engine) {
        h->instance->setVoiceEngine(voice_engine);
    }
}

void playht_set_synthesize_url(playht_handle_t handle, const char* synthesize_url) {
    auto* h = get_handle(handle);
    if (h && synthesize_url) {
        h->instance->setSynthesizeUrl(synthesize_url);
    }
}

void playht_set_language(playht_handle_t handle, const char* language) {
    auto* h = get_handle(handle);
    if (h && language) {
        h->instance->setLanguage(language);
    }
}

void playht_set_emotion(playht_handle_t handle, const char* emotion) {
    auto* h = get_handle(handle);
    if (h && emotion) {
        h->instance->setEmotion(emotion);
    }
}

void playht_set_voice_guidance(playht_handle_t handle, const char* voice_guidance) {
    auto* h = get_handle(handle);
    if (h && voice_guidance) {
        h->instance->setVoiceGuidance(voice_guidance);
    }
}

void playht_set_style_guidance(playht_handle_t handle, const char* style_guidance) {
    auto* h = get_handle(handle);
    if (h && style_guidance) {
        h->instance->setStyleGuidance(style_guidance);
    }
}

void playht_set_text_guidance(playht_handle_t handle, const char* text_guidance) {
    auto* h = get_handle(handle);
    if (h && text_guidance) {
        h->instance->setTextGuidance(text_guidance);
    }
}

void playht_set_top_p(playht_handle_t handle, const char* top_p) {
    auto* h = get_handle(handle);
    if (h && top_p) {
        h->instance->setTopP(top_p);
    }
}

void playht_set_repetition_penalty(playht_handle_t handle, const char* repetition_penalty) {
    auto* h = get_handle(handle);
    if (h && repetition_penalty) {
        h->instance->setRepetitionPenalty(repetition_penalty);
    }
}

// Result data setters
void playht_set_response_code(playht_handle_t handle, long response_code) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setResponseCode(response_code);
    }
}

void playht_set_content_type(playht_handle_t handle, const char* content_type) {
    auto* h = get_handle(handle);
    if (h && content_type) {
        h->instance->setContentType(content_type);
    }
}

void playht_set_request_id(playht_handle_t handle, const char* request_id) {
    auto* h = get_handle(handle);
    if (h && request_id) {
        h->instance->setRequestId(request_id);
    }
}

void playht_set_name_lookup_time_ms(playht_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) {
        h->instance->setNameLookupTimeMs(time_ms);
    }
}

void playht_set_connect_time_ms(playht_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) {
        h->instance->setConnectTimeMs(time_ms);
    }
}

void playht_set_final_response_time_ms(playht_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) {
        h->instance->setFinalResponseTimeMs(time_ms);
    }
}

void playht_set_error_message(playht_handle_t handle, const char* error_msg) {
    auto* h = get_handle(handle);
    if (h && error_msg) {
        h->instance->setErrorMessage(error_msg);
    }
}

void playht_set_cache_filename(playht_handle_t handle, const char* cache_filename) {
    auto* h = get_handle(handle);
    if (h && cache_filename) {
        h->instance->setCacheFilename(cache_filename);
    }
}

void playht_set_session_id(playht_handle_t handle, const char* session_id) {
    auto* h = get_handle(handle);
    if (h && session_id) {
        h->instance->setSessionId(session_id);
    }
}

// State setters
void playht_set_rate(playht_handle_t handle, int rate) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setRate(rate);
    }
}

void playht_set_draining(playht_handle_t handle, int draining) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setDraining(draining != 0);
    }
}

void playht_set_reads(playht_handle_t handle, int reads) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReads(reads);
    }
}

void playht_set_cache_audio(playht_handle_t handle, int cache_audio) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCacheAudio(cache_audio != 0);
    }
}

void playht_set_playback_start_sent(playht_handle_t handle, int playback_start_sent) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackStartSent(playback_start_sent != 0);
    }
}

// Resource setters
void playht_set_connection(playht_handle_t handle, void* conn) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setConnection(conn);
    }
}

void playht_set_audio_player(playht_handle_t handle, void* audio_player) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setAudioPlayer(audio_player);
    }
}

void playht_set_playout_buffer(playht_handle_t handle, void* playout_buffer) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlayoutBuffer(playout_buffer);
    }
}

void playht_set_file(playht_handle_t handle, FILE* file) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setFile(file);
    }
}

void playht_set_id(playht_handle_t handle, uint16_t id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setId(id);
    }
}

// Mutex initialization
switch_status_t playht_init_mutex(playht_handle_t handle, switch_memory_pool_t* pool) {
    auto* h = get_handle(handle);
    if (h) {
        return h->instance->initMutex(pool);
    }
    return SWITCH_STATUS_FALSE;
}

} // extern "C"