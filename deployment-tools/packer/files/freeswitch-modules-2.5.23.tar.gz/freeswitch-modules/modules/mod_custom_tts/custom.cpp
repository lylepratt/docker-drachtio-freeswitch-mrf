#include "custom.hpp"
#include <switch.h>

CustomTts::CustomTts()
    : response_code_(0),
      rate_(8000),
      draining_(false),
      reads_(0),
      cache_audio_(false),
      playback_start_sent_(false),
      connection_(nullptr),
      circular_buffer_(nullptr),
      audio_player_(nullptr),
      playout_buffer_(nullptr),
      file_(nullptr),
      resampler_(nullptr) {
    // mutex_ is automatically initialized by its constructor
}

CustomTts::~CustomTts() {
    cleanup();
}

std::shared_ptr<CustomTts> CustomTts::create() {
    return std::make_shared<CustomTts>();
}

void CustomTts::reset() {
    std::lock_guard<std::mutex> lock(mutex_);

    // Clear strings
    voice_name_.clear();
    auth_token_.clear();
    custom_tts_url_.clear();
    custom_tts_method_.clear();
    text_type_.clear();
    session_id_.clear();
    cache_filename_.clear();
    playback_id_.clear();
    content_type_.clear();
    request_id_.clear();
    name_lookup_time_ms_.clear();
    connect_time_ms_.clear();
    final_response_time_ms_.clear();
    error_message_.clear();

    // Reset values
    response_code_ = 0;
    rate_ = 8000;
    draining_ = false;
    reads_ = 0;
    cache_audio_ = false;
    playback_start_sent_ = false;

    // Clean up resources
    cleanup();
}

bool CustomTts::isValid() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return !custom_tts_url_.empty();
}

void CustomTts::cleanup() {
    // Note: This is called from destructor, so mutex may already be locked
    if (file_) {
        fclose(file_);
        file_ = nullptr;
    }

    if (resampler_) {
        speex_resampler_destroy(resampler_);
        resampler_ = nullptr;
    }

    // Note: circular_buffer_ and connection_ cleanup should be handled by custom_glue.cpp
    // as it knows the actual types
}