#ifndef __CUSTOM_HPP__
#define __CUSTOM_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <string>
#include <memory>
#include <mutex>
#include <chrono>

class CustomTts {
private:
    // Configuration parameters
    std::string voice_name_;
    std::string auth_token_;
    std::string custom_tts_url_;
    std::string custom_tts_method_;
    std::string text_type_;
    std::string session_id_;
    std::string cache_filename_;
    std::string playback_id_;

    // Result data
    long response_code_;
    std::string content_type_;
    std::string request_id_;
    std::string name_lookup_time_ms_;
    std::string connect_time_ms_;
    std::string final_response_time_ms_;
    std::string error_message_;

    // State and configuration
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;

    // Resources
    void* connection_;        // ConnInfo_t*
    void* circular_buffer_;
    void* audio_player_;      // AudioPlayer*
    void* playout_buffer_;    // CircularBuffer* for playout
    mutable std::mutex mutex_;  // Now a member object, not a pointer
    FILE* file_;
    SpeexResamplerState* resampler_;

public:
    // Constructor
    CustomTts();

    // Destructor
    ~CustomTts();

    // Static factory method
    static std::shared_ptr<CustomTts> create();

    // Delete copy operations to prevent accidental copies
    CustomTts(const CustomTts&) = delete;
    CustomTts& operator=(const CustomTts&) = delete;

    // Move constructor and assignment
    CustomTts(CustomTts&& other) noexcept = default;
    CustomTts& operator=(CustomTts&& other) noexcept = default;

    // Configuration getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getAuthToken() const { return auth_token_; }
    const std::string& getCustomTtsUrl() const { return custom_tts_url_; }
    const std::string& getCustomTtsMethod() const { return custom_tts_method_; }
    const std::string& getTextType() const { return text_type_; }
    const std::string& getSessionId() const { return session_id_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    const std::string& getPlaybackId() const { return playback_id_; }

    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getContentType() const { return content_type_; }
    const std::string& getRequestId() const { return request_id_; }
    const std::string& getNameLookupTimeMs() const { return name_lookup_time_ms_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFinalResponseTimeMs() const { return final_response_time_ms_; }
    const std::string& getErrorMessage() const { return error_message_; }

    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }

    // Resource getters
    void* getConnection() const { return connection_; }
    void* getCircularBuffer() const { return circular_buffer_; }
    void* getAudioPlayer() const { return audio_player_; }
    void* getPlayoutBuffer() const { return playout_buffer_; }
    std::mutex& getMutex() const { return mutex_; }
    FILE* getFile() const { return file_; }
    SpeexResamplerState* getResampler() const { return resampler_; }

    // Configuration setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setAuthToken(const std::string& auth_token) { auth_token_ = auth_token; }
    void setCustomTtsUrl(const std::string& url) { custom_tts_url_ = url; }
    void setCustomTtsMethod(const std::string& method) { custom_tts_method_ = method; }
    void setTextType(const std::string& text_type) { text_type_ = text_type; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }

    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setContentType(const std::string& content_type) { content_type_ = content_type; }
    void setRequestId(const std::string& request_id) { request_id_ = request_id; }
    void setNameLookupTimeMs(const std::string& time_ms) { name_lookup_time_ms_ = time_ms; }
    void setConnectTimeMs(const std::string& time_ms) { connect_time_ms_ = time_ms; }
    void setFinalResponseTimeMs(const std::string& time_ms) { final_response_time_ms_ = time_ms; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }

    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setPlaybackStartSent(bool sent) { playback_start_sent_ = sent; }

    // Resource setters
    void setConnection(void* conn) { connection_ = conn; }
    void setCircularBuffer(void* buffer) { circular_buffer_ = buffer; }
    void setAudioPlayer(void* audio_player) { audio_player_ = audio_player; }
    void setPlayoutBuffer(void* playout_buffer) { playout_buffer_ = playout_buffer; }
    void setFile(FILE* file) { file_ = file; }
    void setResampler(SpeexResamplerState* resampler) { resampler_ = resampler; }

    // Increment reads atomically
    int incrementReads() {
        std::lock_guard<std::mutex> lock(mutex_);
        return ++reads_;
    }

    // Utility methods
    void reset();
    bool isValid() const;

private:
    void cleanup();
};

#endif