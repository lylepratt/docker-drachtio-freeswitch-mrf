#ifndef __MOD_CUSTOM_TTS_H__
#define __MOD_CUSTOM_TTS_H__

#include <switch.h>

#endif