#include "mod_custom_tts.h"
#include "custom_glue.h"
#include "custom_wrapper.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_custom_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_custom_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_custom_tts, mod_custom_tts_load, mod_custom_tts_shutdown, NULL);

static void clearCustomVendor(custom_handle_t handle, int freeAll) {
  const char* session_id = handle ? custom_tts_get_session_id(handle) : NULL;
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s clearCustomVendor\n", session_id ? session_id : "");
  if (!handle) return;

  // Clear result data
  custom_tts_set_auth_token(handle, "");
  custom_tts_set_custom_tts_url(handle, "");
  custom_tts_set_text_type(handle, "");
  custom_tts_set_content_type(handle, "");
  custom_tts_set_error_message(handle, "");
  custom_tts_set_name_lookup_time_ms(handle, "");
  custom_tts_set_connect_time_ms(handle, "");
  custom_tts_set_final_response_time_ms(handle, "");
  custom_tts_set_cache_filename(handle, "");
  custom_tts_set_playback_id(handle, "");

  if (freeAll) {
    custom_tts_set_voice_name(handle, "");
    custom_tts_set_session_id(handle, "");
  }
}

static custom_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  custom_handle_t handle = (custom_handle_t) sh->private_info;
  if (!handle) {
    handle = custom_tts_create();
    if (handle) {
      sh->private_info = handle;
      // Mutex initialization removed - std::mutex is now managed internally by CustomTts class
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "allocated custom_handle_t\n");
    }
  }
  return handle;
}

switch_status_t w_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  custom_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) return SWITCH_STATUS_FALSE;

  custom_tts_set_voice_name(handle, voice_name);
  custom_tts_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "w_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
  return custom_speech_open(handle);
}

static switch_status_t w_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  custom_handle_t handle;
  const char* playback_id;
  const char* session_id;

  handle = createOrRetrievePrivateData(sh);
  if (!handle) return SWITCH_STATUS_FALSE;

  playback_id = custom_tts_get_playback_id(handle);
  session_id = custom_tts_get_session_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s w_speech_close: %s\n", session_id ? session_id : "", playback_id ? playback_id : "no-playback-id");

  /* mutex allocated from session pool - automatically cleaned up */

  rc = custom_speech_close(handle);
  clearCustomVendor(handle, 1);

  // Release the handle
  custom_tts_release(handle);
  sh->private_info = NULL;

  return rc;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t w_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  custom_handle_t handle;
  const char* playback_id;
  const char* session_id;

  handle = createOrRetrievePrivateData(sh);
  if (!handle) return SWITCH_STATUS_FALSE;

  custom_tts_set_draining(handle, 0);
  custom_tts_set_reads(handle, 0);
  custom_tts_set_response_code(handle, 0);
  custom_tts_set_error_message(handle, "");
  custom_tts_set_playback_start_sent(handle, 0);

  playback_id = custom_tts_get_playback_id(handle);
  session_id = custom_tts_get_session_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s w_speech_feed_tts id: %s\n", session_id ? session_id : "", playback_id ? playback_id : "no-playback-id");

  return custom_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t w_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  custom_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) return SWITCH_STATUS_FALSE;

  return custom_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void w_speech_flush_tts(switch_speech_handle_t *sh)
{
  custom_handle_t handle;
  const char* playback_id;
  const char* session_id;

  handle = createOrRetrievePrivateData(sh);
  if (!handle) return;

  playback_id = custom_tts_get_playback_id(handle);
  session_id = custom_tts_get_session_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s w_speech_flush_tts: %s\n", session_id ? session_id : "", playback_id ? playback_id : "no-playback-id");
  custom_speech_flush_tts(handle);

  clearCustomVendor(handle, 0);
}

static void w_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  custom_handle_t handle = createOrRetrievePrivateData(sh);
  const char* session_id;
  if (!handle) return;

  session_id = custom_tts_get_session_id(handle);
  if (0 == strcmp(param, "auth_token")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s w_text_param_tts: %s=XXXXX\n", session_id ? session_id : "", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s w_text_param_tts: %s=%s\n", session_id ? session_id : "", param, val);
  }
  if (0 == strcmp(param, "auth_token")) {
    custom_tts_set_auth_token(handle, val);
  } else if (0 == strcmp(param, "custom_tts_url")) {
    custom_tts_set_custom_tts_url(handle, val);
  } else if (0 == strcmp(param, "text_type")) {
    custom_tts_set_text_type(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    custom_tts_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    custom_tts_set_cache_audio(handle, 1);
  } else if (0 == strcmp(param, "playback_id")) {
    custom_tts_set_playback_id(handle, val);
  } else if (0 == strcmp(param, "voice")) {
    custom_tts_set_voice_name(handle, val);
  }
}
static void w_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}
static void w_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_custom_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "custom";
  speech_interface->speech_open = w_speech_open;
  speech_interface->speech_close = w_speech_close;
  speech_interface->speech_feed_tts = w_speech_feed_tts;
  speech_interface->speech_read_tts = w_speech_read_tts;
	speech_interface->speech_flush_tts = w_speech_flush_tts;
	speech_interface->speech_text_param_tts = w_text_param_tts;
	speech_interface->speech_numeric_param_tts = w_numeric_param_tts;
	speech_interface->speech_float_param_tts = w_float_param_tts;
  return custom_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_custom_tts_shutdown)
{
  return custom_speech_unload();
}