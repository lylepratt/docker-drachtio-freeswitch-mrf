#ifndef __CUSTOM_GLUE_H__
#define __CUSTOM_GLUE_H__

#include "custom_wrapper.h"

switch_status_t custom_speech_load();
switch_status_t custom_speech_open(custom_handle_t handle);
switch_status_t custom_speech_feed_tts(custom_handle_t handle, char* text, switch_speech_flag_t *flags);
switch_status_t custom_speech_read_tts(custom_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t custom_speech_flush_tts(custom_handle_t handle);
switch_status_t custom_speech_close(custom_handle_t handle);
switch_status_t custom_speech_unload();

#endif