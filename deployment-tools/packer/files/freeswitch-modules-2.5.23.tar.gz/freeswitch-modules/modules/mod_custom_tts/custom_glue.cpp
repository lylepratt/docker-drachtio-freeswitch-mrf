#include "mod_custom_tts.h"
#include "custom_wrapper.h"
#include "custom.hpp"
#include <switch.h>
#include <switch_json.h>
#include <curl/curl.h>
#include <cstdlib>
#include <thread>
#include <chrono>
#include <mutex>

#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/bind/bind.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>
#include <boost/asio.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/algorithm/string.hpp>

#include "mpg123.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"
#include <speex/speex_resampler.h>

#define BUFFER_GROW_SIZE (8192)
#define MP3_DCACHE 8192 * 2

/* Global information, common to all connections */
typedef struct
{
  CURLM *multi;
  int still_running;
} GlobalInfo_t;
static GlobalInfo_t global;

/* Information associated with a specific easy handle */
typedef struct
{
  CURL *easy;
  custom_handle_t custom_handle;  // Changed from pointer to handle
  std::shared_ptr<CustomTts> custom;  // Keep shared_ptr for async operations
  char* body;
  struct curl_slist *hdr_list;
  GlobalInfo_t *global;
  mpg123_handle *mh;  // MP3 decoder (custom_tts specific - not in deepgram)
  char error[CURL_ERROR_SIZE];
  std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
  bool flushed;
  // Format-specific state for handling various audio formats (custom_tts specific)
  bool wav_header_skipped;
  uint8_t partial_sample_buffer[1];
  bool has_partial_sample;
  int wav_header_size;
  int wav_sample_rate;
} ConnInfo_t;


static std::map<curl_socket_t, boost::asio::ip::tcp::socket *> socket_map;
static boost::asio::io_service io_service;
static boost::asio::deadline_timer timer(io_service);
static std::string fullDirPath;
static std::thread worker_thread;
static std::mutex curl_mutex;

std::string secondsToMillisecondsString(double seconds) {
    // Convert to milliseconds
    double milliseconds = seconds * 1000.0;

    // Truncate to remove fractional part
    long milliseconds_long = static_cast<long>(milliseconds);

    // Convert to string
    return std::to_string(milliseconds_long);
}

static std::string getEnvVar(const std::string& varName) {
    const char* val = std::getenv(varName.c_str());
    return val ? std::string(val) : "";
}

static long getConnectionTimeout() {
    std::string connectTimeoutStr = getEnvVar("CUSTOM_TTS_CURL_CONNECT_TIMEOUT");

    if (connectTimeoutStr.empty()) {
        connectTimeoutStr = getEnvVar("TTS_CURL_CONNECT_TIMEOUT");
    }

    long connectTimeout = 10L;

    if (!connectTimeoutStr.empty()) {
        connectTimeout = std::stol(connectTimeoutStr);
    }

    return connectTimeout;
}

static CURL* createEasyHandle(void) {
  CURL* easy = curl_easy_init();
  if(!easy) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "curl_easy_init() failed!\n");
    return nullptr ;
  }  

  curl_easy_setopt(easy, CURLOPT_FOLLOWLOCATION, 1L);
  curl_easy_setopt(easy, CURLOPT_USERAGENT, "jambonz/0.8.5");

  // set connect timeout to 3 seconds and total timeout to 109 seconds
  curl_easy_setopt(easy, CURLOPT_CONNECTTIMEOUT_MS, 3000L);
  curl_easy_setopt(easy, CURLOPT_TIMEOUT, getConnectionTimeout());

  return easy ;
}

static void send_playback_start_event(custom_handle_t handle, switch_channel_t *channel, const char* time_to_first_byte_ms) {
    if (!channel) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "send_playback_start_event: channel is null\n");
        return;
    }

    std::shared_ptr<CustomTts> p = custom_get_shared_ptr(handle);
    if (!p) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "send_playback_start_event: custom shared_ptr is null\n");
        return;
    }

    switch_event_t *event;
    if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) != SWITCH_STATUS_SUCCESS) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "send_playback_start_event: failed to create event\n");
        return;
    }

    switch_channel_event_set_data(channel, event);
    const std::string& playbackId = p->getPlaybackId();
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s send_playback_start_event: firing playback-started %s\n",
                      p->getSessionId().c_str(), playbackId.empty() ? "no-playback-id" : playbackId.c_str());

    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
    if (!playbackId.empty()) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playbackId.c_str());
    }
    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms);

    // Add vendor-specific headers
    const std::string& nameLookupTime = p->getNameLookupTimeMs();
    if (!nameLookupTime.empty()) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_custom_name_lookup_time_ms", nameLookupTime.c_str());
    }
    const std::string& connectTime = p->getConnectTimeMs();
    if (!connectTime.empty()) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_custom_connect_time_ms", connectTime.c_str());
    }
    const std::string& finalResponseTime = p->getFinalResponseTimeMs();
    if (!finalResponseTime.empty()) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_custom_final_response_time_ms", finalResponseTime.c_str());
    }
    const std::string& voiceName = p->getVoiceName();
    if (!voiceName.empty()) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_custom_voice_name", voiceName.c_str());
    }
    const std::string& cacheFilename = p->getCacheFilename();
    if (!cacheFilename.empty()) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cacheFilename.c_str());
    }

    switch_event_fire(&event);
    p->setPlaybackStartSent(true);
}

static void cleanupConn(ConnInfo_t *conn) {
  // Use shared_ptr to ensure thread-safe access
  auto p = conn->custom;
  if (!p) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "cleanupConn: custom shared_ptr is null\n");
    curl_easy_cleanup(conn->easy);
    memset(conn, 0, sizeof(ConnInfo_t));
    delete conn;
    return;
  }

  if( conn->hdr_list ) {
    curl_slist_free_all(conn->hdr_list);
    conn->hdr_list = nullptr ;
  }
  curl_easy_cleanup(conn->easy);

  p->setConnection(nullptr);
  p->setDraining(true);

  if (conn->mh) {
    mpg123_close(conn->mh);
    mpg123_delete(conn->mh);
    conn->mh = nullptr;
  }

  // CRITICAL: Release the handle to decrement reference count
  // This was retained in custom_speech_feed_tts
  if (conn->custom_handle) {
    custom_tts_release(conn->custom_handle);
    conn->custom_handle = nullptr;
  }

  delete conn;
}

/* Check for completed transfers, and remove their easy handles */
void check_multi_info(GlobalInfo_t *g) {
  CURLMsg *msg;
  int msgs_left;
  ConnInfo_t *conn;
  CURL *easy;
  CURLcode res;
  
  while((msg = curl_multi_info_read(g->multi, &msgs_left))) {
    if(msg->msg == CURLMSG_DONE) {
      long response_code;
      double namelookup=0, connect=0, total=0 ;
      char *ct = NULL ;

      easy = msg->easy_handle;
      res = msg->data.result;
      curl_easy_getinfo(easy, CURLINFO_PRIVATE, &conn);
      curl_easy_getinfo(easy, CURLINFO_RESPONSE_CODE, &response_code);
      curl_easy_getinfo(easy, CURLINFO_CONTENT_TYPE, &ct);

      curl_easy_getinfo(easy, CURLINFO_NAMELOOKUP_TIME, &namelookup);
      curl_easy_getinfo(easy, CURLINFO_CONNECT_TIME, &connect);
      curl_easy_getinfo(easy, CURLINFO_TOTAL_TIME, &total);

      auto p = conn->custom;
      if (p) {
        p->setResponseCode(response_code);
        if (ct) p->setContentType(ct);

        std::string name_lookup_ms = secondsToMillisecondsString(namelookup);
        std::string connect_ms = secondsToMillisecondsString(connect);
        std::string final_response_time_ms = secondsToMillisecondsString(total);

        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
          "%s mod_custom_tts: response: %ld, content-type %s,"
          "dns(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
          "connect(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
          "total(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld\n",
          p->getSessionId().c_str(), response_code, ct,
          (long)(namelookup), (long)(fmod(namelookup, 1.0) * 1000000),
          (long)(connect), (long)(fmod(connect, 1.0) * 1000000),
          (long)(total), (long)(fmod(total, 1.0) * 1000000));

        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s name lookup time: %s\n", p->getSessionId().c_str(), name_lookup_ms.c_str());
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s connect time: %s\n", p->getSessionId().c_str(), connect_ms.c_str());
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s final response time: %s\n", p->getSessionId().c_str(), final_response_time_ms.c_str());

        p->setNameLookupTimeMs(name_lookup_ms);
        p->setConnectTimeMs(connect_ms);
        p->setFinalResponseTimeMs(final_response_time_ms);
      }

      curl_multi_remove_handle(g->multi, easy);
      cleanupConn(conn);
    }
  }
}

int mcode_test(const char *where, CURLMcode code) {
  if(CURLM_OK != code) {
    const char *s;
    switch(code) {
    case CURLM_CALL_MULTI_PERFORM:
      s = "CURLM_CALL_MULTI_PERFORM";
      break;
    case CURLM_BAD_HANDLE:
      s = "CURLM_BAD_HANDLE";
      break;
    case CURLM_BAD_EASY_HANDLE:
      s = "CURLM_BAD_EASY_HANDLE";
      break;
    case CURLM_OUT_OF_MEMORY:
      s = "CURLM_OUT_OF_MEMORY";
      break;
    case CURLM_INTERNAL_ERROR:
      s = "CURLM_INTERNAL_ERROR";
      break;
    case CURLM_UNKNOWN_OPTION:
      s = "CURLM_UNKNOWN_OPTION";
      break;
    case CURLM_LAST:
      s = "CURLM_LAST";
      break;
    default:
      s = "CURLM_unknown";
      break;
    case CURLM_BAD_SOCKET:
      s = "CURLM_BAD_SOCKET";
      break;
    }
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mcode_test ERROR: %s returns %s:%d\n", where, s, code);

    return -1;
  }
  return 0 ;
}

static void remsock(int *f, GlobalInfo_t *g) {
  if(f) {
    free(f);
    f = NULL;
  }
}

/* Called by asio when there is an action on a socket */
static void event_cb(GlobalInfo_t *g, curl_socket_t s, int action, const boost::system::error_code & error, int *fdp) {
  int f = *fdp;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X has action %d\n", s, action) ; 

  // Socket already POOL REMOVED.
  if (f == CURL_POLL_REMOVE) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X removed\n", s); 
    remsock(fdp, g);
    return;
  }

  if(socket_map.find(s) == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb: socket  %#X already closed\n, s");
    return;
  }

  /* make sure the event matches what are wanted */
  if(f == action || f == CURL_POLL_INOUT) {
    if(error) {
      action = CURL_CSELECT_ERR;
    }
    
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, s, action, &g->still_running);

    mcode_test("event_cb: curl_multi_socket_action", rc);
    check_multi_info(g);

    if(g->still_running <= 0) {
      timer.cancel();
    }

    /* keep on watching.
      * the socket may have been closed and/or fdp may have been changed
      * in curl_multi_socket_action(), so check them both */
    if(!error && socket_map.find(s) != socket_map.end() &&
        (f == action || f == CURL_POLL_INOUT)) {
      boost::asio::ip::tcp::socket *tcp_socket = socket_map.find(s)->second;

      if(action == CURL_POLL_IN) {
        tcp_socket->async_read_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                                action, boost::placeholders::_1, fdp));
      }
      if(action == CURL_POLL_OUT) {
        tcp_socket->async_write_some(boost::asio::null_buffers(),
                                      boost::bind(&event_cb, g, s,
                                                  action, boost::placeholders::_1, fdp));
      } 
    }
  }
}

/* socket functions */
static void setsock(int *fdp, curl_socket_t s, CURL *e, int act, int oldact, GlobalInfo_t *g) {
  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(s);

  if(it == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "setsock: socket  %#X not found\n, s");
    return;
  }

  boost::asio::ip::tcp::socket * tcp_socket = it->second;

  *fdp = act;

  if(act == CURL_POLL_IN) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_OUT) {
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_INOUT) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
}

static void addsock(curl_socket_t s, CURL *easy, int action, GlobalInfo_t *g) {
  /* fdp is used to store current action */
  int *fdp = (int *) calloc(sizeof(int), 1);

  setsock(fdp, s, easy, action, 0, g);
  curl_multi_assign(g->multi, s, fdp);
}

static int sock_cb(CURL *e, curl_socket_t s, int what, void *cbp, void *sockp) {
  GlobalInfo_t *g = &global;

  int *actionp = (int *) sockp;
  static const char *whatstr[] = { "none", "IN", "OUT", "INOUT", "REMOVE"};

  if(what == CURL_POLL_REMOVE) {
    *actionp = what;
  }
  else {
    if(!actionp) {
      addsock(s, e, what, g);
    }
    else {
      setsock(actionp, s, e, what, *actionp, g);
    }
  }
  return 0;  
}

static void threadFunc() {      
  /* to make sure the event loop doesn't terminate when there is no work to do */
  io_service.reset() ;
  boost::asio::io_service::work work(io_service);
  
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_custom_tts threadFunc - starting\n");

  for(;;) {
      
    try {
      io_service.run() ;
      break ;
    }
    catch( std::exception& e) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_custom_tts threadFunc - Error: %s\n", e.what());
    }
  }
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_custom_tts threadFunc - ending\n");
}


/* Called by asio when our timeout expires */
static void timer_cb(const boost::system::error_code & error, GlobalInfo_t *g)
{
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "timer_cb\n");

  if(!error) {
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, CURL_SOCKET_TIMEOUT, 0, &g->still_running);
    
    mcode_test("timer_cb: curl_multi_socket_action", rc);
    check_multi_info(g);
  }
}

int multi_timer_cb(CURLM *multi, long timeout_ms, GlobalInfo_t *g) {

  /* cancel running timer */
  timer.cancel();

  if(timeout_ms >= 0) {
    // from libcurl 7.88.1-10+deb12u4 does not allow call curl_multi_socket_action or curl_multi_perform in curl_multi callback directly
    timer.expires_from_now(boost::posix_time::millisec(timeout_ms ? timeout_ms : 1));
    timer.async_wait(boost::bind(&timer_cb, boost::placeholders::_1, g));
  }

  return 0;
}

static std::vector<uint16_t> convert_mp3_to_linear(ConnInfo_t *conn, uint8_t *data, size_t len) {
  std::vector<uint16_t> linear_data;
  int eof = 0;
  int mp3err = 0;
  unsigned char decode_buf[MP3_DCACHE];

  if(mpg123_feed(conn->mh, data, len) == MPG123_OK) {
    while(!eof) {
      size_t usedlen = 0;
      off_t frame_offset;
      unsigned char* audio;

      int decode_status = mpg123_decode_frame(conn->mh, &frame_offset, &audio, &usedlen);

      switch(decode_status) {
        case MPG123_NEW_FORMAT:
          continue;

        case MPG123_OK:
          for(size_t i = 0; i < usedlen; i += 2) {
            uint16_t value = reinterpret_cast<uint16_t*>(audio)[i / 2];
            linear_data.push_back(value);
          }
          break;

        case MPG123_DONE:
        case MPG123_NEED_MORE:
          eof = 1;
          break;

        case MPG123_ERR:
        default:
          if(++mp3err >= 5) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Decoder Error!\n");
            eof = 1;
          }
      }

      if (eof)
        break;

      mp3err = 0;
    }
  }

  return linear_data;
}

static int parseAudioRate(const std::string& contentType) {
  // Parse audio/l16;rate=XXXXX format
  size_t ratePos = contentType.find("rate=");
  if (ratePos == std::string::npos) {
    return 0; // No rate specified
  }
  
  size_t rateStart = ratePos + 5; // Skip "rate="
  size_t rateEnd = contentType.find_first_of(";, ", rateStart);
  if (rateEnd == std::string::npos) {
    rateEnd = contentType.length();
  }
  
  std::string rateStr = contentType.substr(rateStart, rateEnd - rateStart);
  try {
    return std::stoi(rateStr);
  } catch (const std::exception& e) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "parseAudioRate: failed to parse rate from %s\n", rateStr.c_str());
    return 0;
  }
}

// WAV header parsing function
static bool parseWavHeader(const uint8_t* data, size_t data_size, int* sample_rate, int* header_size) {
  // Minimum WAV header is 44 bytes
  if (data_size < 44) {
    return false;
  }
  
  // Check RIFF signature
  if (memcmp(data, "RIFF", 4) != 0) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "parseWavHeader: Invalid RIFF signature\n");
    return false;
  }
  
  // Check WAVE signature
  if (memcmp(data + 8, "WAVE", 4) != 0) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "parseWavHeader: Invalid WAVE signature\n");
    return false;
  }
  
  // Look for fmt chunk
  size_t pos = 12;
  while (pos + 8 <= data_size) {
    const uint8_t* chunk_id = data + pos;
    uint32_t chunk_size = *reinterpret_cast<const uint32_t*>(data + pos + 4);
    
    if (memcmp(chunk_id, "fmt ", 4) == 0) {
      // Found fmt chunk, extract sample rate
      if (pos + 8 + 16 <= data_size) { // fmt chunk should be at least 16 bytes
        *sample_rate = *reinterpret_cast<const uint32_t*>(data + pos + 12); // Sample rate is at offset 12 in fmt chunk
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "parseWavHeader: Found sample rate: %d Hz\n", *sample_rate);
      }
    } else if (memcmp(chunk_id, "data", 4) == 0) {
      // Found data chunk, this is where audio data starts
      *header_size = pos + 8;
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "parseWavHeader: Header size: %d bytes\n", *header_size);
      return true;
    }
    
    // Move to next chunk
    pos += 8 + chunk_size;
    if (chunk_size % 2 == 1) pos++; // WAV chunks are word-aligned
  }
  
  // If we get here, we didn't find a data chunk
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "parseWavHeader: No data chunk found\n");
  return false;
}

// Helper function to handle partial audio samples for 16-bit formats
static void handlePartialSamples(ConnInfo_t *conn, uint8_t* input_data, size_t input_size, 
                                 uint8_t** output_data, size_t* output_size, bool* allocated_memory) {
  size_t effective_bytes = input_size;
  uint8_t* effective_data = input_data;
  *allocated_memory = false;
  
  // Handle partial sample from previous chunk
  if (conn->has_partial_sample) {
    // We have a partial sample from last time, combine it with current data
    size_t combined_size = input_size + 1;
    uint8_t* combined_data = (uint8_t*)malloc(combined_size);
    combined_data[0] = conn->partial_sample_buffer[0];
    memcpy(combined_data + 1, input_data, input_size);
    
    effective_data = combined_data;
    effective_bytes = combined_size;
    conn->has_partial_sample = false;
    *allocated_memory = true;
  }
  
  // Check if we have an odd number of bytes (incomplete sample at the end)
  if (effective_bytes % 2 == 1) {
    // Save the last byte for next chunk
    conn->partial_sample_buffer[0] = effective_data[effective_bytes - 1];
    conn->has_partial_sample = true;
    effective_bytes--; // Reduce by 1 to make it even
  }
  
  *output_data = effective_data;
  *output_size = effective_bytes;
}

/* CURLOPT_WRITEFUNCTION */
static size_t write_cb(void *ptr, size_t size, size_t nmemb, ConnInfo_t *conn) {
  bool fireEvent = false;
  uint8_t *data = (uint8_t *) ptr;
  size_t bytes_received = size * nmemb;
  auto p = conn->custom;
  if (!p) return 0;
  AudioPlayer *pAudioPlayer = (AudioPlayer *) p->getAudioPlayer();
  std::vector<uint16_t> pcm_data;
  bool allocated_memory = false;

  if (conn->flushed || pAudioPlayer == nullptr) {
    /* this will abort the transfer */
    return 0;
  }

  if (p->getResponseCode() > 0 && p->getResponseCode() != 200) {
    std::string body((char *) ptr, bytes_received);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: received body %s\n", p->getSessionId().c_str(), body.c_str());
    p->setErrorMessage(body);
    return 0;
  }

  // Process audio based on content type
  size_t bytesToBuffer = 0;
  const char* audioData = nullptr;
  int sourceRate = 0;

  if (!p->getContentType().empty()) {
    std::string contentType = p->getContentType();
    boost::to_lower(contentType);

    if (contentType.find("audio/mpeg") != std::string::npos || contentType.find("audio/mp3") != std::string::npos) {
      // Handle MP3 audio - after convert_mp3_to_linear, data is at p->getRate() due to MPG123_FORCE_RATE
      pcm_data = convert_mp3_to_linear(conn, data, bytes_received);
      bytesToBuffer = pcm_data.size() * sizeof(uint16_t);
      audioData = reinterpret_cast<const char*>(pcm_data.data());
      sourceRate = p->getRate(); // MP3 is decoded to p->getRate() due to MPG123_FORCE_RATE

    } else if (contentType.find("audio/l16") != std::string::npos) {
      // Handle raw L16 audio - buffer directly, but handle partial samples
      uint8_t* effective_data;
      size_t effective_bytes;

      handlePartialSamples(conn, data, bytes_received, &effective_data, &effective_bytes, &allocated_memory);

      bytesToBuffer = effective_bytes;
      audioData = reinterpret_cast<const char*>(effective_data);
      sourceRate = parseAudioRate(contentType);
      if (sourceRate == 0) sourceRate = p->getRate(); // fallback to configured rate
      
    } else if (contentType.find("audio/wav") != std::string::npos || contentType.find("audio/x-wav") != std::string::npos) {
      // Handle WAV audio - parse header on first packet and handle partial samples
      if (!conn->wav_header_skipped) {
        if (bytes_received > 44) {
          // Parse the WAV header to get actual header size and sample rate
          if (parseWavHeader(data, bytes_received, &conn->wav_sample_rate, &conn->wav_header_size)) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s write_cb: WAV header parsed - size: %d bytes, rate: %d Hz\n",
                            p->getSessionId().c_str(), conn->wav_header_size, conn->wav_sample_rate);
          } else {
            // Header parsing failed - treat as headerless WAV with raw audio
            conn->wav_header_size = 0;
            conn->wav_sample_rate = 8000;
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s write_cb: WAV header parsing failed, treating as headerless WAV at 8000 Hz\n", p->getSessionId().c_str());
          }
        } else {
          // Not enough data for header - treat as headerless WAV with raw audio
          conn->wav_header_size = 0;
          conn->wav_sample_rate = 8000;
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s write_cb: WAV file without header, using 8000 Hz default\n", p->getSessionId().c_str());
        }

        // Set up resampling if the WAV file sample rate differs from the target rate
        if (conn->wav_sample_rate != p->getRate()) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s write_cb: Setting up WAV resampling from %d Hz to %d Hz\n",
                          p->getSessionId().c_str(), conn->wav_sample_rate, p->getRate());
          pAudioPlayer->setResampling(conn->wav_sample_rate, p->getRate());
        }
        
        if (bytes_received > conn->wav_header_size) {
          // Skip the WAV header (if any), then handle partial samples
          uint8_t* wav_data = data + conn->wav_header_size;
          size_t wav_data_size = bytes_received - conn->wav_header_size;
          
          uint8_t* effective_data;
          size_t effective_bytes;
          
          handlePartialSamples(conn, wav_data, wav_data_size, &effective_data, &effective_bytes, &allocated_memory);
          
          bytesToBuffer = effective_bytes;
          audioData = reinterpret_cast<const char*>(effective_data);
          conn->wav_header_skipped = true;
        } else {
          // Entire packet is header, skip it (only applies when header_size > 0)
          conn->wav_header_skipped = true;
          return bytes_received;
        }
      } else {
        // Header already skipped, handle partial samples for subsequent chunks
        uint8_t* effective_data;
        size_t effective_bytes;
        
        handlePartialSamples(conn, data, bytes_received, &effective_data, &effective_bytes, &allocated_memory);
        
        bytesToBuffer = effective_bytes;
        audioData = reinterpret_cast<const char*>(effective_data);
      }
      sourceRate = conn->wav_sample_rate;
    } else {
      // Unknown format, try to handle as raw audio
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "%s write_cb: unknown content type %s, treating as raw audio\n", p->getSessionId().c_str(), contentType.c_str());
      bytesToBuffer = bytes_received;
      audioData = reinterpret_cast<const char*>(data);
      sourceRate = p->getRate(); // fallback to configured rate
    }
  } else {
    // No content type specified, default to MP3 for backward compatibility
    pcm_data = convert_mp3_to_linear(conn, data, bytes_received);
    bytesToBuffer = pcm_data.size() * sizeof(uint16_t);
    audioData = reinterpret_cast<const char*>(pcm_data.data());
    sourceRate = p->getRate(); // MP3 is decoded to p->getRate() due to MPG123_FORCE_RATE
  }

  // Buffer audio for playback
  if (bytesToBuffer > 0 && audioData) {
    pAudioPlayer->bufferAudio(audioData, bytesToBuffer);
  }

  // Clean up any allocated memory for partial sample handling
  if (allocated_memory) {
    free(const_cast<char*>(audioData));
  }

  if (conn->flushed || !p) return bytes_received;

  if (0 == p->getReads()) {
    fireEvent = true;
  }
  p->incrementReads();
  const std::string& sessionId = p->getSessionId();
  if (fireEvent && !sessionId.empty()) {
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - conn->startTime);
    auto time_to_first_byte_ms = std::to_string(duration.count());
    switch_core_session_t* session = switch_core_session_locate(sessionId.c_str());
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_core_session_rwunlock(session);
      if (channel) {
        send_playback_start_event(conn->custom_handle, channel, time_to_first_byte_ms.c_str());
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: channel not found\n", sessionId.c_str());
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: session not found\n", sessionId.c_str());
    }
  }
  return bytes_received;
}

static bool parseHeader(const std::string& str, std::string& header, std::string& value) {
    std::vector<std::string> parts;
    boost::split(parts, str, boost::is_any_of(":"), boost::token_compress_on);

    if (parts.size() != 2)
        return false;

    header = boost::trim_copy(parts[0]);
    value = boost::trim_copy(parts[1]);
    return true;
}

static int extract_response_code(const std::string& input) {
  std::size_t space_pos = input.find(' ');
  if (space_pos == std::string::npos) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Invalid HTTP response format %s\n", input.c_str());
    return 0;
  }

  std::size_t code_start_pos = space_pos + 1;
  std::size_t code_end_pos = input.find(' ', code_start_pos);
  if (code_end_pos == std::string::npos) {
    code_end_pos = input.length();
  }

  std::string code_str = input.substr(code_start_pos, code_end_pos - code_start_pos);
  try {
    return std::stoi(code_str);
  } catch (const std::exception& e) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "extract_response_code: failed to parse response code from %s\n", code_str.c_str());
    return 0;
  }
}

static size_t header_callback(char *buffer, size_t size, size_t nitems, ConnInfo_t *conn) {
  size_t bytes_received = size * nitems;
  const std::string prefix = "HTTP/";
  auto p = conn->custom;
  if (!p) return bytes_received;

  std::string header, value;
  std::string input(buffer, bytes_received);
  if (parseHeader(input, header, value)) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s recv header: %s with value %s\n", p->getSessionId().c_str(), header.c_str(), value.c_str());
    if (boost::iequals(header, "Content-Type")) {
      p->setContentType(value);

      // Check if this is audio/l16 with a specific rate
      std::string contentType = value;
      boost::to_lower(contentType); // Convert to lowercase for comparison

      if (contentType.find("audio/l16") == 0) {
        int sourceRate = parseAudioRate(contentType);
        if (sourceRate > 0 && sourceRate != p->getRate()) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s Setting up resampling from %d to %d Hz\n", p->getSessionId().c_str(), sourceRate, p->getRate());
          AudioPlayer *audioPlayer = (AudioPlayer *) p->getAudioPlayer();
          if (audioPlayer) {
            audioPlayer->setResampling(sourceRate, p->getRate());
          }
        }
      }
    }

  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s header_callback: %s\n", p->getSessionId().c_str(), input.c_str());
    if (input.rfind(prefix, 0) == 0) {
      try {
        long response_code = extract_response_code(input);
        p->setResponseCode(response_code);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s header_callback: parsed response code: %ld\n", p->getSessionId().c_str(), response_code);
      } catch (const std::invalid_argument& e) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s header_callback: invalid response code %s\n", p->getSessionId().c_str(), input.substr(prefix.length()).c_str());
      }
    }
  }
  return bytes_received;
}

/* CURLOPT_OPENSOCKETFUNCTION */
static curl_socket_t opensocket(void *clientp, curlsocktype purpose, struct curl_sockaddr *address) {
  curl_socket_t sockfd = CURL_SOCKET_BAD;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "opensocket: %d\n", purpose);
  /* restrict to IPv4 */
  if(purpose == CURLSOCKTYPE_IPCXN && address->family == AF_INET) {
    /* create a tcp socket object */
    boost::asio::ip::tcp::socket *tcp_socket = new boost::asio::ip::tcp::socket(io_service);

    /* open it and get the native handle*/
    boost::system::error_code ec;
    tcp_socket->open(boost::asio::ip::tcp::v4(), ec);

    if(ec) {
      /* An error occurred */
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't open socket [%d][%s]\n", ec.value(), ec.message().c_str());
    }
    else {
      sockfd = tcp_socket->native_handle();

      /* save it for monitoring */
      socket_map.insert(std::pair<curl_socket_t, boost::asio::ip::tcp::socket *>(sockfd, tcp_socket));
    }
  }
  return sockfd;
}

/* CURLOPT_CLOSESOCKETFUNCTION */
static int close_socket(void *clientp, curl_socket_t item) {
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "close_socket : %#X\n", item);

  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(item);
  if(it != socket_map.end()) {
    delete it->second;
    socket_map.erase(it);
  }
  return 0;
}


extern "C" {
  switch_status_t custom_speech_load() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "custom_speech_loading..\n");
    memset(&global, 0, sizeof(GlobalInfo_t));
    global.multi = curl_multi_init();

     if (!global.multi) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "custom_speech_load curl_multi_init() failed, exiting!\n");
      return SWITCH_STATUS_FALSE;
    }

    curl_multi_setopt(global.multi, CURLMOPT_SOCKETFUNCTION, sock_cb);
    curl_multi_setopt(global.multi, CURLMOPT_SOCKETDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERFUNCTION, multi_timer_cb);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);

    /* create temp folder for cache files */
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) {
      baseDir = "/tmp/";
    }
    if (strcmp(baseDir, "/") == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", baseDir);
      return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    // Create the directory with read, write, and execute permissions for everyone
    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);
    if (result != 0) {
      if (errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", fullDirPath.c_str());
        fullDirPath = "";
      }
      else switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "folder %s already exists\n", fullDirPath.c_str());
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "created folder %s\n", fullDirPath.c_str());
    }
    // init mgp123
    if (mpg123_init() != MPG123_OK) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to initiate MPG123");
      return SWITCH_STATUS_FALSE;
    }

    /* start worker thread that handles transfers*/
    std::thread t(threadFunc) ;
    worker_thread.swap( t ) ;

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "custom_speech_loaded..\n");


    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t custom_speech_unload() {
    /* stop the ASIO IO service */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "custom_speech_unload: stopping io service\n");
    io_service.stop();

    /* Join the worker thread */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "custom_speech_unload: wait for worker thread to complete\n");
    if (worker_thread.joinable()) {
        worker_thread.join();
    }

    /* cleanup curl multi handle*/
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "custom_speech_unload: release curl multi\n");
    curl_multi_cleanup(global.multi);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "custom_speech_unload: completed\n");

    mpg123_exit();

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t custom_speech_open(custom_handle_t handle) {
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t custom_speech_feed_tts(custom_handle_t handle, char* text, switch_speech_flag_t *flags) {
    // Get shared_ptr for thread-safe access
    std::shared_ptr<CustomTts> p = custom_get_shared_ptr(handle);
    if (!p) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "custom_speech_feed_tts: invalid handle\n");
      return SWITCH_STATUS_FALSE;
    }
    CURLMcode rc;

    const int MAX_CHARS = 20;
    char tempText[MAX_CHARS + 4]; // +4 for the ellipsis and null terminator

    if (strlen(text) > MAX_CHARS) {
        strncpy(tempText, text, MAX_CHARS);
        strcpy(tempText + MAX_CHARS, "...");
    } else {
        strcpy(tempText, text);
    }

    /* generate cache filename if needed */
    if (p->isCacheAudio() && fullDirPath.length() > 0) {
      switch_uuid_t uuid;
      char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
      char outfile[512] = "";

      switch_uuid_get(&uuid);
      switch_uuid_format(uuid_str, &uuid);

      switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
      p->setCacheFilename(outfile);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s cache file will be: %s\n", p->getSessionId().c_str(), p->getCacheFilename().c_str());
    }

    if (p->getCustomTtsUrl().empty()) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s custom_speech_feed_tts: no custom_tts_url provided\n", p->getSessionId().c_str());
      return SWITCH_STATUS_FALSE;
    }

    /* format url*/
    std::string url = p->getCustomTtsUrl();

    /* create the JSON body */
    cJSON * jResult = cJSON_CreateObject();
    cJSON_AddStringToObject(jResult, "text", text);
    cJSON_AddStringToObject(jResult, "type", std::strncmp(text, "<speak", 6) == 0 ? "ssml" : "text");
    if (!p->getTextType().empty()) {
      cJSON_AddStringToObject(jResult, "text_type", p->getTextType().c_str());
    }
    if (!p->getVoiceName().empty()) {
      cJSON_AddStringToObject(jResult, "voice", p->getVoiceName().c_str());
    }
    char *json = cJSON_PrintUnformatted(jResult);

    cJSON_Delete(jResult);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s custom_speech_feed_tts: [%s] [%s]\n", p->getSessionId().c_str(), url.c_str(), tempText);

    ConnInfo_t *conn = new ConnInfo_t();
    memset(conn, 0, sizeof(ConnInfo_t));

    // Configure MPG123
    int mhError = 0;
    mpg123_handle *mh = mpg123_new("auto", &mhError);
    if (!mh) {
      const char *mhErr = mpg123_plain_strerror(mhError);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error allocating mpg123 handle! %s\n", switch_str_nil(mhErr));
      return SWITCH_STATUS_FALSE;
    }

    if (mpg123_open_feed(mh) != MPG123_OK) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error mpg123_open_feed!\n");
      return SWITCH_STATUS_FALSE;
		}

    if (mpg123_format_all(mh) != MPG123_OK) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error mpg123_format_all!\n");
      return SWITCH_STATUS_FALSE;
		}

    if (mpg123_param(mh, MPG123_FLAGS, MPG123_MONO_MIX, 0) != MPG123_OK) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error forcing single channel!\n");
      return SWITCH_STATUS_FALSE;
    }

    CURL* easy = createEasyHandle();
    p->setConnection((void *) conn);

    // CRITICAL: Store both handle and shared_ptr for thread safety
    // The handle is retained here and released in cleanupConn
    custom_tts_retain(handle);
    conn->custom_handle = handle;
    conn->custom = p;  // Store shared_ptr for async operations

    conn->easy = easy;
    conn->mh = mh;
    conn->global = &global;
    conn->hdr_list = NULL ;
    conn->body = json;
    conn->flushed = false;
    conn->wav_header_skipped = false;
    conn->has_partial_sample = false;
    conn->wav_header_size = 0;
    conn->wav_sample_rate = 0;

    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(p->getMutex(), playoutBuffer);

    if (!p->getCacheFilename().empty()) {
      audioPlayer->setCacheFilePath(p->getCacheFilename());
    }

    p->setPlayoutBuffer((void *) playoutBuffer);
    p->setAudioPlayer((void *) audioPlayer);

    if (mpg123_param(mh, MPG123_FORCE_RATE, p->getRate() /*Hz*/, 0) != MPG123_OK) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error mpg123_param!\n");
      return SWITCH_STATUS_FALSE;
    }

    curl_easy_setopt(easy, CURLOPT_URL, url.c_str());
    curl_easy_setopt(easy, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(easy, CURLOPT_WRITEDATA, conn);
    curl_easy_setopt(easy, CURLOPT_ERRORBUFFER, conn->error);
    curl_easy_setopt(easy, CURLOPT_PRIVATE, conn);
    curl_easy_setopt(easy, CURLOPT_VERBOSE, 0L);
    curl_easy_setopt(easy, CURLOPT_NOPROGRESS, 1L);
    curl_easy_setopt(easy, CURLOPT_HEADERFUNCTION, header_callback);
    curl_easy_setopt(easy, CURLOPT_HEADERDATA, conn);

    /* call this function to get a socket */
    curl_easy_setopt(easy, CURLOPT_OPENSOCKETFUNCTION, opensocket);

    /* call this function to close a socket */
    curl_easy_setopt(easy, CURLOPT_CLOSESOCKETFUNCTION, close_socket);

    if (!p->getAuthToken().empty()) {
      std::ostringstream api_key_stream;
      api_key_stream << "Authorization: Bearer " << p->getAuthToken();
      conn->hdr_list = curl_slist_append(conn->hdr_list, api_key_stream.str().c_str());
    }
    conn->hdr_list = curl_slist_append(conn->hdr_list, "Accept: audio/mpeg");
    conn->hdr_list = curl_slist_append(conn->hdr_list, "Content-Type: application/json");
    curl_easy_setopt(easy, CURLOPT_HTTPHEADER, conn->hdr_list);

    curl_easy_setopt(easy, CURLOPT_POSTFIELDS, conn->body);
    //curl_easy_setopt(easy, CURLOPT_POSTFIELDSIZE, body.length());

    curl_easy_setopt(easy, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);

    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    rc = curl_multi_add_handle(global.multi, conn->easy);

    mcode_test("new_conn: curl_multi_add_handle", rc);

    /* start a timer to measure the duration until we receive first byte of audio */
    conn->startTime = std::chrono::high_resolution_clock::now();

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s custom_speech_feed_tts: called curl_multi_add_handle\n", p->getSessionId().c_str());


    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t custom_speech_read_tts(custom_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    // Get shared_ptr for thread-safe access
    std::shared_ptr<CustomTts> p = custom_get_shared_ptr(handle);
    if (!p) {
      memset(data, 255, *datalen);
      return SWITCH_STATUS_SUCCESS;
    }
    CircularBuffer *playoutBuffer = (CircularBuffer *) p->getPlayoutBuffer();
    int samplesToCopy = 0;

    // Try lock approach with std::mutex
    std::unique_lock<std::mutex> lock(p->getMutex(), std::try_to_lock);
    if (lock.owns_lock()) {
      ConnInfo_t *conn = (ConnInfo_t *) p->getConnection();
      if (p->getResponseCode() > 0 && p->getResponseCode() != 200) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s custom_speech_read_tts, returning failure\n", p->getSessionId().c_str()) ;
        return SWITCH_STATUS_FALSE;
      }

      if (conn && conn->flushed) {
        return SWITCH_STATUS_BREAK;
      }

      if (playoutBuffer->size() == 0) {
        if (p->isDraining()) {
          return SWITCH_STATUS_BREAK;
        }
        /* no audio available yet so send silence */
        memset(data, 255, *datalen);
        return SWITCH_STATUS_SUCCESS;
      }
      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(*datalen / sizeof(int16_t)));

      auto count = playoutBuffer->getBlock(reinterpret_cast<int16_t*>(data), samplesToCopy);
      if (count != samplesToCopy) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s custom_speech_read_tts - failed to get %d samples from playout buffer, got %d\n", p->getSessionId().c_str(), samplesToCopy, count);
      }
      *datalen = count * sizeof(int16_t);
    } else {
      /* no audio available yet so send silence */
      memset(data, 255, *datalen);
      return SWITCH_STATUS_SUCCESS;
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "custom_speech_read_tts failed to lock mutex\n");
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t custom_speech_flush_tts(custom_handle_t handle) {
    // Get shared_ptr for thread-safe access
    std::shared_ptr<CustomTts> p = custom_get_shared_ptr(handle);
    if (!p) {
      return SWITCH_STATUS_SUCCESS;
    }
    bool download_complete = p->getResponseCode() == 200;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s custom_speech_flush_tts, download complete? %s\n", p->getSessionId().c_str(), download_complete ? "yes" : "no") ;

    ConnInfo_t *conn = nullptr;
    {
      std::lock_guard<std::mutex> lock(curl_mutex);
      conn = (ConnInfo_t *) p->getConnection();
      if (conn) {
        conn->flushed = true;  // Set this while we have curl_mutex
      }
    }

    // Extract pointers while holding lock, then delete outside lock to avoid deadlock
    // The consumer thread needs p->getMutex() to finish, so we can't hold it during thread join
    AudioPlayer* audioPlayer = nullptr;
    CircularBuffer* playoutBuffer = nullptr;

    {
      std::lock_guard<std::mutex> lock(p->getMutex());

      // Get pointers and clear them while holding lock
      if (p->getAudioPlayer()) {
        audioPlayer = static_cast<AudioPlayer*>(p->getAudioPlayer());
        p->setAudioPlayer(nullptr);  // Clear pointer first
      }

      if (p->getPlayoutBuffer()) {
        playoutBuffer = static_cast<CircularBuffer*>(p->getPlayoutBuffer());
        p->setPlayoutBuffer(nullptr);  // Clear pointer first
      }
    }  // Release p->getMutex() here - consumer thread can now finish and exit

    // Delete outside the lock - this allows consumer thread to complete its work and exit
    // delete audioPlayer will call consumer_thread.join() which waits for the thread to exit
    if (audioPlayer) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s destroying audio player\n", p->getSessionId().c_str());
      delete audioPlayer;  // This closes the cache file after consumer thread finishes
    }

    if (playoutBuffer) {
      delete playoutBuffer;
    }

    // If download was incomplete, delete the cache file
    if (!p->getCacheFilename().empty() && !download_complete) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s removing incomplete cache file %s (response code: %ld)\n",
        p->getSessionId().c_str(), p->getCacheFilename().c_str(), p->getResponseCode());
      if (unlink(p->getCacheFilename().c_str()) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s error removing incomplete cache file %s: %d:%s\n",
          p->getSessionId().c_str(), p->getCacheFilename().c_str(), errno, strerror(errno));
      }
      p->setCacheFilename("");  // Clear filename so we don't report it in PLAYBACK_STOP event
    }

    if (!p->getSessionId().empty()) {
      switch_core_session_t* session = switch_core_session_locate(p->getSessionId().c_str());
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);
        switch_core_session_rwunlock(session);
        if (channel) {
          // Check if PLAYBACK_START was never sent and send it now if needed
          if (!p->isPlaybackStartSent()) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s custom_speech_flush_tts: callback was never called, sending delayed playback-started event\n", p->getSessionId().c_str());
            send_playback_start_event(handle, channel, "0");

            // Add 100ms delay before sending PLAYBACK_STOP
            switch_yield(100000);
          }

          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);

            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s custom_speech_flush_tts: firing playback-stopped %s\n",
              p->getSessionId().c_str(), !p->getPlaybackId().empty() ? p->getPlaybackId().c_str() : "no-playback-id");

            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (!p->getPlaybackId().empty()) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", p->getPlaybackId().c_str());
            }
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_custom_response_code", std::to_string(p->getResponseCode()).c_str());
            if (!p->getCacheFilename().empty() && p->getResponseCode() == 200) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", p->getCacheFilename().c_str());
            }
            if (p->getResponseCode() != 200 && !p->getErrorMessage().empty()) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", p->getErrorMessage().c_str());
            }
            switch_event_fire(&event);
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s custom_speech_flush_tts: failed to create event\n", p->getSessionId().c_str());
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s custom_speech_flush_tts: channel not found\n", p->getSessionId().c_str());
        }
      }
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t custom_speech_close(custom_handle_t handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "custom_speech_close\n") ;
		return SWITCH_STATUS_SUCCESS;
	}
}
