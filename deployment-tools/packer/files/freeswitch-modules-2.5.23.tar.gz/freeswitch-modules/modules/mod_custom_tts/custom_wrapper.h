// custom_wrapper.h - C-compatible header
#ifndef __CUSTOM_WRAPPER_H__
#define __CUSTOM_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct custom_handle* custom_handle_t;

#ifdef __cplusplus
#include <memory>

// Forward declaration
class CustomTts;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<CustomTts> custom_get_shared_ptr(custom_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
custom_handle_t custom_get_handle_from_shared_ptr(const std::shared_ptr<CustomTts>& ptr);

extern "C" {
#endif

// C API functions
custom_handle_t custom_tts_create(void);
void custom_tts_retain(custom_handle_t handle);
void custom_tts_release(custom_handle_t handle);

// Configuration getters
const char* custom_tts_get_voice_name(custom_handle_t handle);
const char* custom_tts_get_auth_token(custom_handle_t handle);
const char* custom_tts_get_custom_tts_url(custom_handle_t handle);
const char* custom_tts_get_custom_tts_method(custom_handle_t handle);
const char* custom_tts_get_text_type(custom_handle_t handle);
const char* custom_tts_get_session_id(custom_handle_t handle);
const char* custom_tts_get_cache_filename(custom_handle_t handle);
const char* custom_tts_get_playback_id(custom_handle_t handle);

// Result data getters
long custom_tts_get_response_code(custom_handle_t handle);
const char* custom_tts_get_content_type(custom_handle_t handle);
const char* custom_tts_get_request_id(custom_handle_t handle);
const char* custom_tts_get_name_lookup_time_ms(custom_handle_t handle);
const char* custom_tts_get_connect_time_ms(custom_handle_t handle);
const char* custom_tts_get_final_response_time_ms(custom_handle_t handle);
const char* custom_tts_get_error_message(custom_handle_t handle);

// State getters
int custom_tts_get_rate(custom_handle_t handle);
int custom_tts_is_draining(custom_handle_t handle);
int custom_tts_get_reads(custom_handle_t handle);
int custom_tts_is_cache_audio(custom_handle_t handle);
int custom_tts_is_playback_start_sent(custom_handle_t handle);

// Resource getters
void* custom_tts_get_connection(custom_handle_t handle);
void* custom_tts_get_circular_buffer(custom_handle_t handle);
FILE* custom_tts_get_file(custom_handle_t handle);
void* custom_tts_get_resampler(custom_handle_t handle);

// Configuration setters
void custom_tts_set_voice_name(custom_handle_t handle, const char* voice_name);
void custom_tts_set_auth_token(custom_handle_t handle, const char* auth_token);
void custom_tts_set_custom_tts_url(custom_handle_t handle, const char* url);
void custom_tts_set_custom_tts_method(custom_handle_t handle, const char* method);
void custom_tts_set_text_type(custom_handle_t handle, const char* text_type);
void custom_tts_set_session_id(custom_handle_t handle, const char* session_id);
void custom_tts_set_cache_filename(custom_handle_t handle, const char* cache_filename);
void custom_tts_set_playback_id(custom_handle_t handle, const char* playback_id);

// Result data setters
void custom_tts_set_response_code(custom_handle_t handle, long response_code);
void custom_tts_set_content_type(custom_handle_t handle, const char* content_type);
void custom_tts_set_request_id(custom_handle_t handle, const char* request_id);
void custom_tts_set_name_lookup_time_ms(custom_handle_t handle, const char* time_ms);
void custom_tts_set_connect_time_ms(custom_handle_t handle, const char* time_ms);
void custom_tts_set_final_response_time_ms(custom_handle_t handle, const char* time_ms);
void custom_tts_set_error_message(custom_handle_t handle, const char* error_msg);

// State setters
void custom_tts_set_rate(custom_handle_t handle, int rate);
void custom_tts_set_draining(custom_handle_t handle, int draining);
void custom_tts_set_reads(custom_handle_t handle, int reads);
void custom_tts_set_cache_audio(custom_handle_t handle, int cache_audio);
void custom_tts_set_playback_start_sent(custom_handle_t handle, int sent);

// Resource setters
void custom_tts_set_connection(custom_handle_t handle, void* conn);
void custom_tts_set_circular_buffer(custom_handle_t handle, void* buffer);
void custom_tts_set_file(custom_handle_t handle, FILE* file);
void custom_tts_set_resampler(custom_handle_t handle, void* resampler);

// Utility
int custom_tts_increment_reads(custom_handle_t handle);

#ifdef __cplusplus
}
#endif

#endif