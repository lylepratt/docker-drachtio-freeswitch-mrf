#include "custom_wrapper.h"
#include "custom.hpp"
#include <memory>
#include <mutex>
#include <unordered_map>

// Internal handle structure
struct custom_handle {
    std::shared_ptr<CustomTts> instance;
    int ref_count;
    std::mutex ref_mutex;

    custom_handle(std::shared_ptr<CustomTts> inst)
        : instance(std::move(inst)), ref_count(1) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "custom_handle initialized with ref_count %d\n", ref_count);
        }
};

// Thread-safe handle management
static std::mutex g_handle_mutex;
static std::unordered_map<custom_handle_t, std::unique_ptr<custom_handle>> g_handles;

// Helper function to validate handle
static custom_handle* get_handle(custom_handle_t handle) {
    if (!handle) return nullptr;

    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second.get() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
std::shared_ptr<CustomTts> custom_get_shared_ptr(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance : nullptr;
}

// Private internal function to get handle from shared_ptr
custom_handle_t custom_get_handle_from_shared_ptr(const std::shared_ptr<CustomTts>& ptr) {
    if (!ptr) return nullptr;

    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->instance == ptr) {
            return pair.first;
        }
    }
    return nullptr;
}

// C API Implementation
extern "C" {

custom_handle_t custom_tts_create(void) {
    try {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "custom_tts_create\n");

        auto instance = CustomTts::create();
        auto handle = std::make_unique<custom_handle>(instance);
        custom_handle_t handle_ptr = handle.get();

        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles[handle_ptr] = std::move(handle);

        return handle_ptr;
    } catch (...) {
        return nullptr;
    }
}

void custom_tts_retain(custom_handle_t handle) {
    auto* h = get_handle(handle);
    if (h) {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "custom_tts_retain, ref count %d\n", h->ref_count);
    }
}

void custom_tts_release(custom_handle_t handle) {
    auto* h = get_handle(handle);
    if (!h) return;

    bool should_delete = false;
    {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count--;
        should_delete = (h->ref_count <= 0);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "custom_tts_release, ref count %d\n", h->ref_count);
    }

    if (should_delete) {
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles.erase(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "custom_tts_release, handle erased\n");
    }
}

// Configuration getters
const char* custom_tts_get_voice_name(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceName().c_str() : nullptr;
}

const char* custom_tts_get_auth_token(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getAuthToken().c_str() : nullptr;
}

const char* custom_tts_get_custom_tts_url(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCustomTtsUrl().c_str() : nullptr;
}

const char* custom_tts_get_custom_tts_method(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCustomTtsMethod().c_str() : nullptr;
}

const char* custom_tts_get_text_type(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getTextType().c_str() : nullptr;
}

const char* custom_tts_get_session_id(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSessionId().c_str() : nullptr;
}

const char* custom_tts_get_cache_filename(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCacheFilename().c_str() : nullptr;
}

const char* custom_tts_get_playback_id(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlaybackId().c_str() : nullptr;
}

// Result data getters
long custom_tts_get_response_code(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getResponseCode() : 0;
}

const char* custom_tts_get_content_type(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getContentType().c_str() : nullptr;
}

const char* custom_tts_get_request_id(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRequestId().c_str() : nullptr;
}

const char* custom_tts_get_name_lookup_time_ms(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getNameLookupTimeMs().c_str() : nullptr;
}

const char* custom_tts_get_connect_time_ms(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnectTimeMs().c_str() : nullptr;
}

const char* custom_tts_get_final_response_time_ms(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFinalResponseTimeMs().c_str() : nullptr;
}

const char* custom_tts_get_error_message(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getErrorMessage().c_str() : nullptr;
}

// State getters
int custom_tts_get_rate(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRate() : 0;
}

int custom_tts_is_draining(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->isDraining() : 0;
}

int custom_tts_get_reads(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReads() : 0;
}

int custom_tts_is_cache_audio(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->isCacheAudio() : 0;
}

int custom_tts_is_playback_start_sent(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->isPlaybackStartSent() : 0;
}

// Resource getters
void* custom_tts_get_connection(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnection() : nullptr;
}

void* custom_tts_get_circular_buffer(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCircularBuffer() : nullptr;
}

FILE* custom_tts_get_file(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFile() : nullptr;
}

void* custom_tts_get_resampler(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getResampler() : nullptr;
}

// Configuration setters
void custom_tts_set_voice_name(custom_handle_t handle, const char* voice_name) {
    auto* h = get_handle(handle);
    if (h && voice_name) h->instance->setVoiceName(voice_name);
}

void custom_tts_set_auth_token(custom_handle_t handle, const char* auth_token) {
    auto* h = get_handle(handle);
    if (h && auth_token) h->instance->setAuthToken(auth_token);
}

void custom_tts_set_custom_tts_url(custom_handle_t handle, const char* url) {
    auto* h = get_handle(handle);
    if (h && url) h->instance->setCustomTtsUrl(url);
}

void custom_tts_set_custom_tts_method(custom_handle_t handle, const char* method) {
    auto* h = get_handle(handle);
    if (h && method) h->instance->setCustomTtsMethod(method);
}

void custom_tts_set_text_type(custom_handle_t handle, const char* text_type) {
    auto* h = get_handle(handle);
    if (h && text_type) h->instance->setTextType(text_type);
}

void custom_tts_set_session_id(custom_handle_t handle, const char* session_id) {
    auto* h = get_handle(handle);
    if (h && session_id) h->instance->setSessionId(session_id);
}

void custom_tts_set_cache_filename(custom_handle_t handle, const char* cache_filename) {
    auto* h = get_handle(handle);
    if (h && cache_filename) h->instance->setCacheFilename(cache_filename);
}

void custom_tts_set_playback_id(custom_handle_t handle, const char* playback_id) {
    auto* h = get_handle(handle);
    if (h && playback_id) h->instance->setPlaybackId(playback_id);
}

// Result data setters
void custom_tts_set_response_code(custom_handle_t handle, long response_code) {
    auto* h = get_handle(handle);
    if (h) h->instance->setResponseCode(response_code);
}

void custom_tts_set_content_type(custom_handle_t handle, const char* content_type) {
    auto* h = get_handle(handle);
    if (h && content_type) h->instance->setContentType(content_type);
}

void custom_tts_set_request_id(custom_handle_t handle, const char* request_id) {
    auto* h = get_handle(handle);
    if (h && request_id) h->instance->setRequestId(request_id);
}

void custom_tts_set_name_lookup_time_ms(custom_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) h->instance->setNameLookupTimeMs(time_ms);
}

void custom_tts_set_connect_time_ms(custom_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) h->instance->setConnectTimeMs(time_ms);
}

void custom_tts_set_final_response_time_ms(custom_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h && time_ms) h->instance->setFinalResponseTimeMs(time_ms);
}

void custom_tts_set_error_message(custom_handle_t handle, const char* error_msg) {
    auto* h = get_handle(handle);
    if (h && error_msg) h->instance->setErrorMessage(error_msg);
}

// State setters
void custom_tts_set_rate(custom_handle_t handle, int rate) {
    auto* h = get_handle(handle);
    if (h) h->instance->setRate(rate);
}

void custom_tts_set_draining(custom_handle_t handle, int draining) {
    auto* h = get_handle(handle);
    if (h) h->instance->setDraining(draining != 0);
}

void custom_tts_set_reads(custom_handle_t handle, int reads) {
    auto* h = get_handle(handle);
    if (h) h->instance->setReads(reads);
}

void custom_tts_set_cache_audio(custom_handle_t handle, int cache_audio) {
    auto* h = get_handle(handle);
    if (h) h->instance->setCacheAudio(cache_audio != 0);
}

void custom_tts_set_playback_start_sent(custom_handle_t handle, int sent) {
    auto* h = get_handle(handle);
    if (h) h->instance->setPlaybackStartSent(sent != 0);
}

// Resource setters
void custom_tts_set_connection(custom_handle_t handle, void* conn) {
    auto* h = get_handle(handle);
    if (h) h->instance->setConnection(conn);
}

void custom_tts_set_circular_buffer(custom_handle_t handle, void* buffer) {
    auto* h = get_handle(handle);
    if (h) h->instance->setCircularBuffer(buffer);
}

void custom_tts_set_file(custom_handle_t handle, FILE* file) {
    auto* h = get_handle(handle);
    if (h) h->instance->setFile(file);
}

void custom_tts_set_resampler(custom_handle_t handle, void* resampler) {
    auto* h = get_handle(handle);
    if (h) h->instance->setResampler((SpeexResamplerState*)resampler);
}

// Utility
int custom_tts_increment_reads(custom_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->incrementReads() : 0;
}

} // extern "C"