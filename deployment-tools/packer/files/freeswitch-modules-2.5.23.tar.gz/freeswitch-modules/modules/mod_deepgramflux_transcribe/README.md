# mod_deepgramflux_transcribe

A Freeswitch module that generates real-time transcriptions on a Freeswitch channel by using Deepgram's streaming River Preview transcription API

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_deepgramflux_transcribe <uuid> start <lang-code> [interim]
```
Attaches media bug to channel and performs streaming recognize request.
- `uuid` - unique identifier of Freeswitch channel
- `lang-code` - a valid deepgram language code.
- `interim` - If the 'interim' keyword is present then both interim and final transcription results will be returned; otherwise only final transcriptions will be returned

```
uuid_deepgramflux_transcribe <uuid> stop
```
Stop transcription on the channel.

### Channel Variables

The following channel variables can be set to control the behavior of the transcription:

- `DEEPGRAM_SPEECH_PRELIGHT_THRESHOLD` - Controls the prelight threshold for speech detection
- `DEEPGRAM_SPEECH_EOT_THRESHOLD` - Sets the end-of-transcript threshold for speech detection
- `DEEPGRAM_SPEECH_EOT_TIMEOUT_MS` - Specifies the end-of-transcript timeout in milliseconds
- `DEEPGRAM_SPEECH_MIP_OPT_OUT` - Allows opting out of MIP (Media Intelligence Platform) features

### Events

## Usage
When using [drachtio-fsrmf](https://www.npmjs.com/package/drachtio-fsmrf), you can access this API command via the api method on the 'endpoint' object.
```js
ep.api('uuid_deepgramflux_flux_transcribe', `${ep.uuid} start en-US interim`);  
```

