# mod_google_tts_streaming

FreeSWITCH module for streaming text-to-speech using Google Cloud Text-to-Speech API.

## Overview

This module enables real-time text-to-speech synthesis using Google Cloud's streaming TTS API. It receives text incrementally and streams back audio in real-time, allowing for low-latency speech synthesis in interactive voice applications.

## Configuration

### Environment Variables

Set the Google Cloud credentials file path:

```bash
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account-key.json
```

### Channel Variables

You can override settings per call using channel variables:

- `GOOGLE_APPLICATION_CREDENTIALS` - Path to credentials file (overrides env var)
- `GOOGLE_TTS_LANGUAGE_CODE` - Language code (default: "en-US")
- `GOOGLE_TTS_VOICE_NAME` - Specific voice name (optional)

See [Google Cloud TTS Voices](https://cloud.google.com/text-to-speech/docs/voices) for complete list.

## API Commands

### Connect

Establish a streaming TTS connection:

```
uuid_google_tts_streaming <uuid> connect
```

### Send Text

Send text to be synthesized:

```
uuid_google_tts_streaming <uuid> send "Hello, this is a test"
```

### Clear

Clear the audio buffer:

```
uuid_google_tts_streaming <uuid> clear
```

### Flush

Flush pending audio:

```
uuid_google_tts_streaming <uuid> flush
```

### Stop

Stop the streaming session:

```
uuid_google_tts_streaming <uuid> stop
```

## Events

The module fires the following custom events:

- `google_tts_streaming::connect` - Connection established successfully
- `google_tts_streaming::connect_failed` - Connection failed
- `google_tts_streaming::disconnect` - Connection dropped
- `google_tts_streaming::empty` - Audio buffer is empty

## See Also

- [Google Cloud Text-to-Speech Documentation](https://cloud.google.com/text-to-speech/docs)
- [Google Cloud TTS Streaming API](https://cloud.google.com/text-to-speech/docs/reference/rpc/google.cloud.texttospeech.v1)
- [FreeSWITCH Documentation](https://freeswitch.org/confluence/)
