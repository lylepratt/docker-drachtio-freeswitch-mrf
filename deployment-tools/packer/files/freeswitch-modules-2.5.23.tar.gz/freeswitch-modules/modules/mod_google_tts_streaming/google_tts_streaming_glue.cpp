#include <switch.h>
#include <switch_json.h>
#include <grpc++/grpc++.h>
#include <thread>
#include <atomic>
#include <mutex>

#include "mod_google_tts_streaming.h"
#include "gstreamer.h"

#include <google/cloud/texttospeech/v1/cloud_tts.grpc.pb.h>

#include "jambonz/audio_player.hpp"
#include "jambonz/circular_buffer.h"
#include "jambonz/vector_math.h"

using google::cloud::texttospeech::v1::TextToSpeech;
using google::cloud::texttospeech::v1::StreamingSynthesizeRequest;
using google::cloud::texttospeech::v1::StreamingSynthesizeResponse;
using google::cloud::texttospeech::v1::VoiceSelectionParams;
using google::cloud::texttospeech::v1::SsmlVoiceGender;

// Static member initialization
std::atomic<unsigned int> GStreamer::s_idCounter{0};

// Forward declaration
static GStreamer* create_streamer(switch_core_session_t* session);

namespace {
    static int MAX_CONNECTION_RETRY = 10;
    static int MAX_KEEP_ALIVE_INTERVAL_COUNTER = 150; // 150 * 20 ms = 3 seconds

    static void destroy_tech_pvt(private_t *tech_pvt) {
        if (tech_pvt) {
            tech_pvt->pStreamer = nullptr;
            if (tech_pvt->bufferedTokens) {
                free(tech_pvt->bufferedTokens);
                tech_pvt->bufferedTokens = nullptr;
            }

            if (tech_pvt->audioPlayer) {
                AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
                delete p;
                tech_pvt->audioPlayer = nullptr;
            }

            if (tech_pvt->playoutBuffer) {
                CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
                delete playoutBuffer;
                tech_pvt->playoutBuffer = nullptr;
            }
        }
    }

    static void eventCallback(const char* sessionId, unsigned int id, GStreamerEvent event,
        const char* data, size_t dataLen) {
        switch_core_session_t* session = switch_core_session_locate(sessionId);
        if (session) {
            switch_channel_t *channel = switch_core_session_get_channel(session);
            switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, MY_BUG_NAME);

            if (!bug) {
                switch_core_session_rwunlock(session);
                return;
            }

            private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
            if (tech_pvt) {
                    // Ignore events from old connections
                    if (id != tech_pvt->id) {
                        switch_core_session_rwunlock(session);
                        return;
                    }

                    GStreamer *pStreamer = static_cast<GStreamer *>(tech_pvt->pStreamer);

                    switch (event) {
                        case GStreamerEvent::AUDIO:
                            if (tech_pvt->active && tech_pvt->audioPlayer && data && dataLen > 0) {
                                AudioPlayer* player = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
                                player->bufferAudio(data, dataLen);
                            }
                            break;

                        case GStreamerEvent::CONNECT_SUCCESS:
                            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
                                "connection (%s) (%u) successful\n", tech_pvt->bugname, id);

                            tech_pvt->active = true;
                            tech_pvt->keep_alive_interval_counter = 0;
                            if (tech_pvt->bufferedTokens && pStreamer) {
                                pStreamer->writeText(tech_pvt->bufferedTokens);
                                free(tech_pvt->bufferedTokens);
                                tech_pvt->bufferedTokens = nullptr;
                            }
                            tech_pvt->responseHandler(session, TTS_STREAM_EVENT_CONNECT_SUCCESS, NULL);
                            break;

                        case GStreamerEvent::CONNECT_FAIL:
                        {
                            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
                                "google tts connection failed: %s\n", data ? data : "unknown");
                            if (tech_pvt->bufferedTokens) {
                                free(tech_pvt->bufferedTokens);
                                tech_pvt->bufferedTokens = nullptr;
                            }
                            std::string json = "{\"reason\":\"";
                            json += (data ? data : "unknown");
                            json += "\"}";
                            // Mark streamer for deletion (self-deletes after callback returns)
                            if (pStreamer) {
                                pStreamer->markForDeletion();
                            }
                            tech_pvt->pStreamer = nullptr;
                            tech_pvt->responseHandler(session, TTS_STREAM_EVENT_CONNECT_FAIL, json.c_str());
                        }
                        break;

                        case GStreamerEvent::DISCONNECT:
                            // Connection dropped - try to reconnect if within retry limit
                            if (tech_pvt->connection_retry_counter < MAX_CONNECTION_RETRY) {
                                tech_pvt->connection_retry_counter++;
                                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
                                    "google tts reconnecting (retry %d/%d)\n",
                                    tech_pvt->connection_retry_counter, MAX_CONNECTION_RETRY);

                                GStreamer* newStreamer = create_streamer(session);
                                if (newStreamer) {
                                    tech_pvt->pStreamer = static_cast<void *>(newStreamer);
                                    tech_pvt->id = newStreamer->getId();
                                    newStreamer->connect();
                                    switch_core_session_rwunlock(session);
                                    if (pStreamer) {
                                        pStreamer->markForDeletion();
                                    }
                                    return;
                                }
                            }
                            // Mark old streamer for deletion (self-deletes after callback returns)
                            if (pStreamer) {
                                pStreamer->markForDeletion();
                            }
                            tech_pvt->pStreamer = nullptr;
                            tech_pvt->responseHandler(session, TTS_STREAM_EVENT_DISCONNECT, NULL);
                            break;

                        case GStreamerEvent::ERROR:
                            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
                                "google tts error: %s\n", data ? data : "unknown");
                            break;

                        default:
                            break;
                    }
            }
            switch_core_session_rwunlock(session);
        }
    }
}

// GStreamer implementation
GStreamer::GStreamer(
    const char* sessionId,
    const char* languageCode,
    const char* voiceName,
    const char* gender,
    const char* credentialsFile,
    GStreamerCallback callback)
    : m_sessionId(sessionId ? sessionId : ""),
      m_languageCode(languageCode ? languageCode : "en-US"),
      m_voiceName(voiceName ? voiceName : ""),
      m_gender(gender ? gender : ""),
      m_credentialsFile(credentialsFile ? credentialsFile : ""),
      m_callback(callback),
      m_id(++s_idCounter),
      m_stub(nullptr),
      m_streamer(nullptr),
      m_request(nullptr),
      m_connected(false),
      m_running(false),
      m_writesDone(false),
      m_deleteAfterCallback(false),
      m_state(STATE_IDLE) {

    m_channel = createGrpcChannel(credentialsFile);

    auto stub = TextToSpeech::NewStub(m_channel);
    m_stub = stub.release();

    // Create and configure the request
    auto* request = new StreamingSynthesizeRequest();
    auto* streaming_config = request->mutable_streaming_config();

    // Configure voice
    auto* voice = streaming_config->mutable_voice();
    voice->set_language_code(m_languageCode);

    if (!m_voiceName.empty()) {
        voice->set_name(m_voiceName);
    }

    // Set gender if specified
    if (!m_gender.empty()) {
        if (strcasecmp(m_gender.c_str(), "MALE") == 0) {
            voice->set_ssml_gender(SsmlVoiceGender::MALE);
        } else if (strcasecmp(m_gender.c_str(), "FEMALE") == 0) {
            voice->set_ssml_gender(SsmlVoiceGender::FEMALE);
        } else if (strcasecmp(m_gender.c_str(), "NEUTRAL") == 0) {
            voice->set_ssml_gender(SsmlVoiceGender::NEUTRAL);
        }
    }

    m_request = request;
}

GStreamer::~GStreamer() {
    m_running = false;

    // Cancel context to unblock reads
    m_context.TryCancel();

    if (m_readThread.joinable()) {
        m_readThread.join();
    }

    if (m_stub) {
        delete static_cast<TextToSpeech::Stub*>(m_stub);
        m_stub = nullptr;
    }
    if (m_request) {
        delete static_cast<StreamingSynthesizeRequest*>(m_request);
        m_request = nullptr;
    }
    // m_streamer is managed by unique_ptr internally, don't delete
}

std::shared_ptr<grpc::Channel> GStreamer::createGrpcChannel(const char* credentialsFile) {
    const char* google_uri = std::getenv("GOOGLE_TTS_URI");
    if (!google_uri) {
        google_uri = "texttospeech.googleapis.com";
    }

    if (credentialsFile && strlen(credentialsFile) > 0) {
        auto channelCreds = grpc::SslCredentials(grpc::SslCredentialsOptions());
        auto callCreds = grpc::ServiceAccountJWTAccessCredentials(credentialsFile);
        auto creds = grpc::CompositeChannelCredentials(channelCreds, callCreds);
        return grpc::CreateChannel(google_uri, creds);
    }
    else {
        auto creds = grpc::GoogleDefaultCredentials();
        return grpc::CreateChannel(google_uri, creds);
    }
}

void GStreamer::connect() {
    m_state = STATE_CONNECTING;
    m_running = true;

    // Start the read thread
    m_readThread = std::thread(&GStreamer::readThreadFunc, this);
}

void GStreamer::readThreadFunc() {
    try {
        auto* stub = static_cast<TextToSpeech::Stub*>(m_stub);
        auto* initialRequest = static_cast<StreamingSynthesizeRequest*>(m_request);

        auto streamer = stub->StreamingSynthesize(&m_context);
        m_streamer = streamer.get();

        bool write_success = streamer->Write(*initialRequest);
        if (write_success) {
            m_connected = true;
            m_state = STATE_CONNECTED;

            if (m_callback) {
                m_callback(m_sessionId.c_str(), m_id, GStreamerEvent::CONNECT_SUCCESS, nullptr, 0);
            }

            StreamingSynthesizeResponse response;
            while (m_running && streamer->Read(&response)) {
                if (response.audio_content().size() > 0 && m_callback) {
                    m_callback(m_sessionId.c_str(), m_id, GStreamerEvent::AUDIO,
                        response.audio_content().data(), response.audio_content().size());
                }
            }

            grpc::Status status = streamer->Finish();
            m_connected = false;
            m_state = STATE_DISCONNECTED;
            m_streamer = nullptr;

            if (m_callback) {
                m_callback(m_sessionId.c_str(), m_id, GStreamerEvent::DISCONNECT, nullptr, 0);
            }
        } else {
            m_state = STATE_DISCONNECTED;
            m_streamer = nullptr;
            if (m_callback) {
                m_callback(m_sessionId.c_str(), m_id, GStreamerEvent::CONNECT_FAIL,
                    "Failed to write initial config", 0);
            }
        }

    } catch (const std::exception& e) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "%s google tts exception: %s\n", m_sessionId.c_str(), e.what());
        m_connected = false;
        m_state = STATE_DISCONNECTED;
        m_streamer = nullptr;
        if (m_callback) {
            m_callback(m_sessionId.c_str(), m_id, GStreamerEvent::CONNECT_FAIL, e.what(), 0);
        }
    } catch (...) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s google tts unknown exception\n", m_sessionId.c_str());
        m_connected = false;
        m_state = STATE_DISCONNECTED;
        m_streamer = nullptr;
        if (m_callback) {
            m_callback(m_sessionId.c_str(), m_id, GStreamerEvent::CONNECT_FAIL, "unknown exception", 0);
        }
    }

    if (m_deleteAfterCallback) {
        m_readThread.detach();
        delete this;
    }
}

bool GStreamer::writeText(const std::string& text) {
    if (!m_connected || !m_streamer) {
        return false;
    }

    std::lock_guard<std::mutex> lock(m_writeMutex);

    auto* streamer = static_cast<grpc::ClientReaderWriter<StreamingSynthesizeRequest, StreamingSynthesizeResponse>*>(m_streamer);

    StreamingSynthesizeRequest request;
    request.mutable_input()->set_text(text);

    return streamer->Write(request);
}

void GStreamer::close() {
    m_running = false;

    if (m_streamer && !m_writesDone) {
        std::lock_guard<std::mutex> lock(m_writeMutex);
        auto* streamer = static_cast<grpc::ClientReaderWriter<StreamingSynthesizeRequest, StreamingSynthesizeResponse>*>(m_streamer);
        if (streamer) {
            streamer->WritesDone();
        }
        m_writesDone = true;
    }

    m_context.TryCancel();
}

// Helper function to create a new streamer
static GStreamer* create_streamer(switch_core_session_t* session) {
    switch_channel_t *channel = switch_core_session_get_channel(session);

    const char *languageCode = switch_channel_get_variable(channel, "GOOGLE_TTS_LANGUAGE_CODE");
    if (!languageCode) {
        languageCode = "en-US";
    }
    const char *voiceName = switch_channel_get_variable(channel, "GOOGLE_TTS_VOICE_NAME");
    const char *gender = switch_channel_get_variable(channel, "GOOGLE_TTS_VOICE_GENDER");
    const char *credentials = switch_channel_get_variable(channel, "GOOGLE_APPLICATION_CREDENTIALS");
    const char *sessionId = switch_core_session_get_uuid(session);

    try {
        return new GStreamer(sessionId, languageCode, voiceName, gender, credentials, eventCallback);
    } catch (std::exception& e) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
            "Error creating gRPC streamer: %s\n", e.what());
        return nullptr;
    }
}

static switch_status_t make_streaming_connection(switch_core_session_t *session, private_t *tech_pvt) {
    GStreamer* streamer = create_streamer(session);
    if (!streamer) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
            "Error creating google tts streamer\n");
        return SWITCH_STATUS_FALSE;
    }

    tech_pvt->pStreamer = static_cast<void *>(streamer);
    tech_pvt->id = streamer->getId();
    streamer->connect();

    return SWITCH_STATUS_SUCCESS;
}

extern "C" {
    switch_status_t google_tts_streaming_init() {
        return SWITCH_STATUS_SUCCESS;
    }

    switch_status_t google_tts_streaming_cleanup() {
        return SWITCH_STATUS_SUCCESS;
    }

    switch_status_t google_tts_streaming_session_init(
        switch_core_session_t *session,
        responseHandler_t responseHandler,
        void **ppUserData) {

        switch_channel_t *channel = switch_core_session_get_channel(session);
        private_t* tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
        switch_codec_t* read_codec = switch_core_session_get_read_codec(session);

        if (!tech_pvt) {
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
            return SWITCH_STATUS_FALSE;
        }

        if (!read_codec || !read_codec->implementation) {
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no read codec available!\n");
            return SWITCH_STATUS_FALSE;
        }

        memset(tech_pvt, 0, sizeof(private_t));
        tech_pvt->pStreamer = NULL;
        switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
        tech_pvt->responseHandler = responseHandler;
        strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
        tech_pvt->sessionId[MAX_SESSION_ID] = '\0';
        strncpy(tech_pvt->bugname, MY_BUG_NAME, MAX_BUG_LEN);
        tech_pvt->bugname[MAX_BUG_LEN] = '\0';
        tech_pvt->sampleRate = read_codec->implementation->actual_samples_per_second;

        auto playoutBuffer = new CircularBuffer(500000);
        auto audioPlayer = new AudioPlayer(tech_pvt->mutex, playoutBuffer);

        // Google TTS always outputs 24kHz LINEAR16 audio
        audioPlayer->setResampling(24000, tech_pvt->sampleRate);

        tech_pvt->audioPlayer = (void *) audioPlayer;
        tech_pvt->playoutBuffer = (void *) playoutBuffer;
        tech_pvt->active = false;
        tech_pvt->bufferedTokens = NULL;
        tech_pvt->connection_retry_counter = 0;
        tech_pvt->is_good_to_reconnect = 0;
        tech_pvt->keep_alive_interval_counter = 0;

        *ppUserData = tech_pvt;

        if (SWITCH_STATUS_SUCCESS != make_streaming_connection(session, tech_pvt)) {
            destroy_tech_pvt(tech_pvt);
            return SWITCH_STATUS_FALSE;
        }

        return SWITCH_STATUS_SUCCESS;
    }

    switch_status_t google_tts_streaming_session_send_tokens(
        switch_core_session_t *session,
        switch_media_bug_t *bug,
        char* tokens) {

        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

        if (!tech_pvt) {
            return SWITCH_STATUS_FALSE;
        }

        tech_pvt->active = true;
        tech_pvt->keep_alive_interval_counter = 0;

        if (tech_pvt->pStreamer) {
            GStreamer *pStreamer = static_cast<GStreamer *>(tech_pvt->pStreamer);

            if (pStreamer->getState() == GStreamer::STATE_CONNECTED) {
                AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
                if (p && p->isCleared()) p->open();

                pStreamer->writeText(tokens);
                return SWITCH_STATUS_SUCCESS;
            }
            else if (pStreamer->getState() == GStreamer::STATE_CONNECTING ||
                     pStreamer->getState() == GStreamer::STATE_IDLE) {
                // Buffer tokens while connecting
                size_t currentLength = tech_pvt->bufferedTokens ? strlen(tech_pvt->bufferedTokens) : 0;
                size_t additionalLength = strlen(tokens);
                size_t newSize = currentLength + additionalLength + 1;
                char* newBuffer = (char*)realloc(tech_pvt->bufferedTokens, newSize);
                if (nullptr == newBuffer) {
                    free(tech_pvt->bufferedTokens);
                    tech_pvt->bufferedTokens = nullptr;
                    return SWITCH_STATUS_FALSE;
                }

                if (currentLength == 0) {
                    newBuffer[0] = '\0';
                }
                strcat(newBuffer, tokens);
                tech_pvt->bufferedTokens = newBuffer;
                return SWITCH_STATUS_SUCCESS;
            }
            else {
                return SWITCH_STATUS_FALSE;
            }
        }
        else {
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
                "no grpc connection to google tts\n");
            return SWITCH_STATUS_FALSE;
        }
    }

    switch_status_t google_tts_streaming_session_stop(
        switch_core_session_t *session,
        int channelIsClosing,
        switch_media_bug_t *bug) {

        switch_channel_t *channel = switch_core_session_get_channel(session);
        if (!bug) {
            return SWITCH_STATUS_FALSE;
        }

        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (!tech_pvt) return SWITCH_STATUS_FALSE;

        switch_mutex_lock(tech_pvt->mutex);
        switch_channel_set_private(channel, MY_BUG_NAME, NULL);
        if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

        GStreamer *pStreamer = static_cast<GStreamer *>(tech_pvt->pStreamer);
        if (pStreamer) {
            pStreamer->close();
            delete pStreamer;
            tech_pvt->pStreamer = nullptr;
        }

        destroy_tech_pvt(tech_pvt);

        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_STATUS_SUCCESS;
    }

    switch_status_t google_tts_streaming_session_clear(
        switch_core_session_t *session,
        switch_media_bug_t *bug) {

        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
            switch_mutex_lock(tech_pvt->mutex);
            AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
            if (p) p->clear();
            tech_pvt->active = false;
            switch_mutex_unlock(tech_pvt->mutex);
        }
        return SWITCH_STATUS_SUCCESS;
    }

    switch_status_t google_tts_streaming_session_flush(
        switch_core_session_t *session,
        switch_media_bug_t *bug) {

        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
            tech_pvt->keep_alive_interval_counter = 0;
        }
        return SWITCH_STATUS_SUCCESS;
    }

    switch_bool_t google_dub_speech_frame(switch_media_bug_t *bug, private_t* tech_pvt) {
        if (!tech_pvt->active) {
            return SWITCH_TRUE;
        }

        // Send keepalive every 3 seconds
        if (++tech_pvt->keep_alive_interval_counter >= MAX_KEEP_ALIVE_INTERVAL_COUNTER) {
            tech_pvt->keep_alive_interval_counter = 0;
            GStreamer *pStreamer = static_cast<GStreamer *>(tech_pvt->pStreamer);
            if (pStreamer && pStreamer->isConnected()) {
                pStreamer->writeText(" ");
            }
        }

        if (switch_mutex_trylock(tech_pvt->mutex) != SWITCH_STATUS_SUCCESS) {
            return SWITCH_TRUE;
        }

        CircularBuffer *playoutBuffer = static_cast<CircularBuffer *>(tech_pvt->playoutBuffer);
        if (!playoutBuffer || playoutBuffer->size() == 0) {
            switch_mutex_unlock(tech_pvt->mutex);
            return SWITCH_TRUE;
        }

        switch_frame_t* rframe = switch_core_media_bug_get_write_replace_frame(bug);
        int16_t *fp = reinterpret_cast<int16_t*>(rframe->data);
        rframe->channels = 1;
        rframe->datalen = rframe->samples * sizeof(int16_t);

        int samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(rframe->samples));
        int16_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];

        auto count = playoutBuffer->getBlock(data, samplesToCopy);
        if (count == samplesToCopy) {
            vector_add(fp, data, rframe->samples);
            vector_normalize(fp, rframe->samples);
            switch_core_media_bug_set_write_replace_frame(bug, rframe);

            if (playoutBuffer->size() == 0) {
                switch_core_session_t* session = switch_core_session_locate(tech_pvt->sessionId);
                if (session) {
                    tech_pvt->responseHandler(session, TTS_STREAM_EVENT_EMPTY, NULL);
                    switch_core_session_rwunlock(session);
                }
            }
        }

        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
    }
}
