#ifndef __GSTREAMER_TTS_H__
#define __GSTREAMER_TTS_H__

#include <cstdlib>
#include <algorithm>
#include <future>
#include <string>
#include <atomic>
#include <thread>
#include <mutex>

#include <switch.h>
#include <switch_json.h>
#include <grpc++/grpc++.h>
#include <grpcpp/impl/codegen/sync_stream.h>

#include "mod_google_tts_streaming.h"

#define TTS_CHUNKSIZE (320)

// Event types for callback
enum class GStreamerEvent {
	CONNECT_SUCCESS,
	CONNECT_FAIL,
	AUDIO,
	DISCONNECT,
	ERROR
};

// Callback function type
typedef void (*GStreamerCallback)(const char* sessionId, unsigned int id, GStreamerEvent event,
	const char* data, size_t dataLen);

class GStreamer {
public:
	GStreamer(
		const char* sessionId,
		const char* languageCode,
		const char* voiceName,
		const char* gender,
		const char* credentialsFile,
		GStreamerCallback callback);

	~GStreamer();

	bool writeText(const std::string& text);
	void connect();
	void close();
	void markForDeletion() { m_deleteAfterCallback = true; }

	unsigned int getId() const { return m_id; }
	bool isConnected() const { return m_connected; }

	enum ConnectionState {
		STATE_IDLE,
		STATE_CONNECTING,
		STATE_CONNECTED,
		STATE_DISCONNECTED
	};

	ConnectionState getState() const { return m_state; }

private:
	void readThreadFunc();
	std::shared_ptr<grpc::Channel> createGrpcChannel(const char* credentialsFile);

	static std::atomic<unsigned int> s_idCounter;

	std::string m_sessionId;
	std::string m_languageCode;
	std::string m_voiceName;
	std::string m_gender;
	std::string m_credentialsFile;
	GStreamerCallback m_callback;

	unsigned int m_id;
	grpc::ClientContext m_context;
	std::shared_ptr<grpc::Channel> m_channel;

	// These will be set in the cpp file with proper types
	void* m_stub;
	void* m_streamer;
	void* m_request;

	std::atomic<bool> m_connected;
	std::atomic<bool> m_running;
	std::atomic<bool> m_writesDone;
	std::atomic<bool> m_deleteAfterCallback;
	ConnectionState m_state;
	std::thread m_readThread;
	std::mutex m_writeMutex;
};

#endif // __GSTREAMER_TTS_H__
