#ifndef __WHISPER_HPP__
#define __WHISPER_HPP__

#include <switch.h>
#include <memory>
#include <string>
#include <mutex>

class Whisper {
private:
    // Basic configuration
    std::string voice_name_;
    std::string api_key_;
    std::string model_id_;
    std::string speed_;
    std::string instructions_;

    // Result data
    long response_code_;
    std::string content_type_;
    std::string reported_organization_;
    std::string reported_latency_;
    std::string reported_ratelimit_requests_;
    std::string reported_ratelimit_remaining_requests_;
    std::string reported_ratelimit_reset_requests_;
    std::string request_id_;
    std::string name_lookup_time_ms_;
    std::string connect_time_ms_;
    std::string final_response_time_ms_;
    std::string error_message_;
    std::string cache_filename_;
    std::string session_id_;
    std::string playback_id_;

    // State data
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;

    // Resources
    void* connection_;
    void* audio_player_;
    void* playout_buffer_;
    mutable std::mutex mutex_;
    FILE* file_;

    Whisper(); // Private constructor

public:
    ~Whisper();
    
    static std::shared_ptr<Whisper> create();

    // Getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getApiKey() const { return api_key_; }
    const std::string& getModelId() const { return model_id_; }
    const std::string& getSpeed() const { return speed_; }
    const std::string& getInstructions() const { return instructions_; }

    long getResponseCode() const { return response_code_; }
    const std::string& getContentType() const { return content_type_; }
    const std::string& getReportedOrganization() const { return reported_organization_; }
    const std::string& getReportedLatency() const { return reported_latency_; }
    const std::string& getReportedRatelimitRequests() const { return reported_ratelimit_requests_; }
    const std::string& getReportedRatelimitRemainingRequests() const { return reported_ratelimit_remaining_requests_; }
    const std::string& getReportedRatelimitResetRequests() const { return reported_ratelimit_reset_requests_; }
    const std::string& getRequestId() const { return request_id_; }
    const std::string& getNameLookupTimeMs() const { return name_lookup_time_ms_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFinalResponseTimeMs() const { return final_response_time_ms_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    const std::string& getSessionId() const { return session_id_; }
    const std::string& getPlaybackId() const { return playback_id_; }

    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }

    void* getConnection() const { return connection_; }
    void* getAudioPlayer() const { return audio_player_; }
    void* getPlayoutBuffer() const { return playout_buffer_; }
    std::mutex& getMutex() const { return mutex_; }
    FILE* getFile() const { return file_; }

    // Setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setApiKey(const std::string& api_key) { api_key_ = api_key; }
    void setModelId(const std::string& model_id) { model_id_ = model_id; }
    void setSpeed(const std::string& speed) { speed_ = speed; }
    void setInstructions(const std::string& instructions) { instructions_ = instructions; }

    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setContentType(const std::string& content_type) { content_type_ = content_type; }
    void setReportedOrganization(const std::string& org) { reported_organization_ = org; }
    void setReportedLatency(const std::string& latency) { reported_latency_ = latency; }
    void setReportedRatelimitRequests(const std::string& requests) { reported_ratelimit_requests_ = requests; }
    void setReportedRatelimitRemainingRequests(const std::string& remaining) { reported_ratelimit_remaining_requests_ = remaining; }
    void setReportedRatelimitResetRequests(const std::string& reset) { reported_ratelimit_reset_requests_ = reset; }
    void setRequestId(const std::string& request_id) { request_id_ = request_id; }
    void setNameLookupTimeMs(const std::string& time_ms) { name_lookup_time_ms_ = time_ms; }
    void setConnectTimeMs(const std::string& time_ms) { connect_time_ms_ = time_ms; }
    void setFinalResponseTimeMs(const std::string& time_ms) { final_response_time_ms_ = time_ms; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }

    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setPlaybackStartSent(bool playback_start_sent) { playback_start_sent_ = playback_start_sent; }

    void setConnection(void* conn) { connection_ = conn; }
    void setAudioPlayer(void* audio_player) { audio_player_ = audio_player; }
    void setPlayoutBuffer(void* playout_buffer) { playout_buffer_ = playout_buffer; }
    void setFile(FILE* file) { file_ = file; }
};

#endif