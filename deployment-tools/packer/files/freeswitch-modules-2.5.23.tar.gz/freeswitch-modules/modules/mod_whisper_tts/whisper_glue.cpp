#include "mod_whisper_tts.h"
#include "whisper_glue.h"
#include "whisper.hpp"
#include <switch.h>
#include <switch_json.h>
#include <curl/curl.h>
#include <cstdlib>
#include <mutex>

#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/bind/bind.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>
#include <boost/asio.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/algorithm/string.hpp>

#include "mpg123.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

#define MP3_DCACHE 8192 * 2

/* Global information, common to all connections */
typedef struct
{
  CURLM *multi;
  int still_running;
} GlobalInfo_t;
static GlobalInfo_t global;

/* Information associated with a specific easy handle */
typedef struct
{
  CURL *easy;
  whisper_handle_t handle;
  char* body;
  struct curl_slist *hdr_list;
  GlobalInfo_t *global;
  mpg123_handle *mh;
  char error[CURL_ERROR_SIZE];
  FILE* file;
  std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
  bool flushed;
} ConnInfo_t;


static std::map<curl_socket_t, boost::asio::ip::tcp::socket *> socket_map;
static boost::asio::io_service io_service;
static boost::asio::deadline_timer timer(io_service);
static std::string fullDirPath;
static std::thread worker_thread;
static std::mutex curl_mutex;

std::string secondsToMillisecondsString(double seconds) {
    // Convert to milliseconds
    double milliseconds = seconds * 1000.0;

    // Truncate to remove fractional part
    long milliseconds_long = static_cast<long>(milliseconds);

    // Convert to string
    return std::to_string(milliseconds_long);
}

static std::string getEnvVar(const std::string& varName) {
    const char* val = std::getenv(varName.c_str());
    return val ? std::string(val) : "";
}

static long getConnectionTimeout() {
    std::string connectTimeoutStr = getEnvVar("WHISPER_TTS_CURL_CONNECT_TIMEOUT");

    if (connectTimeoutStr.empty()) {
        connectTimeoutStr = getEnvVar("TTS_CURL_CONNECT_TIMEOUT");
    }

    long connectTimeout = 10L;

    if (!connectTimeoutStr.empty()) {
        connectTimeout = std::stol(connectTimeoutStr);
    }

    return connectTimeout;
}

static CURL* createEasyHandle(void) {
  CURL* easy = curl_easy_init();
  if(!easy) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "curl_easy_init() failed!\n");
    return nullptr ;
  }  

  curl_easy_setopt(easy, CURLOPT_FOLLOWLOCATION, 1L);
  curl_easy_setopt(easy, CURLOPT_USERAGENT, "jambonz/0.8.5");

  // set connect timeout to 3 seconds and total timeout to 109 seconds
  curl_easy_setopt(easy, CURLOPT_CONNECTTIMEOUT_MS, 3000L);
  curl_easy_setopt(easy, CURLOPT_TIMEOUT, getConnectionTimeout());

  return easy ;
}

static void send_playback_start_event(whisper_handle_t handle, switch_channel_t *channel, const char* time_to_first_byte_ms) {
    if (!channel) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s send_playback_start_event: channel is null\n", whisper_get_session_id(handle));
        return;
    }

    switch_event_t *event;
    if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) != SWITCH_STATUS_SUCCESS) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s send_playback_start_event: failed to create event\n", whisper_get_session_id(handle));
        return;
    }

    switch_channel_event_set_data(channel, event);
    const char* playback_id = whisper_get_playback_id(handle);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s send_playback_start_event: firing playback-started %s\n",
                      whisper_get_session_id(handle), playback_id ? playback_id : "no-playback-id");

    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
    if (playback_id && strlen(playback_id) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
    }
    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms);

    // Add vendor-specific headers
    const char *reported_latency = whisper_get_reported_latency(handle);
    if (reported_latency && strlen(reported_latency) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_reported_latency_ms", reported_latency);
    }
    const char *request_id = whisper_get_request_id(handle);
    if (request_id && strlen(request_id) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_request_id", request_id);
    }
    const char *reported_organization = whisper_get_reported_organization(handle);
    if (reported_organization && strlen(reported_organization) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_reported_organization", reported_organization);
    }
    const char *reported_ratelimit_requests = whisper_get_reported_ratelimit_requests(handle);
    if (reported_ratelimit_requests && strlen(reported_ratelimit_requests) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_reported_ratelimit_requests", reported_ratelimit_requests);
    }
    const char *reported_ratelimit_remaining_requests = whisper_get_reported_ratelimit_remaining_requests(handle);
    if (reported_ratelimit_remaining_requests && strlen(reported_ratelimit_remaining_requests) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_reported_ratelimit_remaining_requests", reported_ratelimit_remaining_requests);
    }
    const char *reported_ratelimit_reset_requests = whisper_get_reported_ratelimit_reset_requests(handle);
    if (reported_ratelimit_reset_requests && strlen(reported_ratelimit_reset_requests) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_reported_ratelimit_reset_requests", reported_ratelimit_reset_requests);
    }
    const char *name_lookup_time_ms = whisper_get_name_lookup_time_ms(handle);
    if (name_lookup_time_ms && strlen(name_lookup_time_ms) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_name_lookup_time_ms", name_lookup_time_ms);
    }
    const char *connect_time_ms = whisper_get_connect_time_ms(handle);
    if (connect_time_ms && strlen(connect_time_ms) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_connect_time_ms", connect_time_ms);
    }
    const char *final_response_time_ms = whisper_get_final_response_time_ms(handle);
    if (final_response_time_ms && strlen(final_response_time_ms) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_final_response_time_ms", final_response_time_ms);
    }
    const char *voice_name = whisper_get_voice_name(handle);
    if (voice_name && strlen(voice_name) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_voice_name", voice_name);
    }
    const char *model_id = whisper_get_model_id(handle);
    if (model_id && strlen(model_id) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_model_id", model_id);
    }
    const char *cache_filename = whisper_get_cache_filename(handle);
    if (cache_filename && strlen(cache_filename) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);
    }

    switch_event_fire(&event);
    whisper_set_playback_start_sent(handle, 1);
}

static void cleanupConn(ConnInfo_t *conn) {
  whisper_handle_t handle = conn->handle;

  if (conn->mh) {
    mpg123_close(conn->mh);
    mpg123_delete(conn->mh);
    conn->mh = nullptr;
  }

  if( conn->hdr_list ) {
    curl_slist_free_all(conn->hdr_list);
    conn->hdr_list = nullptr ;
  }
  curl_easy_cleanup(conn->easy);

  auto p = whisper_get_shared_ptr(handle);
  if (p) {
    std::lock_guard<std::mutex> lock(p->getMutex());
  if (conn->file) {
    if (fclose(conn->file) != 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s cleanupConn: error closing audio cache file\n", whisper_get_session_id(handle));
    }
    conn->file = nullptr ;
    whisper_set_file(handle, nullptr);
  }

    whisper_set_connection(handle, nullptr);
    whisper_set_draining(handle, 1);
  }

  // Release the handle reference
  whisper_release(handle);

  delete conn;
}

/* Check for completed transfers, and remove their easy handles */
void check_multi_info(GlobalInfo_t *g) {
  CURLMsg *msg;
  int msgs_left;
  ConnInfo_t *conn;
  CURL *easy;
  CURLcode res;
  
  while((msg = curl_multi_info_read(g->multi, &msgs_left))) {
    if(msg->msg == CURLMSG_DONE) {
      long response_code;
      double namelookup=0, connect=0, total=0 ;
      char *ct = NULL ;

      easy = msg->easy_handle;
      res = msg->data.result;
      curl_easy_getinfo(easy, CURLINFO_PRIVATE, &conn);
      curl_easy_getinfo(easy, CURLINFO_RESPONSE_CODE, &response_code);
      curl_easy_getinfo(easy, CURLINFO_CONTENT_TYPE, &ct);

      curl_easy_getinfo(easy, CURLINFO_NAMELOOKUP_TIME, &namelookup);
      curl_easy_getinfo(easy, CURLINFO_CONNECT_TIME, &connect);
      curl_easy_getinfo(easy, CURLINFO_TOTAL_TIME, &total);

      whisper_handle_t handle = conn->handle;
      whisper_set_response_code(handle, response_code);
      if (ct) whisper_set_content_type(handle, ct);

      std::string name_lookup_ms = secondsToMillisecondsString(namelookup);
      std::string connect_ms = secondsToMillisecondsString(connect);
      std::string final_response_time_ms = secondsToMillisecondsString(total);

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s mod_whisper_tts: response: %ld, content-type %s,"
        "dns(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
        "connect(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
        "total(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld\n",
        whisper_get_session_id(handle),
        response_code, ct,
        (long)(namelookup), (long)(fmod(namelookup, 1.0) * 1000000),
        (long)(connect), (long)(fmod(connect, 1.0) * 1000000),
        (long)(total), (long)(fmod(total, 1.0) * 1000000));

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s name lookup time: %s\n", whisper_get_session_id(handle), name_lookup_ms.c_str());
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s connect time: %s\n", whisper_get_session_id(handle), connect_ms.c_str());
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s final response time: %s\n", whisper_get_session_id(handle), final_response_time_ms.c_str());

      whisper_set_name_lookup_time_ms(handle, name_lookup_ms.c_str());
      whisper_set_connect_time_ms(handle, connect_ms.c_str());
      whisper_set_final_response_time_ms(handle, final_response_time_ms.c_str());

      curl_multi_remove_handle(g->multi, easy);
      cleanupConn(conn);
    }
  }
}

int mcode_test(const char *where, CURLMcode code) {
  if(CURLM_OK != code) {
    const char *s;
    switch(code) {
    case CURLM_CALL_MULTI_PERFORM:
      s = "CURLM_CALL_MULTI_PERFORM";
      break;
    case CURLM_BAD_HANDLE:
      s = "CURLM_BAD_HANDLE";
      break;
    case CURLM_BAD_EASY_HANDLE:
      s = "CURLM_BAD_EASY_HANDLE";
      break;
    case CURLM_OUT_OF_MEMORY:
      s = "CURLM_OUT_OF_MEMORY";
      break;
    case CURLM_INTERNAL_ERROR:
      s = "CURLM_INTERNAL_ERROR";
      break;
    case CURLM_UNKNOWN_OPTION:
      s = "CURLM_UNKNOWN_OPTION";
      break;
    case CURLM_LAST:
      s = "CURLM_LAST";
      break;
    default:
      s = "CURLM_unknown";
      break;
    case CURLM_BAD_SOCKET:
      s = "CURLM_BAD_SOCKET";
      break;
    }
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mcode_test ERROR: %s returns %s:%d\n", where, s, code);

    return -1;
  }
  return 0 ;
}

static void remsock(int *f, GlobalInfo_t *g) {
  if(f) {
    free(f);
    f = NULL;
  }
}

/* Called by asio when there is an action on a socket */
static void event_cb(GlobalInfo_t *g, curl_socket_t s, int action, const boost::system::error_code & error, int *fdp) {
  int f = *fdp;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X has action %d\n", s, action) ; 

  // Socket already POOL REMOVED.
  if (f == CURL_POLL_REMOVE) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X removed\n", s); 
    remsock(fdp, g);
    return;
  }

  if(socket_map.find(s) == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb: socket  %#X already closed\n, s");
    return;
  }

  /* make sure the event matches what are wanted */
  if(f == action || f == CURL_POLL_INOUT) {
    if(error) {
      action = CURL_CSELECT_ERR;
    }
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, s, action, &g->still_running);

    mcode_test("event_cb: curl_multi_socket_action", rc);
    check_multi_info(g);

    if(g->still_running <= 0) {
      timer.cancel();
    }

    /* keep on watching.
      * the socket may have been closed and/or fdp may have been changed
      * in curl_multi_socket_action(), so check them both */
    if(!error && socket_map.find(s) != socket_map.end() &&
        (f == action || f == CURL_POLL_INOUT)) {
      boost::asio::ip::tcp::socket *tcp_socket = socket_map.find(s)->second;

      if(action == CURL_POLL_IN) {
        tcp_socket->async_read_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                                action, boost::placeholders::_1, fdp));
      }
      if(action == CURL_POLL_OUT) {
        tcp_socket->async_write_some(boost::asio::null_buffers(),
                                      boost::bind(&event_cb, g, s,
                                                  action, boost::placeholders::_1, fdp));
      } 
    }
  }
}

/* socket functions */
static void setsock(int *fdp, curl_socket_t s, CURL *e, int act, int oldact, GlobalInfo_t *g) {
  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(s);

  if(it == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "setsock: socket  %#X not found\n, s");
    return;
  }

  boost::asio::ip::tcp::socket * tcp_socket = it->second;

  *fdp = act;

  if(act == CURL_POLL_IN) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_OUT) {
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_INOUT) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
}

static void addsock(curl_socket_t s, CURL *easy, int action, GlobalInfo_t *g) {
  /* fdp is used to store current action */
  int *fdp = (int *) calloc(sizeof(int), 1);

  setsock(fdp, s, easy, action, 0, g);
  curl_multi_assign(g->multi, s, fdp);
}

static int sock_cb(CURL *e, curl_socket_t s, int what, void *cbp, void *sockp) {
  GlobalInfo_t *g = &global;

  int *actionp = (int *) sockp;
  static const char *whatstr[] = { "none", "IN", "OUT", "INOUT", "REMOVE"};

  if(what == CURL_POLL_REMOVE) {
    *actionp = what;
  }
  else {
    if(!actionp) {
      addsock(s, e, what, g);
    }
    else {
      setsock(actionp, s, e, what, *actionp, g);
    }
  }
  return 0;  
}

static void threadFunc() {      
  /* to make sure the event loop doesn't terminate when there is no work to do */
  io_service.reset() ;
  boost::asio::io_service::work work(io_service);
  
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_whisper_tts threadFunc - starting\n");

  for(;;) {
      
    try {
      io_service.run() ;
      break ;
    }
    catch( std::exception& e) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_whisper_tts threadFunc - Error: %s\n", e.what());
    }
  }
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_whisper_tts threadFunc - ending\n");
}


/* Called by asio when our timeout expires */
static void timer_cb(const boost::system::error_code & error, GlobalInfo_t *g)
{
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "timer_cb\n");

  if(!error) {
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, CURL_SOCKET_TIMEOUT, 0, &g->still_running);
    mcode_test("timer_cb: curl_multi_socket_action", rc);
    check_multi_info(g);
  }
}

int multi_timer_cb(CURLM *multi, long timeout_ms, GlobalInfo_t *g) {

  /* cancel running timer */
  timer.cancel();

  if(timeout_ms >= 0) {
    // from libcurl 7.88.1-10+deb12u4 does not allow call curl_multi_socket_action or curl_multi_perform in curl_multi callback directly
    timer.expires_from_now(boost::posix_time::millisec(timeout_ms ? timeout_ms : 1));
    timer.async_wait(boost::bind(&timer_cb, boost::placeholders::_1, g));
  }

  return 0;
}

static std::vector<uint16_t> convert_mp3_to_linear(ConnInfo_t *conn, uint8_t *data, size_t len) {
  std::vector<uint16_t> linear_data;
  int eof = 0;
  int mp3err = 0;
  unsigned char decode_buf[MP3_DCACHE];

  if(mpg123_feed(conn->mh, data, len) == MPG123_OK) {
    while(!eof) {
      size_t usedlen = 0;
      off_t frame_offset;
      unsigned char* audio;

      int decode_status = mpg123_decode_frame(conn->mh, &frame_offset, &audio, &usedlen);

      switch(decode_status) {
        case MPG123_NEW_FORMAT:
          continue;

        case MPG123_OK:
          for(size_t i = 0; i < usedlen; i += 2) {
            uint16_t value = reinterpret_cast<uint16_t*>(audio)[i / 2];
            linear_data.push_back(value);
          }
          break;

        case MPG123_DONE:
        case MPG123_NEED_MORE:
          eof = 1;
          break;

        case MPG123_ERR:
        default:
          if(++mp3err >= 5) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Decoder Error!\n", whisper_get_session_id(conn->handle));
            eof = 1;
          }
      }

      if (eof)
        break;

      mp3err = 0;
    }
  }

  return linear_data;
}
/* CURLOPT_WRITEFUNCTION */
static size_t write_cb(void *ptr, size_t size, size_t nmemb, ConnInfo_t *conn) {
  uint8_t *data = (uint8_t *) ptr;
  size_t bytes_received = size * nmemb;
  whisper_handle_t handle = conn->handle;
  bool fireEvent = 0 == whisper_get_reads(handle);
  whisper_set_reads(handle, whisper_get_reads(handle) + 1);
  AudioPlayer *pAudioPlayer = (AudioPlayer *) whisper_get_audio_player(handle);
  std::vector<uint16_t> pcm_data;
  
  if (conn->flushed || pAudioPlayer == nullptr) {
    /* this will abort the transfer */
    return 0;
  }

  if (whisper_get_response_code(handle) > 0 && whisper_get_response_code(handle) != 200) {
    std::string body((char *) ptr, bytes_received);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: received body %s\n", whisper_get_session_id(handle), body.c_str());
    whisper_set_error_message(handle, body.c_str());
    return 0;
  }

  pcm_data = convert_mp3_to_linear(conn, data, bytes_received);
  size_t bytesResampled = pcm_data.size() * sizeof(uint16_t);

  /* cache file will stay in the mp3 format for size (smaller) and simplicity */
  auto p = whisper_get_shared_ptr(handle);
  if (p) {
    std::lock_guard<std::mutex> lock(p->getMutex());
  if (conn->file) {
    fwrite(data, sizeof(uint8_t), bytes_received, conn->file);
  }
  // buffer audio under mutex lock to make sure we don't add data to freed buffer
  void *audio_player = whisper_get_audio_player(handle);
  if (audio_player) {
    pAudioPlayer = (AudioPlayer *) audio_player;
    pAudioPlayer->bufferAudio(reinterpret_cast<char*>(pcm_data.data()), bytesResampled);
  }

  const char *session_id = whisper_get_session_id(handle);
  if (fireEvent && session_id && strlen(session_id) > 0) {
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - conn->startTime);
    auto time_to_first_byte_ms = std::to_string(duration.count());
    switch_core_session_t* session = switch_core_session_locate(session_id);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_core_session_rwunlock(session);
      if (channel) {
        send_playback_start_event(handle, channel, time_to_first_byte_ms.c_str());
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: channel not found\n", whisper_get_session_id(handle));
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: session not found\n", whisper_get_session_id(handle));
    }
  }
  }
  return bytes_received;
}

static bool parseHeader(const std::string& str, std::string& header, std::string& value) {
    std::vector<std::string> parts;
    boost::split(parts, str, boost::is_any_of(":"), boost::token_compress_on);

    if (parts.size() != 2)
        return false;

    header = boost::trim_copy(parts[0]);
    value = boost::trim_copy(parts[1]);
    return true;
}

static int extract_response_code(const std::string& input) {
  std::size_t space_pos = input.find(' ');
  if (space_pos == std::string::npos) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Invalid HTTP response format %s\n", input.c_str());
    return 0;
  }

  std::size_t code_start_pos = space_pos + 1;
  std::size_t code_end_pos = input.find(' ', code_start_pos);
  if (code_end_pos == std::string::npos) {
    code_end_pos = input.length();
  }

  std::string code_str = input.substr(code_start_pos, code_end_pos - code_start_pos);
  int response_code = std::stoi(code_str);
  return response_code;
}

static size_t header_callback(char *buffer, size_t size, size_t nitems, ConnInfo_t *conn) {
  size_t bytes_received = size * nitems;
  const std::string prefix = "HTTP/";
  whisper_handle_t handle = conn->handle;
  std::string header, value;
  std::string input(buffer, bytes_received);
  if (parseHeader(input, header, value)) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s recv header: %s with value %s\n", whisper_get_session_id(handle), header.c_str(), value.c_str());
    if (0 == header.compare("openai-processing-ms")) whisper_set_reported_latency(handle, value.c_str());
    else if (0 == header.compare("x-request-id")) whisper_set_request_id(handle, value.c_str());
    else if (0 == header.compare("openai-organization")) whisper_set_reported_organization(handle, value.c_str());
    else if (0 == header.compare("x-ratelimit-limit-requests")) whisper_set_reported_ratelimit_requests(handle, value.c_str());
    else if (0 == header.compare("x-ratelimit-remaining-requests")) whisper_set_reported_ratelimit_remaining_requests(handle, value.c_str());
    else if (0 == header.compare("x-ratelimit-reset-requests")) whisper_set_reported_ratelimit_reset_requests(handle, value.c_str());
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s header_callback: %s\n", whisper_get_session_id(handle), input.c_str());
    if (input.rfind(prefix, 0) == 0) {
      try {
        int response_code = extract_response_code(input);
        whisper_set_response_code(handle, response_code);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s header_callback: parsed response code: %d\n", whisper_get_session_id(handle), response_code);
      } catch (const std::invalid_argument& e) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s header_callback: invalid response code %s\n", whisper_get_session_id(handle), input.substr(prefix.length()).c_str());
      }
    }
  }
  return bytes_received;
}

/* CURLOPT_OPENSOCKETFUNCTION */
static curl_socket_t opensocket(void *clientp, curlsocktype purpose, struct curl_sockaddr *address) {
  curl_socket_t sockfd = CURL_SOCKET_BAD;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "opensocket: %d\n", purpose);
  /* restrict to IPv4 */
  if(purpose == CURLSOCKTYPE_IPCXN && address->family == AF_INET) {
    /* create a tcp socket object */
    boost::asio::ip::tcp::socket *tcp_socket = new boost::asio::ip::tcp::socket(io_service);

    /* open it and get the native handle*/
    boost::system::error_code ec;
    tcp_socket->open(boost::asio::ip::tcp::v4(), ec);

    if(ec) {
      /* An error occurred */
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't open socket [%d][%s]\n", ec.value(), ec.message().c_str());
    }
    else {
      sockfd = tcp_socket->native_handle();

      /* save it for monitoring */
      socket_map.insert(std::pair<curl_socket_t, boost::asio::ip::tcp::socket *>(sockfd, tcp_socket));
    }
  }
  return sockfd;
}

/* CURLOPT_CLOSESOCKETFUNCTION */
static int close_socket(void *clientp, curl_socket_t item) {
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "close_socket : %#X\n", item);

  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(item);
  if(it != socket_map.end()) {
    delete it->second;
    socket_map.erase(it);
  }
  return 0;
}


extern "C" {
  switch_status_t whisper_speech_load() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "whisper_speech_loading..\n");
    memset(&global, 0, sizeof(GlobalInfo_t));
    global.multi = curl_multi_init();

     if (!global.multi) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "whisper_speech_load curl_multi_init() failed, exiting!\n");
      return SWITCH_STATUS_FALSE;
    }

    curl_multi_setopt(global.multi, CURLMOPT_SOCKETFUNCTION, sock_cb);
    curl_multi_setopt(global.multi, CURLMOPT_SOCKETDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERFUNCTION, multi_timer_cb);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);

    /* create temp folder for cache files */
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) {
      baseDir = "/tmp/";
    }
    if (strcmp(baseDir, "/") == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", baseDir);
      return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    // Create the directory with read, write, and execute permissions for everyone
    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);
    if (result != 0) {
      if (errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", fullDirPath.c_str());
        fullDirPath = "";
      }
      else switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "folder %s already exists\n", fullDirPath.c_str());
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "created folder %s\n", fullDirPath.c_str());
    }
    // init mgp123
    if (mpg123_init() != MPG123_OK) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to initiate MPG123");
      return SWITCH_STATUS_FALSE;
    }

    /* start worker thread that handles transfers*/
    std::thread t(threadFunc) ;
    worker_thread.swap( t ) ;

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "whisper_speech_loaded..\n");


    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t whisper_speech_unload() {
    /* stop the ASIO IO service */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "whisper_speech_unload: stopping io service\n");
    io_service.stop();

    /* Join the worker thread */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "whisper_speech_unload: wait for worker thread to complete\n");
    if (worker_thread.joinable()) {
        worker_thread.join();
    }

    /* cleanup curl multi handle*/
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "whisper_speech_unload: release curl multi\n");
    curl_multi_cleanup(global.multi);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "whisper_speech_unload: completed\n");

    mpg123_exit();

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t whisper_speech_open(whisper_handle_t handle) {
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t whisper_speech_feed_tts(whisper_handle_t handle, char* text, switch_speech_flag_t *flags) {
    CURLMcode rc;

    const int MAX_CHARS = 20;
    char tempText[MAX_CHARS + 4]; // +4 for the ellipsis and null terminator

    if (strlen(text) > MAX_CHARS) {
        strncpy(tempText, text, MAX_CHARS);
        strcpy(tempText + MAX_CHARS, "...");
    } else {
        strcpy(tempText, text);
    }

    /* open cache file */
    if (whisper_is_cache_audio(handle) && fullDirPath.length() > 0) {
      switch_uuid_t uuid;
      char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
      char outfile[512] = "";
      int fd;

      switch_uuid_get(&uuid);
      switch_uuid_format(uuid_str, &uuid);

      switch_snprintf(outfile, sizeof(outfile), "%s%s%s.mp3", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
      whisper_set_cache_filename(handle, outfile);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s writing audio cache file to %s\n", whisper_get_session_id(handle), outfile);

      mode_t oldMask = umask(0);
      fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
      umask(oldMask);
      if (fd == -1 ) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error opening cache file %s: %s\n", whisper_get_session_id(handle), outfile, strerror(errno));
      }
      else {
        FILE *file = fdopen(fd, "wb");
        whisper_set_file(handle, file);
        if (!file) {
          close(fd);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error opening cache file %s: %s\n", whisper_get_session_id(handle), outfile, strerror(errno));
        }
      }
    }

    const char *api_key = whisper_get_api_key(handle);
    if (!api_key || strlen(api_key) == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s whisper_speech_feed_tts: no api_key provided\n", whisper_get_session_id(handle));
      return SWITCH_STATUS_FALSE;
    }
    const char *model_id = whisper_get_model_id(handle);
    if (!model_id || strlen(model_id) == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s whisper_speech_feed_tts: no model_id provided\n", whisper_get_session_id(handle));
      return SWITCH_STATUS_FALSE;
    }

    /* format url*/
    std::string url = "https://api.openai.com/v1/audio/speech";

    /* create the JSON body */
    cJSON * jResult = cJSON_CreateObject();
    cJSON_AddStringToObject(jResult, "model", model_id);
    cJSON_AddStringToObject(jResult, "input", text);
    const char *voice_name = whisper_get_voice_name(handle);
    cJSON_AddStringToObject(jResult, "voice", voice_name);
    cJSON_AddStringToObject(jResult, "response_format", "mp3");
    const char *speed = whisper_get_speed(handle);
    if (speed && strlen(speed) > 0) {
      cJSON_AddStringToObject(jResult, "speed", speed);
    }
    const char *instructions = whisper_get_instructions(handle);
    if (instructions && strlen(instructions) > 0) {
      cJSON_AddStringToObject(jResult, "instructions", instructions);
    }
    char *json = cJSON_PrintUnformatted(jResult);

    cJSON_Delete(jResult);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s whisper_speech_feed_tts: [%s] [%s]\n", whisper_get_session_id(handle), url.c_str(), tempText);

    ConnInfo_t *conn = new ConnInfo_t();
    memset(conn, 0, sizeof(ConnInfo_t));

    // COnfigure MPG123
    int mhError = 0;
    mpg123_handle *mh = mpg123_new("auto", &mhError);
    if (!mh) {
      const char *mhErr = mpg123_plain_strerror(mhError);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error allocating mpg123 handle! %s\n", whisper_get_session_id(handle), switch_str_nil(mhErr));
      return SWITCH_STATUS_FALSE;
    }

    if (mpg123_open_feed(mh) != MPG123_OK) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error mpg123_open_feed!\n", whisper_get_session_id(handle));
      return SWITCH_STATUS_FALSE;
		}

    if (mpg123_format_all(mh) != MPG123_OK) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error mpg123_format_all!\n", whisper_get_session_id(handle));
      return SWITCH_STATUS_FALSE;
		}

    if (mpg123_param(mh, MPG123_FLAGS, MPG123_MONO_MIX, 0) != MPG123_OK) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error forcing single channel!\n", whisper_get_session_id(handle));
      return SWITCH_STATUS_FALSE;
    }

    CURL* easy = createEasyHandle();
    whisper_set_connection(handle, (void *) conn);
    conn->handle = handle;
    whisper_retain(handle);
    conn->easy = easy;
    conn->mh = mh;
    conn->global = &global;
    conn->hdr_list = NULL ;
    conn->file = whisper_get_file(handle);
    conn->body = json;
    conn->flushed = false;
    

    auto playoutBuffer = new CircularBuffer(8192);
    auto p = whisper_get_shared_ptr(handle);
    auto audioPlayer = new AudioPlayer(p->getMutex(), playoutBuffer);
    whisper_set_playout_buffer(handle, (void *) playoutBuffer);
    whisper_set_audio_player(handle, (void *) audioPlayer);

    if (mpg123_param(mh, MPG123_FORCE_RATE, whisper_get_rate(handle) /*Hz*/, 0) != MPG123_OK) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Error mpg123_param!\n", whisper_get_session_id(handle));
      return SWITCH_STATUS_FALSE;
    }

    std::ostringstream api_key_stream;
    api_key_stream << "Authorization: Bearer " << api_key;

    curl_easy_setopt(easy, CURLOPT_URL, url.c_str());
    curl_easy_setopt(easy, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(easy, CURLOPT_WRITEDATA, conn);
    curl_easy_setopt(easy, CURLOPT_ERRORBUFFER, conn->error);
    curl_easy_setopt(easy, CURLOPT_PRIVATE, conn);
    curl_easy_setopt(easy, CURLOPT_VERBOSE, 0L);
    curl_easy_setopt(easy, CURLOPT_NOPROGRESS, 1L);
    curl_easy_setopt(easy, CURLOPT_HEADERFUNCTION, header_callback);
    curl_easy_setopt(easy, CURLOPT_HEADERDATA, conn);
    
    /* call this function to get a socket */
    curl_easy_setopt(easy, CURLOPT_OPENSOCKETFUNCTION, opensocket);

    /* call this function to close a socket */
    curl_easy_setopt(easy, CURLOPT_CLOSESOCKETFUNCTION, close_socket);

    conn->hdr_list = curl_slist_append(conn->hdr_list, api_key_stream.str().c_str());
    conn->hdr_list = curl_slist_append(conn->hdr_list, "Content-Type: application/json");
    curl_easy_setopt(easy, CURLOPT_HTTPHEADER, conn->hdr_list);

    curl_easy_setopt(easy, CURLOPT_POSTFIELDS, conn->body);
    //curl_easy_setopt(easy, CURLOPT_POSTFIELDSIZE, body.length());

    // libcurl adding random byte to the response body that creates white noise to audio file
    // https://github.com/curl/curl/issues/10525
    const bool disable_http_2 = switch_true(std::getenv("DISABLE_HTTP2_FOR_TTS_STREAMING"));
    curl_easy_setopt(easy, CURLOPT_HTTP_VERSION, disable_http_2 ? CURL_HTTP_VERSION_1_1 : CURL_HTTP_VERSION_2_0);

    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    rc = curl_multi_add_handle(global.multi, conn->easy);
    mcode_test("new_conn: curl_multi_add_handle", rc);

    /* start a timer to measure the duration until we receive first byte of audio */
    conn->startTime = std::chrono::high_resolution_clock::now();

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s whisper_speech_feed_tts: called curl_multi_add_handle\n", whisper_get_session_id(handle));


    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t whisper_speech_read_tts(whisper_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    CircularBuffer *playoutBuffer = (CircularBuffer *) whisper_get_playout_buffer(handle);
    int samplesToCopy = 0;

    auto p = whisper_get_shared_ptr(handle);
    if (p) {
      std::lock_guard<std::mutex> lock(p->getMutex());

      ConnInfo_t *conn = (ConnInfo_t *) whisper_get_connection(handle);
      if (whisper_get_response_code(handle) > 0 && whisper_get_response_code(handle) != 200) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s whisper_speech_read_tts, returning failure\n", whisper_get_session_id(handle)) ;
        return SWITCH_STATUS_FALSE;
      }

      if (conn && conn->flushed) {
        return SWITCH_STATUS_BREAK;
      }

      if (playoutBuffer->size() == 0) {
        if (whisper_is_draining(handle)) {
          return SWITCH_STATUS_BREAK;
        }
        /* no audio available yet so send silence */
        memset(data, 255, *datalen);
        return SWITCH_STATUS_SUCCESS;
      }
      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(*datalen / sizeof(int16_t)));

      auto count = playoutBuffer->getBlock(reinterpret_cast<int16_t*>(data), samplesToCopy);
      if (count != samplesToCopy) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s whisper_speech_read_tts - failed to get %d samples from playout buffer, got %d\n", whisper_get_session_id(handle), samplesToCopy, count);
      }
      *datalen = count * sizeof(int16_t);
      return SWITCH_STATUS_SUCCESS;
    } else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s whisper_speech_read_tts failed to get shared_ptr\n", whisper_get_session_id(handle));
      return SWITCH_STATUS_SUCCESS;
    }
  }

  switch_status_t whisper_speech_flush_tts(whisper_handle_t handle) {
    long response_code = whisper_get_response_code(handle);
    bool download_complete = response_code == 200;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s whisper_speech_flush_tts, download complete? %s\n", whisper_get_session_id(handle), download_complete ? "yes" : "no") ;  
  
    ConnInfo_t *conn = nullptr;
    {
      std::lock_guard<std::mutex> lock(curl_mutex);
      conn = (ConnInfo_t *) whisper_get_connection(handle);
      if (conn) {
        conn->flushed = true;  // Set this while we have curl_mutex
      }
    }

    // Extract pointers while holding lock, then delete outside lock to avoid deadlock
    // The consumer thread needs p->getMutex() to finish, so we can't hold it during thread join
    AudioPlayer* audioPlayer = nullptr;
    CircularBuffer* playoutBuffer = nullptr;

    {
      auto p = whisper_get_shared_ptr(handle);
      if (p) {
        std::lock_guard<std::mutex> lock(p->getMutex());

        // Get pointers and clear them while holding lock
        if (whisper_get_audio_player(handle)) {
          audioPlayer = static_cast<AudioPlayer*>(whisper_get_audio_player(handle));
          whisper_set_audio_player(handle, nullptr);  // Clear pointer first
        }

        if (whisper_get_playout_buffer(handle)) {
          playoutBuffer = static_cast<CircularBuffer*>(whisper_get_playout_buffer(handle));
          whisper_set_playout_buffer(handle, nullptr);  // Clear pointer first
        }

        // Close file while still holding lock
        if (conn && !download_complete && conn->file) {
          const char *cache_filename = whisper_get_cache_filename(handle);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s closing audio cache file %s because download was interrupted\n", whisper_get_session_id(handle), cache_filename);
          if (fclose(conn->file) != 0) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s error closing audio cache file\n", whisper_get_session_id(handle));
          }
          conn->file = nullptr;
          whisper_set_file(handle, nullptr);
        }
      }
    }  // Release p->getMutex() here - consumer thread can now finish and exit

    // Delete outside the lock - this allows consumer thread to complete its work and exit
    if (audioPlayer) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s destroying audio player\n", whisper_get_session_id(handle));
      delete audioPlayer;
    }

    if (playoutBuffer) {
      delete playoutBuffer;
    }

    // if playback_start event has not been sent, delete the file
    const char *cache_filename = whisper_get_cache_filename(handle);
    if (cache_filename && !whisper_is_playback_start_sent(handle)) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s removing audio cache file %s because download was interrupted\n", whisper_get_session_id(handle), cache_filename);
      if (unlink(cache_filename) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s cleanupConn: error removing audio cache file %s: %d:%s\n",
          whisper_get_session_id(handle), cache_filename, errno, strerror(errno));
      }
      whisper_set_cache_filename(handle, "");
    }
    const char *session_id = whisper_get_session_id(handle);
    if (session_id && strlen(session_id) > 0) {
      switch_core_session_t* session = switch_core_session_locate(session_id);
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);
        switch_core_session_rwunlock(session);
        if (channel) {
          // Check if PLAYBACK_START was never sent and send it now if needed
          if (!whisper_is_playback_start_sent(handle)) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s whisper_speech_flush_tts: callback was never called, sending delayed playback-started event\n", whisper_get_session_id(handle));
            send_playback_start_event(handle, channel, "0");

            // Add 100ms delay before sending PLAYBACK_STOP
            switch_yield(100000);
          }

          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);
            const char *playback_id = whisper_get_playback_id(handle);
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s whisper_speech_flush_tts: firing playback-stopped %s\n", whisper_get_session_id(handle), playback_id ? playback_id : "no-playback-id");
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (playback_id && strlen(playback_id) > 0) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
            }
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_whisper_response_code", std::to_string(response_code).c_str());
            if (cache_filename && response_code == 200) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);
            }
            if (response_code != 200) {
              const char *error_msg = whisper_get_error_message(handle);
              if (error_msg && strlen(error_msg) > 0) {
                switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", error_msg);
              }
            }
            switch_event_fire(&event);
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s whisper_speech_flush_tts: failed to create event\n", whisper_get_session_id(handle));
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s whisper_speech_flush_tts: channel not found\n", whisper_get_session_id(handle));
        }
      }
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t whisper_speech_close(whisper_handle_t handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s whisper_speech_close\n", whisper_get_session_id(handle)) ;
		return SWITCH_STATUS_SUCCESS;
	}
}
