#ifndef __WHISPER_GLUE_H__
#define __WHISPER_GLUE_H__

#include "whisper_wrapper.h"

#ifdef __cplusplus
extern "C" {
#endif

switch_status_t whisper_speech_load();
switch_status_t whisper_speech_open(whisper_handle_t handle);
switch_status_t whisper_speech_feed_tts(whisper_handle_t handle, char* text, switch_speech_flag_t *flags);
switch_status_t whisper_speech_read_tts(whisper_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t whisper_speech_flush_tts(whisper_handle_t handle);
switch_status_t whisper_speech_close(whisper_handle_t handle);
switch_status_t whisper_speech_unload();

#ifdef __cplusplus
}
#endif

#endif