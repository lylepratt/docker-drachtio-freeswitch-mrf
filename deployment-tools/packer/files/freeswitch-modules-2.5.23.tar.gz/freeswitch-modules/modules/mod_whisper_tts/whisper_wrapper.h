#ifndef __WHISPER_WRAPPER_H__
#define __WHISPER_WRAPPER_H__

#include <switch.h>

// Opaque handle type for C compatibility
typedef struct whisper_handle* whisper_handle_t;

#ifdef __cplusplus
#include <mutex>
#include <memory>

// Forward declaration
class Whisper;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<Whisper> whisper_get_shared_ptr(whisper_handle_t handle);

extern "C" {
#endif

// Handle management functions
whisper_handle_t whisper_create(void);
void whisper_retain(whisper_handle_t handle);
void whisper_release(whisper_handle_t handle);

// Configuration getters
const char* whisper_get_voice_name(whisper_handle_t handle);
const char* whisper_get_api_key(whisper_handle_t handle);
const char* whisper_get_model_id(whisper_handle_t handle);
const char* whisper_get_speed(whisper_handle_t handle);
const char* whisper_get_instructions(whisper_handle_t handle);
const char* whisper_get_session_id(whisper_handle_t handle);

// Result data getters
long whisper_get_response_code(whisper_handle_t handle);
const char* whisper_get_content_type(whisper_handle_t handle);
const char* whisper_get_reported_organization(whisper_handle_t handle);
const char* whisper_get_reported_latency(whisper_handle_t handle);
const char* whisper_get_reported_ratelimit_requests(whisper_handle_t handle);
const char* whisper_get_reported_ratelimit_remaining_requests(whisper_handle_t handle);
const char* whisper_get_reported_ratelimit_reset_requests(whisper_handle_t handle);
const char* whisper_get_request_id(whisper_handle_t handle);
const char* whisper_get_name_lookup_time_ms(whisper_handle_t handle);
const char* whisper_get_connect_time_ms(whisper_handle_t handle);
const char* whisper_get_final_response_time_ms(whisper_handle_t handle);
const char* whisper_get_error_message(whisper_handle_t handle);
const char* whisper_get_cache_filename(whisper_handle_t handle);

// State getters
int whisper_get_rate(whisper_handle_t handle);
int whisper_is_draining(whisper_handle_t handle);
int whisper_get_reads(whisper_handle_t handle);
int whisper_is_cache_audio(whisper_handle_t handle);
int whisper_is_playback_start_sent(whisper_handle_t handle);

// Resource getters
void* whisper_get_connection(whisper_handle_t handle);
FILE* whisper_get_file(whisper_handle_t handle);
const char* whisper_get_playback_id(whisper_handle_t handle);
void* whisper_get_audio_player(whisper_handle_t handle);
void* whisper_get_playout_buffer(whisper_handle_t handle);

// Configuration setters
void whisper_set_voice_name(whisper_handle_t handle, const char* voice_name);
void whisper_set_api_key(whisper_handle_t handle, const char* api_key);
void whisper_set_model_id(whisper_handle_t handle, const char* model_id);
void whisper_set_speed(whisper_handle_t handle, const char* speed);
void whisper_set_instructions(whisper_handle_t handle, const char* instructions);
void whisper_set_session_id(whisper_handle_t handle, const char* session_id);

// Result data setters
void whisper_set_response_code(whisper_handle_t handle, long response_code);
void whisper_set_content_type(whisper_handle_t handle, const char* content_type);
void whisper_set_reported_organization(whisper_handle_t handle, const char* org);
void whisper_set_reported_latency(whisper_handle_t handle, const char* latency);
void whisper_set_reported_ratelimit_requests(whisper_handle_t handle, const char* requests);
void whisper_set_reported_ratelimit_remaining_requests(whisper_handle_t handle, const char* remaining);
void whisper_set_reported_ratelimit_reset_requests(whisper_handle_t handle, const char* reset);
void whisper_set_request_id(whisper_handle_t handle, const char* request_id);
void whisper_set_name_lookup_time_ms(whisper_handle_t handle, const char* time_ms);
void whisper_set_connect_time_ms(whisper_handle_t handle, const char* time_ms);
void whisper_set_final_response_time_ms(whisper_handle_t handle, const char* time_ms);
void whisper_set_error_message(whisper_handle_t handle, const char* error_msg);
void whisper_set_cache_filename(whisper_handle_t handle, const char* cache_filename);

// State setters
void whisper_set_rate(whisper_handle_t handle, int rate);
void whisper_set_draining(whisper_handle_t handle, int draining);
void whisper_set_reads(whisper_handle_t handle, int reads);
void whisper_set_cache_audio(whisper_handle_t handle, int cache_audio);
void whisper_set_playback_start_sent(whisper_handle_t handle, int playback_start_sent);

// Resource setters
void whisper_set_connection(whisper_handle_t handle, void* conn);
void whisper_set_file(whisper_handle_t handle, FILE* file);
void whisper_set_playback_id(whisper_handle_t handle, const char* playback_id);
void whisper_set_audio_player(whisper_handle_t handle, void* audio_player);
void whisper_set_playout_buffer(whisper_handle_t handle, void* playout_buffer);


#ifdef __cplusplus
}
#endif

#endif