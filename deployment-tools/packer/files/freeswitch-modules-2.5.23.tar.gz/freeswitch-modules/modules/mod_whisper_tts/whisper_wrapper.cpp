#include "whisper_wrapper.h"
#include "whisper.hpp"
#include <map>
#include <mutex>
#include <atomic>

struct whisper_handle {
    std::shared_ptr<Whisper> ptr;
    std::atomic<int> ref_count;
    
    whisper_handle(std::shared_ptr<Whisper> p) : ptr(p), ref_count(1) {}
};

static std::mutex g_handle_mutex;
static std::map<whisper_handle_t, std::shared_ptr<whisper_handle>> g_handle_map;

extern "C" {

whisper_handle_t whisper_create(void) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "whisper_create\n");

    auto whisper_obj = Whisper::create();
    if (!whisper_obj) return nullptr;

    auto handle_obj = std::make_shared<whisper_handle>(whisper_obj);
    whisper_handle_t handle = handle_obj.get();

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "whisper_handle initialized with ref_count %d\n",
      handle->ref_count.load());
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    g_handle_map[handle] = handle_obj;
    
    return handle;
}

void whisper_retain(whisper_handle_t handle) {
    if (!handle) return;
    int new_count = handle->ref_count.fetch_add(1) + 1;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s whisper_retain, ref count %d\n", whisper_get_session_id(handle), new_count);
}

void whisper_release(whisper_handle_t handle) {
    if (!handle) return;
    
    int old_count = handle->ref_count.fetch_sub(1);
    int new_count = old_count - 1;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s whisper_release, ref count %d\n", whisper_get_session_id(handle), new_count);
    
    if (old_count == 1) {
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handle_map.erase(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s whisper_release, handle erased\n", whisper_get_session_id(handle));
    }
}

// Getters
const char* whisper_get_voice_name(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getVoiceName().c_str();
}

const char* whisper_get_api_key(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getApiKey().c_str();
}

const char* whisper_get_model_id(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getModelId().c_str();
}

const char* whisper_get_speed(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getSpeed().c_str();
}

const char* whisper_get_instructions(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getInstructions().c_str();
}

const char* whisper_get_session_id(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getSessionId().c_str();
}

// Result data getters
long whisper_get_response_code(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->getResponseCode();
}

const char* whisper_get_content_type(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getContentType().c_str();
}

const char* whisper_get_reported_organization(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getReportedOrganization().c_str();
}

const char* whisper_get_reported_latency(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getReportedLatency().c_str();
}

const char* whisper_get_reported_ratelimit_requests(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getReportedRatelimitRequests().c_str();
}

const char* whisper_get_reported_ratelimit_remaining_requests(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getReportedRatelimitRemainingRequests().c_str();
}

const char* whisper_get_reported_ratelimit_reset_requests(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getReportedRatelimitResetRequests().c_str();
}

const char* whisper_get_request_id(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getRequestId().c_str();
}

const char* whisper_get_name_lookup_time_ms(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getNameLookupTimeMs().c_str();
}

const char* whisper_get_connect_time_ms(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getConnectTimeMs().c_str();
}

const char* whisper_get_final_response_time_ms(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getFinalResponseTimeMs().c_str();
}

const char* whisper_get_error_message(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getErrorMessage().c_str();
}

const char* whisper_get_cache_filename(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getCacheFilename().c_str();
}

// State getters
int whisper_get_rate(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->getRate();
}

int whisper_is_draining(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->isDraining() ? 1 : 0;
}

int whisper_get_reads(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->getReads();
}

int whisper_is_cache_audio(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->isCacheAudio() ? 1 : 0;
}

int whisper_is_playback_start_sent(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return 0;
    return handle->ptr->isPlaybackStartSent() ? 1 : 0;
}

// Resource getters
void* whisper_get_connection(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr->getConnection();
}

FILE* whisper_get_file(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr->getFile();
}

const char* whisper_get_playback_id(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return "";
    return handle->ptr->getPlaybackId().c_str();
}

void* whisper_get_audio_player(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr->getAudioPlayer();
}

void* whisper_get_playout_buffer(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr->getPlayoutBuffer();
}

// Setters
void whisper_set_voice_name(whisper_handle_t handle, const char* voice_name) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setVoiceName(voice_name ? voice_name : "");
}

void whisper_set_api_key(whisper_handle_t handle, const char* api_key) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setApiKey(api_key ? api_key : "");
}

void whisper_set_model_id(whisper_handle_t handle, const char* model_id) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setModelId(model_id ? model_id : "");
}

void whisper_set_speed(whisper_handle_t handle, const char* speed) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setSpeed(speed ? speed : "");
}

void whisper_set_instructions(whisper_handle_t handle, const char* instructions) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setInstructions(instructions ? instructions : "");
}

void whisper_set_session_id(whisper_handle_t handle, const char* session_id) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setSessionId(session_id ? session_id : "");
}

// Result data setters
void whisper_set_response_code(whisper_handle_t handle, long response_code) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setResponseCode(response_code);
}

void whisper_set_content_type(whisper_handle_t handle, const char* content_type) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setContentType(content_type ? content_type : "");
}

void whisper_set_reported_organization(whisper_handle_t handle, const char* org) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setReportedOrganization(org ? org : "");
}

void whisper_set_reported_latency(whisper_handle_t handle, const char* latency) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setReportedLatency(latency ? latency : "");
}

void whisper_set_reported_ratelimit_requests(whisper_handle_t handle, const char* requests) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setReportedRatelimitRequests(requests ? requests : "");
}

void whisper_set_reported_ratelimit_remaining_requests(whisper_handle_t handle, const char* remaining) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setReportedRatelimitRemainingRequests(remaining ? remaining : "");
}

void whisper_set_reported_ratelimit_reset_requests(whisper_handle_t handle, const char* reset) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setReportedRatelimitResetRequests(reset ? reset : "");
}

void whisper_set_request_id(whisper_handle_t handle, const char* request_id) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setRequestId(request_id ? request_id : "");
}

void whisper_set_name_lookup_time_ms(whisper_handle_t handle, const char* time_ms) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setNameLookupTimeMs(time_ms ? time_ms : "");
}

void whisper_set_connect_time_ms(whisper_handle_t handle, const char* time_ms) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setConnectTimeMs(time_ms ? time_ms : "");
}

void whisper_set_final_response_time_ms(whisper_handle_t handle, const char* time_ms) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setFinalResponseTimeMs(time_ms ? time_ms : "");
}

void whisper_set_error_message(whisper_handle_t handle, const char* error_msg) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setErrorMessage(error_msg ? error_msg : "");
}

void whisper_set_cache_filename(whisper_handle_t handle, const char* cache_filename) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setCacheFilename(cache_filename ? cache_filename : "");
}

// State setters
void whisper_set_rate(whisper_handle_t handle, int rate) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setRate(rate);
}

void whisper_set_draining(whisper_handle_t handle, int draining) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setDraining(draining != 0);
}

void whisper_set_reads(whisper_handle_t handle, int reads) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setReads(reads);
}

void whisper_set_cache_audio(whisper_handle_t handle, int cache_audio) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setCacheAudio(cache_audio != 0);
}

void whisper_set_playback_start_sent(whisper_handle_t handle, int playback_start_sent) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setPlaybackStartSent(playback_start_sent != 0);
}

// Resource setters
void whisper_set_connection(whisper_handle_t handle, void* conn) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setConnection(conn);
}

void whisper_set_file(whisper_handle_t handle, FILE* file) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setFile(file);
}

void whisper_set_playback_id(whisper_handle_t handle, const char* playback_id) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setPlaybackId(playback_id ? playback_id : "");
}

void whisper_set_audio_player(whisper_handle_t handle, void* audio_player) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setAudioPlayer(audio_player);
}

void whisper_set_playout_buffer(whisper_handle_t handle, void* playout_buffer) {
    if (!handle || !handle->ptr) return;
    handle->ptr->setPlayoutBuffer(playout_buffer);
}


} // extern "C"

// C++ functions (not in extern "C")
std::shared_ptr<Whisper> whisper_get_shared_ptr(whisper_handle_t handle) {
    if (!handle || !handle->ptr) return nullptr;
    return handle->ptr;
}