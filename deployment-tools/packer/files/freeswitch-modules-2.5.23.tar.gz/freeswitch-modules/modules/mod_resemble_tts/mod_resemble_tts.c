/* 
 *
 * mod_resemble_tts.c -- Google GRPC-based text to speech
 *
 */
#include "mod_resemble_tts.h"
#include "resemble_glue.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_resemble_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_resemble_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_resemble_tts, mod_resemble_tts_load, mod_resemble_tts_shutdown, NULL);


static void clearResemble(resemble_t* el, int freeAll) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "clearResemble\n");
  if (el->api_key) free(el->api_key);
  if (el->project_uuid) free(el->project_uuid);
  if (el->endpoint) free(el->endpoint);
  if (el->use_tls) free(el->use_tls);
  if (el->ct) free(el->ct);
  if (el->reported_latency) free(el->reported_latency);
  if (el->request_id) free(el->request_id);
  if (el->err_msg) free(el->err_msg);
  if (el->connect_time_ms) free(el->connect_time_ms);
  if (el->final_response_time_ms) free(el->final_response_time_ms);
  if (el->cache_filename) free(el->cache_filename);
  if (el->body) free(el->body);
  
  el->api_key = NULL;
  el->project_uuid = NULL;
  el->endpoint = NULL;
  el->use_tls = NULL;
  el->ct = NULL;
  el->reported_latency = NULL;
  el->request_id = NULL;
  el->err_msg = NULL;
  el->connect_time_ms = NULL;
  el->final_response_time_ms = NULL;
  el->cache_filename = NULL;
  el->body = NULL;
  
  if (el->playbackId) free(el->playbackId);
  el->playbackId = NULL;

  el->file = NULL;

  if (freeAll) {
    if (el->voice_name) free(el->voice_name);
    if (el->session_id) free(el->session_id);
    el->voice_name = NULL;
    el->session_id = NULL;
  }
}
static resemble_t * createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  resemble_t *r = (resemble_t *) sh->private_info;  
  if (!r) {
    r = switch_core_alloc(sh->memory_pool, sizeof(*r));
  	sh->private_info = r;
    memset(r, 0, sizeof(*r));
    switch_mutex_init(&r->mutex, SWITCH_MUTEX_NESTED, sh->memory_pool);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "allocated resemble_t\n");
  }
  return r;
}

/**
 * this is called when FreeSWITCH loads the module
 * if the module is retrieved from cache this will not be called
 * therefore, probably best not to connect to resemble yet
 * Note: if cached, the voice will be provide as a param
 */
static switch_status_t resemble_speech_open_wrapper(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{

  resemble_t *r = createOrRetrievePrivateData(sh);
  r->voice_name = strdup(voice_name);
  r->rate = rate;
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
	return resemble_speech_open(r);
}

static switch_status_t resemble_speech_close_wrapper(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
	resemble_t *r = (resemble_t *) sh->private_info;
  assert(r != NULL);
  
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_close\n");

  /* mutex allocated from session pool - automatically cleaned up */

	rc = resemble_speech_close(r);
  clearResemble(r, 1);
  return rc;  
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t resemble_speech_feed_tts_wrapper(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  resemble_t *r = createOrRetrievePrivateData(sh);
  r->draining = 0;
  r->reads = 0;
  r->response_code = 0;
  r->err_msg = NULL;
  r->playback_start_sent = 0;
  
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_feed_tts\n");
  
	return resemble_speech_feed_tts(r, text, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void resemble_speech_flush_tts_wrapper(switch_speech_handle_t *sh)
{
	resemble_t *r = (resemble_t *) sh->private_info;
	//assert(r != NULL);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "resemble_speech_flush_tts\n");
  resemble_speech_flush_tts(r);

  clearResemble(r, 0);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t resemble_speech_read_tts_wrapper(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
	resemble_t *r = (resemble_t *) sh->private_info;
  return resemble_speech_read_tts(r, data, datalen, flags);
}

static void resemble_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  resemble_t *r = createOrRetrievePrivateData(sh);
  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "el_text_param_tts: %s=XXXXX\n", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "el_text_param_tts: %s=%s\n", param, val);
  }
  if (0 == strcmp(param, "voice")) {
    if (r->voice_name) free(r->voice_name);
    r->voice_name = strdup(val);
  }
  else if (0 == strcmp(param, "api_key")) {
    if (r->api_key) free(r->api_key);
    r->api_key = strdup(val);
  }
  else if (0 == strcmp(param, "endpoint")) {
    if (r->endpoint) free(r->endpoint);
    r->endpoint = strdup(val);
  }
  else if (0 == strcmp(param, "use_tls")) {
    if (r->use_tls) free(r->use_tls);
    r->use_tls = strdup(val);
  }
  else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    r->cache_audio = 1;
  }
  else if (0 == strcmp(param, "playback_id")) {
    if (r->playbackId) free(r->playbackId);
    r->playbackId = strdup(val);
  }
  else if (0 == strcmp(param, "session-uuid")) {
    if (r->session_id) free(r->session_id);
    r->session_id = strdup(val);
  }
}

static void resemble_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}

static void resemble_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_resemble_tts_load)
{
	switch_speech_interface_t *speech_interface;

	/* connect my internal structure to the blank pointer passed to me */
	*module_interface = switch_loadable_module_create_module_interface(pool, modname);
	speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
	speech_interface->interface_name = "resemble";
	speech_interface->speech_open = resemble_speech_open_wrapper;
	speech_interface->speech_close = resemble_speech_close_wrapper;
	speech_interface->speech_feed_tts = resemble_speech_feed_tts_wrapper;
	speech_interface->speech_read_tts = resemble_speech_read_tts_wrapper;
	speech_interface->speech_flush_tts = resemble_speech_flush_tts_wrapper;
	speech_interface->speech_text_param_tts = resemble_text_param_tts;
	speech_interface->speech_numeric_param_tts = resemble_numeric_param_tts;
	speech_interface->speech_float_param_tts = resemble_float_param_tts;

	return resemble_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_resemble_tts_shutdown)
{
  return resemble_speech_unload();
}
