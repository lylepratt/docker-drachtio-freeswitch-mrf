#ifndef __RESEMBLE_GLUE_H__
#define __RESEMBLE_GLUE_H__

switch_status_t resemble_speech_load();
switch_status_t resemble_speech_open(resemble_t* resemble);
switch_status_t resemble_speech_feed_tts(resemble_t* resemble, char* text, switch_speech_flag_t *flags);
switch_status_t resemble_speech_read_tts(resemble_t* resemble, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t resemble_speech_flush_tts(resemble_t* resemble);
switch_status_t resemble_speech_close(resemble_t* resemble);
switch_status_t resemble_speech_unload();

#endif