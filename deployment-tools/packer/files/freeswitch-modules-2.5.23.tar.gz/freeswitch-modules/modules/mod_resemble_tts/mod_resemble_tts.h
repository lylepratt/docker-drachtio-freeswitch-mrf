#ifndef __MOD_RESEMBLE_TTS_H__
#define __MOD_RESEMBLE_TTS_H__

#include <switch.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <speex/speex_resampler.h>

struct resemble_data {
  char *session_id;
	char *voice_name;
  char* api_key;
  char* project_uuid;
  char* endpoint;
  char* use_tls;

  char* body;

  /* result data */
  long response_code;
  char *ct;
  char *reported_latency;
  char *request_id;
  char *connect_time_ms;
  char *final_response_time_ms;
  char *err_msg;
  char *cache_filename;

	int rate;

  void *conn;
  void *pAudioPipe;
	FILE *file;
  char *playbackId;
  switch_mutex_t *mutex;
  void *audioPlayer;
  void *playoutBuffer;
  int draining;
  int flushed;
  int reads;
  int cache_audio;
  int playback_start_sent;
};

typedef struct resemble_data resemble_t;

#endif