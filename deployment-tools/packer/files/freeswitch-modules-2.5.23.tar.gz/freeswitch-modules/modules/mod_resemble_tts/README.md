# mod_resemble_tts

A Freeswitch module that allows Resemble' Text-to-Speech API to be used as a tts provider.
