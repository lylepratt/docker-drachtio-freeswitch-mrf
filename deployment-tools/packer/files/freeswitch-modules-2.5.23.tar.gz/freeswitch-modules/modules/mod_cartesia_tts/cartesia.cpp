#include "cartesia.hpp"
#include <cstring>

// Constructor
Cartesia::Cartesia()
    : response_code_(0)
    , rate_(0)
    , draining_(false)
    , reads_(0)
    , cache_audio_(false)
    , playback_start_sent_(false)
    , conn_(nullptr)
    , circular_buffer_(nullptr)
    // mutex_ is automatically initialized by std::mutex default constructor
    , file_(nullptr)
    , resampler_(nullptr) {
}

// Destructor
Cartesia::~Cartesia() {
    cleanup();
}

// Static factory method
std::shared_ptr<Cartesia> Cartesia::create() {
    return std::make_shared<Cartesia>();
}

// Mutex initialization removed - std::mutex is automatically initialized in constructor

// Reset method - clears transient data but keeps configuration
void Cartesia::reset() {
    // Clear result data
    response_code_ = 0;
    content_type_.clear();
    request_id_.clear();
    name_lookup_time_ms_.clear();
    connect_time_ms_.clear();
    final_response_time_ms_.clear();
    error_message_.clear();
    cache_filename_.clear();
    
    // Reset state
    draining_ = false;
    reads_ = 0;
    playback_start_sent_ = false;
    
    // Clear pointers (but don't free - that's the caller's responsibility)
    conn_ = nullptr;
    file_ = nullptr;
}

// Check if instance is valid
bool Cartesia::isValid() const {
    return !voice_name_.empty();
}

// Private cleanup method
void Cartesia::cleanup() {
    // Note: We don't free the mutex here as it's allocated from the session pool
    // We also don't free other resources as they may be managed externally
    // This is just for cleaning up any internal state if needed
    
    // Clear all strings
    voice_name_.clear();
    api_key_.clear();
    model_id_.clear();
    speed_.clear();
    volume_.clear();
    emotion_.clear();
    language_.clear();
    voice_mode_.clear();
    embedding_.clear();
    
    content_type_.clear();
    request_id_.clear();
    name_lookup_time_ms_.clear();
    connect_time_ms_.clear();
    final_response_time_ms_.clear();
    error_message_.clear();
    cache_filename_.clear();
    session_id_.clear();
    playback_id_.clear();
    
    // Reset pointers
    conn_ = nullptr;
    circular_buffer_ = nullptr;
    // mutex_ is not reset - std::mutex is automatically destroyed
    file_ = nullptr;
    resampler_ = nullptr;
}