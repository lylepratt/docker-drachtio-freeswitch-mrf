#ifndef __CARTESIA_GLUE_H__
#define __CARTESIA_GLUE_H__

#include "cartesia_wrapper.h"

#ifdef __cplusplus
extern "C" {
#endif

switch_status_t cartesia_speech_load();
switch_status_t cartesia_speech_open(cartesia_handle_t handle);
switch_status_t cartesia_speech_feed_tts(cartesia_handle_t handle, char* text, switch_speech_flag_t *flags);
switch_status_t cartesia_speech_read_tts(cartesia_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t cartesia_speech_flush_tts(cartesia_handle_t handle);
switch_status_t cartesia_speech_close(cartesia_handle_t handle);
switch_status_t cartesia_speech_unload();

#ifdef __cplusplus
}
#endif

#endif