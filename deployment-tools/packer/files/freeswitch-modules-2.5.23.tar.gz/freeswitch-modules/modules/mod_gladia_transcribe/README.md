# mod_gladia_transcribe

A FreeSWITCH module for real-time speech transcription using Gladia's WebSocket API.

## Overview

This module provides real-time speech transcription capabilities by streaming audio to Gladia's speech-to-text service via WebSocket connection. Unlike other transcription modules that build parameters internally, mod_gladia_transcribe uses connection parameters directly from FreeSWITCH channel variables, providing maximum flexibility for different Gladia deployment scenarios.

## Features

- Real-time speech transcription via WebSocket
- Support for interim and final transcripts  
- Configurable connection parameters via channel variables
- Support for both TLS and non-TLS connections
- Automatic audio resampling to 8kHz
- Buffer overrun protection
- Graceful connection handling

## Installation

1. Build the module using the provided Makefile.am
2. Install into your FreeSWITCH modules directory
3. Load the module in FreeSWITCH configuration

## Configuration

### Required Channel Variables

The module requires the following channel variables to be set before starting transcription:

- `GLADIA_HOST` - The hostname for the Gladia WebSocket endpoint  
- `GLADIA_PATH` - The WebSocket path (including session token and any query parameters)

### Optional Channel Variables

- `GLADIA_USE_TLS` - Set to "true" to use TLS/SSL, "false" for plain WebSocket (default: true)

### Environment Variables

- `GLADIA_SPEECH_USE_SINGLE_CONNECTION` - Enable connection reuse (default: false)
- `MOD_AUDIO_FORK_BUFFER_SECS` - Audio buffer size in seconds (default: 2, range: 1-5)

## Usage

### Starting Transcription

```
uuid_gladia_transcribe <uuid> start <language-code> [interim] [stereo|mono] [bugname]
```

Parameters:
- `uuid` - The session UUID
- `language-code` - Language code (e.g., "en", "en-US", "fr", etc.)
- `interim` - Optional: Include interim results
- `stereo|mono` - Optional: Audio channel configuration (default: mono)
- `bugname` - Optional: Custom bug name for multiple transcription sessions

### Stopping Transcription

```
uuid_gladia_transcribe <uuid> stop [bugname]
```

### Example Usage

```javascript
// Set connection parameters
session.setVariable("GLADIA_HOST", "api.gladia.io");
session.setVariable("GLADIA_PATH", "/v2/live?token=your-session-token");
session.setVariable("GLADIA_USE_TLS", "true");

// Start transcription
session.execute("uuid_gladia_transcribe", session.uuid + " start en-US interim");

// Stop transcription
session.execute("uuid_gladia_transcribe", session.uuid + " stop");
```

## Gladia WebSocket Flow

1. **Session Initialization**: Create a session using Gladia's REST API to get WebSocket URL with embedded token
2. **WebSocket Connection**: Connect to the WebSocket endpoint using the provided URL 
3. **Start Recording**: Module automatically sends `{"type": "start_recording"}` message after connection
4. **Audio Streaming**: Stream binary audio data (PCM 8kHz, 16-bit) to the WebSocket as binary frames
5. **Receive Messages**: Receive JSON messages with different types (transcript, speech_start, speech_end, etc.)
6. **Stop Recording**: Module sends `{"type": "stop_recording"}` message when session ends

## Events

The module generates the following FreeSWITCH events:

- `gladia_transcribe::transcription` - Contains transcription results
- `gladia_transcribe::connect` - WebSocket connection established
- `gladia_transcribe::connect_failed` - WebSocket connection failed
- `gladia_transcribe::disconnect` - WebSocket connection lost
- `gladia_transcribe::error` - Error occurred during transcription
- `gladia_transcribe::buffer_overrun` - Audio buffer overflow

## Event Handler Example

```javascript
session.addEventListener("gladia_transcribe::transcription", function(event) {
    var body = event.getBody();
    var transcription = JSON.parse(body);
    console.log("Transcription: " + transcription.transcript);
});
```

## Integration with Gladia

### Step 1: Initialize Session

First, make an HTTP POST request to initialize a Gladia session:

```bash
curl -X POST https://api.gladia.io/v2/live \
  -H "Content-Type: application/json" \
  -H "x-gladia-key: YOUR_API_KEY" \
  -d '{
    "encoding": "wav/pcm",
    "bit_depth": 16,
    "sample_rate": 8000,
    "channels": 1,
    "language_config": {
      "languages": ["en"]
    }
  }'
```

Response:
```json
{
  "id": "session-id",
  "url": "wss://api.gladia.io/v2/live?token=session-token"
}
```

### Step 2: Extract Connection Parameters

From the WebSocket URL, extract:
- Host: `api.gladia.io`
- Path: `/v2/live?token=session-token`

### Step 3: Set Channel Variables and Start

```javascript
// Parse the WebSocket URL from Gladia response
var gladiaUrl = "wss://api.gladia.io/v2/live?token=session-token";
var url = new URL(gladiaUrl);

session.setVariable("GLADIA_HOST", url.hostname);
session.setVariable("GLADIA_PATH", url.pathname + url.search);

// Start transcription
session.execute("uuid_gladia_transcribe", session.uuid + " start en-US interim");
```

## Troubleshooting

### Common Issues

1. **Connection Failed**: Check that GLADIA_HOST and GLADIA_PATH are correctly set
2. **No Transcription Results**: Verify the session token in the path is valid and not expired
3. **Buffer Overruns**: Increase buffer size with MOD_AUDIO_FORK_BUFFER_SECS environment variable
4. **TLS Errors**: Try setting GLADIA_USE_TLS to "false" for debugging

### Debug Logging

Enable debug logging in FreeSWITCH to see detailed connection and transcription logs:

```
console loglevel 7
```

## Dependencies

- libwebsockets
- libev
- speex (for audio resampling)
- FreeSWITCH development headers

## License

This module follows the same license as the containing jambonz project.

## Support

For issues related to this module, please refer to the jambonz documentation or create an issue in the repository.

For Gladia API-specific questions, consult the [Gladia API documentation](https://docs.gladia.io/api-reference/v2/live/websocket).