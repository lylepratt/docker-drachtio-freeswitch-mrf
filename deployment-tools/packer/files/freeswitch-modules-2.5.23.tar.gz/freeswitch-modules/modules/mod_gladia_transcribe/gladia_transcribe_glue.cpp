#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>
#include <memory>

#include "mod_gladia_transcribe.h"
#include "simple_buffer.h"
#include "parser.hpp"
#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/

namespace {
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static const char *requestedNumServiceThreads = std::getenv("MOD_AUDIO_FORK_SERVICE_THREADS");
  static unsigned int idxCallCount = 0;
  static uint32_t playCount = 0;

  static std::shared_ptr<gladia::AudioPipe> getAP(void *pAudioPipe) {
    if (pAudioPipe) {
      auto pAp = reinterpret_cast<std::shared_ptr<gladia::AudioPipe>*>(pAudioPipe);
      return *pAp;
    }
    return nullptr;
  }

  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      if (tech_pvt->pAudioPipe) {
        // Initiate graceful shutdown if connected
        auto pAp = getAP(tech_pvt->pAudioPipe);
        if (pAp && pAp->getLwsState() == gladia::AudioPipe::LWS_CLIENT_CONNECTED) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) initiating graceful close\n", tech_pvt->sessionId, tech_pvt->id);
          pAp->finish();
        }
        // release our shared_ptr; lws maintains a shared_ptr in per-connection data until it gets close event
        delete reinterpret_cast<std::shared_ptr<gladia::AudioPipe>*>(tech_pvt->pAudioPipe);
        tech_pvt->pAudioPipe = nullptr;
      }
      if (tech_pvt->resampler) {
          speex_resampler_destroy(tech_pvt->resampler);
          tech_pvt->resampler = NULL;
      }
    }
  }

  static bool eventCallback(const char* sessionId, const char* bugname, 
    gladia::AudioPipe::NotifyEvent_t event, const char* message, bool finished) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case gladia::AudioPipe::CONNECT_SUCCESS:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) successful\n", tech_pvt->bugname);
              
              // Send start_recording message to Gladia after successful connection
              {
                auto pAudioPipe = getAP(tech_pvt->pAudioPipe);
                if (pAudioPipe) {
                  pAudioPipe->sendStartRecording();
                  tech_pvt->is_recording = 1;
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "sent start_recording message to Gladia\n");
                }
              }
              
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_SUCCESS, NULL, tech_pvt->bugname, finished);
            break;
            case gladia::AudioPipe::CONNECT_FAIL:
            {
              std::stringstream json;
              json << "{\"reason\":\"" << message << "\"}";
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_FAIL, (char *) json.str().c_str(), tech_pvt->bugname, finished);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
            }
            break;
            case gladia::AudioPipe::CONNECTION_DROPPED:

              /**
               * this is a bit tricky.  If we just closed a previous connection it may be returning final transcripts
               * In this scenario, the fact that the connection is dropped is not significant.
               */
              if (finished) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "old connection (%s) gracefully closed by Gladia\n", tech_pvt->bugname);
              }
              else {
                if (message && strlen(message) > 0) {
                  tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_ERROR, (char *) message, tech_pvt->bugname, finished);
                }
                tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_DISCONNECT, NULL, tech_pvt->bugname, finished);
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) dropped from far end\n", tech_pvt->bugname);
              }
            break;
            case gladia::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
            break;
            case gladia::AudioPipe::MESSAGE:
              {
                // Parse the JSON message to extract the type
                std::string messageType;
                cJSON* json = parse_json(session, message, messageType);
                
                if (json) {
                  if (messageType == "transcript") {
                    // This is a transcription result
                    tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_RESULTS, message, tech_pvt->bugname, finished);
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gladia transcript (%s): %s\n", tech_pvt->bugname, message);
                  }
                  else if (messageType == "speech_start") {
                    // Speech detection started
                    tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_VAD_DETECTED, message, tech_pvt->bugname, finished);
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gladia speech_start (%s)\n", tech_pvt->bugname);
                  }
                  else if (messageType == "speech_end") {
                    // Speech detection ended
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gladia speech_end (%s)\n", tech_pvt->bugname);
                  }
                  else if (messageType == "start_session" || messageType == "start_recording") {
                    // Session/recording started successfully
                    if (messageType == "start_recording") {
                      tech_pvt->is_recording = 1;
                    }
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gladia %s (%s)\n", messageType.c_str(), tech_pvt->bugname);
                  }
                  else if (messageType == "end_recording" || messageType == "end_session") {
                    // Recording/session ended
                    if (messageType == "end_recording") {
                      tech_pvt->is_recording = 0;
                    }
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gladia %s (%s)\n", messageType.c_str(), tech_pvt->bugname);
                  }
                  else if (messageType == "error") {
                    // Error occurred
                    tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_ERROR, message, tech_pvt->bugname, finished);
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "gladia error (%s): %s\n", tech_pvt->bugname, message);
                  }
                  else {
                    // Other message types (translation, sentiment, etc.)
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gladia %s message (%s): %s\n", messageType.c_str(), tech_pvt->bugname, message);
                  }
                  
                  cJSON_Delete(json);
                }
                else {
                  // Fallback for non-JSON messages
                  tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_RESULTS, message, tech_pvt->bugname, finished);
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gladia message (%s): %s\n", tech_pvt->bugname, message);
                }
              }
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from gladia %d:%s\n", event, message);
              break;
          }
        }
      }
      switch_core_session_rwunlock(session);
      return true;  // Session found and processed
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "session %s gone, event %d:%s\n", sessionId, event, message);
      return false; // Session gone
    }
  }
  
  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, 
    int sampling, int desiredSampling, int channels, char *lang, int interim, 
    char* bugname, responseHandler_t responseHandler) {

    int err;
    int useTls = true;
    std::string host;
    int port = 443;
    std::string path;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * desiredSampling / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_codec_implementation_t read_impl;
    switch_channel_t *channel = switch_core_session_get_channel(session);

    switch_core_session_get_read_impl(session, &read_impl);

    // Get connection parameters from channel variables
    const char* hostVar = switch_channel_get_variable(channel, "GLADIA_SPEECH_HOST");
    const char* pathVar = switch_channel_get_variable(channel, "GLADIA_SPEECH_PATH");
    const char* useTlsVar = switch_channel_get_variable(channel, "GLADIA_SPEECH_USE_TLS");

    if (!hostVar || !pathVar) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "GLADIA_SPEECH_HOST and GLADIA_SPEECH_PATH channel variables must be set\n");
      return SWITCH_STATUS_FALSE;
    }

    host = hostVar;
    path = pathVar;
    
    // Parse host and port if host contains port
    size_t pos = host.find(':');
    if (pos != std::string::npos) {
      std::string strPort = host.substr(pos + 1);
      host = host.substr(0, pos);
      port = ::atoi(strPort.c_str());
    }

    // Use TLS by default, disable only if explicitly set to false
    if (useTlsVar) {
      useTls = switch_true(useTlsVar);
    }

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, 
      "connecting to gladia host %s port %d path %s, using tls? (%s)\n", host.c_str(), port, path.c_str(), useTls ? "yes" : "no");

    memset(tech_pvt, 0, sizeof(private_t));

    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->host, host.c_str(), MAX_WS_URL_LEN);
    tech_pvt->port = port;
    strncpy(tech_pvt->path, path.c_str(), MAX_PATH_LEN);
    tech_pvt->sampling = desiredSampling;
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->channels = channels;
    tech_pvt->id = ++idxCallCount;
    tech_pvt->buffer_overrun_notified = 0;
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    if (!tech_pvt->mutex) {
      switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
    }
    if (!tech_pvt->resampler) {
      if (desiredSampling != sampling) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) resampling from %u to %u\n", tech_pvt->id, sampling, desiredSampling);
        tech_pvt->resampler = speex_resampler_init(channels, sampling, desiredSampling, SWITCH_RESAMPLE_QUALITY, &err);
        if (0 != err) {
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing resampler: %s.\n", speex_resampler_strerror(err));
          return SWITCH_STATUS_FALSE;
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) no resampling needed for this call\n", tech_pvt->id);
      }
    }
    tech_pvt->initialized = 1;

    // Create AudioPipe with shared_ptr for proper lifecycle management
    auto apShared = std::make_shared<gladia::AudioPipe>(tech_pvt->sessionId, bugname, tech_pvt->host, tech_pvt->port, tech_pvt->path, 
      buflen, read_impl.decoded_bytes_per_packet, useTls, eventCallback);
    if (!apShared) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }

    // Store the shared_ptr itself (not the raw pointer)
    tech_pvt->pAudioPipe = new std::shared_ptr<gladia::AudioPipe>(apShared);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connecting to gladia now\n");
    apShared->connect();
    //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");
    
    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {
  switch_status_t gladia_transcribe_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_gladia_transcribe: audio buffer (in secs):    %d secs\n", nAudioBufferSecs);
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    gladia::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, 
			"Gladia authentication is handled via session tokens embedded in WebSocket URLs\n");
		
		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t gladia_transcribe_cleanup() {
    bool cleanup = false;
    cleanup = gladia::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }
	
  switch_status_t gladia_transcribe_session_init(switch_core_session_t *session, 
    responseHandler_t responseHandler, uint32_t samples_per_second, uint32_t channels, 
    char* lang, int interim, char* bugname, void **ppUserData)
  {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    
    // Always create a new tech_pvt structure for each session
    private_t* tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    tech_pvt->initialized = 0;
    tech_pvt->pAudioPipe = NULL;
    tech_pvt->is_recording = 0;
    tech_pvt->mutex = NULL;
    tech_pvt->resampler = NULL;

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second, 8000, channels, lang, interim, bugname, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;

    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t gladia_transcribe_session_stop(switch_core_session_t *session,int channelIsClosing, char* bugname) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gladia_transcribe_session_stop: no bug - websocket connection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    uint32_t id = tech_pvt->id;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) gladia_transcribe_session_stop\n", id);

    if (!tech_pvt) return SWITCH_STATUS_FALSE;
    
    // Send stop_recording message to Gladia before closing connection
    auto pAudioPipe = getAP(tech_pvt->pAudioPipe);
    if (pAudioPipe && pAudioPipe->getLwsState() == gladia::AudioPipe::LWS_CLIENT_CONNECTED) {
      pAudioPipe->sendStopRecording();
      tech_pvt->is_recording = 0;
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "sent stop_recording message to Gladia\n");
    }
      
    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);
    switch_channel_set_private(channel, bugname, NULL);
    if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

    destroy_tech_pvt(tech_pvt);
    switch_mutex_unlock(tech_pvt->mutex);
    /* mutex allocated from session pool - automatically cleaned up */
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "(%u) gladia_transcribe_session_stop\n", id);
    return SWITCH_STATUS_SUCCESS;
  }

	switch_bool_t gladia_transcribe_frame(switch_core_session_t *session, switch_media_bug_t *bug, private_t* tech_pvt) {
    bool dirty = false;
    char *p = (char *) "{\"msg\": \"buffer overrun\"}";

    if (!tech_pvt || !tech_pvt->initialized) return SWITCH_TRUE;

    
    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      if (!tech_pvt->pAudioPipe) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      auto pAudioPipe = getAP(tech_pvt->pAudioPipe);
      if (!pAudioPipe || pAudioPipe->getLwsState() != gladia::AudioPipe::LWS_CLIENT_CONNECTED) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      
      // Only send audio when recording is active
      if (!tech_pvt->is_recording) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      
      pAudioPipe->lockAudioBuffer();
      size_t available = pAudioPipe->binarySpaceAvailable();
      if (NULL == tech_pvt->resampler) {
        switch_frame_t frame = { 0 };
        frame.data = pAudioPipe->binaryWritePtr();
        frame.buflen = available;
        while (true) {

          // check if buffer would be overwritten; dump packets if so
          if (available < pAudioPipe->binaryMinSpace()) {
            if (!tech_pvt->buffer_overrun_notified) {
              tech_pvt->buffer_overrun_notified = 1;
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
            }
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n", 
              tech_pvt->id);
            pAudioPipe->binaryWritePtrResetToZero();

            frame.data = pAudioPipe->binaryWritePtr();
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          }

          switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
          if (rv != SWITCH_STATUS_SUCCESS) break;
          if (frame.datalen) {
            pAudioPipe->binaryWritePtrAdd(frame.datalen);
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
            frame.data = pAudioPipe->binaryWritePtr();
            dirty = true;
          }
        }
      }
      else {
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = { 0 };
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;
        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
          if (frame.datalen) {
            spx_uint32_t out_len = available >> 1;  // space for samples which are 2 bytes
            spx_uint32_t in_len = frame.samples;
            speex_resampler_process_interleaved_int(tech_pvt->resampler, 
              (const spx_int16_t *) frame.data, 
              (spx_uint32_t *) &in_len, 
              (spx_int16_t *) ((char *) pAudioPipe->binaryWritePtr()),
              &out_len);

            if (out_len > 0) {
              // bytes written = num samples * 2 * num channels
              size_t bytes_written = out_len << tech_pvt->channels;
              pAudioPipe->binaryWritePtrAdd(bytes_written);
              available = pAudioPipe->binarySpaceAvailable();
              dirty = true;
            }
            if (available < pAudioPipe->binaryMinSpace()) {
              if (!tech_pvt->buffer_overrun_notified) {
                tech_pvt->buffer_overrun_notified = 1;
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n", 
                  tech_pvt->id);
                tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
              }
              break;
            }
          }
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}