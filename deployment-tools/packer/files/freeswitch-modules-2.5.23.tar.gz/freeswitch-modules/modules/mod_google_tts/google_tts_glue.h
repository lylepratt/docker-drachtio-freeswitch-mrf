#ifndef __GOOGLE_TTS_GLUE_H__
#define __GOOGLE_TTS_GLUE_H__

#include "google_tts_wrapper.h"

#ifdef __cplusplus
extern "C" {
#endif

switch_status_t google_tts_speech_load();
switch_status_t google_tts_speech_open(google_tts_handle_t handle);
switch_status_t google_tts_speech_feed_tts(google_tts_handle_t handle, char* text, switch_speech_flag_t *flags);
switch_status_t google_tts_speech_read_tts(google_tts_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t google_tts_speech_flush_tts(google_tts_handle_t handle);
switch_status_t google_tts_speech_close(google_tts_handle_t handle);
switch_status_t google_tts_speech_unload();

#ifdef __cplusplus
}
#endif

#endif
