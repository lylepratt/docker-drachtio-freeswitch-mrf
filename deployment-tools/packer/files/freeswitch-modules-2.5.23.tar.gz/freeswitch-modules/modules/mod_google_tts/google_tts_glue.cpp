#include <switch.h>
#include <grpc++/grpc++.h>
#include <google/cloud/texttospeech/v1/cloud_tts.grpc.pb.h>

#include <atomic>
#include <chrono>
#include <string>
#include <thread>
#include <mutex>
#include <sys/stat.h>
#include <unistd.h>

#include "mod_google_tts.h"
#include "google_tts_wrapper.h"
#include "google_tts.hpp"
#include "jambonz/audio_player.hpp"
#include "jambonz/circular_buffer.h"
#include "jambonz/base64.hpp"

using google::cloud::texttospeech::v1::AudioEncoding;
using google::cloud::texttospeech::v1::SsmlVoiceGender;
using google::cloud::texttospeech::v1::StreamingSynthesizeRequest;
using google::cloud::texttospeech::v1::StreamingSynthesizeResponse;
using google::cloud::texttospeech::v1::SynthesizeSpeechRequest;
using google::cloud::texttospeech::v1::SynthesizeSpeechResponse;
using google::cloud::texttospeech::v1::TextToSpeech;

static std::string fullDirPath;

struct ConnInfo_t {
    google_tts_handle_t handle;
    std::string text;
    std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
    std::atomic<bool> flushed;

    ConnInfo_t(google_tts_handle_t h, const std::string& t)
        : handle(h), text(t), startTime(std::chrono::high_resolution_clock::now()), flushed(false) {}
};

static std::shared_ptr<grpc::Channel> create_grpc_channel(const char* credentialsFile) {
    const char* google_uri = std::getenv("GOOGLE_TTS_URI");
    if (!google_uri) google_uri = "texttospeech.googleapis.com";

    if (credentialsFile && *credentialsFile) {
        std::string decoded = drachtio::base64_decode(credentialsFile);
        auto channelCreds = grpc::SslCredentials(grpc::SslCredentialsOptions());
        auto callCreds = grpc::ServiceAccountJWTAccessCredentials(decoded);
        return grpc::CreateChannel(google_uri, grpc::CompositeChannelCredentials(channelCreds, callCreds));
    }
    return grpc::CreateChannel(google_uri, grpc::GoogleDefaultCredentials());
}

static void send_playback_start_event(google_tts_handle_t handle, switch_channel_t *channel, const char* ttfb_ms) {
    if (!channel) return;

    switch_event_t *event;
    if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) != SWITCH_STATUS_SUCCESS) return;

    switch_channel_event_set_data(channel, event);

    const char* playback_id = google_tts_get_playback_id(handle);
    const char* voice_name = google_tts_get_voice_name(handle);
    const char* language_code = google_tts_get_language_code(handle);
    const char* cache_filename = google_tts_get_cache_filename(handle);

    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", ttfb_ms);

    if (playback_id && *playback_id)
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
    if (voice_name && *voice_name)
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_google_voice_name", voice_name);
    if (language_code && *language_code)
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_google_language_code", language_code);
    if (cache_filename && *cache_filename)
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);

    const char* session_id = google_tts_get_session_id(handle);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s firing playback-started %s\n",
                      session_id, (playback_id && *playback_id) ? playback_id : "");

    switch_event_fire(&event);
    google_tts_set_playback_start_sent(handle, 1);
}

static void fire_playback_start_from_session(google_tts_handle_t handle, const std::string& ttfb_str) {
    const char *session_id = google_tts_get_session_id(handle);
    if (session_id && *session_id) {
        switch_core_session_t* session = switch_core_session_locate(session_id);
        if (session) {
            switch_channel_t *channel = switch_core_session_get_channel(session);
            if (channel) send_playback_start_event(handle, channel, ttfb_str.c_str());
            switch_core_session_rwunlock(session);
        }
    }
}

static SsmlVoiceGender parse_gender(const char* gender) {
    if (!gender || !*gender) return SsmlVoiceGender::SSML_VOICE_GENDER_UNSPECIFIED;
    if (strcasecmp(gender, "MALE") == 0) return SsmlVoiceGender::MALE;
    if (strcasecmp(gender, "FEMALE") == 0) return SsmlVoiceGender::FEMALE;
    if (strcasecmp(gender, "NEUTRAL") == 0) return SsmlVoiceGender::NEUTRAL;
    return SsmlVoiceGender::SSML_VOICE_GENDER_UNSPECIFIED;
}

static void cleanupConn(ConnInfo_t *conn) {
    if (!conn) return;

    google_tts_handle_t handle = conn->handle;

    google_tts_set_synthesis_context(handle, nullptr);
    google_tts_set_reads(handle, 0);
    google_tts_set_draining(handle, 1);

    google_tts_release(handle);

    delete conn;
}

static void do_streaming_synthesis(ConnInfo_t* conn) {
    google_tts_handle_t handle = conn->handle;
    auto p = google_tts_get_shared_ptr(handle);
    if (!p || conn->flushed) {
        google_tts_set_draining(handle, 1);
        cleanupConn(conn);
        return;
    }

    const char* credentials_file = google_tts_get_credentials_file(handle);
    const char* language_code = google_tts_get_language_code(handle);
    const char* voice_name = google_tts_get_voice_name(handle);
    const char* gender = google_tts_get_gender(handle);
    const char* prompt = google_tts_get_prompt(handle);
    const char* speaking_rate = google_tts_get_speaking_rate(handle);
    const char* session_id = google_tts_get_session_id(handle);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO,
        "%s Streaming TTS: voice=%s, lang=%s\n",
        session_id, voice_name ? voice_name : "default",
        language_code ? language_code : "en-US");

    try {
        auto channel = create_grpc_channel(credentials_file);
        auto stub = TextToSpeech::NewStub(channel);

        grpc::ClientContext context;
        auto streamer = stub->StreamingSynthesize(&context);

        StreamingSynthesizeRequest config_request;
        auto* streaming_config = config_request.mutable_streaming_config();
        auto* voice = streaming_config->mutable_voice();
        voice->set_language_code(language_code ? language_code : "en-US");
        if (voice_name && *voice_name) voice->set_name(voice_name);
        if (gender && *gender) voice->set_ssml_gender(parse_gender(gender));

        auto* audio_config = streaming_config->mutable_streaming_audio_config();
        audio_config->set_audio_encoding(google::cloud::texttospeech::v1::PCM);
        audio_config->set_sample_rate_hertz(8000);
        if (speaking_rate && *speaking_rate) audio_config->set_speaking_rate(atof(speaking_rate));

        if (!streamer->Write(config_request)) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Streaming TTS: failed to write config\n", session_id);
            google_tts_set_response_code(handle, 500);
            google_tts_set_error_message(handle, "Failed to write streaming config");
            cleanupConn(conn);
            return;
        }

        auto connectMs = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::high_resolution_clock::now() - conn->startTime).count();
        google_tts_set_connect_time_ms(handle, std::to_string(connectMs).c_str());

        StreamingSynthesizeRequest text_request;
        auto* input = text_request.mutable_input();
        input->set_text(conn->text);
        if (prompt && *prompt) input->set_prompt(prompt);

        if (!streamer->Write(text_request)) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Streaming TTS: failed to write text\n", session_id);
            google_tts_set_response_code(handle, 500);
            google_tts_set_error_message(handle, "Failed to send text");
            cleanupConn(conn);
            return;
        }

        streamer->WritesDone();

        StreamingSynthesizeResponse response;
        bool first_audio = true;

        while (!conn->flushed && streamer->Read(&response)) {
            if (response.audio_content().empty()) continue;

            if (first_audio) {
                auto ttfbMs = std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::high_resolution_clock::now() - conn->startTime).count();
                std::string ttfb_str = std::to_string(ttfbMs);
                google_tts_set_first_byte_time_ms(handle, ttfb_str.c_str());
                fire_playback_start_from_session(handle, ttfb_str);
                first_audio = false;
            }

            {
                std::lock_guard<std::mutex> lock(p->getMutex());
                AudioPlayer* player = (AudioPlayer*) google_tts_get_audio_player(handle);
                if (player && !conn->flushed) {
                    player->bufferAudio(response.audio_content().data(), response.audio_content().size());
                }
            }
        }

        grpc::Status status = streamer->Finish();
        if (!status.ok() && !conn->flushed) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                "%s Streaming TTS error: %d - %s\n", session_id, status.error_code(), status.error_message().c_str());
            google_tts_set_response_code(handle, 500);
            google_tts_set_error_message(handle, status.error_message().c_str());
        } else {
            google_tts_set_response_code(handle, 200);
        }

    } catch (const std::exception& e) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s Streaming TTS exception: %s\n", session_id, e.what());
        google_tts_set_response_code(handle, 500);
        google_tts_set_error_message(handle, e.what());
    }

    cleanupConn(conn);
}

static void do_unary_synthesis(ConnInfo_t* conn, bool is_gemini) {
    google_tts_handle_t handle = conn->handle;
    auto p = google_tts_get_shared_ptr(handle);
    if (!p || conn->flushed) {
        google_tts_set_draining(handle, 1);
        cleanupConn(conn);
        return;
    }

    const char* credentials_file = google_tts_get_credentials_file(handle);
    const char* language_code = google_tts_get_language_code(handle);
    const char* voice_name = google_tts_get_voice_name(handle);
    const char* gender = google_tts_get_gender(handle);
    const char* model_name = google_tts_get_model_name(handle);
    const char* prompt = google_tts_get_prompt(handle);
    const char* speaking_rate = google_tts_get_speaking_rate(handle);
    const char* pitch = google_tts_get_pitch(handle);
    const char* volume_gain_db = google_tts_get_volume_gain_db(handle);
    const char* session_id = google_tts_get_session_id(handle);

    const char* mode = is_gemini ? "Gemini" : "Standard";
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO,
        "%s %s TTS: voice=%s, lang=%s%s%s\n",
        session_id, mode,
        voice_name ? voice_name : "default",
        language_code ? language_code : "en-US",
        is_gemini && model_name ? ", model=" : "",
        is_gemini && model_name ? model_name : "");

    try {
        auto channel = create_grpc_channel(credentials_file);
        auto stub = TextToSpeech::NewStub(channel);

        SynthesizeSpeechRequest request;
        auto* input = request.mutable_input();

        if (conn->text.compare(0, 6, "<speak") == 0) {
            input->set_ssml(conn->text);
        } else {
            input->set_text(conn->text);
        }

        if (is_gemini && prompt && *prompt) {
            input->set_prompt(prompt);
        }

        auto* voice = request.mutable_voice();
        voice->set_language_code(language_code ? language_code : "en-US");
        if (voice_name && *voice_name) voice->set_name(voice_name);

        if (is_gemini) {
            if (model_name && *model_name) voice->set_model_name(model_name);
        } else {
            if (gender && *gender) voice->set_ssml_gender(parse_gender(gender));
        }

        auto* audio_config = request.mutable_audio_config();
        audio_config->set_audio_encoding(AudioEncoding::LINEAR16);
        audio_config->set_sample_rate_hertz(8000);

        if (!is_gemini) {
            if (speaking_rate && *speaking_rate) audio_config->set_speaking_rate(atof(speaking_rate));
            if (pitch && *pitch) audio_config->set_pitch(atof(pitch));
            if (volume_gain_db && *volume_gain_db) audio_config->set_volume_gain_db(atof(volume_gain_db));
        }

        grpc::ClientContext context;
        context.set_deadline(std::chrono::system_clock::now() + std::chrono::seconds(60));

        SynthesizeSpeechResponse response;
        grpc::Status status = stub->SynthesizeSpeech(&context, request, &response);

        auto ttfbMs = std::chrono::duration_cast<std::chrono::milliseconds>(
            std::chrono::high_resolution_clock::now() - conn->startTime).count();
        std::string ttfb_str = std::to_string(ttfbMs);
        google_tts_set_first_byte_time_ms(handle, ttfb_str.c_str());
        google_tts_set_connect_time_ms(handle, ttfb_str.c_str());

        if (!status.ok()) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                "%s %s TTS failed: %d - %s\n", session_id, mode, status.error_code(), status.error_message().c_str());
            google_tts_set_response_code(handle, 500);
            google_tts_set_error_message(handle, status.error_message().c_str());
            cleanupConn(conn);
            return;
        }

        if (conn->flushed) {
            google_tts_set_response_code(handle, 200);
            cleanupConn(conn);
            return;
        }

        const std::string& audio_content = response.audio_content();
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "%s %s TTS response: %zu bytes\n", session_id, mode, audio_content.size());

        if (!audio_content.empty()) {
            fire_playback_start_from_session(handle, ttfb_str);

            const size_t WAV_HEADER_SIZE = 44;
            const char* audio_data = audio_content.data();
            size_t audio_size = audio_content.size();

            if (audio_size > WAV_HEADER_SIZE &&
                audio_content[0] == 'R' && audio_content[1] == 'I' &&
                audio_content[2] == 'F' && audio_content[3] == 'F') {
                audio_data += WAV_HEADER_SIZE;
                audio_size -= WAV_HEADER_SIZE;
            }

            {
                std::lock_guard<std::mutex> lock(p->getMutex());
                AudioPlayer* player = (AudioPlayer*) google_tts_get_audio_player(handle);
                if (player && !conn->flushed) {
                    player->bufferAudio(audio_data, audio_size);
                }
            }
        }

        google_tts_set_response_code(handle, 200);

    } catch (const std::exception& e) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s %s TTS exception: %s\n", session_id, mode, e.what());
        google_tts_set_response_code(handle, 500);
        google_tts_set_error_message(handle, e.what());
    }

    cleanupConn(conn);
}

static void synthesis_work(ConnInfo_t* conn) {
    google_tts_handle_t handle = conn->handle;

    const char* api_mode = google_tts_get_api_mode(handle);

    if (strcmp(api_mode, "live") == 0) {
        do_streaming_synthesis(conn);
    } else if (strcmp(api_mode, "gemini") == 0) {
        do_unary_synthesis(conn, true);
    } else {
        // default: "tts"
        do_unary_synthesis(conn, false);
    }
}

extern "C" {

switch_status_t google_tts_speech_load() {
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) baseDir = "/tmp/";
    if (strcmp(baseDir, "/") == 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "invalid cache folder: %s\n", baseDir);
        return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);

    if (result != 0 && errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create cache folder: %s\n", fullDirPath.c_str());
        fullDirPath = "";
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "mod_google_tts loaded\n");
    return SWITCH_STATUS_SUCCESS;
}

switch_status_t google_tts_speech_unload() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "mod_google_tts unloaded\n");
    return SWITCH_STATUS_SUCCESS;
}

switch_status_t google_tts_speech_open(google_tts_handle_t handle) {
    return SWITCH_STATUS_SUCCESS;
}

switch_status_t google_tts_speech_feed_tts(google_tts_handle_t handle, char* text, switch_speech_flag_t *flags) {
    auto p = google_tts_get_shared_ptr(handle);
    if (!p) return SWITCH_STATUS_FALSE;

    google_tts_retain(handle);

    int rate = google_tts_get_rate(handle);
    if (google_tts_is_cache_audio(handle) && !fullDirPath.empty()) {
        switch_uuid_t uuid;
        char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
        char outfile[512];

        switch_uuid_get(&uuid);
        switch_uuid_format(uuid_str, &uuid);
        switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
        google_tts_set_cache_filename(handle, outfile);
    }

    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(p->getMutex(), playoutBuffer);
    audioPlayer->setResampling(8000, rate);

    const char *cache_filename = google_tts_get_cache_filename(handle);
    if (cache_filename && *cache_filename) {
        audioPlayer->setCacheFilePath(cache_filename);
    }

    google_tts_set_playout_buffer(handle, playoutBuffer);
    google_tts_set_audio_player(handle, audioPlayer);

    auto* conn = new ConnInfo_t(handle, text);
    google_tts_set_synthesis_context(handle, conn);

    std::thread t(synthesis_work, conn);
    t.detach();

    return SWITCH_STATUS_SUCCESS;
}

switch_status_t google_tts_speech_read_tts(google_tts_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    auto p = google_tts_get_shared_ptr(handle);
    if (!p) {
        memset(data, 0, *datalen);
        return SWITCH_STATUS_SUCCESS;
    }

    std::lock_guard<std::mutex> lock(p->getMutex());

    long response_code = google_tts_get_response_code(handle);
    if (response_code != 0 && response_code != 200) {
        const char* session_id = google_tts_get_session_id(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "%s read_tts: TTS error %ld: %s\n", session_id, response_code, google_tts_get_error_message(handle));
        return SWITCH_STATUS_FALSE;
    }

    CircularBuffer *playoutBuffer = (CircularBuffer *) google_tts_get_playout_buffer(handle);

    if (!playoutBuffer) {
        if (google_tts_is_draining(handle)) {
            return SWITCH_STATUS_BREAK;
        }
        memset(data, 0, *datalen);
        return SWITCH_STATUS_SUCCESS;
    }

    if (playoutBuffer->size() == 0) {
        if (google_tts_is_draining(handle)) {
            int empty_count = google_tts_get_reads(handle);
            empty_count++;
            google_tts_set_reads(handle, empty_count);
            if (empty_count > 5) {
                return SWITCH_STATUS_BREAK;
            }
        }
        memset(data, 0, *datalen);
        return SWITCH_STATUS_SUCCESS;
    }

    google_tts_set_reads(handle, 0);

    int samplesToCopy = std::min((int)playoutBuffer->size(), (int)(*datalen / sizeof(int16_t)));
    int count = playoutBuffer->getBlock(reinterpret_cast<int16_t*>(data), samplesToCopy);
    *datalen = count * sizeof(int16_t);

    return SWITCH_STATUS_SUCCESS;
}

switch_status_t google_tts_speech_flush_tts(google_tts_handle_t handle) {
    ConnInfo_t* conn = (ConnInfo_t*) google_tts_get_synthesis_context(handle);
    if (conn) {
        conn->flushed = true;
    }

    auto p = google_tts_get_shared_ptr(handle);
    AudioPlayer* audioPlayer = nullptr;
    CircularBuffer* playoutBuffer = nullptr;

    if (p) {
        std::lock_guard<std::mutex> lock(p->getMutex());
        audioPlayer = static_cast<AudioPlayer*>(google_tts_get_audio_player(handle));
        playoutBuffer = static_cast<CircularBuffer*>(google_tts_get_playout_buffer(handle));
        google_tts_set_audio_player(handle, nullptr);
        google_tts_set_playout_buffer(handle, nullptr);
    }

    delete audioPlayer;
    delete playoutBuffer;

    long response_code = google_tts_get_response_code(handle);
    const char *session_id = google_tts_get_session_id(handle);

    // If playback_start has not been sent, delete the cache file
    const char *cache_filename = google_tts_get_cache_filename(handle);
    if (cache_filename && *cache_filename && !google_tts_is_playback_start_sent(handle)) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "%s removing audio cache file %s because download was interrupted\n", session_id, cache_filename);
        if (unlink(cache_filename) != 0) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                "%s error removing audio cache file %s: %d:%s\n", session_id, cache_filename, errno, strerror(errno));
        }
        google_tts_set_cache_filename(handle, "");
    }
    if (session_id && *session_id) {
        switch_core_session_t* session = switch_core_session_locate(session_id);
        if (session) {
            switch_channel_t *channel = switch_core_session_get_channel(session);
            if (channel) {
                if (!google_tts_is_playback_start_sent(handle)) {
                    send_playback_start_event(handle, channel, "0");
                }

                switch_event_t *event;
                if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
                    switch_channel_event_set_data(channel, event);

                    const char *playback_id = google_tts_get_playback_id(handle);
                    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s firing playback-stopped %s\n",
                        session_id, (playback_id && *playback_id) ? playback_id : "");

                    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
                    if (playback_id && *playback_id)
                        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);

                    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_google_response_code",
                        std::to_string(response_code).c_str());

                    cache_filename = google_tts_get_cache_filename(handle);
                    if (cache_filename && *cache_filename && response_code == 200)
                        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);

                    const char *error_message = google_tts_get_error_message(handle);
                    if (response_code != 200 && error_message && *error_message)
                        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", error_message);

                    switch_event_fire(&event);
                }
            }
            switch_core_session_rwunlock(session);
        }
    }

    return SWITCH_STATUS_SUCCESS;
}

switch_status_t google_tts_speech_close(google_tts_handle_t handle) {
    return SWITCH_STATUS_SUCCESS;
}

} // extern "C"
