/*
 * mod_google_tts.h -- Google gRPC-based text to speech using speech interface
 */
#ifndef __MOD_GOOGLE_TTS_H__
#define __MOD_GOOGLE_TTS_H__

#include <switch.h>

#endif /* __MOD_GOOGLE_TTS_H__ */
