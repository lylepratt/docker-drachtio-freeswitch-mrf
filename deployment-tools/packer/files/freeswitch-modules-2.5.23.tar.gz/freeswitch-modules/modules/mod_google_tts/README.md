# mod_google_tts

A FreeSWITCH module that provides Text-to-Speech functionality using Google Cloud Text-to-Speech API via gRPC.

## Overview

This module integrates with Google Cloud's Text-to-Speech service to convert text into natural-sounding speech. It supports three different API modes:

- **tts** (default): Standard unary TTS API - sends text and receives complete audio response
- **live**: Streaming synthesis API - receives audio chunks in real-time as they are generated
- **gemini**: Gemini TTS API - uses Google's Gemini model for speech synthesis

## API

### Commands

This module integrates into the FreeSWITCH TTS interface and is invoked when an application uses the `speak` command with a tts engine of `google`.

### Events

- **SWITCH_EVENT_PLAYBACK_START**: Fired when audio playback begins, includes time-to-first-byte metrics
- **SWITCH_EVENT_PLAYBACK_STOP**: Fired when audio playback ends, includes response code and any error messages

## Usage

When using [drachtio-fsmrf](https://www.npmjs.com/package/drachtio-fsmrf), you can access this functionality via the speak method on the 'endpoint' object.

```js
var text = "Hello, this is a test of Google Text-to-Speech.";
await endpoint.speak({
    "ttsEngine": "google",
    "voice": "en-US-Wavenet-D",
    "text": `{language_code=en-US,gender=MALE,credentials=BASE64_ENCODED_SERVICE_ACCOUNT_JSON}${text}`,
});
```

### Using Different API Modes

```js
// Standard TTS (default)
await endpoint.speak({
    "ttsEngine": "google",
    "voice": "en-US-Wavenet-D",
    "text": `{api_mode=tts,language_code=en-US}${text}`,
});

// Streaming/Live API
await endpoint.speak({
    "ttsEngine": "google",
    "voice": "en-US-Wavenet-D",
    "text": `{api_mode=live,language_code=en-US}${text}`,
});

// Gemini TTS
await endpoint.speak({
    "ttsEngine": "google",
    "voice": "en-US-Wavenet-D",
    "text": `{api_mode=gemini,model_name=gemini-model,language_code=en-US}${text}`,
});
```

## Options

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `api_mode` | string | `tts` | API mode to use: `tts`, `live`, or `gemini` |
| `voice` | string | - | Voice name (e.g., `en-US-Wavenet-D`) |
| `language_code` | string | `en-US` | Language code for synthesis |
| `gender` | string | - | Voice gender: `MALE`, `FEMALE`, or `NEUTRAL` |
| `credentials` | string | - | Base64-encoded Google service account JSON |
| `model_name` | string | - | Model name (used with `gemini` api_mode) |
| `prompt` | string | - | Prompt for voice styling (used with `live` and `gemini` modes) |
| `speaking_rate` | string | - | Speaking rate (0.25 to 4.0, where 1.0 is normal) |
| `pitch` | string | - | Pitch adjustment (-20.0 to 20.0 semitones) |
| `volume_gain_db` | string | - | Volume gain in dB (-96.0 to 16.0) |
| `write_cache_file` | boolean | false | Cache audio to file for reuse |
| `playback_id` | string | - | Custom ID for tracking playback events |
| `session-uuid` | string | - | Session UUID for event correlation |

## API Mode Details

### tts (Standard)

Uses Google's `SynthesizeSpeech` unary RPC. The entire text is sent to the API and the complete audio response is returned. Supports all audio configuration options (speaking_rate, pitch, volume_gain_db).

### live (Streaming)

Uses Google's `StreamingSynthesize` RPC for real-time audio streaming. Audio chunks are received and played as they are generated, providing lower latency for the first audio byte. Best for interactive applications.

### gemini

Uses Google's `SynthesizeSpeech` unary RPC with Gemini model support. Requires `model_name` parameter. Supports the `prompt` parameter for voice styling but does not support speaking_rate, pitch, or volume_gain_db.

## Authentication

The module supports two authentication methods:

1. **Service Account JSON**: Pass base64-encoded service account credentials via the `credentials` parameter
2. **Application Default Credentials**: If no credentials are provided, the module uses Google's default credential chain (GOOGLE_APPLICATION_CREDENTIALS environment variable)

## Environment Variables

| Variable | Description |
|----------|-------------|
| `GOOGLE_TTS_URI` | Override the default Google TTS endpoint (default: `texttospeech.googleapis.com`) |
| `JAMBONZ_TMP_CACHE_FOLDER` | Directory for cached audio files (default: `/tmp/`) |

## Architecture

The module consists of several components:

- **mod_google_tts.c**: FreeSWITCH module interface and parameter handling
- **google_tts.hpp/cpp**: Core C++ class managing TTS state and configuration
- **google_tts_wrapper.h/cpp**: C wrapper functions for C++ implementation
- **google_tts_glue.cpp**: gRPC implementation and synthesis logic
