#include "google_tts_wrapper.h"
#include "google_tts.hpp"
#include <unordered_map>
#include <mutex>

struct google_tts_handle {
    std::shared_ptr<GoogleTTS> impl;
    int ref_count;
    google_tts_handle(std::shared_ptr<GoogleTTS> p) : impl(p), ref_count(1) {}
};

static std::unordered_map<google_tts_handle_t, std::unique_ptr<google_tts_handle>> g_handles;
static std::mutex g_handle_mutex;

std::shared_ptr<GoogleTTS> google_tts_get_shared_ptr(google_tts_handle_t handle) {
    if (!handle) return nullptr;
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second->impl : nullptr;
}

google_tts_handle_t google_tts_get_handle_from_shared_ptr(const std::shared_ptr<GoogleTTS>& ptr) {
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->impl == ptr) return pair.first;
    }
    return nullptr;
}

extern "C" {

google_tts_handle_t google_tts_create(void) {
    auto* h = new google_tts_handle(GoogleTTS::create());
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    g_handles[h] = std::unique_ptr<google_tts_handle>(h);
    return h;
}

void google_tts_retain(google_tts_handle_t handle) {
    if (!handle) return;
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    if (it != g_handles.end()) it->second->ref_count++;
}

void google_tts_release(google_tts_handle_t handle) {
    if (!handle) return;
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    if (it != g_handles.end() && --it->second->ref_count <= 0) g_handles.erase(it);
}

// Configuration getters
const char* google_tts_get_session_id(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getSessionId().c_str() : ""; }
const char* google_tts_get_voice_name(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getVoiceName().c_str() : ""; }
const char* google_tts_get_language_code(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getLanguageCode().c_str() : ""; }
const char* google_tts_get_gender(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getGender().c_str() : ""; }
const char* google_tts_get_credentials_file(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getCredentialsFile().c_str() : ""; }
const char* google_tts_get_model_name(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getModelName().c_str() : ""; }
const char* google_tts_get_prompt(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getPrompt().c_str() : ""; }
const char* google_tts_get_speaking_rate(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getSpeakingRate().c_str() : ""; }
const char* google_tts_get_pitch(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getPitch().c_str() : ""; }
const char* google_tts_get_volume_gain_db(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getVolumeGainDb().c_str() : ""; }

// Result data getters
long google_tts_get_response_code(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getResponseCode() : 0; }
const char* google_tts_get_error_message(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getErrorMessage().c_str() : ""; }
const char* google_tts_get_connect_time_ms(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getConnectTimeMs().c_str() : ""; }
const char* google_tts_get_first_byte_time_ms(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getFirstByteTimeMs().c_str() : ""; }
const char* google_tts_get_cache_filename(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getCacheFilename().c_str() : ""; }

// State getters
int google_tts_get_rate(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getRate() : 8000; }
int google_tts_is_draining(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p && p->isDraining() ? 1 : 0; }
int google_tts_get_reads(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getReads() : 0; }
int google_tts_is_cache_audio(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p && p->isCacheAudio() ? 1 : 0; }
int google_tts_is_playback_start_sent(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p && p->isPlaybackStartSent() ? 1 : 0; }
const char* google_tts_get_api_mode(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getApiMode().c_str() : "tts"; }

// Resource getters
void* google_tts_get_audio_player(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getAudioPlayer() : nullptr; }
void* google_tts_get_playout_buffer(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getPlayoutBuffer() : nullptr; }
void* google_tts_get_synthesis_context(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getSynthesisContext() : nullptr; }
const char* google_tts_get_playback_id(google_tts_handle_t h) { auto p = google_tts_get_shared_ptr(h); return p ? p->getPlaybackId().c_str() : ""; }

// Configuration setters
void google_tts_set_session_id(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setSessionId(v); }
void google_tts_set_voice_name(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setVoiceName(v); }
void google_tts_set_language_code(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setLanguageCode(v); }
void google_tts_set_gender(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setGender(v); }
void google_tts_set_credentials_file(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setCredentialsFile(v); }
void google_tts_set_model_name(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setModelName(v); }
void google_tts_set_prompt(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setPrompt(v); }
void google_tts_set_speaking_rate(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setSpeakingRate(v); }
void google_tts_set_pitch(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setPitch(v); }
void google_tts_set_volume_gain_db(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setVolumeGainDb(v); }

// Result data setters
void google_tts_set_response_code(google_tts_handle_t h, long v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setResponseCode(v); }
void google_tts_set_error_message(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setErrorMessage(v); }
void google_tts_set_connect_time_ms(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setConnectTimeMs(v); }
void google_tts_set_first_byte_time_ms(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setFirstByteTimeMs(v); }
void google_tts_set_cache_filename(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setCacheFilename(v); }

// State setters
void google_tts_set_rate(google_tts_handle_t h, int v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setRate(v); }
void google_tts_set_draining(google_tts_handle_t h, int v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setDraining(v != 0); }
void google_tts_set_reads(google_tts_handle_t h, int v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setReads(v); }
void google_tts_set_cache_audio(google_tts_handle_t h, int v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setCacheAudio(v != 0); }
void google_tts_set_playback_start_sent(google_tts_handle_t h, int v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setPlaybackStartSent(v != 0); }
void google_tts_set_api_mode(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setApiMode(v); }

// Resource setters
void google_tts_set_audio_player(google_tts_handle_t h, void* v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setAudioPlayer(v); }
void google_tts_set_playout_buffer(google_tts_handle_t h, void* v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setPlayoutBuffer(v); }
void google_tts_set_synthesis_context(google_tts_handle_t h, void* v) { auto p = google_tts_get_shared_ptr(h); if (p) p->setSynthesisContext(v); }
void google_tts_set_playback_id(google_tts_handle_t h, const char* v) { auto p = google_tts_get_shared_ptr(h); if (p && v) p->setPlaybackId(v); }

} // extern "C"
