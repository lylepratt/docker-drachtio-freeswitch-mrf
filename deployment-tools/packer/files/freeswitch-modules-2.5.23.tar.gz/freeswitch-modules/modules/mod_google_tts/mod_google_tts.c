/* mod_google_tts.c -- Google gRPC-based text to speech */
#include "mod_google_tts.h"
#include "google_tts_glue.h"
#include "google_tts_wrapper.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_google_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_google_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_google_tts, mod_google_tts_load, mod_google_tts_shutdown, NULL);

static void clearGoogleTTS(google_tts_handle_t handle, int freeAll) {
  google_tts_set_credentials_file(handle, "");
  google_tts_set_model_name(handle, "");
  google_tts_set_prompt(handle, "");
  google_tts_set_speaking_rate(handle, "");
  google_tts_set_pitch(handle, "");
  google_tts_set_volume_gain_db(handle, "");
  google_tts_set_error_message(handle, "");
  google_tts_set_connect_time_ms(handle, "");
  google_tts_set_first_byte_time_ms(handle, "");
  google_tts_set_cache_filename(handle, "");
  google_tts_set_playback_id(handle, "");
  google_tts_set_api_mode(handle, "tts");
  google_tts_set_cache_audio(handle, 0);

  if (freeAll) {
    google_tts_set_voice_name(handle, "");
    google_tts_set_language_code(handle, "");
    google_tts_set_gender(handle, "");
    google_tts_set_session_id(handle, "");
  }
}

static google_tts_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  google_tts_handle_t handle = (google_tts_handle_t) sh->private_info;
  if (!handle) {
    handle = google_tts_create();
    sh->private_info = handle;
  }
  return handle;
}

static switch_status_t google_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags) {
  google_tts_handle_t handle = createOrRetrievePrivateData(sh);
  google_tts_set_voice_name(handle, voice_name);
  google_tts_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "speech_open: voice=%s, rate=%d\n", voice_name, rate);
  return google_tts_speech_open(handle);
}

static switch_status_t google_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags) {
  switch_status_t rc;
  google_tts_handle_t handle = (google_tts_handle_t) sh->private_info;
  assert(handle != NULL);

  rc = google_tts_speech_close(handle);
  clearGoogleTTS(handle, 1);
  google_tts_release(handle);
  return rc;
}

static switch_status_t google_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags) {
  google_tts_handle_t handle = createOrRetrievePrivateData(sh);
  google_tts_set_draining(handle, 0);
  google_tts_set_reads(handle, 0);
  google_tts_set_response_code(handle, 0);
  google_tts_set_error_message(handle, "");
  google_tts_set_playback_start_sent(handle, 0);
  return google_tts_speech_feed_tts(handle, text, flags);
}

static void google_speech_flush_tts(switch_speech_handle_t *sh) {
  google_tts_handle_t handle = (google_tts_handle_t) sh->private_info;
  google_tts_speech_flush_tts(handle);
  clearGoogleTTS(handle, 0);
}

static switch_status_t google_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags) {
  google_tts_handle_t handle = (google_tts_handle_t) sh->private_info;
  return google_tts_speech_read_tts(handle, data, datalen, flags);
}

static void google_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val) {
  google_tts_handle_t handle = createOrRetrievePrivateData(sh);

  if (0 == strcmp(param, "voice")) google_tts_set_voice_name(handle, val);
  else if (0 == strcmp(param, "language_code")) google_tts_set_language_code(handle, val);
  else if (0 == strcmp(param, "gender")) google_tts_set_gender(handle, val);
  else if (0 == strcmp(param, "credentials")) google_tts_set_credentials_file(handle, val);
  else if (0 == strcmp(param, "model_name")) google_tts_set_model_name(handle, val);
  else if (0 == strcmp(param, "prompt")) google_tts_set_prompt(handle, val);
  else if (0 == strcmp(param, "speaking_rate")) google_tts_set_speaking_rate(handle, val);
  else if (0 == strcmp(param, "pitch")) google_tts_set_pitch(handle, val);
  else if (0 == strcmp(param, "volume_gain_db")) google_tts_set_volume_gain_db(handle, val);
  else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) google_tts_set_cache_audio(handle, 1);
  else if (0 == strcmp(param, "playback_id")) google_tts_set_playback_id(handle, val);
  else if (0 == strcmp(param, "session-uuid")) google_tts_set_session_id(handle, val);
  else if (0 == strcmp(param, "api_mode")) google_tts_set_api_mode(handle, val);
}

static void google_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val) {
}

static void google_float_param_tts(switch_speech_handle_t *sh, char *param, double val) {
}

SWITCH_MODULE_LOAD_FUNCTION(mod_google_tts_load) {
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "google";
  speech_interface->speech_open = google_speech_open;
  speech_interface->speech_close = google_speech_close;
  speech_interface->speech_feed_tts = google_speech_feed_tts;
  speech_interface->speech_read_tts = google_speech_read_tts;
  speech_interface->speech_flush_tts = google_speech_flush_tts;
  speech_interface->speech_text_param_tts = google_text_param_tts;
  speech_interface->speech_numeric_param_tts = google_numeric_param_tts;
  speech_interface->speech_float_param_tts = google_float_param_tts;

  return google_tts_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_google_tts_shutdown) {
  return google_tts_speech_unload();
}
