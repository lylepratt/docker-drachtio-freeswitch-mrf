#ifndef __GOOGLE_TTS_WRAPPER_H__
#define __GOOGLE_TTS_WRAPPER_H__

#include <switch.h>

typedef struct google_tts_handle* google_tts_handle_t;

#ifdef __cplusplus
#include <memory>
class GoogleTTS;
std::shared_ptr<GoogleTTS> google_tts_get_shared_ptr(google_tts_handle_t handle);
google_tts_handle_t google_tts_get_handle_from_shared_ptr(const std::shared_ptr<GoogleTTS>& ptr);
extern "C" {
#endif

// Handle management
google_tts_handle_t google_tts_create(void);
void google_tts_retain(google_tts_handle_t handle);
void google_tts_release(google_tts_handle_t handle);

// Configuration
const char* google_tts_get_session_id(google_tts_handle_t handle);
const char* google_tts_get_voice_name(google_tts_handle_t handle);
const char* google_tts_get_language_code(google_tts_handle_t handle);
const char* google_tts_get_gender(google_tts_handle_t handle);
const char* google_tts_get_credentials_file(google_tts_handle_t handle);
const char* google_tts_get_model_name(google_tts_handle_t handle);
const char* google_tts_get_prompt(google_tts_handle_t handle);
const char* google_tts_get_speaking_rate(google_tts_handle_t handle);
const char* google_tts_get_pitch(google_tts_handle_t handle);
const char* google_tts_get_volume_gain_db(google_tts_handle_t handle);
void google_tts_set_session_id(google_tts_handle_t handle, const char* val);
void google_tts_set_voice_name(google_tts_handle_t handle, const char* val);
void google_tts_set_language_code(google_tts_handle_t handle, const char* val);
void google_tts_set_gender(google_tts_handle_t handle, const char* val);
void google_tts_set_credentials_file(google_tts_handle_t handle, const char* val);
void google_tts_set_model_name(google_tts_handle_t handle, const char* val);
void google_tts_set_prompt(google_tts_handle_t handle, const char* val);
void google_tts_set_speaking_rate(google_tts_handle_t handle, const char* val);
void google_tts_set_pitch(google_tts_handle_t handle, const char* val);
void google_tts_set_volume_gain_db(google_tts_handle_t handle, const char* val);

// Result data
long google_tts_get_response_code(google_tts_handle_t handle);
const char* google_tts_get_error_message(google_tts_handle_t handle);
const char* google_tts_get_connect_time_ms(google_tts_handle_t handle);
const char* google_tts_get_first_byte_time_ms(google_tts_handle_t handle);
const char* google_tts_get_cache_filename(google_tts_handle_t handle);
void google_tts_set_response_code(google_tts_handle_t handle, long val);
void google_tts_set_error_message(google_tts_handle_t handle, const char* val);
void google_tts_set_connect_time_ms(google_tts_handle_t handle, const char* val);
void google_tts_set_first_byte_time_ms(google_tts_handle_t handle, const char* val);
void google_tts_set_cache_filename(google_tts_handle_t handle, const char* val);

// State
int google_tts_get_rate(google_tts_handle_t handle);
int google_tts_is_draining(google_tts_handle_t handle);
int google_tts_get_reads(google_tts_handle_t handle);
int google_tts_is_cache_audio(google_tts_handle_t handle);
int google_tts_is_playback_start_sent(google_tts_handle_t handle);
const char* google_tts_get_api_mode(google_tts_handle_t handle);
void google_tts_set_rate(google_tts_handle_t handle, int val);
void google_tts_set_draining(google_tts_handle_t handle, int val);
void google_tts_set_reads(google_tts_handle_t handle, int val);
void google_tts_set_cache_audio(google_tts_handle_t handle, int val);
void google_tts_set_playback_start_sent(google_tts_handle_t handle, int val);
void google_tts_set_api_mode(google_tts_handle_t handle, const char* val);

// Resources
void* google_tts_get_audio_player(google_tts_handle_t handle);
void* google_tts_get_playout_buffer(google_tts_handle_t handle);
void* google_tts_get_synthesis_context(google_tts_handle_t handle);
const char* google_tts_get_playback_id(google_tts_handle_t handle);
void google_tts_set_audio_player(google_tts_handle_t handle, void* val);
void google_tts_set_playout_buffer(google_tts_handle_t handle, void* val);
void google_tts_set_synthesis_context(google_tts_handle_t handle, void* val);
void google_tts_set_playback_id(google_tts_handle_t handle, const char* val);

#ifdef __cplusplus
}
#endif

#endif
