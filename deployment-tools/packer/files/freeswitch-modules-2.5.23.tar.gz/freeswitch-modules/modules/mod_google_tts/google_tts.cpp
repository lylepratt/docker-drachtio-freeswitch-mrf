#include "google_tts.hpp"

GoogleTTS::GoogleTTS()
    : api_mode_("tts")
    , response_code_(0)
    , rate_(8000)
    , draining_(false)
    , reads_(0)
    , cache_audio_(false)
    , playback_start_sent_(false)
    , audio_player_(nullptr)
    , playout_buffer_(nullptr)
    , synthesis_context_(nullptr)
{
}

GoogleTTS::~GoogleTTS() {
}

std::shared_ptr<GoogleTTS> GoogleTTS::create() {
    return std::shared_ptr<GoogleTTS>(new GoogleTTS());
}
