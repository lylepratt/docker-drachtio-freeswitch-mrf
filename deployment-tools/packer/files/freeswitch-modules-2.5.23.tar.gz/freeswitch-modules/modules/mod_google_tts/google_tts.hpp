#ifndef __GOOGLE_TTS_HPP__
#define __GOOGLE_TTS_HPP__

#include <switch.h>
#include <memory>
#include <string>
#include <mutex>

class GoogleTTS {
public:
    ~GoogleTTS();
    static std::shared_ptr<GoogleTTS> create();

    // Configuration
    const std::string& getSessionId() const { return session_id_; }
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getLanguageCode() const { return language_code_; }
    const std::string& getGender() const { return gender_; }
    const std::string& getCredentialsFile() const { return credentials_file_; }
    const std::string& getModelName() const { return model_name_; }
    const std::string& getPrompt() const { return prompt_; }
    const std::string& getSpeakingRate() const { return speaking_rate_; }
    const std::string& getPitch() const { return pitch_; }
    const std::string& getVolumeGainDb() const { return volume_gain_db_; }
    const std::string& getApiMode() const { return api_mode_; }

    void setSessionId(const std::string& v) { session_id_ = v; }
    void setVoiceName(const std::string& v) { voice_name_ = v; }
    void setLanguageCode(const std::string& v) { language_code_ = v; }
    void setGender(const std::string& v) { gender_ = v; }
    void setCredentialsFile(const std::string& v) { credentials_file_ = v; }
    void setModelName(const std::string& v) { model_name_ = v; }
    void setPrompt(const std::string& v) { prompt_ = v; }
    void setSpeakingRate(const std::string& v) { speaking_rate_ = v; }
    void setPitch(const std::string& v) { pitch_ = v; }
    void setVolumeGainDb(const std::string& v) { volume_gain_db_ = v; }
    void setApiMode(const std::string& v) { api_mode_ = v; }

    // Result data
    long getResponseCode() const { return response_code_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFirstByteTimeMs() const { return first_byte_time_ms_; }
    const std::string& getCacheFilename() const { return cache_filename_; }

    void setResponseCode(long v) { response_code_ = v; }
    void setErrorMessage(const std::string& v) { error_message_ = v; }
    void setConnectTimeMs(const std::string& v) { connect_time_ms_ = v; }
    void setFirstByteTimeMs(const std::string& v) { first_byte_time_ms_ = v; }
    void setCacheFilename(const std::string& v) { cache_filename_ = v; }

    // State
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }

    void setRate(int v) { rate_ = v; }
    void setDraining(bool v) { draining_ = v; }
    void setReads(int v) { reads_ = v; }
    void setCacheAudio(bool v) { cache_audio_ = v; }
    void setPlaybackStartSent(bool v) { playback_start_sent_ = v; }

    // Resources
    void* getAudioPlayer() const { return audio_player_; }
    void* getPlayoutBuffer() const { return playout_buffer_; }
    void* getSynthesisContext() const { return synthesis_context_; }
    std::mutex& getMutex() const { return mutex_; }
    const std::string& getPlaybackId() const { return playback_id_; }

    void setAudioPlayer(void* v) { audio_player_ = v; }
    void setPlayoutBuffer(void* v) { playout_buffer_ = v; }
    void setSynthesisContext(void* v) { synthesis_context_ = v; }
    void setPlaybackId(const std::string& v) { playback_id_ = v; }

private:
    GoogleTTS();

    std::string session_id_;
    std::string voice_name_;
    std::string language_code_;
    std::string gender_;
    std::string credentials_file_;
    std::string model_name_;
    std::string prompt_;
    std::string speaking_rate_;
    std::string pitch_;
    std::string volume_gain_db_;
    std::string api_mode_;

    long response_code_;
    std::string error_message_;
    std::string connect_time_ms_;
    std::string first_byte_time_ms_;
    std::string cache_filename_;

    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;

    void* audio_player_;
    void* playout_buffer_;
    void* synthesis_context_;
    mutable std::mutex mutex_;
    std::string playback_id_;
};

#endif
