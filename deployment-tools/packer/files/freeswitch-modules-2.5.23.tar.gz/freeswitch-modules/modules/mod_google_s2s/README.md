# mod_google_s2s

A Freeswitch module that integrates with Google Gemini speech-to-speech api

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_google_s2s <uuid> session.create apiKey
```
where:
- apiKey: Google Gemini api key

This api call establishes a websocket connection to the Google Gemini endpoint (generativelanguage.googleapis.com).  If the connection is successfully established, which the caller will know through the 'google_s2s::connect' event, then the caller must next send a `client.event` client event with the [BidiGenerateContentSetup](https://ai.google.dev/api/live#bidigeneratecontentsetup) json payload

```
uuid_google_s2s <uuid> client.event client-event-json
```
where
- client-event-json: a json string conforming to the [syntax described here](https://ai.google.dev/api/live).

```
uuid_google_s2s <uuid> session.delete
```
Ends the session.

### Events
This module fires the following events:
- google_s2s::connect - fired when the websocket connection is established
- google_s2s::connect_failed - fired if the websocket connection fails
- google_s2s::disconnect - fired when when the connection is dropped from far end (includes `close_code` and `close_reason` in JSON body)
- google_s2s::server_event - fired when a message is received from the server

### Assistant Speaking Events
The module emits synthetic events for assistant audio playback status via `google_s2s::server_event`:
- `{"type": "output_audio.playback_started"}` - fired when the assistant starts speaking (first audio frame)
- `{"type": "output_audio.playback_stopped", "completion_reason": "completed"}` - fired when the assistant finishes speaking normally
- `{"type": "output_audio.playback_stopped", "completion_reason": "interrupted"}` - fired when the user interrupts the assistant

### Session Resumption
The Gemini Live API supports session resumption. To enable it, include `sessionResumption` in your BidiGenerateContentSetup:

```json
{
  "setup": {
    "model": "models/gemini-2.0-flash-exp",
    "sessionResumption": {}
  }
}
```

The server will send `sessionResumptionUpdate` events via `google_s2s::server_event`:

```json
{
  "sessionResumptionUpdate": {
    "newHandle": "abc123...",
    "resumable": true
  }
}
```

To resume a previous session, include the stored handle in a new connection:

```json
{
  "setup": {
    "model": "models/gemini-2.0-flash-exp",
    "sessionResumption": {
      "handle": "abc123..."
    }
  }
}
```

**Important constraints:**
- Session resumption is not possible during model generation or function execution (`resumable` will be `false`)
- The model cannot be changed when resuming a session
- Always store the latest `newHandle` from `sessionResumptionUpdate` events
- Data loss may occur if resuming during active operations

