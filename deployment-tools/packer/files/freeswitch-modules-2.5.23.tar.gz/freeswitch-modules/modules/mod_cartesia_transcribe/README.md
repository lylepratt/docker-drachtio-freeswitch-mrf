# mod_cartesia_transcribe

A Freeswitch module that generates real-time transcriptions on a Freeswitch channel by using Cartesia's streaming transcription API

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_cartesia_transcribe <uuid> start <lang-code> [interim]
```
Attaches media bug to channel and performs streaming recognize request.
- `uuid` - unique identifier of Freeswitch channel
- `lang-code` - a valid AWS [language code](https://docs.cartesia.amazon.com/transcribe/latest/dg/what-is-transcribe.html) that is supported for streaming transcription
- `interim` - If the 'interim' keyword is present then both interim and final transcription results will be returned; otherwise only final transcriptions will be returned

```
uuid_cartesia_transcribe <uuid> stop
```
Stop transcription on the channel.

### Channel Variables

| variable | Description |
| --- | ----------- |
| CARTESIA_API_KEY | Cartesia API key used to authenticate |


## Usage
When using [drachtio-fsrmf](https://www.npmjs.com/package/drachtio-fsmrf), you can access this API command via the api method on the 'endpoint' object.
```js
ep.api('uuid_cartesia_transcribe', `${ep.uuid} start en-US interim`);  
```

