#include "elevenlabs_wrapper.h"
#include "elevenlabs.hpp"
#include <memory>
#include <mutex>
#include <unordered_map>

// Internal handle structure
struct elevenlabs_handle {
    std::shared_ptr<ElevenLabs> instance;
    int ref_count;
    std::mutex ref_mutex;
    
    elevenlabs_handle(std::shared_ptr<ElevenLabs> inst) 
        : instance(std::move(inst)), ref_count(1) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "elevenlabs_handle initialized with ref_count %d\n", ref_count);
        }
};

// Thread-safe handle management
static std::mutex g_handle_mutex;
static std::unordered_map<elevenlabs_handle_t, std::unique_ptr<elevenlabs_handle>> g_handles;

// Helper function to validate handle
static elevenlabs_handle* get_handle(elevenlabs_handle_t handle) {
    if (!handle) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second.get() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
std::shared_ptr<ElevenLabs> elevenlabs_get_shared_ptr(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance : nullptr;
}

// Private internal function to get handle from shared_ptr
elevenlabs_handle_t elevenlabs_get_handle_from_shared_ptr(const std::shared_ptr<ElevenLabs>& ptr) {
    if (!ptr) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->instance == ptr) {
            return pair.first;
        }
    }
    return nullptr;
}

// C API Implementation
extern "C" {

elevenlabs_handle_t elevenlabs_create(void) {
    try {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "elevenlabs_create\n");

        auto instance = ElevenLabs::create();
        auto handle = std::make_unique<elevenlabs_handle>(instance);
        elevenlabs_handle_t handle_ptr = handle.get();
        
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles[handle_ptr] = std::move(handle);
        
        return handle_ptr;
    } catch (...) {
        return nullptr;
    }
}

void elevenlabs_retain(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    if (h) {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "elevenlabs_retain, ref count %d\n", h->ref_count);
    }
}

void elevenlabs_release(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    if (!h) return;
    
    bool should_delete = false;
    {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count--;
        should_delete = (h->ref_count <= 0);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "elevenlabs_release, ref count %d\n", h->ref_count);
    }
    
    if (should_delete) {
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles.erase(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "elevenlabs_release, handle erased\n");
    }
}

// Getters
const char* elevenlabs_get_session_id(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSessionId().c_str() : nullptr;
}

const char* elevenlabs_get_voice_name(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceName().c_str() : nullptr;
}

const char* elevenlabs_get_api_key(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getApiKey().c_str() : nullptr;
}

const char* elevenlabs_get_api_uri(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getApiUri().c_str() : nullptr;
}

const char* elevenlabs_get_model_id(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getModelId().c_str() : nullptr;
}

const char* elevenlabs_get_similarity_boost(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSimilarityBoost().c_str() : nullptr;
}

const char* elevenlabs_get_stability(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getStability().c_str() : nullptr;
}

const char* elevenlabs_get_style(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getStyle().c_str() : nullptr;
}

const char* elevenlabs_get_use_speaker_boost(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getUseSpeakerBoost().c_str() : nullptr;
}

const char* elevenlabs_get_optimize_streaming_latency(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getOptimizeStreamingLatency().c_str() : nullptr;
}

const char* elevenlabs_get_speed(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSpeed().c_str() : nullptr;
}

const char* elevenlabs_get_pronunciation_dictionary_locators(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPronunciationDictionaryLocators().c_str() : nullptr;
}

const char* elevenlabs_get_previous_text(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPreviousText().c_str() : nullptr;
}

const char* elevenlabs_get_next_text(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getNextText().c_str() : nullptr;
}

// Result data getters
long elevenlabs_get_response_code(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getResponseCode() : 0;
}

const char* elevenlabs_get_content_type(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getContentType().c_str() : nullptr;
}

const char* elevenlabs_get_reported_latency(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReportedLatency().c_str() : nullptr;
}

const char* elevenlabs_get_request_id(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRequestId().c_str() : nullptr;
}

const char* elevenlabs_get_history_item_id(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getHistoryItemId().c_str() : nullptr;
}

const char* elevenlabs_get_name_lookup_time_ms(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getNameLookupTimeMs().c_str() : nullptr;
}

const char* elevenlabs_get_connect_time_ms(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnectTimeMs().c_str() : nullptr;
}

const char* elevenlabs_get_final_response_time_ms(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFinalResponseTimeMs().c_str() : nullptr;
}

const char* elevenlabs_get_error_message(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getErrorMessage().c_str() : nullptr;
}

const char* elevenlabs_get_cache_filename(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCacheFilename().c_str() : nullptr;
}

// State getters
int elevenlabs_get_rate(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRate() : 0;
}

int elevenlabs_is_draining(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isDraining() ? 1 : 0) : 0;
}

int elevenlabs_get_reads(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReads() : 0;
}

int elevenlabs_is_cache_audio(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isCacheAudio() ? 1 : 0) : 0;
}

int elevenlabs_is_playback_start_sent(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isPlaybackStartSent() ? 1 : 0) : 0;
}

// Resource getters
void* elevenlabs_get_connection(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnection() : nullptr;
}

FILE* elevenlabs_get_file(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFile() : nullptr;
}

const char* elevenlabs_get_playback_id(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlaybackId().c_str() : nullptr;
}

// elevenlabs_get_mutex removed - use shared_ptr->getMutex() directly

void* elevenlabs_get_audio_player(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getAudioPlayer() : nullptr;
}

void* elevenlabs_get_playout_buffer(elevenlabs_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlayoutBuffer() : nullptr;
}

// Setters
void elevenlabs_set_session_id(elevenlabs_handle_t handle, const char* session_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setSessionId(session_id ? session_id : "");
    }
}

void elevenlabs_set_voice_name(elevenlabs_handle_t handle, const char* voice_name) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setVoiceName(voice_name ? voice_name : "");
    }
}

void elevenlabs_set_api_key(elevenlabs_handle_t handle, const char* api_key) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setApiKey(api_key ? api_key : "");
    }
}

void elevenlabs_set_api_uri(elevenlabs_handle_t handle, const char* api_uri) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setApiUri(api_uri ? api_uri : "");
    }
}

void elevenlabs_set_model_id(elevenlabs_handle_t handle, const char* model_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setModelId(model_id ? model_id : "");
    }
}

void elevenlabs_set_similarity_boost(elevenlabs_handle_t handle, const char* similarity_boost) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setSimilarityBoost(similarity_boost ? similarity_boost : "");
    }
}

void elevenlabs_set_stability(elevenlabs_handle_t handle, const char* stability) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setStability(stability ? stability : "");
    }
}

void elevenlabs_set_style(elevenlabs_handle_t handle, const char* style) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setStyle(style ? style : "");
    }
}

void elevenlabs_set_use_speaker_boost(elevenlabs_handle_t handle, const char* use_speaker_boost) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setUseSpeakerBoost(use_speaker_boost ? use_speaker_boost : "");
    }
}

void elevenlabs_set_optimize_streaming_latency(elevenlabs_handle_t handle, const char* optimize_streaming_latency) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setOptimizeStreamingLatency(optimize_streaming_latency ? optimize_streaming_latency : "");
    }
}

void elevenlabs_set_speed(elevenlabs_handle_t handle, const char* speed) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setSpeed(speed ? speed : "");
    }
}

void elevenlabs_set_pronunciation_dictionary_locators(elevenlabs_handle_t handle, const char* pronunciation_dictionary_locators) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPronunciationDictionaryLocators(pronunciation_dictionary_locators ? pronunciation_dictionary_locators : "");
    }
}

void elevenlabs_set_previous_text(elevenlabs_handle_t handle, const char* previous_text) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPreviousText(previous_text ? previous_text : "");
    }
}

void elevenlabs_set_next_text(elevenlabs_handle_t handle, const char* next_text) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setNextText(next_text ? next_text : "");
    }
}

// Result data setters
void elevenlabs_set_response_code(elevenlabs_handle_t handle, long response_code) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setResponseCode(response_code);
    }
}

void elevenlabs_set_content_type(elevenlabs_handle_t handle, const char* content_type) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setContentType(content_type ? content_type : "");
    }
}

void elevenlabs_set_reported_latency(elevenlabs_handle_t handle, const char* reported_latency) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReportedLatency(reported_latency ? reported_latency : "");
    }
}

void elevenlabs_set_request_id(elevenlabs_handle_t handle, const char* request_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setRequestId(request_id ? request_id : "");
    }
}

void elevenlabs_set_history_item_id(elevenlabs_handle_t handle, const char* history_item_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setHistoryItemId(history_item_id ? history_item_id : "");
    }
}

void elevenlabs_set_name_lookup_time_ms(elevenlabs_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setNameLookupTimeMs(time_ms ? time_ms : "");
    }
}

void elevenlabs_set_connect_time_ms(elevenlabs_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setConnectTimeMs(time_ms ? time_ms : "");
    }
}

void elevenlabs_set_final_response_time_ms(elevenlabs_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setFinalResponseTimeMs(time_ms ? time_ms : "");
    }
}

void elevenlabs_set_error_message(elevenlabs_handle_t handle, const char* error_msg) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setErrorMessage(error_msg ? error_msg : "");
    }
}

void elevenlabs_set_cache_filename(elevenlabs_handle_t handle, const char* cache_filename) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCacheFilename(cache_filename ? cache_filename : "");
    }
}

// State setters
void elevenlabs_set_rate(elevenlabs_handle_t handle, int rate) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setRate(rate);
    }
}

void elevenlabs_set_draining(elevenlabs_handle_t handle, int draining) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setDraining(draining != 0);
    }
}

void elevenlabs_set_reads(elevenlabs_handle_t handle, int reads) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReads(reads);
    }
}

void elevenlabs_set_cache_audio(elevenlabs_handle_t handle, int cache_audio) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCacheAudio(cache_audio != 0);
    }
}

void elevenlabs_set_playback_start_sent(elevenlabs_handle_t handle, int playback_start_sent) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackStartSent(playback_start_sent != 0);
    }
}

// Resource setters
void elevenlabs_set_connection(elevenlabs_handle_t handle, void* conn) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setConnection(conn);
    }
}

void elevenlabs_set_file(elevenlabs_handle_t handle, FILE* file) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setFile(file);
    }
}

void elevenlabs_set_playback_id(elevenlabs_handle_t handle, const char* playback_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackId(playback_id ? playback_id : "");
    }
}

void elevenlabs_set_audio_player(elevenlabs_handle_t handle, void* audio_player) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setAudioPlayer(audio_player);
    }
}

void elevenlabs_set_playout_buffer(elevenlabs_handle_t handle, void* playout_buffer) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlayoutBuffer(playout_buffer);
    }
}

// Mutex initialization
// elevenlabs_init_mutex removed - std::mutex is automatically initialized

} // extern "C"