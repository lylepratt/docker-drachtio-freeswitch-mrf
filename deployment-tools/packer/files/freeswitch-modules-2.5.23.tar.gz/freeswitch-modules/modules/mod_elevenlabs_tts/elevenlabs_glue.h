#ifndef __ELEVENLABS_GLUE_H__
#define __ELEVENLABS_GLUE_H__

#include "elevenlabs_wrapper.h"

#ifdef __cplusplus
extern "C" {
#endif

switch_status_t elevenlabs_speech_load();
switch_status_t elevenlabs_speech_open(elevenlabs_handle_t handle);
switch_status_t elevenlabs_speech_feed_tts(elevenlabs_handle_t handle, char* text, switch_speech_flag_t *flags);
switch_status_t elevenlabs_speech_read_tts(elevenlabs_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t elevenlabs_speech_flush_tts(elevenlabs_handle_t handle);
switch_status_t elevenlabs_speech_close(elevenlabs_handle_t handle);
switch_status_t elevenlabs_speech_unload();

#ifdef __cplusplus
}
#endif

#endif