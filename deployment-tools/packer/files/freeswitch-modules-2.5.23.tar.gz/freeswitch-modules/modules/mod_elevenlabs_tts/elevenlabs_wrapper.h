// elevenlabs_wrapper.h - C-compatible header
#ifndef __ELEVENLABS_WRAPPER_H__
#define __ELEVENLABS_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct elevenlabs_handle* elevenlabs_handle_t;

#ifdef __cplusplus
#include <memory>

// Forward declaration
class ElevenLabs;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<ElevenLabs> elevenlabs_get_shared_ptr(elevenlabs_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
elevenlabs_handle_t elevenlabs_get_handle_from_shared_ptr(const std::shared_ptr<ElevenLabs>& ptr);

extern "C" {
#endif

// C API functions
elevenlabs_handle_t elevenlabs_create(void);
void elevenlabs_retain(elevenlabs_handle_t handle);
void elevenlabs_release(elevenlabs_handle_t handle);

// Getters - C-style interface
const char* elevenlabs_get_session_id(elevenlabs_handle_t handle);
const char* elevenlabs_get_voice_name(elevenlabs_handle_t handle);
const char* elevenlabs_get_api_key(elevenlabs_handle_t handle);
const char* elevenlabs_get_api_uri(elevenlabs_handle_t handle);
const char* elevenlabs_get_model_id(elevenlabs_handle_t handle);
const char* elevenlabs_get_similarity_boost(elevenlabs_handle_t handle);
const char* elevenlabs_get_stability(elevenlabs_handle_t handle);
const char* elevenlabs_get_style(elevenlabs_handle_t handle);
const char* elevenlabs_get_use_speaker_boost(elevenlabs_handle_t handle);
const char* elevenlabs_get_optimize_streaming_latency(elevenlabs_handle_t handle);
const char* elevenlabs_get_speed(elevenlabs_handle_t handle);
const char* elevenlabs_get_pronunciation_dictionary_locators(elevenlabs_handle_t handle);
const char* elevenlabs_get_previous_text(elevenlabs_handle_t handle);
const char* elevenlabs_get_next_text(elevenlabs_handle_t handle);

// Result data getters
long elevenlabs_get_response_code(elevenlabs_handle_t handle);
const char* elevenlabs_get_content_type(elevenlabs_handle_t handle);
const char* elevenlabs_get_reported_latency(elevenlabs_handle_t handle);
const char* elevenlabs_get_request_id(elevenlabs_handle_t handle);
const char* elevenlabs_get_history_item_id(elevenlabs_handle_t handle);
const char* elevenlabs_get_name_lookup_time_ms(elevenlabs_handle_t handle);
const char* elevenlabs_get_connect_time_ms(elevenlabs_handle_t handle);
const char* elevenlabs_get_final_response_time_ms(elevenlabs_handle_t handle);
const char* elevenlabs_get_error_message(elevenlabs_handle_t handle);
const char* elevenlabs_get_cache_filename(elevenlabs_handle_t handle);

// State getters
int elevenlabs_get_rate(elevenlabs_handle_t handle);
int elevenlabs_is_draining(elevenlabs_handle_t handle);
int elevenlabs_get_reads(elevenlabs_handle_t handle);
int elevenlabs_is_cache_audio(elevenlabs_handle_t handle);
int elevenlabs_is_playback_start_sent(elevenlabs_handle_t handle);

// Resource getters
void* elevenlabs_get_connection(elevenlabs_handle_t handle);
FILE* elevenlabs_get_file(elevenlabs_handle_t handle);
const char* elevenlabs_get_playback_id(elevenlabs_handle_t handle);
// elevenlabs_get_mutex removed - use shared_ptr->getMutex() directly
void* elevenlabs_get_audio_player(elevenlabs_handle_t handle);
void* elevenlabs_get_playout_buffer(elevenlabs_handle_t handle);

// Setters
void elevenlabs_set_session_id(elevenlabs_handle_t handle, const char* session_id);
void elevenlabs_set_voice_name(elevenlabs_handle_t handle, const char* voice_name);
void elevenlabs_set_api_key(elevenlabs_handle_t handle, const char* api_key);
void elevenlabs_set_api_uri(elevenlabs_handle_t handle, const char* api_uri);
void elevenlabs_set_model_id(elevenlabs_handle_t handle, const char* model_id);
void elevenlabs_set_similarity_boost(elevenlabs_handle_t handle, const char* similarity_boost);
void elevenlabs_set_stability(elevenlabs_handle_t handle, const char* stability);
void elevenlabs_set_style(elevenlabs_handle_t handle, const char* style);
void elevenlabs_set_use_speaker_boost(elevenlabs_handle_t handle, const char* use_speaker_boost);
void elevenlabs_set_optimize_streaming_latency(elevenlabs_handle_t handle, const char* optimize_streaming_latency);
void elevenlabs_set_speed(elevenlabs_handle_t handle, const char* speed);
void elevenlabs_set_pronunciation_dictionary_locators(elevenlabs_handle_t handle, const char* pronunciation_dictionary_locators);
void elevenlabs_set_previous_text(elevenlabs_handle_t handle, const char* previous_text);
void elevenlabs_set_next_text(elevenlabs_handle_t handle, const char* next_text);

// Result data setters
void elevenlabs_set_response_code(elevenlabs_handle_t handle, long response_code);
void elevenlabs_set_content_type(elevenlabs_handle_t handle, const char* content_type);
void elevenlabs_set_reported_latency(elevenlabs_handle_t handle, const char* reported_latency);
void elevenlabs_set_request_id(elevenlabs_handle_t handle, const char* request_id);
void elevenlabs_set_history_item_id(elevenlabs_handle_t handle, const char* history_item_id);
void elevenlabs_set_name_lookup_time_ms(elevenlabs_handle_t handle, const char* time_ms);
void elevenlabs_set_connect_time_ms(elevenlabs_handle_t handle, const char* time_ms);
void elevenlabs_set_final_response_time_ms(elevenlabs_handle_t handle, const char* time_ms);
void elevenlabs_set_error_message(elevenlabs_handle_t handle, const char* error_msg);
void elevenlabs_set_cache_filename(elevenlabs_handle_t handle, const char* cache_filename);

// State setters
void elevenlabs_set_rate(elevenlabs_handle_t handle, int rate);
void elevenlabs_set_draining(elevenlabs_handle_t handle, int draining);
void elevenlabs_set_reads(elevenlabs_handle_t handle, int reads);
void elevenlabs_set_cache_audio(elevenlabs_handle_t handle, int cache_audio);
void elevenlabs_set_playback_start_sent(elevenlabs_handle_t handle, int playback_start_sent);

// Resource setters
void elevenlabs_set_connection(elevenlabs_handle_t handle, void* conn);
void elevenlabs_set_file(elevenlabs_handle_t handle, FILE* file);
void elevenlabs_set_playback_id(elevenlabs_handle_t handle, const char* playback_id);
void elevenlabs_set_audio_player(elevenlabs_handle_t handle, void* audio_player);
void elevenlabs_set_playout_buffer(elevenlabs_handle_t handle, void* playout_buffer);

// Mutex initialization
// elevenlabs_init_mutex removed - std::mutex is automatically initialized

#ifdef __cplusplus
}
#endif

#endif