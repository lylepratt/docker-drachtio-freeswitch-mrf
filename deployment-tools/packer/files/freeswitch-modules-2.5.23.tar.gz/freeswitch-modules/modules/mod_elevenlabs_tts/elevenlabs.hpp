#ifndef __ELEVENLABS_HPP__
#define __ELEVENLABS_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <memory>
#include <string>
#include <mutex>

class ElevenLabs {
private:
    std::string session_id_;
    std::string voice_name_;
    std::string api_key_;
    std::string api_uri_;
    std::string model_id_;
    std::string similarity_boost_;
    std::string stability_;
    std::string style_;
    std::string use_speaker_boost_;
    std::string optimize_streaming_latency_;
    std::string speed_;
    std::string pronunciation_dictionary_locators_;
    std::string previous_text_;
    std::string next_text_;

    // Result data
    long response_code_;
    std::string content_type_;
    std::string reported_latency_;
    std::string request_id_;
    std::string history_item_id_;
    std::string name_lookup_time_ms_;
    std::string connect_time_ms_;
    std::string final_response_time_ms_;
    std::string error_message_;
    std::string cache_filename_;

    // State
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;

    // Resources
    void* connection_;
    FILE* file_;
    std::string playback_id_;
    mutable std::mutex mutex_;
    void* audio_player_;
    void* playout_buffer_;

    // Private constructor to enforce shared_ptr usage
    ElevenLabs();

public:
    ~ElevenLabs();
    
    // Factory method
    static std::shared_ptr<ElevenLabs> create();
    
    // Getters
    const std::string& getSessionId() const { return session_id_; }
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getApiKey() const { return api_key_; }
    const std::string& getApiUri() const { return api_uri_; }
    const std::string& getModelId() const { return model_id_; }
    const std::string& getSimilarityBoost() const { return similarity_boost_; }
    const std::string& getStability() const { return stability_; }
    const std::string& getStyle() const { return style_; }
    const std::string& getUseSpeakerBoost() const { return use_speaker_boost_; }
    const std::string& getOptimizeStreamingLatency() const { return optimize_streaming_latency_; }
    const std::string& getSpeed() const { return speed_; }
    const std::string& getPronunciationDictionaryLocators() const { return pronunciation_dictionary_locators_; }
    const std::string& getPreviousText() const { return previous_text_; }
    const std::string& getNextText() const { return next_text_; }
    
    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getContentType() const { return content_type_; }
    const std::string& getReportedLatency() const { return reported_latency_; }
    const std::string& getRequestId() const { return request_id_; }
    const std::string& getHistoryItemId() const { return history_item_id_; }
    const std::string& getNameLookupTimeMs() const { return name_lookup_time_ms_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFinalResponseTimeMs() const { return final_response_time_ms_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    
    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }
    
    // Resource getters
    void* getConnection() const { return connection_; }
    FILE* getFile() const { return file_; }
    const std::string& getPlaybackId() const { return playback_id_; }
    std::mutex& getMutex() const { return mutex_; }
    void* getAudioPlayer() const { return audio_player_; }
    void* getPlayoutBuffer() const { return playout_buffer_; }
    
    // Setters
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setApiKey(const std::string& api_key) { api_key_ = api_key; }
    void setApiUri(const std::string& api_uri) { api_uri_ = api_uri; }
    void setModelId(const std::string& model_id) { model_id_ = model_id; }
    void setSimilarityBoost(const std::string& similarity_boost) { similarity_boost_ = similarity_boost; }
    void setStability(const std::string& stability) { stability_ = stability; }
    void setStyle(const std::string& style) { style_ = style; }
    void setUseSpeakerBoost(const std::string& use_speaker_boost) { use_speaker_boost_ = use_speaker_boost; }
    void setOptimizeStreamingLatency(const std::string& optimize_streaming_latency) { optimize_streaming_latency_ = optimize_streaming_latency; }
    void setSpeed(const std::string& speed) { speed_ = speed; }
    void setPronunciationDictionaryLocators(const std::string& pronunciation_dictionary_locators) { pronunciation_dictionary_locators_ = pronunciation_dictionary_locators; }
    void setPreviousText(const std::string& previous_text) { previous_text_ = previous_text; }
    void setNextText(const std::string& next_text) { next_text_ = next_text; }
    
    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setContentType(const std::string& content_type) { content_type_ = content_type; }
    void setReportedLatency(const std::string& reported_latency) { reported_latency_ = reported_latency; }
    void setRequestId(const std::string& request_id) { request_id_ = request_id; }
    void setHistoryItemId(const std::string& history_item_id) { history_item_id_ = history_item_id; }
    void setNameLookupTimeMs(const std::string& time_ms) { name_lookup_time_ms_ = time_ms; }
    void setConnectTimeMs(const std::string& time_ms) { connect_time_ms_ = time_ms; }
    void setFinalResponseTimeMs(const std::string& time_ms) { final_response_time_ms_ = time_ms; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    
    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setPlaybackStartSent(bool playback_start_sent) { playback_start_sent_ = playback_start_sent; }
    
    // Resource setters
    void setConnection(void* conn) { connection_ = conn; }
    void setFile(FILE* file) { file_ = file; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }
    void setAudioPlayer(void* audio_player) { audio_player_ = audio_player; }
    void setPlayoutBuffer(void* playout_buffer) { playout_buffer_ = playout_buffer; }

    // std::mutex is automatically initialized
};

#endif