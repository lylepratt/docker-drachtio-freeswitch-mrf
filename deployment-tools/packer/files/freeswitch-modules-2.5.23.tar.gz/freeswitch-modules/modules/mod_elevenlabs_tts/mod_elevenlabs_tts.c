/* 
 *
 * mod_elevenlabs_tts.c -- Google GRPC-based text to speech
 *
 */
#include "mod_elevenlabs_tts.h"
#include "elevenlabs_glue.h"
#include "elevenlabs_wrapper.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_elevenlabs_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_elevenlabs_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_elevenlabs_tts, mod_elevenlabs_tts_load, mod_elevenlabs_tts_shutdown, NULL);


static void clearElevenlabs(elevenlabs_handle_t handle, int freeAll) {
  const char *session_id = elevenlabs_get_session_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s clearElevenlabs\n", session_id ? session_id : "");
  
  elevenlabs_set_api_key(handle, "");
  elevenlabs_set_api_uri(handle, "");
  elevenlabs_set_model_id(handle, "");
  elevenlabs_set_similarity_boost(handle, "");
  elevenlabs_set_stability(handle, "");
  elevenlabs_set_style(handle, "");
  elevenlabs_set_use_speaker_boost(handle, "");
  elevenlabs_set_optimize_streaming_latency(handle, "");
  elevenlabs_set_previous_text(handle, "");
  elevenlabs_set_next_text(handle, "");
  elevenlabs_set_content_type(handle, "");
  elevenlabs_set_reported_latency(handle, "");
  elevenlabs_set_request_id(handle, "");
  elevenlabs_set_history_item_id(handle, "");
  elevenlabs_set_error_message(handle, "");
  elevenlabs_set_name_lookup_time_ms(handle, "");
  elevenlabs_set_connect_time_ms(handle, "");
  elevenlabs_set_final_response_time_ms(handle, "");
  elevenlabs_set_cache_filename(handle, "");
  elevenlabs_set_speed(handle, "");
  elevenlabs_set_pronunciation_dictionary_locators(handle, "");

  elevenlabs_set_playback_id(handle, "");
  elevenlabs_set_file(handle, NULL);

  if (freeAll) {
    elevenlabs_set_voice_name(handle, "");
    elevenlabs_set_session_id(handle, "");
  }
}
static elevenlabs_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  elevenlabs_handle_t handle = (elevenlabs_handle_t) sh->private_info;
  const char *session_id = NULL;
  if (!handle) {
    handle = elevenlabs_create();
  	sh->private_info = handle;
    // std::mutex is automatically initialized
    session_id = elevenlabs_get_session_id(handle);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s allocated elevenlabs handle\n", session_id ? session_id : "");
  }
  return handle;
}

/**
 * this is called when FreeSWITCH loads the module
 * if the module is retrieved from cache this will not be called
 * therefore, probably best not to connect to elevenlabs yet
 * Note: if cached, the voice will be provide as a param
 */
static switch_status_t ell_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  elevenlabs_handle_t handle = createOrRetrievePrivateData(sh);
  const char *session_id = elevenlabs_get_session_id(handle);
  elevenlabs_set_voice_name(handle, voice_name);
  elevenlabs_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s ell_speech_open voice: %s, rate %d, channels %d\n", session_id ? session_id : "", voice_name, rate, channels);
	return elevenlabs_speech_open(handle);
}

static switch_status_t ell_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
	elevenlabs_handle_t handle = (elevenlabs_handle_t) sh->private_info;
  const char *session_id = handle ? elevenlabs_get_session_id(handle) : NULL;
  assert(handle != NULL);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s ell_speech_close\n", session_id ? session_id : "");

  /* mutex allocated from session pool - automatically cleaned up */

	rc = elevenlabs_speech_close(handle);
  clearElevenlabs(handle, 1);
  elevenlabs_release(handle);
  return rc;  
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t ell_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  elevenlabs_handle_t handle = createOrRetrievePrivateData(sh);
  const char *session_id = elevenlabs_get_session_id(handle);
  elevenlabs_set_draining(handle, 0);
  elevenlabs_set_reads(handle, 0);
  elevenlabs_set_response_code(handle, 0);
  elevenlabs_set_error_message(handle, "");
  elevenlabs_set_playback_start_sent(handle, 0);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s ell_speech_feed_tts\n", session_id ? session_id : "");
  
	return elevenlabs_speech_feed_tts(handle, text, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void ell_speech_flush_tts(switch_speech_handle_t *sh)
{
	elevenlabs_handle_t handle = (elevenlabs_handle_t) sh->private_info;
  const char *session_id = handle ? elevenlabs_get_session_id(handle) : NULL;
	//assert(handle != NULL);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s ell_speech_flush_tts\n", session_id ? session_id : "");
  elevenlabs_speech_flush_tts(handle);

  clearElevenlabs(handle, 0);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t ell_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
	elevenlabs_handle_t handle = (elevenlabs_handle_t) sh->private_info;
  return elevenlabs_speech_read_tts(handle, data, datalen, flags);
}

static void ell_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  elevenlabs_handle_t handle = createOrRetrievePrivateData(sh);
  const char *session_id = elevenlabs_get_session_id(handle);
  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s el_text_param_tts: %s=XXXXX\n", session_id ? session_id : "", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s el_text_param_tts: %s=%s\n", session_id ? session_id : "", param, val);
  }
  if (0 == strcmp(param, "voice")) {
    elevenlabs_set_voice_name(handle, val);
  }
  else if (0 == strcmp(param, "api_key")) {
    elevenlabs_set_api_key(handle, val);
  }
  else if (0 == strcmp(param, "api_uri")) {
    elevenlabs_set_api_uri(handle, val);
  }
  else if (0 == strcmp(param, "model_id")) {
    elevenlabs_set_model_id(handle, val);
  }
  else if (0 == strcmp(param, "similarity_boost")) {
    elevenlabs_set_similarity_boost(handle, val);
  }
  else if (0 == strcmp(param, "stability")) {
    elevenlabs_set_stability(handle, val);
  }
  else if (0 == strcmp(param, "style")) {
    elevenlabs_set_style(handle, val);
  }
  else if (0 == strcmp(param, "use_speaker_boost")) {
    elevenlabs_set_use_speaker_boost(handle, val);
  }
  else if (0 == strcmp(param, "optimize_streaming_latency")) {
    elevenlabs_set_optimize_streaming_latency(handle, val);
  }
  else if (0 == strcmp(param, "speed")) {
    elevenlabs_set_speed(handle, val);
  }
  else if (0 == strcmp(param, "pronunciation_dictionary_locators")) {
    elevenlabs_set_pronunciation_dictionary_locators(handle, val);
  }
  else if (0 == strcmp(param, "next_text")) {
    elevenlabs_set_next_text(handle, val);
  }
  else if (0 == strcmp(param, "previous_text")) {
    elevenlabs_set_previous_text(handle, val);
  }
  else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    elevenlabs_set_cache_audio(handle, 1);
  }
  else if (0 == strcmp(param, "playback_id")) {
    elevenlabs_set_playback_id(handle, val);
  }
  else if (0 == strcmp(param, "session-uuid")) {
    elevenlabs_set_session_id(handle, val);
  }
}

static void ell_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}

static void ell_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_elevenlabs_tts_load)
{
	switch_speech_interface_t *speech_interface;

	/* connect my internal structure to the blank pointer passed to me */
	*module_interface = switch_loadable_module_create_module_interface(pool, modname);
	speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
	speech_interface->interface_name = "elevenlabs";
	speech_interface->speech_open = ell_speech_open;
	speech_interface->speech_close = ell_speech_close;
	speech_interface->speech_feed_tts = ell_speech_feed_tts;
	speech_interface->speech_read_tts = ell_speech_read_tts;
	speech_interface->speech_flush_tts = ell_speech_flush_tts;
	speech_interface->speech_text_param_tts = ell_text_param_tts;
	speech_interface->speech_numeric_param_tts = ell_numeric_param_tts;
	speech_interface->speech_float_param_tts = ell_float_param_tts;

	return elevenlabs_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_elevenlabs_tts_shutdown)
{
  return elevenlabs_speech_unload();
}
