#include "elevenlabs.hpp"

ElevenLabs::ElevenLabs() : 
    response_code_(0),
    rate_(0),
    draining_(false),
    reads_(0),
    cache_audio_(false),
    playback_start_sent_(false),
    connection_(nullptr),
    file_(nullptr),
    audio_player_(nullptr),
    playout_buffer_(nullptr) {
}

ElevenLabs::~ElevenLabs() {
    if (file_) {
        fclose(file_);
        file_ = nullptr;
    }
    if (connection_) {
        connection_ = nullptr;
    }
    audio_player_ = nullptr;
    playout_buffer_ = nullptr;
}

std::shared_ptr<ElevenLabs> ElevenLabs::create() {
    return std::shared_ptr<ElevenLabs>(new ElevenLabs());
}

// std::mutex is automatically initialized in constructor