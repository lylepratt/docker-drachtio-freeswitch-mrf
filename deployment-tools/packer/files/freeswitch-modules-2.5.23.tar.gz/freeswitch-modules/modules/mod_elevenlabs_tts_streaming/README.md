# mod_elevenlabs_tts_streaming

A Freeswitch module that enables streaming of text from LLMs

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_elevenlabs_tts_streaming <uuid> |connect|send|clear|flush|close [tokens]
```

- `connect` - connect to Elevenlabs TTS websocket server
- `send tokens` - sends text tokens
- `flush` - tells Elevenlabs to generate audio
- `clear` - tells Elevenlabs to clear any queued audio or tokens
- `close` - closes the websocket connection to Elevenlabs