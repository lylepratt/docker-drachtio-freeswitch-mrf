#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>
#include <iomanip>
#include <cstring>
#include <cctype>


#include "mod_elevenlabs_tts_streaming.h"

#include "jambonz/simple_json_parser.hpp"
#include "jambonz/vector_math.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

#include "jambonz/simple_json_parser.hpp"
#include "audio_pipe.hpp"


namespace {
  static bool hasDefaultCredentials = false;
  static const char* defaultApiKey = nullptr;
  static const char *requestedNumServiceThreads = std::getenv("MOD_AUDIO_FORK_SERVICE_THREADS");
  static int MAX_CONNECTION_RETRY = 10;
  static int MAX_KEEP_ALIVE_INTERVAL_COUNTER = 500; // 500 * 20 ms = 10 seconds

  std::string escapeJson(const char *text) {
      std::ostringstream escaped;
      while (*text) {
          switch (*text) {
              case '\"': escaped << "\\\""; break;
              case '\\': escaped << "\\\\"; break;
              case '\b': escaped << "\\b"; break;
              case '\f': escaped << "\\f"; break;
              case '\n': escaped << "\\n"; break;
              case '\r': escaped << "\\r"; break;
              case '\t': escaped << "\\t"; break;
              default:
                  if (static_cast<unsigned char>(*text) < 0x20) {
                      escaped << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                              << static_cast<int>(*text);
                  } else {
                      escaped << *text;
                  }
          }
          ++text;
      }
      return escaped.str();
  }

  std::string createSpeakPayload(const char *text) {
      std::ostringstream oss;
      // Should always end with a single space string " "
      oss << "{\"text\":\"" << escapeJson(text) << " \"}";
      return oss.str();
  }

  std::string createFirstPayload(switch_core_session_t* session) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    // VOICE SETTINGS
    const char *stability = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_VOICE_SETTINGS_STABILITY");
    const char *similarity_boost = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_VOICE_SETTINGS_SIMILARITY_BOOST");
    const char *style = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_VOICE_SETTINGS_STYLE");
    const char *use_speaker_boost = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_VOICE_SETTINGS_USE_SPEAKER_BOOST");
    const char *speed = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_VOICE_SETTINGS_SPEED");
    const char *pronunciation_dictionary_locators = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_PRONUNCIATION_DICTIONARY_LOCATORS");

    cJSON * jPayload = cJSON_CreateObject();
    cJSON_AddStringToObject(jPayload, "text", " ");

    if (pronunciation_dictionary_locators) {
      cJSON *jPronunciationDictionaryLocators = cJSON_Parse(pronunciation_dictionary_locators);
      if (jPronunciationDictionaryLocators) {
        cJSON_AddItemToObject(jPayload, "pronunciation_dictionary_locators", jPronunciationDictionaryLocators);
      } else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "createFirstPayload: failed to parse pronunciation dictionary locators %s\n", pronunciation_dictionary_locators);
      }
    }

    if (stability || similarity_boost || style || use_speaker_boost) {
      cJSON * jVoiceSettings = cJSON_CreateObject();
      cJSON_AddItemToObject(jPayload, "voice_settings", jVoiceSettings);
      if (similarity_boost) {
        cJSON_AddStringToObject(jVoiceSettings, "similarity_boost", similarity_boost);
      }
      if (style) {
        cJSON_AddStringToObject(jVoiceSettings, "style", style);
      }
      if (use_speaker_boost) {
        cJSON_AddStringToObject(jVoiceSettings, "use_speaker_boost", use_speaker_boost);
      }
      if (stability) {
        cJSON_AddStringToObject(jVoiceSettings, "stability", stability);
      }
      if (speed) {
        cJSON_AddNumberToObject(jVoiceSettings, "speed", atof(speed));
      }
    }

    char *json = cJSON_PrintUnformatted(jPayload);
    cJSON_Delete(jPayload);

    return json;

  }

  void sendFirstToken(switch_core_session_t* session, e_tts::AudioPipe* ap) {
    if (ap) {
      ap->bufferForSending(createFirstPayload(session).c_str());
    }
  }

  void sendTokens(e_tts::AudioPipe* ap, const char* input) {
    if (ap) {
      ap->bufferForSending(createSpeakPayload(input).c_str());
    }
  }


  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s destroy_tech_pvt\n", tech_pvt->sessionId);
    if (tech_pvt) {
      tech_pvt->pAudioPipe = nullptr;
      if (tech_pvt->bufferedTokens) {
        free(tech_pvt->bufferedTokens);
        tech_pvt->bufferedTokens = nullptr;
      }

      if (tech_pvt->audioPlayer) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s destroying audio player\n", tech_pvt->sessionId);
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        delete p;
        tech_pvt->audioPlayer = nullptr;
      }

      if (tech_pvt->playoutBuffer) {
        CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
        delete playoutBuffer;
        tech_pvt->playoutBuffer = nullptr;
      }

      // NB: do not destroy the mutex here, that is caller responsibility
    }
  }

  std::string constructPath(switch_core_session_t* session, std::string& path, 
    int sampleRate) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    const char *var ;
    std::ostringstream oss;

    oss << "/v1/text-to-speech/";

    //Voice
    const char *voice = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_VOICE_ID");
    oss << voice << "/stream-input?";
    // model
    const char *model = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_MODEL_ID");
    oss << "model_id=" << model;
    // language
    const char *language = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_LANGUAGE");
    if (language) {
      oss << "&language_code=" << language;
    }
    // output_format
    oss << "&output_format=pcm_16000";

   path = oss.str();
   return path;
  }

  switch_status_t processIncomingBinary(private_t* tech_pvt, switch_core_session_t* session, const char* message, size_t dataLength) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    p->bufferAudio(message, dataLength);
   return SWITCH_STATUS_SUCCESS;
  }

  void processIncomingMessage(private_t* tech_pvt, switch_core_session_t* session, const char* message) {
    std::string msg = message;
    cJSON* json = parse_json_string(session, msg);
    if (json) {
      //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "(%u) processIncomingMessage - received json message from elevenlabs for audio\n", tech_pvt->sessionId);
      cJSON* jsonAudio = cJSON_DetachItemFromObject(json, "audio");
      int validAudio = (jsonAudio && NULL != jsonAudio->valuestring);

      if (validAudio) {
        if (tech_pvt->active) {
          std::string rawAudio = jsonAudio->valuestring;
          AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
          p->bufferAudio(rawAudio.c_str(), rawAudio.length());
        }
      }
      else {
        cJSON* jsonError = cJSON_DetachItemFromObject(json, "error");
        int validError = (jsonError && NULL != jsonError->valuestring);
          std::string errorValue = jsonError->valuestring;
          if (errorValue == "input_timeout_exceeded") {
              tech_pvt->is_good_to_reconnect = 1;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "(%s) Reconnect allowed due to timeout\n", tech_pvt->sessionId);
          } else {
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "(%s) Received error: %s\n", tech_pvt->sessionId, errorValue.c_str());
          }
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "(%s) processIncomingMessage - discarding message %s\n", tech_pvt->sessionId, message);
      }
      cJSON_Delete(json);
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%s) processIncomingMessage - could not parse message: %s\n", tech_pvt->sessionId, message);
    }
  }

  static void eventCallback(const char* sessionId, unsigned int id, e_tts::AudioPipe::NotifyEvent_t event, const char* message, const char* binary, size_t len) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, MY_BUG_NAME);

      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          // Check if this is an event from an old connection
          if (id != tech_pvt->id) {
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
              "OLD connection (%s) (%u) event %d; current connection is (%u), ignoring\n", 
              tech_pvt->bugname, id, event, tech_pvt->id);
            switch_core_session_rwunlock(session);
            return;
          }
          
          e_tts::AudioPipe *pAudioPipe = static_cast<e_tts::AudioPipe *>(tech_pvt->pAudioPipe);
          
          switch (event) {
            case e_tts::AudioPipe::BINARY:
              processIncomingBinary(tech_pvt, session, binary, len);
            break;

            case e_tts::AudioPipe::CONNECT_SUCCESS:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) (%u) successful\n", tech_pvt->bugname, id);

              tech_pvt->active = true;
              tech_pvt->keep_alive_interval_counter = 0;
              if (pAudioPipe) {
                sendFirstToken(session, pAudioPipe);
                if (tech_pvt->bufferedTokens) {
                  sendTokens(pAudioPipe, tech_pvt->bufferedTokens);
                  free(tech_pvt->bufferedTokens);
                  tech_pvt->bufferedTokens = nullptr;
                }
              } else {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_WARNING, 
                  "pAudioPipe is NULL during CONNECT_SUCCESS for connection (%u)\n", id);
                if (tech_pvt->bufferedTokens) {
                  free(tech_pvt->bufferedTokens);
                  tech_pvt->bufferedTokens = nullptr;
                }
              }
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_CONNECT_SUCCESS, NULL);
            break;
            case e_tts::AudioPipe::CONNECT_FAIL:
            {
              // first thing: we can no longer access the AudioPipe
              if (tech_pvt->bufferedTokens) {
                free(tech_pvt->bufferedTokens);
                tech_pvt->bufferedTokens = nullptr;
              }
              std::stringstream json;
              json << "{\"reason\":\"" << message << "\"}";
              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_CONNECT_FAIL, (char *) json.str().c_str());
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
            }
            break;
            case e_tts::AudioPipe::CONNECTION_DROPPED:
              // first thing: we can no longer access the AudioPipe
              // Connection is droped, it's was working before, let try to reconnect.
              if (tech_pvt->connection_retry_counter < MAX_CONNECTION_RETRY && tech_pvt->is_good_to_reconnect) {
                tech_pvt->connection_retry_counter++;
                tech_pvt->is_good_to_reconnect = 0;
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) (%u) dropped from far end, reconnect to elevenlabs\n", tech_pvt->bugname, id);
                
                if (pAudioPipe) {
                  e_tts::AudioPipe* ap = new e_tts::AudioPipe(tech_pvt->sessionId, tech_pvt->host, tech_pvt->port, tech_pvt->path, 
                    pAudioPipe->getApiKey().c_str(), pAudioPipe->useTls(), eventCallback);
                  if (ap) {
                    tech_pvt->pAudioPipe = static_cast<void *>(ap);
                    tech_pvt->id = ap->getId();
                    ap->connect();
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "Successfull reconnect after connection (%s) (%u) dropped, new connection id is (%u)\n", tech_pvt->bugname, id, tech_pvt->id);
                    switch_core_session_rwunlock(session);
                    return;
                  }
                }
              }
              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_DISCONNECT, NULL);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) (%u) dropped from far end\n", tech_pvt->bugname, id);
            break;
            case e_tts::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) (%u) closed gracefully\n", tech_pvt->bugname, id);
            break;
            case e_tts::AudioPipe::MESSAGE:
              processIncomingMessage(tech_pvt, session, message);
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from elevenlabs %d:%s\n", event, message);
              break;
          }
        }
      }
      switch_core_session_rwunlock(session);
    }
  }
  switch_status_t make_streaming_connection(switch_core_session_t *session, private_t *tech_pvt) {
    int err;
    int useTls = true;
    std::string host = "api.elevenlabs.io";
    int port = 443;
    std::string path;
    switch_channel_t *channel = switch_core_session_get_channel(session);

    // Check for custom API URI (domain)
    const char* apiUri = switch_channel_get_variable(channel, "ELEVENLABS_API_URI");
    if (apiUri) {
      host = apiUri;
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "Using custom API URI: %s\n", host.c_str());
    }

    constructPath(session, path, tech_pvt->sampleRate);
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "path: %s\n", path.c_str());

    const char* apiKey = switch_channel_get_variable(channel, "ELEVENLABS_API_KEY");
    if (!apiKey && defaultApiKey) {
      apiKey = defaultApiKey;
    } else if (!apiKey) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no elevenlabs api key provided\n");
      return SWITCH_STATUS_FALSE;
    }

    strncpy(tech_pvt->host, host.c_str(), MAX_WS_URL_LEN);
    tech_pvt->port = port;
    strncpy(tech_pvt->path, path.c_str(), MAX_PATH_LEN);   
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);

    e_tts::AudioPipe* ap = new e_tts::AudioPipe(tech_pvt->sessionId, tech_pvt->host, tech_pvt->port, tech_pvt->path, 
      apiKey, useTls, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }
    tech_pvt->pAudioPipe = static_cast<void *>(ap);
    tech_pvt->id = ap->getId();

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now (id=%u)\n", tech_pvt->id);
    ap->connect();
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress (id=%u)\n", tech_pvt->id);

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {
  switch_status_t e_tts_streaming_init() {
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE
    | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    e_tts::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		const char* apiKey = std::getenv("ELEVENLABS_API_KEY");
		if (NULL == apiKey) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, 
				"\"ELEVENLABS_API_KEY\" env var not set; authentication will expect channel variables of same names to be set\n");
		}
		else {
			hasDefaultCredentials = true;
      defaultApiKey = apiKey;
		}
		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t e_tts_streaming_cleanup() {
    bool cleanup = false;
    cleanup = e_tts::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }

  switch_status_t e_tts_streaming_session_init(switch_core_session_t *session, responseHandler_t responseHandler, void **ppUserData) {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    private_t* tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    switch_codec_t* read_codec = switch_core_session_get_read_codec(session);

    /* validate that we have a elevenlabs model (i.e. voice) to use */
    const char *model = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_MODEL_ID");
    if (NULL == model) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no elevenlabs model specified, must set ELEVENLABS_TTS_STREAMING_MODEL_ID\n");
      return SWITCH_STATUS_FALSE;
    }

    const char *voice = switch_channel_get_variable(channel, "ELEVENLABS_TTS_STREAMING_VOICE_ID");
    if (NULL == voice) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no elevenlabs voice id specified, must set ELEVENLABS_TTS_STREAMING_VOICE_ID\n");
      return SWITCH_STATUS_FALSE;
    }

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }

    memset(tech_pvt, 0, sizeof(private_t));
    tech_pvt->pAudioPipe = NULL;
    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
    tech_pvt->responseHandler = responseHandler;
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    tech_pvt->sampleRate = read_codec->implementation->actual_samples_per_second;

    auto playoutBuffer = new CircularBuffer(500000);
    auto audioPlayer = new AudioPlayer(tech_pvt->mutex, playoutBuffer);
    audioPlayer->enableBase64Encoding(true);
    audioPlayer->setResampling(16000, tech_pvt->sampleRate);

    tech_pvt->audioPlayer = (void *) audioPlayer;
    tech_pvt->playoutBuffer = (void *) playoutBuffer;
    tech_pvt->active = false;
    tech_pvt->bufferedTokens = NULL;
    tech_pvt->connection_retry_counter = 0;
    tech_pvt->is_good_to_reconnect = 0;
    tech_pvt->keep_alive_interval_counter = 0;

    *ppUserData = tech_pvt;

    /* need to create the websocket connection for this session since we don't have one */
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "establish websocket for session tts streaming\n");

    if (SWITCH_STATUS_SUCCESS != make_streaming_connection(session, tech_pvt)) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing elevenlabs streaming connection.\n");
      return SWITCH_STATUS_FALSE;
    }

    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_status_t e_tts_streaming_session_send_tokens(switch_core_session_t *session, switch_media_bug_t *bug, char* tokens)
  {
    int err;
    switch_status_t status = SWITCH_STATUS_FALSE;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no tech_pvt for session\n");
      return SWITCH_STATUS_FALSE;
    }
    tech_pvt->active = true;
    tech_pvt->keep_alive_interval_counter = 0;

    /* do we have a ws connection to elevenlabs? */
    if (tech_pvt->pAudioPipe) {
      e_tts::AudioPipe *pAudioPipe = static_cast<e_tts::AudioPipe *>(tech_pvt->pAudioPipe);

      if (pAudioPipe->getLwsState() == e_tts::AudioPipe::LWS_CLIENT_CONNECTED) {
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        if (p && p->isCleared()) p->open();

        sendTokens(pAudioPipe, tokens);
        return SWITCH_STATUS_SUCCESS;
      }
      else if (pAudioPipe->getLwsState() == e_tts::AudioPipe::LWS_CLIENT_CONNECTING ||
        pAudioPipe->getLwsState() == e_tts::AudioPipe::LWS_CLIENT_IDLE) {
        size_t currentLength = tech_pvt->bufferedTokens ? strlen(tech_pvt->bufferedTokens) : 0;
        size_t additionalLength = strlen(tokens);
        size_t newSize = currentLength + additionalLength + 1;
        char* newBuffer = (char*)realloc(tech_pvt->bufferedTokens, newSize);
        if (nullptr == newBuffer) {
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error reallocating memory for buffered tokens\n");
          free(tech_pvt->bufferedTokens); 
          tech_pvt->bufferedTokens = nullptr;
          return SWITCH_STATUS_FALSE;
        }
        
        // Initialize buffer if it's new, strcat appends from the end
        if (currentLength == 0) {
          newBuffer[0] = '\0';
        }
        strcat(newBuffer, tokens);
        tech_pvt->bufferedTokens = newBuffer;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "added additional tokens while connecting, now have %zu chars\n", newSize);
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "cannot send tokens as websocket state is %d\n", pAudioPipe->getLwsState());
        return SWITCH_STATUS_FALSE;
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no websocket connection to elevenlabs\n");
      return SWITCH_STATUS_FALSE;
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t e_tts_streaming_session_flush(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "e_tts_streaming_session_flush\n");
    if (tech_pvt) {
      e_tts::AudioPipe *pAudioPipe = static_cast<e_tts::AudioPipe *>(tech_pvt->pAudioPipe);
      tech_pvt->keep_alive_interval_counter = 0;
      if (pAudioPipe) pAudioPipe->flush();
    }
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t e_tts_streaming_session_clear(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "e_tts_streaming_session_clear\n");
    if (tech_pvt) {
      switch_mutex_lock(tech_pvt->mutex);
      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
      AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
      if (p) p->clear();
      tech_pvt->active = false;
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t e_tts_streaming_session_stop(switch_core_session_t *session,int channelIsClosing, switch_media_bug_t* bug) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "e_tts_streaming_session_stop: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "e_tts_streaming_session_stop\n");

    if (!tech_pvt) return SWITCH_STATUS_FALSE;
      
    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);
    switch_channel_set_private(channel, MY_BUG_NAME, NULL);
    if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

    e_tts::AudioPipe *pAudioPipe = static_cast<e_tts::AudioPipe *>(tech_pvt->pAudioPipe);
    if (pAudioPipe) pAudioPipe->close();

    CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;

    if (playoutBuffer != nullptr) {
      playoutBuffer->clear();
    }
    destroy_tech_pvt(tech_pvt);
    
    switch_mutex_unlock(tech_pvt->mutex);
    /* mutex allocated from session pool - automatically cleaned up */

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "e_tts_streaming_session_stop\n");
    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_bool_t el_dub_speech_frame(switch_media_bug_t *bug, private_t* tech_pvt) {
    int samplesToCopy = 0;

    if (nullptr == tech_pvt->playoutBuffer || !tech_pvt->active) {
      return SWITCH_TRUE;
    }

    if (++tech_pvt->keep_alive_interval_counter >= MAX_KEEP_ALIVE_INTERVAL_COUNTER) {
      // Send empty string for keep alive
      tech_pvt->keep_alive_interval_counter = 0;
      e_tts::AudioPipe *pAudioPipe = static_cast<e_tts::AudioPipe *>(tech_pvt->pAudioPipe);
      if (pAudioPipe) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "el_dub_speech_frame: sending elevenlabs keep alive\n");
        sendTokens(pAudioPipe, "");
      }
    }

    switch_frame_t* rframe = switch_core_media_bug_get_write_replace_frame(bug);
    int16_t *fp = reinterpret_cast<int16_t*>(rframe->data);

    rframe->channels = 1;
    rframe->datalen = rframe->samples * sizeof(int16_t);

    int16_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
    memset(data, 0, sizeof(data));

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(rframe->samples));
      
      if (samplesToCopy > 0) {
      
        auto count = playoutBuffer->getBlock(data, samplesToCopy);
        if (count != samplesToCopy) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, " (%s) el_dub_speech_frame - failed to get %d samples from playout buffer, got %d\n", tech_pvt->sessionId, samplesToCopy, count);
        }
        else {
          vector_add(fp, data, rframe->samples);
          vector_normalize(fp, rframe->samples);
          switch_core_media_bug_set_write_replace_frame(bug, rframe);

          if (samplesToCopy > 0 && playoutBuffer->size() == 0) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, " (%s) el_dub_speech_frame - playout buffer is empty\n", tech_pvt->sessionId);
            switch_core_session_t* session = switch_core_session_locate(tech_pvt->sessionId);
            if (session) {
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_EMPTY, NULL);
              switch_core_session_rwunlock(session);
            }
          }
        }
      }
      switch_mutex_unlock(tech_pvt->mutex);
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, " (%s) el_dub_speech_frame - failed to lock mutex\n", tech_pvt->sessionId);
    }
    return SWITCH_TRUE;
  }
}
