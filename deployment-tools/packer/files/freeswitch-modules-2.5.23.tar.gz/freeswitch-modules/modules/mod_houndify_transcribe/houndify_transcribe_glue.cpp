#include <cstdlib>
#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <mutex>
#include <string>
#include <sstream>
#include <deque>
#include <memory>
#include <chrono>
#include <atomic>
#include <thread>
#include <condition_variable>
#include <queue>

#include <houndify/houndify.hpp>

#include "mod_houndify_transcribe.h"
#include "simple_buffer.h"

const char ALLOC_TAG[] = "houndify";

// Static variables to cache environment variables
static const char* static_client_id = nullptr;
static const char* static_client_key = nullptr;
static const char* static_user_id = nullptr;

// Forward declaration
extern "C" switch_bool_t houndify_transcribe_frame(switch_media_bug_t *bug, void* user_data);

class GStreamer {
private:
	// Audio frame structure for the queue
	struct AudioFrame {
		std::vector<int16_t> data;
		AudioFrame(const int16_t* samples, size_t count) : data(samples, samples + count) {}
	};

	std::function<void(houndify::Transcript)> createTranscriptCallback() {
		return [this](houndify::Transcript transcript) {
			try {
				if (transcript.text != m_lastTranscript && m_interim && !transcript.text.empty()) {
					m_lastTranscript = transcript.text;
					m_hasNewInterimTranscript.store(true);
				}
			} catch (const std::exception& e) {
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
					"Error in transcript callback: %s\n", e.what());
			}
		};
	}

public:
	GStreamer(
		const char *sessionId,
		const char *bugname,
		u_int16_t channels,
		char *lang,
		int interim,
		uint32_t samples_per_second,
		const char* clientId,
		const char* clientKey,
		const char* userId,
		responseHandler_t responseHandler
	) : m_sessionId(sessionId), m_bugname(bugname), m_finished(false), m_stopped(false), m_interim(interim),
		m_connected(false), m_hasNewInterimTranscript(false),
		m_responseHandler(responseHandler), m_sampleRate(samples_per_second), m_channels(channels),
		m_clientId(clientId), m_clientKey(clientKey), m_userId(userId),
		m_lang(lang ? lang : ""),
		m_workerThreadRunning(false), m_streamEnded(false) {

		// Read all channel variables first, then release session lock quickly
		// Store them in m_requestInfoConfig for later use in worker thread
		std::string str_latitude, str_longitude, str_city, str_state, str_country, str_timezone;
		std::string str_max_silence_seconds, str_max_silence_after_full, str_max_silence_after_partial;
		std::string str_vad_sensitivity, str_vad_timeout, str_domain, str_audio_format;
		std::string str_enable_noise_reduction, str_enable_profanity_filter, str_enable_punctuation;
		std::string str_enable_capitalization, str_confidence_threshold, str_max_results;
		std::string str_enable_word_timestamps, str_max_alternatives, str_session_timeout;
		std::string str_connection_timeout, str_custom_vocabulary, str_language_model;
		std::string str_enable_disfluency_filter, str_partial_transcript_interval;
		std::string str_endpoint, str_request_info_json;

		{
			switch_core_session_t* psession = switch_core_session_locate(sessionId);
			if (!psession) throw std::invalid_argument("session id no longer active");
			switch_channel_t *channel = switch_core_session_get_channel(psession);

			// Read all channel variables into local strings
			const char* tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_LATITUDE"))) str_latitude = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_LONGITUDE"))) str_longitude = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_CITY"))) str_city = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_STATE"))) str_state = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_COUNTRY"))) str_country = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_TIMEZONE"))) str_timezone = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_MAX_SILENCE_SECONDS"))) str_max_silence_seconds = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_MAX_SILENCE_AFTER_FULL_QUERY_SECONDS"))) str_max_silence_after_full = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_MAX_SILENCE_AFTER_PARTIAL_QUERY_SECONDS"))) str_max_silence_after_partial = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_VAD_SENSITIVITY"))) str_vad_sensitivity = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_VAD_TIMEOUT"))) str_vad_timeout = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_DOMAIN"))) str_domain = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_AUDIO_FORMAT"))) str_audio_format = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_NOISE_REDUCTION"))) str_enable_noise_reduction = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_PROFANITY_FILTER"))) str_enable_profanity_filter = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_PUNCTUATION"))) str_enable_punctuation = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_CAPITALIZATION"))) str_enable_capitalization = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_CONFIDENCE_THRESHOLD"))) str_confidence_threshold = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_MAX_RESULTS"))) str_max_results = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_WORD_TIMESTAMPS"))) str_enable_word_timestamps = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_MAX_ALTERNATIVES"))) str_max_alternatives = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_SESSION_TIMEOUT"))) str_session_timeout = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_CONNECTION_TIMEOUT"))) str_connection_timeout = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_CUSTOM_VOCABULARY"))) str_custom_vocabulary = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_LANGUAGE_MODEL"))) str_language_model = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_ENABLE_DISFLUENCY_FILTER"))) str_enable_disfluency_filter = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_PARTIAL_TRANSCRIPT_INTERVAL"))) str_partial_transcript_interval = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_AUDIO_ENDPOINT"))) str_endpoint = tmp;
			if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_REQUEST_INFO"))) str_request_info_json = tmp;

			// Release session lock immediately after reading variables
			switch_core_session_rwunlock(psession);
		}

		// Build the configuration JSON for later use in worker thread
		// DO NOT create houndify::Client here - it will be created on the worker thread
		try {
			m_requestInfoConfig = nlohmann::json::object();

			if (!str_latitude.empty() && !str_longitude.empty()) {
				m_requestInfoConfig["Latitude"] = std::stod(str_latitude);
				m_requestInfoConfig["Longitude"] = std::stod(str_longitude);
			}

			if (!str_city.empty()) m_requestInfoConfig["City"] = str_city;
			if (!str_state.empty()) m_requestInfoConfig["State"] = str_state;
			if (!str_country.empty()) m_requestInfoConfig["Country"] = str_country;
			if (!str_timezone.empty()) m_requestInfoConfig["TimeZone"] = str_timezone;

			if (!m_lang.empty()) {
				m_requestInfoConfig["InputLanguageIETFTag"] = m_lang;
			} else {
				m_requestInfoConfig["InputLanguageEnglishName"] = "English";
				m_requestInfoConfig["InputLanguageIETFTag"] = "en-US";
			}

			// Voice Activity Detection parameters
			if (!str_max_silence_seconds.empty() || !str_max_silence_after_full.empty() ||
				!str_max_silence_after_partial.empty() || !str_vad_sensitivity.empty() || !str_vad_timeout.empty()) {
				nlohmann::json voiceDetectionConfig = nlohmann::json::object();
				if (!str_max_silence_seconds.empty()) voiceDetectionConfig["MaxSilenceSeconds"] = std::stod(str_max_silence_seconds);
				if (!str_max_silence_after_full.empty()) voiceDetectionConfig["MaxSilenceAfterFullQuerySeconds"] = std::stod(str_max_silence_after_full);
				if (!str_max_silence_after_partial.empty()) voiceDetectionConfig["MaxSilenceAfterPartialQuerySeconds"] = std::stod(str_max_silence_after_partial);
				if (!str_vad_sensitivity.empty()) voiceDetectionConfig["VadSensitivity"] = std::stod(str_vad_sensitivity);
				if (!str_vad_timeout.empty()) voiceDetectionConfig["VadTimeout"] = std::stod(str_vad_timeout);
				m_requestInfoConfig["VoiceActivityDetection"] = voiceDetectionConfig;
			}

			m_requestInfoConfig["ServerDeterminesEndOfAudio"] = true;
			m_requestInfoConfig["ClientID"] = m_clientId;
			m_requestInfoConfig["UserID"] = m_userId;
			m_requestInfoConfig["SessionID"] = m_sessionId;
			m_requestInfoConfig["AudioFormat"] = "PCM16";
			m_requestInfoConfig["SampleRate"] = samples_per_second;
			m_requestInfoConfig["Channels"] = static_cast<int>(channels);
			m_requestInfoConfig["PartialTranscriptsDesired"] = interim > 0;

			if (!str_domain.empty()) {
				m_requestInfoConfig["ConversationState"] = nlohmann::json::object();
				m_requestInfoConfig["ConversationState"]["Domain"] = str_domain;
			}

			// Audio processing parameters
			if (!str_audio_format.empty()) m_requestInfoConfig["AudioFormat"] = str_audio_format;

			if (!str_enable_noise_reduction.empty() && str_enable_noise_reduction == "true") {
				m_requestInfoConfig["AudioProcessing"] = nlohmann::json::object();
				m_requestInfoConfig["AudioProcessing"]["NoiseReduction"] = true;
			}

			// Recognition control parameters
			if (!str_enable_profanity_filter.empty() && str_enable_profanity_filter == "true") {
				m_requestInfoConfig["ProfanityFilter"] = true;
			}

			if (!str_enable_punctuation.empty() && str_enable_punctuation == "true") {
				m_requestInfoConfig["EnablePunctuation"] = true;
			}

			if (!str_enable_capitalization.empty() && str_enable_capitalization == "true") {
				m_requestInfoConfig["EnableCapitalization"] = true;
			}

			if (!str_confidence_threshold.empty()) {
				m_requestInfoConfig["ConfidenceThreshold"] = std::stod(str_confidence_threshold);
			}

			// Response formatting parameters
			if (!str_max_results.empty()) {
				m_requestInfoConfig["NumToReturn"] = atoi(str_max_results.c_str());
			}

			if (!str_enable_word_timestamps.empty() && str_enable_word_timestamps == "true") {
				m_requestInfoConfig["EnableWordTimestamps"] = true;
			}

			if (!str_max_alternatives.empty()) {
				m_requestInfoConfig["MaxAlternatives"] = atoi(str_max_alternatives.c_str());
			}

			// Session management parameters
			if (!str_session_timeout.empty()) {
				m_requestInfoConfig["SessionTimeout"] = atoi(str_session_timeout.c_str());
			}

			if (!str_connection_timeout.empty()) {
				m_requestInfoConfig["ConnectionTimeout"] = atoi(str_connection_timeout.c_str());
			}

			// Advanced features
			if (!str_custom_vocabulary.empty()) {
				nlohmann::json vocab_array = nlohmann::json::array();
				std::stringstream ss(str_custom_vocabulary);
				std::string item;
				while (std::getline(ss, item, ',')) {
					item.erase(0, item.find_first_not_of(" \t"));
					item.erase(item.find_last_not_of(" \t") + 1);
					if (!item.empty()) {
						vocab_array.push_back(item);
					}
				}
				if (!vocab_array.empty()) {
					m_requestInfoConfig["CustomVocabulary"] = vocab_array;
				}
			}

			if (!str_language_model.empty()) {
				m_requestInfoConfig["LanguageModel"] = str_language_model;
			}

			if (!str_enable_disfluency_filter.empty() && str_enable_disfluency_filter == "true") {
				m_requestInfoConfig["DisfluencyFilter"] = true;
			}

			if (!str_partial_transcript_interval.empty()) {
				m_requestInfoConfig["PartialTranscriptInterval"] = atoi(str_partial_transcript_interval.c_str());
			}

			// Store endpoint for later use
			if (!str_endpoint.empty()) {
				m_requestInfoConfig["_endpoint"] = str_endpoint;  // Special key for endpoint
			}

			// Parse and merge custom request info JSON if provided
			if (!str_request_info_json.empty()) {
				try {
					nlohmann::json custom_request_info = nlohmann::json::parse(str_request_info_json);
					for (auto& [key, value] : custom_request_info.items()) {
						m_requestInfoConfig[key] = value;
					}
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
						"Successfully merged custom request info from HOUNDIFY_REQUEST_INFO\n");
				} catch (const nlohmann::json::parse_error& e) {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
						"Failed to parse HOUNDIFY_REQUEST_INFO JSON: %s\n", e.what());
				} catch (const std::exception& e) {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
						"Error processing HOUNDIFY_REQUEST_INFO: %s\n", e.what());
				}
			}

			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
				"GStreamer constructor: stored configuration for worker thread initialization\n");

		} catch (const std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error building configuration: %s\n", e.what());
			throw std::runtime_error("Houndify configuration failed");
		}
	}

	~GStreamer() {
		// Stop the worker thread first
		stopWorkerThread();
	}

private:
	std::string m_sessionId;
	std::string m_bugname;
	std::atomic<bool> m_finished;
	std::atomic<bool> m_stopped;
	int m_interim;
	std::atomic<bool> m_connected;
	responseHandler_t m_responseHandler;
	uint32_t m_sampleRate;
	uint16_t m_channels;

	// SDK credentials and configuration (stored for worker thread initialization)
	std::string m_clientId;
	std::string m_clientKey;
	std::string m_userId;
	std::string m_lang;
	nlohmann::json m_requestInfoConfig;  // Pre-built configuration to apply on worker thread

	std::unique_ptr<houndify::Client> m_client;
	std::unique_ptr<houndify::AudioQuery> m_audioQuery;
	std::string m_lastTranscript;
	std::atomic<bool> m_hasNewInterimTranscript;

	// Async worker thread infrastructure
	std::thread m_workerThread;
	std::atomic<bool> m_workerThreadRunning;
	std::atomic<bool> m_streamEnded;

	// Thread-safe audio queue (producer-consumer pattern)
	std::queue<AudioFrame> m_audioQueue;
	std::mutex m_queueMutex;
	std::condition_variable m_queueCondition;
	static const size_t MAX_QUEUE_SIZE = 500;  // Max frames in queue

	// Buffer for audio data when not connected yet (pre-connection buffering)
	std::deque<std::vector<int16_t>> m_audioBuffer;
	static const size_t MAX_BUFFER_FRAMES = 500;

	// Mutex for SDK operations (separate from queue mutex)
	std::mutex m_sdkMutex;

	void processResponse(const houndify::Json& response, bool final = false) {
		try {
			switch_core_session_t* psession = switch_core_session_locate(m_sessionId.c_str());
			if (psession) {
				m_responseHandler(psession, TRANSCRIBE_EVENT_RESULTS, response.dump().c_str(), m_bugname.c_str(), 0);
				switch_core_session_rwunlock(psession);
			}
		} catch (const std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error processing response: %s\n", e.what());
		}
	}

	void sendErrorNotification(const std::string& error_msg, const std::string& reason, bool is_fatal = true, const std::string& type = "error") {
		try {
			switch_core_session_t* psession = switch_core_session_locate(m_sessionId.c_str());
			if (psession) {
				nlohmann::json errorResponse;
				errorResponse["type"] = type;
				errorResponse["error"] = error_msg;
				errorResponse["fatal"] = is_fatal;
				errorResponse["reason"] = reason;
				if (type == "transcription_stopped") errorResponse["final"] = true;

				m_responseHandler(psession, TRANSCRIBE_EVENT_ERROR,
					errorResponse.dump().c_str(), m_bugname.c_str(), is_fatal);
				switch_core_session_rwunlock(psession);
			}
		} catch (...) {
			// Suppress exceptions in error reporting
		}
	}

	bool shouldStop() const {
		return m_finished.load() || m_stopped.load();
	}

	bool isRecoverableError(const std::string& error_msg) {
		return (error_msg.find("read:") != std::string::npos ||
				error_msg.find("unspecified system error") != std::string::npos ||
				error_msg.find("connection") != std::string::npos ||
				error_msg.find("network") != std::string::npos ||
				error_msg.find("timeout") != std::string::npos);
	}

	void cleanupAudioQuery() {
		std::lock_guard<std::mutex> lock(m_sdkMutex);
		if (m_audioQuery) {
			try {
				auto response = m_audioQuery->finish();
				processResponse(response, true);
			} catch (const std::exception& e) {
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error finishing audio query: %s\n", e.what());
			}

			try {
				m_audioQuery.reset();
			} catch (...) {
				// Suppress cleanup exceptions
			}
		}

		// Also cleanup the client - it was created on the worker thread
		if (m_client) {
			try {
				m_client.reset();
			} catch (...) {
				// Suppress cleanup exceptions
			}
		}

		m_connected.store(false);
	}

	// Worker thread function - runs in separate thread, handles all SDK operations
	// IMPORTANT: All Houndify SDK calls MUST happen on this thread to satisfy Boost Beast's threading model
	void workerThreadFunc() {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
			"Houndify worker thread started for session %s\n", m_sessionId.c_str());

		// Initialize Houndify SDK on this worker thread
		// This is critical: the SDK uses Boost Beast async I/O internally,
		// which requires all operations to happen on the same thread where it was created
		try {
			m_client = std::make_unique<houndify::Client>(
				m_clientId.c_str(), m_clientKey.c_str(), m_userId.c_str());

			// Apply all configuration from m_requestInfoConfig
			auto& requestInfo = m_client->request_info();

			// Extract endpoint if present (special key)
			std::string endpoint;
			if (m_requestInfoConfig.contains("_endpoint")) {
				endpoint = m_requestInfoConfig["_endpoint"].get<std::string>();
				m_client->set_audio_endpoint(endpoint.c_str());
			}

			// Add timestamp (must be set at connection time)
			auto now = std::chrono::system_clock::now();
			requestInfo["RequestTimestamp"] = std::chrono::system_clock::to_time_t(now);

			// Copy all other configuration values (except _endpoint)
			for (auto& [key, value] : m_requestInfoConfig.items()) {
				if (key != "_endpoint") {
					requestInfo[key] = value;
				}
			}

			// Create AudioQuery with transcript callback
			auto callback = createTranscriptCallback();
			m_audioQuery = std::make_unique<houndify::AudioQuery>(
				m_client->start_audio_query(m_sampleRate, callback)
			);

			m_connected.store(true);
			m_streamEnded.store(false);

			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
				"Houndify SDK initialized on worker thread for session %s\n", m_sessionId.c_str());

		} catch (const std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
				"Failed to initialize Houndify SDK on worker thread: %s\n", e.what());
			sendErrorNotification(e.what(), "worker_init_failed");
			m_stopped.store(true);
			m_finished.store(true);
			return;  // Exit worker thread
		}

		// Flush any buffered audio to the queue now that we're connected
		flushBufferedAudioToQueue();

		// Main processing loop
		while (m_workerThreadRunning.load()) {
			std::vector<int16_t> audioData;

			// Wait for audio data in the queue
			{
				std::unique_lock<std::mutex> lock(m_queueMutex);
				m_queueCondition.wait_for(lock, std::chrono::milliseconds(100), [this] {
					return !m_audioQueue.empty() || !m_workerThreadRunning.load();
				});

				if (!m_workerThreadRunning.load() && m_audioQueue.empty()) {
					break;  // Exit if stopping and queue is empty
				}

				if (m_audioQueue.empty()) {
					continue;  // Timeout, check again
				}

				// Get audio frame from queue
				audioData = std::move(m_audioQueue.front().data);
				m_audioQueue.pop();
			}

			// Process the audio frame (SDK call happens on this worker thread)
			if (!audioData.empty()) {
				processAudioFrame(audioData.data(), audioData.size());
			}
		}

		// Cleanup SDK resources on this thread
		cleanupAudioQuery();

		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
			"Houndify worker thread exiting for session %s\n", m_sessionId.c_str());
	}

	// Process a single audio frame - called from worker thread
	void processAudioFrame(const int16_t* samples, size_t sampleCount) {
		std::lock_guard<std::mutex> lock(m_sdkMutex);

		if (!m_connected.load() || !m_audioQuery) {
			return;  // Not connected yet, skip
		}

		if (m_streamEnded.load()) {
			return;  // Stream already ended
		}

		try {
			bool result = m_audioQuery->stream(samples, sampleCount);

			// If result is true, server detected end of query (normal completion)
			if (result) {
				m_streamEnded.store(true);
				try {
					auto response = m_audioQuery->finish();
					processResponse(response, true);
				} catch (const std::exception& e) {
					switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
						"Error finishing audio query after server detection: %s\n", e.what());
				}
				m_audioQuery.reset();
				m_connected.store(false);
				// Mark as stopped to prevent reconnection attempts after normal completion
				m_stopped.store(true);
				m_finished.store(true);
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
					"Houndify query completed normally for session %s\n", m_sessionId.c_str());
			}
		} catch (const std::exception& e) {
			const std::string error_msg = e.what();
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
				"Error in Houndify SDK stream operation - Session: %s, Samples: %zu, Error: %s\n",
				m_sessionId.c_str(), sampleCount, error_msg.c_str());

			if (isRecoverableError(error_msg)) {
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
					"Detected potentially recoverable network error in worker thread\n");
				sendErrorNotification(error_msg, "recoverable_network_error_worker", false, "warning");
				m_connected.store(false);
				try {
					m_audioQuery.reset();
				} catch (...) {
					// Suppress exceptions during cleanup
				}
			} else {
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
					"Non-recoverable error detected in worker thread, stopping transcription\n");
				sendErrorNotification(error_msg, "fatal_sdk_error");
				m_stopped.store(true);
				m_finished.store(true);
				m_streamEnded.store(true);
			}
		}
	}

	void startWorkerThread() {
		if (m_workerThreadRunning.load()) {
			return;  // Already running
		}

		// Make sure any previous thread is joined before starting a new one
		if (m_workerThread.joinable()) {
			m_workerThread.join();
		}

		// Reset state for new connection
		m_streamEnded.store(false);
		m_stopped.store(false);
		m_finished.store(false);

		// Clear any stale audio from previous connection
		{
			std::lock_guard<std::mutex> lock(m_queueMutex);
			while (!m_audioQueue.empty()) {
				m_audioQueue.pop();
			}
			// Keep buffered audio - it will be flushed after connection
		}

		m_workerThreadRunning.store(true);
		m_workerThread = std::thread(&GStreamer::workerThreadFunc, this);

		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
			"Started Houndify worker thread for session %s\n", m_sessionId.c_str());
	}

	void stopWorkerThread() {
		// Signal the worker thread to stop
		bool wasRunning = m_workerThreadRunning.exchange(false);
		if (!wasRunning) {
			// Thread was not running, but might still need to join if it was previously started
			if (m_workerThread.joinable()) {
				m_workerThread.join();
			}
			return;
		}

		m_queueCondition.notify_all();

		// Wait for the worker thread to finish
		// The worker thread handles its own cleanup of SDK resources
		if (m_workerThread.joinable()) {
			m_workerThread.join();
		}

		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
			"Stopped Houndify worker thread for session %s\n", m_sessionId.c_str());
	}

	void flushBufferedAudioToQueue() {
		// Move pre-connection buffered audio to the async queue
		std::lock_guard<std::mutex> queueLock(m_queueMutex);
		for (const auto& frame : m_audioBuffer) {
			if (m_audioQueue.size() < MAX_QUEUE_SIZE) {
				m_audioQueue.emplace(frame.data(), frame.size());
			}
		}
		m_audioBuffer.clear();
		m_queueCondition.notify_one();
	}

public:
	bool connect() {
		if (m_workerThreadRunning.load()) return true;  // Already started

		// Just start the worker thread - it handles SDK initialization internally
		// This keeps the FreeSWITCH thread non-blocking
		startWorkerThread();
		return true;  // Connection happens async in worker thread
	}

	// NON-BLOCKING: Enqueue audio for async processing
	// This is the main method called from FreeSWITCH thread - it only adds to queue and returns immediately
	bool enqueueAudio(const int16_t* audioData, size_t audioLen) {
		if (shouldStop() || m_streamEnded.load()) {
			return true;  // Signal to stop processing
		}

		if (!m_connected.load()) {
			// Not connected yet - buffer the audio for later
			std::vector<int16_t> audioFrame(audioData, audioData + audioLen);
			std::lock_guard<std::mutex> lock(m_queueMutex);
			m_audioBuffer.push_back(audioFrame);
			while (m_audioBuffer.size() > MAX_BUFFER_FRAMES) {
				m_audioBuffer.pop_front();
			}
			return false;  // Continue buffering
		}

		// Add to the async queue (non-blocking)
		{
			std::lock_guard<std::mutex> lock(m_queueMutex);

			// Drop oldest frames if queue is full to prevent unbounded growth
			if (m_audioQueue.size() >= MAX_QUEUE_SIZE) {
				m_audioQueue.pop();
				switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING,
					"Houndify audio queue full, dropping oldest frame for session %s\n", m_sessionId.c_str());
			}

			m_audioQueue.emplace(audioData, audioLen);
		}

		// Notify the worker thread
		m_queueCondition.notify_one();

		return m_streamEnded.load();  // Return true if stream has ended
	}

	void disconnect() {
		m_stopped.store(true);
		m_finished.store(true);
		m_connected.store(false);

		// Stop the worker thread (will also cleanup audio query)
		stopWorkerThread();
	}

	bool isConnected() {
		return m_connected.load();
	}

	bool isStopped() {
		return m_stopped.load();
	}

	void finish() {
		if (m_finished.load()) return;

		if (m_stopped.load()) {
			sendErrorNotification("Transcription stopped due to error", "error_state", true, "transcription_stopped");
		}

		m_finished.store(true);
		m_stopped.store(true);
		stopWorkerThread();
	}

	// Process interim transcripts from main FreeSWITCH thread - THREAD SAFE
	void processInterimTranscripts() {
		if (!m_interim || !m_hasNewInterimTranscript.load()) return;

		std::unique_lock<std::mutex> lock(m_sdkMutex, std::defer_lock);
		if (!lock.try_lock()) return;  // Mutex busy, skip this iteration

		if (m_lastTranscript.empty()) return;

		m_hasNewInterimTranscript.store(false);
		std::string currentTranscript = m_lastTranscript;
		lock.unlock();

		// Create simplified interim response
		houndify::Json interimResponse = {
			{"Disambiguation", {
				{"ChoiceData", {{
					{"ASRConfidence", 0.8},
					{"ConfidenceScore", 0.7},
					{"FixedTranscription", ""},
					{"FormattedTranscription", currentTranscript},
					{"Transcription", currentTranscript}
				}}},
				{"NumToShow", 1}
			}},
			{"ResultsAreFinal", {false}},
			{"Status", "OK"},
			{"Format", "SoundHoundVoiceSearchResult"},
			{"FormatVersion", "1.0"},
			{"NumToReturn", 1}
		};

		// Generate query ID
		auto timestamp = std::chrono::duration_cast<std::chrono::milliseconds>(
			std::chrono::system_clock::now().time_since_epoch()).count();
		std::string queryId = "interim-" + std::to_string(timestamp);
		interimResponse["QueryID"] = queryId;
		interimResponse["ServerGeneratedId"] = queryId;

		switch_core_session_t* psession = switch_core_session_locate(m_sessionId.c_str());
		if (psession) {
			m_responseHandler(psession, TRANSCRIBE_EVENT_RESULTS,
				interimResponse.dump().c_str(), m_bugname.c_str(), 0);
			switch_core_session_rwunlock(psession);
		}
	}
};

extern "C" {
	switch_status_t houndify_transcribe_init() {
		// Cache environment variables once during module initialization
		static_client_id = std::getenv("HOUNDIFY_CLIENT_ID");
		static_client_key = std::getenv("HOUNDIFY_CLIENT_KEY");
		static_user_id = std::getenv("HOUNDIFY_USER_ID");
		
		if (NULL == static_client_id || NULL == static_client_key || NULL == static_user_id) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, 
				"\"HOUNDIFY_CLIENT_ID\", \"HOUNDIFY_CLIENT_KEY\" and \"HOUNDIFY_USER_ID\" env vars not set; authentication will expect channel variables of same names to be set\n");
		}
		return SWITCH_STATUS_SUCCESS;
	}
	
	switch_status_t houndify_transcribe_cleanup() {
		return SWITCH_STATUS_SUCCESS;
	}

	// start transcribe on a channel
	switch_status_t houndify_transcribe_session_init(
		switch_core_session_t *session, 
		responseHandler_t responseHandler, 
		uint32_t samples_per_second, 
		uint32_t channels, 
		char* lang, 
		int interim, 
		char* bugname, 
		void **ppUserData
	) {
		switch_channel_t *channel = switch_core_session_get_channel(session);
		auto uuid = switch_core_session_get_uuid(session);
		switch_status_t status = SWITCH_STATUS_SUCCESS;
		switch_media_bug_t *bug;
		switch_media_bug_flag_t flags = SMBF_READ_STREAM;
		// https://jambonz.freshdesk.com/a/tickets/1655
		// Soundhoud requested to send 8000 Hz audio 
		uint32_t to_rate = 8000;
		
		// Check if custom sampling rate is specified
		const char* sampling_rate_str = switch_channel_get_variable(channel, "HOUNDIFY_SAMPLING_RATE");
		if (sampling_rate_str) {
			int custom_rate = atoi(sampling_rate_str);
			if (custom_rate > 0) {
				to_rate = custom_rate;
				switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
					"Using custom HOUNDIFY_SAMPLING_RATE: %u Hz\n", to_rate);
			} else {
				switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_WARNING,
					"Invalid HOUNDIFY_SAMPLING_RATE value: %s, using default 8000 Hz\n", sampling_rate_str);
			}
		}
		
		struct cap_cb *cb;
		int err;
		const char* voice_ms;
		const char* mode;
		const char* silence_ms_str;
		const char* vad_debug;

		// Get Houndify credentials from cached environment variables or channel variables
		const char* clientId = static_client_id;
		const char* clientKey = static_client_key;
		const char* userId = static_user_id;
		if (!clientId) clientId = switch_channel_get_variable(channel, "HOUNDIFY_CLIENT_ID");
		if (!clientKey) clientKey = switch_channel_get_variable(channel, "HOUNDIFY_CLIENT_KEY");
		if (!userId) userId = switch_channel_get_variable(channel, "HOUNDIFY_USER_ID");

		if (!clientId || !clientKey || !userId) {
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
				"HOUNDIFY_CLIENT_ID, HOUNDIFY_CLIENT_KEY, and HOUNDIFY_USER_ID must be set in environment or channel variables.\n");
			return SWITCH_STATUS_FALSE;
		}

		if (samples_per_second != to_rate) {
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"houndify_transcribe_session_init:  audio sample rate %u, resampling to %u\n", samples_per_second, to_rate);
		}

		cb = (struct cap_cb *) switch_core_session_alloc(session, sizeof(*cb));
		memset(cb, 0, sizeof(*cb));  // Zero-initialize to ensure clean state
		strncpy(cb->sessionId, uuid, MAX_SESSION_ID);
		strncpy(cb->bugname, bugname, MAX_BUG_LEN);
		strncpy(cb->lang, lang, MAX_LANG);

		cb->interim = interim;
		cb->channels = channels;
		cb->responseHandler = responseHandler;

		// Setup resampler if needed
		if (samples_per_second != to_rate) {
			cb->resampler = speex_resampler_init(channels, samples_per_second, to_rate, SWITCH_RESAMPLE_QUALITY, &err);
			if (0 != err) {
				switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, 
					"Error initializing resampler: %s.\n", speex_resampler_strerror(err));
				status = SWITCH_STATUS_FALSE;
				goto done;
			}
		} else {
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"houndify_transcribe_session_init:  no resampling needed for this call\n");
		}

		switch_mutex_init(&cb->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
		if (status != SWITCH_STATUS_SUCCESS) goto done;

		switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
			"houndify_transcribe_session_init:  allocating streamer\n");

		try {
			GStreamer* streamer = new GStreamer(uuid, bugname, channels, lang, interim, to_rate, clientId, clientKey, userId, responseHandler);
			cb->streamer = streamer;
		} catch (std::exception& e) {
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
				"Error initializing Houndify streamer: %s.\n", e.what());
			// Clean up resampler if it was already allocated
			if (cb->resampler) {
				speex_resampler_destroy(cb->resampler);
				cb->resampler = NULL;
			}
			status = SWITCH_STATUS_FALSE;
			goto done;
		}

		// Check for VAD settings
		voice_ms = switch_channel_get_variable(channel, "HOUNDIFY_VAD_VOICE_MS");
		mode = switch_channel_get_variable(channel, "HOUNDIFY_VAD_MODE");
		silence_ms_str = switch_channel_get_variable(channel, "HOUNDIFY_VAD_SILENCE_MS");
		vad_debug = switch_channel_get_variable(channel, "HOUNDIFY_VAD_DEBUG");
		
		if (voice_ms && mode) {
			int ms = atoi(voice_ms);
			int vad_mode = atoi(mode);
			int silence_ms = silence_ms_str ? atoi(silence_ms_str) : 0;
			int debug = vad_debug ? atoi(vad_debug) : 0;
			
			if (ms > 0 && vad_mode > 0) {
				if (silence_ms_str) {
					switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
						"(%s) enable vad mode: %s voice_ms: %s silence_ms: %d\n", 
						switch_channel_get_name(channel), mode, voice_ms, silence_ms);
				} else {
					switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
						"(%s) enable vad mode: %s voice_ms: %s\n", 
						switch_channel_get_name(channel), mode, voice_ms);
				}
				cb->vad = switch_vad_init(to_rate, channels);
				if (cb->vad) {
					switch_vad_set_mode(cb->vad, vad_mode);
					switch_vad_set_param(cb->vad, "voice_ms", ms);
					if (silence_ms_str) {
						switch_vad_set_param(cb->vad, "silence_ms", silence_ms);
					}
					if (debug) {
						switch_vad_set_param(cb->vad, "debug", debug);
					}
				}
			}
		}

		// If no VAD, connect immediately for minimal latency
		if (!cb->vad) {
			GStreamer* streamer = (GStreamer *) cb->streamer;
			streamer->connect();
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"No VAD configured - connected immediately\n");
		}

	done:
		*ppUserData = cb;
		cb->transcription_counter = 0;
		cb->reconnect_counter = 0;
		return status;
	}

	switch_status_t houndify_transcribe_session_stop(switch_core_session_t *session, int channelIsClosing, char* bugname) {
		switch_channel_t *channel = switch_core_session_get_channel(session);
		switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

		if (bug) {
			struct cap_cb *cb = (struct cap_cb *) switch_core_media_bug_get_user_data(bug);

			switch_mutex_lock(cb->mutex);
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"houndify_transcribe_session_stop: locked session\n");

			switch_channel_set_private(channel, bugname, NULL);
			if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

			GStreamer* streamer = (GStreamer *) cb->streamer;
			if (streamer) {
				streamer->disconnect();
				delete streamer;
				cb->streamer = NULL;
			}

			if (cb->resampler) {
				speex_resampler_destroy(cb->resampler);
				cb->resampler = NULL;
			}

			if (cb->vad) {
				switch_vad_destroy(&cb->vad);
				cb->vad = NULL;
			}

			switch_mutex_unlock(cb->mutex);
			switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
				"houndify_transcribe_session_stop: unlocked session\n");

			return SWITCH_STATUS_SUCCESS;
		}

		switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, 
			"%s Bug is not attached.\n", switch_channel_get_name(channel));
		return SWITCH_STATUS_FALSE;
	}
	
	switch_bool_t houndify_transcribe_frame(switch_media_bug_t *bug, void* user_data) {
		switch_core_session_t *session = switch_core_media_bug_get_session(bug);
		uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
		switch_frame_t frame = {};
		struct cap_cb *cb = (struct cap_cb *) user_data;

		frame.data = data;
		frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;

		if (switch_mutex_trylock(cb->mutex) == SWITCH_STATUS_SUCCESS) {
			GStreamer* streamer = (GStreamer *) cb->streamer;
			if (streamer && !streamer->isStopped()) {
				while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS && !switch_test_flag((&frame), SFF_CNG)) {
					if (frame.datalen) {
						if (cb->vad && !streamer->isConnected()) {
							switch_vad_state_t state = switch_vad_process(cb->vad, (int16_t*) frame.data, frame.samples);
							if (state == SWITCH_VAD_STATE_START_TALKING) {
								switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
									"detected speech, connect to Houndify now\n");
								streamer->connect();
								cb->responseHandler(session, "houndify::vad_detected", NULL, cb->bugname, 0);
							}
						}

						// Process audio - resample if needed, then enqueue for async processing
						spx_int16_t* audioData;
						size_t audioLen;
						spx_int16_t resampledBuffer[SWITCH_RECOMMENDED_BUFFER_SIZE];

						// Handle resampling if needed
						if (cb->resampler) {
							spx_uint32_t out_len = SWITCH_RECOMMENDED_BUFFER_SIZE;
							spx_uint32_t in_len = frame.samples;

							speex_resampler_process_interleaved_int(
								cb->resampler,
								(const spx_int16_t *) frame.data,
								(spx_uint32_t *) &in_len,
								&resampledBuffer[0],
								&out_len);

							audioData = resampledBuffer;
							audioLen = out_len;
						} else {
							audioData = reinterpret_cast<spx_int16_t*>(frame.data);
							audioLen = frame.datalen / sizeof(int16_t);
						}

						// NON-BLOCKING: Enqueue audio for async processing by worker thread
						// This returns immediately without blocking the FreeSWITCH thread
						// enqueueAudio() handles both connected and buffering states internally
						streamer->enqueueAudio(audioData, audioLen);

						// Attempt reconnection if disconnected during recovery mode
						if (!streamer->isConnected() && !streamer->isStopped()) {
							cb->reconnect_counter++;
							if (cb->reconnect_counter % 50 == 0) { // Try every ~1 second at 20ms frames
								switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
									"Attempting to reconnect to Houndify (attempt %d)\n", cb->reconnect_counter / 50);
								if (streamer->connect()) {
									switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
										"Successfully reconnected to Houndify\n");
									cb->reconnect_counter = 0;
								}
							}
						}
						streamer->processInterimTranscripts();
					}
				}
			}
			switch_mutex_unlock(cb->mutex);
		}
		return SWITCH_TRUE;
	}
}
