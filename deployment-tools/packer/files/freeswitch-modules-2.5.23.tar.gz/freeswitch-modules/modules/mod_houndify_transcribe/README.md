# mod_houdify_transcribe

A Freeswitch module that generates real-time transcriptions on a Freeswitch channel by using the Microsoft streaming transcription API
