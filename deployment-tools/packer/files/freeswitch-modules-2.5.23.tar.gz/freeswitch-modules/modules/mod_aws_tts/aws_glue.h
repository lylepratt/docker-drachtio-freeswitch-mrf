#ifndef __AWS_TTS_GLUE_H__
#define __AWS_TTS_GLUE_H__

switch_status_t aws_speech_load();
switch_status_t aws_speech_open(aws_handle_t handle);
switch_status_t aws_speech_feed_tts(aws_handle_t handle, char* text, switch_speech_flag_t *flags);
switch_status_t aws_speech_read_tts(aws_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t aws_speech_flush_tts(aws_handle_t handle);
switch_status_t aws_speech_close(aws_handle_t handle);
switch_status_t aws_speech_unload();

#endif