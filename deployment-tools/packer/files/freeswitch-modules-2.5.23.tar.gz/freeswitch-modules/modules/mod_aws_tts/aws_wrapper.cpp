#include "aws_wrapper.h"
#include "aws.hpp"
#include <memory>
#include <mutex>
#include <unordered_map>
#include <chrono>

// Internal handle structure
struct aws_handle {
    std::shared_ptr<AwsTts> instance;
    int ref_count;
    std::mutex ref_mutex;

    aws_handle(std::shared_ptr<AwsTts> inst)
        : instance(std::move(inst)), ref_count(1) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
                "aws_handle initialized with ref_count %d\n", ref_count);
        }
};

// Thread-safe handle management
static std::mutex g_handle_mutex;
static std::unordered_map<aws_handle_t, std::unique_ptr<aws_handle>> g_handles;

// Helper function to validate handle
static aws_handle* get_handle(aws_handle_t handle) {
    if (!handle) return nullptr;

    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second.get() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
std::shared_ptr<AwsTts> aws_get_shared_ptr(aws_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance : nullptr;
}

// Private internal function to get handle from shared_ptr
aws_handle_t aws_get_handle_from_shared_ptr(const std::shared_ptr<AwsTts>& ptr) {
    if (!ptr) return nullptr;

    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->instance == ptr) {
            return pair.first;
        }
    }
    return nullptr;
}

// C API Implementation
extern "C" {

aws_handle_t aws_tts_create(void) {
    try {
        auto instance = AwsTts::create();
        auto handle = std::make_unique<aws_handle>(instance);
        aws_handle_t handle_ptr = handle.get();

        size_t map_size;
        {
            std::lock_guard<std::mutex> lock(g_handle_mutex);
            g_handles[handle_ptr] = std::move(handle);
            map_size = g_handles.size();
        }

        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "aws_tts_create: created handle=%p, AwsTts object=%p, initial ref_count=1, global_map_size=%zu\n",
            handle_ptr, instance.get(), map_size);

        return handle_ptr;
    } catch (...) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "aws_tts_create: failed to create handle\n");
        return nullptr;
    }
}

void aws_tts_retain(aws_handle_t handle) {
    auto* h = get_handle(handle);
    if (h) {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "aws_tts_retain: handle=%p, ref_count=%d, AwsTts object=%p\n",
            handle, h->ref_count, h->instance.get());
    }
}

void aws_tts_release(aws_handle_t handle) {
    auto* h = get_handle(handle);
    if (!h) return;

    bool should_delete = false;
    void* aws_ptr = nullptr;
    {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count--;
        should_delete = (h->ref_count <= 0);
        aws_ptr = h->instance.get();
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "aws_tts_release: handle=%p, ref_count=%d, AwsTts object=%p%s\n",
            handle, h->ref_count, aws_ptr, should_delete ? " (will delete)" : "");
    }

    if (should_delete) {
        size_t map_size;
        {
            std::lock_guard<std::mutex> lock(g_handle_mutex);
            g_handles.erase(handle);
            map_size = g_handles.size();
        }
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "aws_tts_release: erased handle=%p from global map, triggering destructor for AwsTts=%p, global_map_size=%zu\n",
            handle, aws_ptr, map_size);
    }
}

// Configuration getters
const char* aws_tts_get_voice_name(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getVoiceName().c_str() : "";
}

const char* aws_tts_get_access_key_id(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getAccessKeyId().c_str() : "";
}

const char* aws_tts_get_secret_access_key(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getSecretAccessKey().c_str() : "";
}

const char* aws_tts_get_session_token(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getSessionToken().c_str() : "";
}

const char* aws_tts_get_region(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getRegion().c_str() : "";
}

const char* aws_tts_get_language(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getLanguage().c_str() : "";
}

const char* aws_tts_get_engine(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getEngine().c_str() : "";
}

const char* aws_tts_get_playback_id(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getPlaybackId().c_str() : "";
}

// Result data getters
long aws_tts_get_response_code(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getResponseCode() : 0;
}

const char* aws_tts_get_session_id(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getSessionId().c_str() : "";
}

const char* aws_tts_get_cache_filename(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getCacheFilename().c_str() : "";
}

const char* aws_tts_get_error_message(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getErrorMessage().c_str() : "";
}

// State getters
int aws_tts_get_rate(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getRate() : 8000;
}

int aws_tts_is_draining(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? (p->isDraining() ? 1 : 0) : 0;
}

int aws_tts_get_reads(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getReads() : 0;
}

int aws_tts_is_cache_audio(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? (p->isCacheAudio() ? 1 : 0) : 0;
}

int aws_tts_is_flushed(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? (p->isFlushed() ? 1 : 0) : 0;
}

int aws_tts_is_playback_start_sent(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? (p->isPlaybackStartSent() ? 1 : 0) : 0;
}

// Resource getters
void* aws_tts_get_circular_buffer(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getCircularBuffer() : nullptr;
}

void* aws_tts_get_resampler(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getResampler() : nullptr;
}

FILE* aws_tts_get_file(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getFile() : nullptr;
}

void* aws_tts_get_start_time(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    if (!p) return nullptr;
    // Return a pointer to the start time (for compatibility with existing code)
    return const_cast<void*>(static_cast<const void*>(&p->getStartTime()));
}

// Last byte handling
int aws_tts_has_last_byte(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? (p->hasLastByte() ? 1 : 0) : 0;
}

uint8_t aws_tts_get_last_byte(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->getLastByte() : 0;
}

// Configuration setters
void aws_tts_set_voice_name(aws_handle_t handle, const char* voice_name) {
    auto p = aws_get_shared_ptr(handle);
    if (p && voice_name) p->setVoiceName(voice_name);
}

void aws_tts_set_access_key_id(aws_handle_t handle, const char* key_id) {
    auto p = aws_get_shared_ptr(handle);
    if (p && key_id) p->setAccessKeyId(key_id);
}

void aws_tts_set_secret_access_key(aws_handle_t handle, const char* key) {
    auto p = aws_get_shared_ptr(handle);
    if (p && key) p->setSecretAccessKey(key);
}

void aws_tts_set_session_token(aws_handle_t handle, const char* token) {
    auto p = aws_get_shared_ptr(handle);
    if (p && token) p->setSessionToken(token);
}

void aws_tts_set_region(aws_handle_t handle, const char* region) {
    auto p = aws_get_shared_ptr(handle);
    if (p && region) p->setRegion(region);
}

void aws_tts_set_language(aws_handle_t handle, const char* language) {
    auto p = aws_get_shared_ptr(handle);
    if (p && language) p->setLanguage(language);
}

void aws_tts_set_engine(aws_handle_t handle, const char* engine) {
    auto p = aws_get_shared_ptr(handle);
    if (p && engine) p->setEngine(engine);
}

void aws_tts_set_playback_id(aws_handle_t handle, const char* playback_id) {
    auto p = aws_get_shared_ptr(handle);
    if (p && playback_id) p->setPlaybackId(playback_id);
}

// Result data setters
void aws_tts_set_response_code(aws_handle_t handle, long response_code) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setResponseCode(response_code);
}

void aws_tts_set_session_id(aws_handle_t handle, const char* session_id) {
    auto p = aws_get_shared_ptr(handle);
    if (p && session_id) p->setSessionId(session_id);
}

void aws_tts_set_cache_filename(aws_handle_t handle, const char* cache_filename) {
    auto p = aws_get_shared_ptr(handle);
    if (p && cache_filename) p->setCacheFilename(cache_filename);
}

void aws_tts_set_error_message(aws_handle_t handle, const char* error_msg) {
    auto p = aws_get_shared_ptr(handle);
    if (p && error_msg) p->setErrorMessage(error_msg);
}

// State setters
void aws_tts_set_rate(aws_handle_t handle, int rate) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setRate(rate);
}

void aws_tts_set_draining(aws_handle_t handle, int draining) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setDraining(draining != 0);
}

void aws_tts_set_reads(aws_handle_t handle, int reads) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setReads(reads);
}

void aws_tts_set_cache_audio(aws_handle_t handle, int cache_audio) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setCacheAudio(cache_audio != 0);
}

void aws_tts_set_flushed(aws_handle_t handle, int flushed) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setFlushed(flushed != 0);
}

void aws_tts_set_playback_start_sent(aws_handle_t handle, int sent) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setPlaybackStartSent(sent != 0);
}

// Resource setters
void aws_tts_set_circular_buffer(aws_handle_t handle, void* buffer) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setCircularBuffer(buffer);
}

void aws_tts_set_resampler(aws_handle_t handle, void* resampler) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setResampler(static_cast<SpeexResamplerState*>(resampler));
}

void aws_tts_set_file(aws_handle_t handle, FILE* file) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setFile(file);
}

void aws_tts_set_start_time_now(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    if (p) {
        p->setStartTime(std::chrono::high_resolution_clock::now());
    }
}

// Last byte handling
void aws_tts_set_has_last_byte(aws_handle_t handle, int has) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setHasLastByte(has != 0);
}

void aws_tts_set_last_byte(aws_handle_t handle, uint8_t byte) {
    auto p = aws_get_shared_ptr(handle);
    if (p) p->setLastByte(byte);
}

// Utility
int aws_tts_increment_reads(aws_handle_t handle) {
    auto p = aws_get_shared_ptr(handle);
    return p ? p->incrementReads() : 0;
}

} // extern "C"