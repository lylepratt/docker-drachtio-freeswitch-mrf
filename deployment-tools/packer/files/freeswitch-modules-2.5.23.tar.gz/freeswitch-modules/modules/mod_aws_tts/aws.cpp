#include "aws.hpp"
#include <switch.h>

AwsTts::AwsTts()
    : response_code_(0),
      rate_(8000),
      draining_(false),
      reads_(0),
      cache_audio_(false),
      flushed_(false),
      playback_start_sent_(false),
      circular_buffer_(nullptr),
      resampler_(nullptr),
      file_(nullptr),
      has_last_byte_(false),
      last_byte_(0) {
    // mutex_ is automatically initialized by its constructor
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "AwsTts::AwsTts() - constructor called, object created at %p\n", this);
}

AwsTts::~AwsTts() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "AwsTts::~AwsTts() - destructor called, destroying object at %p\n", this);
    cleanup();
}

std::shared_ptr<AwsTts> AwsTts::create() {
    return std::make_shared<AwsTts>();
}

void AwsTts::reset() {
    std::lock_guard<std::mutex> lock(mutex_);

    // Clear strings
    voice_name_.clear();
    access_key_id_.clear();
    secret_access_key_.clear();
    session_token_.clear();
    region_.clear();
    language_.clear();
    engine_.clear();
    playback_id_.clear();
    session_id_.clear();
    cache_filename_.clear();
    error_message_.clear();

    // Reset values
    response_code_ = 0;
    rate_ = 8000;
    draining_ = false;
    reads_ = 0;
    cache_audio_ = false;
    flushed_ = false;
    playback_start_sent_ = false;
    has_last_byte_ = false;
    last_byte_ = 0;

    // Clean up resources
    cleanup();
}

bool AwsTts::isValid() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return !voice_name_.empty() && !access_key_id_.empty() &&
           !secret_access_key_.empty() && !region_.empty();
}

void AwsTts::cleanup() {
    // Note: This is called from destructor, so mutex may already be locked
    if (file_) {
        fclose(file_);
        file_ = nullptr;
    }

    if (resampler_) {
        speex_resampler_destroy(resampler_);
        resampler_ = nullptr;
    }

    // Note: circular_buffer_ cleanup should be handled by aws_glue.cpp
    // as it knows the actual type
}