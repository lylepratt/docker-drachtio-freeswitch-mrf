# AWS TTS Module Migration Guide

## Overview
This migration addresses the same critical race condition found in mod_azure_tts where session-allocated memory was being accessed by detached threads after the session ended.

## Key Vulnerability Fixed
**Race Condition**: The detached thread at `aws_glue.cpp:295`:
```cpp
std::thread(start_synthesis, pollyClient, dupText, a).detach();
```
This thread receives a raw pointer `a` to session-allocated memory. When the session ends, the memory is freed but the detached thread continues running, causing crashes.

## Changes Made

### File Structure
New files added:
- `aws.hpp` - C++ class definition with proper RAII
- `aws.cpp` - C++ class implementation
- `aws_wrapper.h` - C wrapper interface with opaque handles
- `aws_wrapper.cpp` - Reference-counting wrapper implementation

### Memory Management
- **OLD**: Raw `aws_t*` pointer allocated from session memory pool
- **NEW**: Reference-counted `aws_handle_t` with `std::shared_ptr<AwsTts>`

### Thread Safety
- **OLD**: `std::mutex` embedded in session-allocated struct (freed with session)
- **NEW**: `std::mutex` is member of C++ class that lives via shared_ptr

## Critical Changes Needed

### 1. Update mod_aws_tts.c
Replace all struct access with wrapper function calls:

```c
// OLD
aws_t *a = (aws_t *) sh->private_info;
if (!a) {
    a = switch_core_alloc(sh->memory_pool, sizeof(*a));
    sh->private_info = a;
    memset(a, 0, sizeof(*a));
}
a->voice_name = strdup(voice_name);

// NEW
aws_handle_t handle = (aws_handle_t) sh->private_info;
if (!handle) {
    handle = aws_tts_create();
    sh->private_info = handle;
}
aws_tts_set_voice_name(handle, voice_name);
```

### 2. Update aws_glue.h
```cpp
// OLD
switch_status_t aws_speech_feed_tts(aws_t* aws, char* text, switch_speech_flag_t *flags);

// NEW
switch_status_t aws_speech_feed_tts(aws_handle_t handle, char* text, switch_speech_flag_t *flags);
```

### 3. Update aws_glue.cpp - CRITICAL FIX

**Replace detached thread with protected version:**

```cpp
// OLD - DANGEROUS!
std::thread(start_synthesis, pollyClient, dupText, a).detach();

// NEW - SAFE!
aws_tts_retain(handle);  // Keep alive for thread
std::thread([handle, pollyClient, dupText]() {
    auto aws = aws_get_shared_ptr(handle);
    if (aws) {
        start_synthesis(pollyClient, dupText, aws);
    }
    aws_tts_release(handle);  // Release when thread completes
    free((void*)dupText);
}).detach();
```

**Update start_synthesis function:**
```cpp
// OLD
static void start_synthesis(std::shared_ptr<Aws::Polly::PollyClient> pollyClient, const char* text, aws_t* a)

// NEW
static void start_synthesis(std::shared_ptr<Aws::Polly::PollyClient> pollyClient, const char* text, std::shared_ptr<AwsTts> aws)
```

**Update field access throughout:**
```cpp
// OLD
std::lock_guard<std::mutex> lock(a->mutex);
a->response_code = 200;
if (a->draining) { ... }

// NEW
std::lock_guard<std::mutex> lock(aws->getMutex());
aws->setResponseCode(200);
if (aws->isDraining()) { ... }
```

## Testing Requirements

1. **Stress test rapid session teardown** during TTS synthesis
2. **Verify detached thread completion** - ensure no crashes when sessions end during synthesis
3. **Memory leak testing** with valgrind
4. **Long-running synthesis** - ensure proper cleanup

## Safety Guarantees

1. **Protected detached thread**: The AwsTts object survives until the detached thread completes
2. **Thread-safe mutex**: Mutex is part of the C++ object, not session memory
3. **Reference counting**: Object only deleted when all references are released
4. **Clean shutdown**: No use-after-free crashes during session teardown

This fix eliminates the race condition that was causing crashes when AWS TTS synthesis was interrupted by session cleanup.