#ifndef __MOD_AWS_TTS_H__
#define __MOD_AWS_TTS_H__

#include <switch.h>
#include <speex/speex_resampler.h>

/*
 * We now use an opaque handle type for thread safety.
 * The old aws_t structure is replaced by aws_handle_t
 * which provides reference counting and shared_ptr protection.
 */
#include "aws_wrapper.h"

/* Legacy typedef for compatibility during transition */
typedef aws_handle_t aws_t;

#endif