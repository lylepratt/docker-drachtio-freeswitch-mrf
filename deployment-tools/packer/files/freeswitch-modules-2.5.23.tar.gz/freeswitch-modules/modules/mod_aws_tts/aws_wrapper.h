// aws_wrapper.h - C-compatible header
#ifndef __AWS_WRAPPER_H__
#define __AWS_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct aws_handle* aws_handle_t;

#ifdef __cplusplus
#include <memory>

// Forward declaration
class AwsTts;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<AwsTts> aws_get_shared_ptr(aws_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
aws_handle_t aws_get_handle_from_shared_ptr(const std::shared_ptr<AwsTts>& ptr);

extern "C" {
#endif

// C API functions
aws_handle_t aws_tts_create(void);
void aws_tts_retain(aws_handle_t handle);
void aws_tts_release(aws_handle_t handle);

// Configuration getters
const char* aws_tts_get_voice_name(aws_handle_t handle);
const char* aws_tts_get_access_key_id(aws_handle_t handle);
const char* aws_tts_get_secret_access_key(aws_handle_t handle);
const char* aws_tts_get_session_token(aws_handle_t handle);
const char* aws_tts_get_region(aws_handle_t handle);
const char* aws_tts_get_language(aws_handle_t handle);
const char* aws_tts_get_engine(aws_handle_t handle);
const char* aws_tts_get_playback_id(aws_handle_t handle);

// Result data getters
long aws_tts_get_response_code(aws_handle_t handle);
const char* aws_tts_get_session_id(aws_handle_t handle);
const char* aws_tts_get_cache_filename(aws_handle_t handle);
const char* aws_tts_get_error_message(aws_handle_t handle);

// State getters
int aws_tts_get_rate(aws_handle_t handle);
int aws_tts_is_draining(aws_handle_t handle);
int aws_tts_get_reads(aws_handle_t handle);
int aws_tts_is_cache_audio(aws_handle_t handle);
int aws_tts_is_flushed(aws_handle_t handle);
int aws_tts_is_playback_start_sent(aws_handle_t handle);

// Resource getters
void* aws_tts_get_circular_buffer(aws_handle_t handle);
void* aws_tts_get_resampler(aws_handle_t handle);
FILE* aws_tts_get_file(aws_handle_t handle);
void* aws_tts_get_start_time(aws_handle_t handle);

// Last byte handling
int aws_tts_has_last_byte(aws_handle_t handle);
uint8_t aws_tts_get_last_byte(aws_handle_t handle);

// Configuration setters
void aws_tts_set_voice_name(aws_handle_t handle, const char* voice_name);
void aws_tts_set_access_key_id(aws_handle_t handle, const char* key_id);
void aws_tts_set_secret_access_key(aws_handle_t handle, const char* key);
void aws_tts_set_session_token(aws_handle_t handle, const char* token);
void aws_tts_set_region(aws_handle_t handle, const char* region);
void aws_tts_set_language(aws_handle_t handle, const char* language);
void aws_tts_set_engine(aws_handle_t handle, const char* engine);
void aws_tts_set_playback_id(aws_handle_t handle, const char* playback_id);

// Result data setters
void aws_tts_set_response_code(aws_handle_t handle, long response_code);
void aws_tts_set_session_id(aws_handle_t handle, const char* session_id);
void aws_tts_set_cache_filename(aws_handle_t handle, const char* cache_filename);
void aws_tts_set_error_message(aws_handle_t handle, const char* error_msg);

// State setters
void aws_tts_set_rate(aws_handle_t handle, int rate);
void aws_tts_set_draining(aws_handle_t handle, int draining);
void aws_tts_set_reads(aws_handle_t handle, int reads);
void aws_tts_set_cache_audio(aws_handle_t handle, int cache_audio);
void aws_tts_set_flushed(aws_handle_t handle, int flushed);
void aws_tts_set_playback_start_sent(aws_handle_t handle, int sent);

// Resource setters
void aws_tts_set_circular_buffer(aws_handle_t handle, void* buffer);
void aws_tts_set_resampler(aws_handle_t handle, void* resampler);
void aws_tts_set_file(aws_handle_t handle, FILE* file);
void aws_tts_set_start_time_now(aws_handle_t handle);

// Last byte handling
void aws_tts_set_has_last_byte(aws_handle_t handle, int has);
void aws_tts_set_last_byte(aws_handle_t handle, uint8_t byte);

// Utility
int aws_tts_increment_reads(aws_handle_t handle);

#ifdef __cplusplus
}
#endif

#endif