#include "bug_data.hpp"

namespace drachtio_MAF {

  // Initialize static members
  BugData::mapBug2BugData BugData::m_mapBug2BugData;
  std::mutex BugData::m_mapMutex;

  BugData::BugData(private_t* tech_pvt) : 
    m_sessionId(tech_pvt->sessionId),
    m_id(tech_pvt->id),
    m_resampler(tech_pvt->resampler), 
    m_bidirectional_audio_resampler(tech_pvt->bidirectional_audio_resampler), 
    m_cBuffer(static_cast<CircularBuffer *>(tech_pvt->streamingPlayoutBuffer)),
    m_pVecMarksInInventory(static_cast<std::deque<std::string>*>(tech_pvt->pVecMarksInInventory)), 
    m_pVecMarksInUse(static_cast<std::deque<std::string>*>(tech_pvt->pVecMarksInUse)),
    m_pVecMarksCleared(static_cast<std::deque<std::string>*>(tech_pvt->pVecMarksCleared)) {

    std::lock_guard<std::mutex> lock(m_mapMutex);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "BugData::BugData %s (%u) there are %zu entries\n",
      m_sessionId.c_str(), m_id, m_mapBug2BugData.size());
  }

  BugData::~BugData() {
    // First clean up resources
    if (this->m_resampler) {
      speex_resampler_destroy(this->m_resampler);
    }
    if (this->m_bidirectional_audio_resampler) {
      speex_resampler_destroy(this->m_bidirectional_audio_resampler);
    }
    if (this->m_cBuffer) {
      delete this->m_cBuffer;
    }
    if (this->m_pVecMarksInInventory) {
      delete this->m_pVecMarksInInventory;
    }
    if (this->m_pVecMarksInUse) {
      delete this->m_pVecMarksInUse;
    }
    if (this->m_pVecMarksCleared) {
      delete this->m_pVecMarksCleared;
    }

    // Then log the map size under mutex protection
    std::lock_guard<std::mutex> lock(m_mapMutex);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "BugData::~BugData %s (%u) after deleting there are now %zu entries\n",
      m_sessionId.c_str(), m_id, m_mapBug2BugData.size());
  }

  // static methods
  std::shared_ptr<BugData> BugData::add(private_t* tech_pvt, void *bug) {
    std::shared_ptr<BugData> bugData = std::make_shared<BugData>(tech_pvt);
    std::lock_guard<std::mutex> lock(m_mapMutex);
    m_mapBug2BugData[bug] = bugData;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "BugData::add - after add bug, there are now %zu entries\n", m_mapBug2BugData.size());
    return bugData;
  }

  std::shared_ptr<BugData> BugData::find(void *bug) {
    std::lock_guard<std::mutex> lock(m_mapMutex);
    auto it = m_mapBug2BugData.find(bug);
    if (it != m_mapBug2BugData.end()) {
      return it->second;
    }
    return nullptr;
  }

  std::shared_ptr<BugData> BugData::remove(void *bug) {
    std::lock_guard<std::mutex> lock(m_mapMutex);
    auto it = m_mapBug2BugData.find(bug);
    if (it != m_mapBug2BugData.end()) {
      auto bugData = it->second;
      m_mapBug2BugData.erase(it);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "BugData::remove - after remove bug, there are now %zu entries\n", m_mapBug2BugData.size());
      return bugData;
    }
    return nullptr;
  }
}

