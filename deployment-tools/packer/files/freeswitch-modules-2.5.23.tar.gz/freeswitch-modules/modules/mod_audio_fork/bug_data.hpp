#ifndef BUG_DATA_HPP
#define BUG_DATA_HPP

#include "jambonz/circular_buffer.h"
#include "mod_audio_fork.h"

#include <memory>
#include <string>
#include <unordered_map>
#include <deque>
#include <mutex>

namespace drachtio_MAF {

  class BugData : public std::enable_shared_from_this<BugData> {
    public:
      BugData(private_t* tech_pvt);
      ~BugData();

      static std::shared_ptr<BugData> add(private_t* tech_pvt, void *bug);
      static std::shared_ptr<BugData> find(void *bug);
      static std::shared_ptr<BugData> remove(void *bug);

    protected:
      typedef std::unordered_map<void*, std::shared_ptr<BugData> > mapBug2BugData;
      static mapBug2BugData m_mapBug2BugData;
      static std::mutex m_mapMutex;
    
    private:
      std::string m_sessionId;
      unsigned int m_id;
      
      SpeexResamplerState *m_resampler;
      SpeexResamplerState *m_bidirectional_audio_resampler;
      CircularBuffer *m_cBuffer;
      std::deque<std::string>* m_pVecMarksInInventory;
      std::deque<std::string>* m_pVecMarksInUse;
      std::deque<std::string>* m_pVecMarksCleared;
  };
}

#endif