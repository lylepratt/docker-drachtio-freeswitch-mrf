// deepgram_wrapper.h - C-compatible header
#ifndef __DEEPGRAM_WRAPPER_H__
#define __DEEPGRAM_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct deepgram_handle* deepgram_handle_t;

#ifdef __cplusplus
#include <memory>

// Forward declaration
class Deepgram;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<Deepgram> deepgram_get_shared_ptr(deepgram_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
deepgram_handle_t deepgram_get_handle_from_shared_ptr(const std::shared_ptr<Deepgram>& ptr);

extern "C" {
#endif

// C API functions
deepgram_handle_t deepgram_create(void);
void deepgram_retain(deepgram_handle_t handle);
void deepgram_release(deepgram_handle_t handle);

// Getters - C-style interface
const char* deepgram_get_voice_name(deepgram_handle_t handle);
const char* deepgram_get_api_key(deepgram_handle_t handle);
const char* deepgram_get_endpoint(deepgram_handle_t handle);

// Result data getters
long deepgram_get_response_code(deepgram_handle_t handle);
const char* deepgram_get_content_type(deepgram_handle_t handle);
const char* deepgram_get_reported_model_name(deepgram_handle_t handle);
const char* deepgram_get_reported_model_uuid(deepgram_handle_t handle);
const char* deepgram_get_reported_char_count(deepgram_handle_t handle);
const char* deepgram_get_request_id(deepgram_handle_t handle);
const char* deepgram_get_name_lookup_time_ms(deepgram_handle_t handle);
const char* deepgram_get_connect_time_ms(deepgram_handle_t handle);
const char* deepgram_get_final_response_time_ms(deepgram_handle_t handle);
const char* deepgram_get_error_message(deepgram_handle_t handle);
const char* deepgram_get_cache_filename(deepgram_handle_t handle);
const char* deepgram_get_session_id(deepgram_handle_t handle);

// State getters
int deepgram_get_rate(deepgram_handle_t handle);
int deepgram_is_draining(deepgram_handle_t handle);
int deepgram_get_reads(deepgram_handle_t handle);
int deepgram_is_cache_audio(deepgram_handle_t handle);
int deepgram_is_playback_start_sent(deepgram_handle_t handle);

// Resource getters
void* deepgram_get_connection(deepgram_handle_t handle);
void* deepgram_get_audio_player(deepgram_handle_t handle);
void* deepgram_get_playout_buffer(deepgram_handle_t handle);
// Mutex getter removed - std::mutex is now managed internally by Deepgram class
FILE* deepgram_get_file(deepgram_handle_t handle);
const char* deepgram_get_playback_id(deepgram_handle_t handle);

// Setters
void deepgram_set_voice_name(deepgram_handle_t handle, const char* voice_name);
void deepgram_set_api_key(deepgram_handle_t handle, const char* api_key);
void deepgram_set_endpoint(deepgram_handle_t handle, const char* endpoint);

// Result data setters
void deepgram_set_response_code(deepgram_handle_t handle, long response_code);
void deepgram_set_content_type(deepgram_handle_t handle, const char* content_type);
void deepgram_set_reported_model_name(deepgram_handle_t handle, const char* model_name);
void deepgram_set_reported_model_uuid(deepgram_handle_t handle, const char* model_uuid);
void deepgram_set_reported_char_count(deepgram_handle_t handle, const char* char_count);
void deepgram_set_request_id(deepgram_handle_t handle, const char* request_id);
void deepgram_set_name_lookup_time_ms(deepgram_handle_t handle, const char* time_ms);
void deepgram_set_connect_time_ms(deepgram_handle_t handle, const char* time_ms);
void deepgram_set_final_response_time_ms(deepgram_handle_t handle, const char* time_ms);
void deepgram_set_error_message(deepgram_handle_t handle, const char* error_msg);
void deepgram_set_cache_filename(deepgram_handle_t handle, const char* cache_filename);
void deepgram_set_session_id(deepgram_handle_t handle, const char* session_id);

// State setters
void deepgram_set_rate(deepgram_handle_t handle, int rate);
void deepgram_set_draining(deepgram_handle_t handle, int draining);
void deepgram_set_reads(deepgram_handle_t handle, int reads);
void deepgram_set_cache_audio(deepgram_handle_t handle, int cache_audio);
void deepgram_set_playback_start_sent(deepgram_handle_t handle, int playback_start_sent);

// Resource setters
void deepgram_set_connection(deepgram_handle_t handle, void* conn);
void deepgram_set_audio_player(deepgram_handle_t handle, void* audio_player);
void deepgram_set_playout_buffer(deepgram_handle_t handle, void* playout_buffer);
void deepgram_set_file(deepgram_handle_t handle, FILE* file);
void deepgram_set_playback_id(deepgram_handle_t handle, const char* playback_id);

// Mutex initialization
// Mutex initialization removed - std::mutex is now managed internally by Deepgram class

#ifdef __cplusplus
}
#endif

#endif