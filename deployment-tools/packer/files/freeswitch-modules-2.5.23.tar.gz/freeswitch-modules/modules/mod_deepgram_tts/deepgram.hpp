#ifndef __DEEPGRAM_HPP__
#define __DEEPGRAM_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <memory>
#include <string>
#include <mutex>

class Deepgram {
private:
    std::string voice_name_;
    std::string api_key_;
    std::string endpoint_;

    // Result data
    long response_code_;
    std::string content_type_;
    std::string reported_model_name_;
    std::string reported_model_uuid_;
    std::string reported_char_count_;
    std::string request_id_;
    std::string name_lookup_time_ms_;
    std::string connect_time_ms_;
    std::string final_response_time_ms_;
    std::string error_message_;
    std::string cache_filename_;
    std::string session_id_;

    // State
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;

    // Resources
    void* connection_;
    void* audio_player_;
    void* playout_buffer_;
    mutable std::mutex mutex_;  // Now a member object, not a pointer
    FILE* file_;
    std::string playback_id_;

    // Private constructor to enforce shared_ptr usage
    Deepgram();

public:
    ~Deepgram();
    
    // Factory method
    static std::shared_ptr<Deepgram> create();
    
    // Getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getApiKey() const { return api_key_; }
    const std::string& getEndpoint() const { return endpoint_; }
    
    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getContentType() const { return content_type_; }
    const std::string& getReportedModelName() const { return reported_model_name_; }
    const std::string& getReportedModelUuid() const { return reported_model_uuid_; }
    const std::string& getReportedCharCount() const { return reported_char_count_; }
    const std::string& getRequestId() const { return request_id_; }
    const std::string& getNameLookupTimeMs() const { return name_lookup_time_ms_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFinalResponseTimeMs() const { return final_response_time_ms_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    const std::string& getSessionId() const { return session_id_; }
    
    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }
    
    // Resource getters
    void* getConnection() const { return connection_; }
    void* getAudioPlayer() const { return audio_player_; }
    void* getPlayoutBuffer() const { return playout_buffer_; }
    std::mutex& getMutex() const { return mutex_; }  // Return reference to mutex
    FILE* getFile() const { return file_; }
    const std::string& getPlaybackId() const { return playback_id_; }
    
    // Setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setApiKey(const std::string& api_key) { api_key_ = api_key; }
    void setEndpoint(const std::string& endpoint) { endpoint_ = endpoint; }
    
    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setContentType(const std::string& content_type) { content_type_ = content_type; }
    void setReportedModelName(const std::string& model_name) { reported_model_name_ = model_name; }
    void setReportedModelUuid(const std::string& model_uuid) { reported_model_uuid_ = model_uuid; }
    void setReportedCharCount(const std::string& char_count) { reported_char_count_ = char_count; }
    void setRequestId(const std::string& request_id) { request_id_ = request_id; }
    void setNameLookupTimeMs(const std::string& time_ms) { name_lookup_time_ms_ = time_ms; }
    void setConnectTimeMs(const std::string& time_ms) { connect_time_ms_ = time_ms; }
    void setFinalResponseTimeMs(const std::string& time_ms) { final_response_time_ms_ = time_ms; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    
    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setPlaybackStartSent(bool playback_start_sent) { playback_start_sent_ = playback_start_sent; }
    
    // Resource setters
    void setConnection(void* conn) { connection_ = conn; }
    void setAudioPlayer(void* audio_player) { audio_player_ = audio_player; }
    void setPlayoutBuffer(void* playout_buffer) { playout_buffer_ = playout_buffer; }
    void setFile(FILE* file) { file_ = file; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }
    
    // Mutex initialization removed - std::mutex doesn't need explicit initialization
};

#endif