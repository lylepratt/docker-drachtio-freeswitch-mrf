#include "deepgram.hpp"

Deepgram::Deepgram()
    : response_code_(0)
    , rate_(8000)
    , draining_(false)
    , reads_(0)
    , cache_audio_(false)
    , playback_start_sent_(false)
    , connection_(nullptr)
    , audio_player_(nullptr)
    , playout_buffer_(nullptr)
    // mutex_ is automatically initialized by std::mutex default constructor
    , file_(nullptr) {
}

Deepgram::~Deepgram() {
    // Cleanup is handled by FreeSWITCH memory pools and explicit cleanup calls
}

std::shared_ptr<Deepgram> Deepgram::create() {
    // Use std::shared_ptr constructor that can access private constructor
    return std::shared_ptr<Deepgram>(new Deepgram());
}

// Mutex initialization removed - std::mutex is automatically initialized in constructor