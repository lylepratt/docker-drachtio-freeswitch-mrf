#include "deepgram_wrapper.h"
#include "deepgram.hpp"
#include "deepgram_glue.h"
#include <switch.h>
#include <switch_json.h>
#include <curl/curl.h>
#include <cstdlib>

#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/bind/bind.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>
#include <boost/asio.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/algorithm/string.hpp>

#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

/* Global information, common to all connections */
typedef struct
{
  CURLM *multi;
  int still_running;
} GlobalInfo_t;
static GlobalInfo_t global;

/* Information associated with a specific easy handle */
typedef struct
{
  CURL *easy;
  deepgram_handle_t deepgram_handle;  // Changed from pointer to handle
  std::shared_ptr<Deepgram> deepgram; // Keep shared_ptr for async operations
  char* body;
  struct curl_slist *hdr_list;
  GlobalInfo_t *global;
  char error[CURL_ERROR_SIZE];
  std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
  bool flushed;

  bool has_last_byte;
  uint8_t last_byte;
} ConnInfo_t;


static std::map<curl_socket_t, boost::asio::ip::tcp::socket *> socket_map;
static boost::asio::io_service io_service;
static boost::asio::deadline_timer timer(io_service);
static std::string fullDirPath;
static std::thread worker_thread;
static std::mutex curl_mutex;
static bool profile_write_cb = false;

std::string secondsToMillisecondsString(double seconds) {
    // Convert to milliseconds
    double milliseconds = seconds * 1000.0;

    // Truncate to remove fractional part
    long milliseconds_long = static_cast<long>(milliseconds);

    // Convert to string
    return std::to_string(milliseconds_long);
}

static std::string getEnvVar(const std::string& varName) {
    const char* val = std::getenv(varName.c_str());
    return val ? std::string(val) : "";
}

static long getConnectionTimeout() {
    std::string connectTimeoutStr = getEnvVar("DEEPGRAM_TTS_CURL_CONNECT_TIMEOUT");

    if (connectTimeoutStr.empty()) {
        connectTimeoutStr = getEnvVar("TTS_CURL_CONNECT_TIMEOUT");
    }

    long connectTimeout = 10L;

    if (!connectTimeoutStr.empty()) {
        connectTimeout = std::stol(connectTimeoutStr);
    }

    return connectTimeout;
}

static long getLowSpeedTimeout() {
  std::string lowSpeedTimeoutStr = getEnvVar("DEEPGRAM_TTS_CURL_LOW_SPEED_TIMEOUT");

  long lowSpeedTimeout = 5L;

  if (!lowSpeedTimeoutStr.empty()) {
      lowSpeedTimeout = std::stol(lowSpeedTimeoutStr);
  }

  return lowSpeedTimeout;
}

static void logCurlTimingDetails(CURL* easy, const char* context, const char* session_id) {
    if (!easy) return;

    double namelookup = 0, connect = 0, appconnect = 0, pretransfer = 0, redirect = 0, starttransfer = 0, total = 0;
    curl_off_t speed_download = 0, speed_upload = 0;
    long header_size = 0, request_size = 0;

    curl_easy_getinfo(easy, CURLINFO_NAMELOOKUP_TIME, &namelookup);
    curl_easy_getinfo(easy, CURLINFO_CONNECT_TIME, &connect);
    curl_easy_getinfo(easy, CURLINFO_APPCONNECT_TIME, &appconnect);
    curl_easy_getinfo(easy, CURLINFO_PRETRANSFER_TIME, &pretransfer);
    curl_easy_getinfo(easy, CURLINFO_REDIRECT_TIME, &redirect);
    curl_easy_getinfo(easy, CURLINFO_STARTTRANSFER_TIME, &starttransfer);
    curl_easy_getinfo(easy, CURLINFO_TOTAL_TIME, &total);
    curl_easy_getinfo(easy, CURLINFO_SPEED_DOWNLOAD_T, &speed_download);
    curl_easy_getinfo(easy, CURLINFO_SPEED_UPLOAD_T, &speed_upload);
    curl_easy_getinfo(easy, CURLINFO_HEADER_SIZE, &header_size);
    curl_easy_getinfo(easy, CURLINFO_REQUEST_SIZE, &request_size);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s mod_deepgram_tts: %s - Timing details:\n"
        "  DNS lookup: %.3fs\n"
        "  Connect: %.3fs\n"
        "  SSL handshake: %.3fs\n"
        "  Pre-transfer: %.3fs\n"
        "  Start transfer: %.3fs\n"
        "  Total: %.3fs\n"
        "  Download speed: %ld bytes/sec\n"
        "  Upload speed: %ld bytes/sec\n"
        "  Header size: %ld bytes\n"
        "  Request size: %ld bytes\n",
        session_id ? session_id : "", context, namelookup, connect, appconnect, pretransfer,
        starttransfer, total, speed_download, speed_upload, header_size, request_size);
}

static CURL* createEasyHandle(void) {
  CURL* easy = curl_easy_init();
  if(!easy) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: curl_easy_init() failed!\n");
    return nullptr ;
  }  

  curl_easy_setopt(easy, CURLOPT_FOLLOWLOCATION, 1L);
  curl_easy_setopt(easy, CURLOPT_USERAGENT, "jambonz/0.8.5");

  // set connect timeout to 3 seconds and total timeout to 109 seconds
  curl_easy_setopt(easy, CURLOPT_CONNECTTIMEOUT_MS, 3000L);
  curl_easy_setopt(easy, CURLOPT_TIMEOUT, getConnectionTimeout());

  // Set only if environment variable is defined
  std::string lowSpeedTimeoutStr = getEnvVar("DEEPGRAM_TTS_CURL_LOW_SPEED_TIMEOUT");
  if (!lowSpeedTimeoutStr.empty()) {
    curl_easy_setopt(easy, CURLOPT_LOW_SPEED_LIMIT, 1L);
    curl_easy_setopt(easy, CURLOPT_LOW_SPEED_TIME, std::stol(lowSpeedTimeoutStr));
  }

  return easy ;    
}

static void send_playback_start_event(deepgram_handle_t handle, switch_channel_t *channel, const char* time_to_first_byte_ms) {
    const char* session_id = deepgram_get_session_id(handle);
    if (!channel) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s send_playback_start_event: channel is null\n",
                          session_id ? session_id : "");
        return;
    }

    switch_event_t *event;
    if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) != SWITCH_STATUS_SUCCESS) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s send_playback_start_event: failed to create event\n",
                          session_id ? session_id : "");
        return;
    }

    switch_channel_event_set_data(channel, event);
    const char* playback_id = deepgram_get_playback_id(handle);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s send_playback_start_event: firing playback-started %s\n",
                      session_id ? session_id : "", playback_id ? playback_id : "no-playback-id");

    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
    if (playback_id) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
    }
    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms);

    // Add vendor-specific headers
    const char* reported_model_name = deepgram_get_reported_model_name(handle);
    if (reported_model_name && strlen(reported_model_name) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_reported_model_name", reported_model_name);
    }
    const char* reported_model_uuid = deepgram_get_reported_model_uuid(handle);
    if (reported_model_uuid && strlen(reported_model_uuid) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_reported_model_uuid", reported_model_uuid);
    }
    const char* reported_char_count = deepgram_get_reported_char_count(handle);
    if (reported_char_count && strlen(reported_char_count) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_reported_char_count", reported_char_count);
    }
    const char* request_id = deepgram_get_request_id(handle);
    if (request_id && strlen(request_id) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_request_id", request_id);
    }
    const char* name_lookup_time_ms = deepgram_get_name_lookup_time_ms(handle);
    if (name_lookup_time_ms && strlen(name_lookup_time_ms) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_name_lookup_time_ms", name_lookup_time_ms);
    }
    const char* connect_time_ms = deepgram_get_connect_time_ms(handle);
    if (connect_time_ms && strlen(connect_time_ms) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_connect_time_ms", connect_time_ms);
    }
    const char* final_response_time_ms = deepgram_get_final_response_time_ms(handle);
    if (final_response_time_ms && strlen(final_response_time_ms) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_final_response_time_ms", final_response_time_ms);
    }
    const char* voice_name = deepgram_get_voice_name(handle);
    if (voice_name && strlen(voice_name) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_voice_name", voice_name);
    }
    const char* cache_filename = deepgram_get_cache_filename(handle);
    if (cache_filename && strlen(cache_filename) > 0) {
        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);
    }

    switch_event_fire(&event);
    deepgram_set_playback_start_sent(handle, 1);
}

static void cleanupConn(ConnInfo_t *conn) {
  // Use shared_ptr to ensure thread-safe access
  auto p = conn->deepgram;
  if (!p) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "mod_deepgram_tts: cleanupConn: deepgram shared_ptr is null\n");
    curl_easy_cleanup(conn->easy);
    memset(conn, 0, sizeof(ConnInfo_t));
    delete conn;
    return;
  }

  if( conn->hdr_list ) {
    curl_slist_free_all(conn->hdr_list);
    conn->hdr_list = nullptr ;
  }
  curl_easy_cleanup(conn->easy);

  p->setConnection(nullptr);
  p->setDraining(true);

  // CRITICAL: Release the handle that was retained in deepgram_speech_feed_tts
  if (conn->deepgram_handle) {
    deepgram_release(conn->deepgram_handle);
    conn->deepgram_handle = nullptr;
  }

  memset(conn, 0, sizeof(ConnInfo_t));
  delete conn;
}

/* Check for completed transfers, and remove their easy handles */
void check_multi_info(GlobalInfo_t *g) {
  CURLMsg *msg;
  int msgs_left;
  ConnInfo_t *conn;
  CURL *easy;
  CURLcode res;
  
  while((msg = curl_multi_info_read(g->multi, &msgs_left))) {
    if(msg->msg == CURLMSG_DONE) {
      long response_code;
      double namelookup=0, connect=0, total=0 ;
      char *ct = NULL ;

      easy = msg->easy_handle;
      res = msg->data.result;
      curl_easy_getinfo(easy, CURLINFO_PRIVATE, &conn);
      curl_easy_getinfo(easy, CURLINFO_RESPONSE_CODE, &response_code);
      curl_easy_getinfo(easy, CURLINFO_CONTENT_TYPE, &ct);

      curl_easy_getinfo(easy, CURLINFO_NAMELOOKUP_TIME, &namelookup);
      curl_easy_getinfo(easy, CURLINFO_CONNECT_TIME, &connect);
      curl_easy_getinfo(easy, CURLINFO_TOTAL_TIME, &total);

      // Use shared_ptr for thread-safe access
      auto p = conn->deepgram;
      if (!p) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: check_multi_info: deepgram shared_ptr is null\n");
        curl_multi_remove_handle(g->multi, easy);
        cleanupConn(conn);
        continue;
      }
      
      // Log curl errors, especially timeout and low speed related ones
      if (res != CURLE_OK) {
        const char* error_msg = curl_easy_strerror(res);

        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
          "mod_deepgram_tts: CURL error [%d]: %s - %s (session-id: %s)\n",
          res, error_msg, conn->error, p->getSessionId().c_str());

        // Log detailed timing information for debugging
        logCurlTimingDetails(easy, "Error Analysis", p->getSessionId().c_str());
        
        // Specific handling for timeout and low speed errors
        switch(res) {
          case CURLE_OPERATION_TIMEDOUT:
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
              "mod_deepgram_tts: Operation timeout on session %s - total time: %.3fs, connect time: %.3fs\n", 
              !p->getSessionId().empty() ? p->getSessionId().c_str() : "unknown", total, connect);
            break;
          case CURLE_SEND_ERROR:
          case CURLE_RECV_ERROR:
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
              "mod_deepgram_tts: Network send/receive error during transfer for session %s\n", 
              !p->getSessionId().empty() ? p->getSessionId().c_str() : "unknown");
            break;
          case CURLE_COULDNT_CONNECT:
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
              "mod_deepgram_tts: Connection failed for session %s - connect time: %.3fs\n", 
              !p->getSessionId().empty() ? p->getSessionId().c_str() : "unknown", connect);
            break;
          case CURLE_PARTIAL_FILE:
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, 
              "mod_deepgram_tts: Partial file transfer for session %s - possible timeout or connection issue\n", 
              !p->getSessionId().empty() ? p->getSessionId().c_str() : "unknown");
            break;
          default:
            // Log other errors that might be related to connectivity/timing
            if (res >= CURLE_UNSUPPORTED_PROTOCOL && res <= CURLE_UNKNOWN_OPTION) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
                "mod_deepgram_tts: CURL error details for session %s - DNS: %.3fs, Connect: %.3fs, Total: %.3fs\n",
                !p->getSessionId().empty() ? p->getSessionId().c_str() : "unknown", namelookup, connect, total);
            }
            break;
        }
      }

      p->setResponseCode(response_code);
      if (ct) p->setContentType(ct);

      std::string name_lookup_ms = secondsToMillisecondsString(namelookup);
      std::string connect_ms = secondsToMillisecondsString(connect);
      std::string final_response_time_ms = secondsToMillisecondsString(total);

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
        "%s mod_deepgram_tts: response: %ld, content-type %s,"
        "dns(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
        "connect(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
        "total(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld\n", p->getSessionId().c_str(),
        response_code, ct,
        (long)(namelookup), (long)(fmod(namelookup, 1.0) * 1000000),
        (long)(connect), (long)(fmod(connect, 1.0) * 1000000),
        (long)(total), (long)(fmod(total, 1.0) * 1000000));

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s mod_deepgram_tts: name lookup time: %s\n", p->getSessionId().c_str(), name_lookup_ms.c_str());
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s mod_deepgram_tts: connect time: %s\n", p->getSessionId().c_str(), connect_ms.c_str());
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s mod_deepgram_tts: final response time: %s\n", p->getSessionId().c_str(), final_response_time_ms.c_str());

      p->setNameLookupTimeMs(name_lookup_ms);
      p->setConnectTimeMs(connect_ms);
      p->setFinalResponseTimeMs(final_response_time_ms);

      curl_multi_remove_handle(g->multi, easy);
      cleanupConn(conn);
    }
  }
}

int mcode_test(const char *where, CURLMcode code) {
  if(CURLM_OK != code) {
    const char *s;
    switch(code) {
    case CURLM_CALL_MULTI_PERFORM:
      s = "CURLM_CALL_MULTI_PERFORM";
      break;
    case CURLM_BAD_HANDLE:
      s = "CURLM_BAD_HANDLE";
      break;
    case CURLM_BAD_EASY_HANDLE:
      s = "CURLM_BAD_EASY_HANDLE";
      break;
    case CURLM_OUT_OF_MEMORY:
      s = "CURLM_OUT_OF_MEMORY";
      break;
    case CURLM_INTERNAL_ERROR:
      s = "CURLM_INTERNAL_ERROR";
      break;
    case CURLM_UNKNOWN_OPTION:
      s = "CURLM_UNKNOWN_OPTION";
      break;
    case CURLM_LAST:
      s = "CURLM_LAST";
      break;
    default:
      s = "CURLM_unknown";
      break;
    case CURLM_BAD_SOCKET:
      s = "CURLM_BAD_SOCKET";
      break;
    }
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: mcode_test ERROR: %s returns %s:%d\n", where, s, code);

    return -1;
  }
  return 0 ;
}

static void remsock(int *f, GlobalInfo_t *g) {
  if(f) {
    free(f);
    f = NULL;
  }
}

/* Called by asio when there is an action on a socket */
static void event_cb(GlobalInfo_t *g, curl_socket_t s, int action, const boost::system::error_code & error, int *fdp) {
  int f = *fdp;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X has action %d\n", s, action) ; 

  // Socket already POOL REMOVED.
  if (f == CURL_POLL_REMOVE) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X removed\n", s); 
    remsock(fdp, g);
    return;
  }

  if(socket_map.find(s) == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb: socket  %#X already closed\n, s");
    return;
  }

  /* make sure the event matches what are wanted */
  if(f == action || f == CURL_POLL_INOUT) {
    if(error) {
      action = CURL_CSELECT_ERR;
    }
    
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, s, action, &g->still_running);

    mcode_test("event_cb: curl_multi_socket_action", rc);
    check_multi_info(g);

    if(g->still_running <= 0) {
      timer.cancel();
    }

    /* keep on watching.
      * the socket may have been closed and/or fdp may have been changed
      * in curl_multi_socket_action(), so check them both */
    if(!error && socket_map.find(s) != socket_map.end() &&
        (f == action || f == CURL_POLL_INOUT)) {
      boost::asio::ip::tcp::socket *tcp_socket = socket_map.find(s)->second;

      if(action == CURL_POLL_IN) {
        tcp_socket->async_read_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                                action, boost::placeholders::_1, fdp));
      }
      if(action == CURL_POLL_OUT) {
        tcp_socket->async_write_some(boost::asio::null_buffers(),
                                      boost::bind(&event_cb, g, s,
                                                  action, boost::placeholders::_1, fdp));
      } 
    }
  }
}

/* socket functions */
static void setsock(int *fdp, curl_socket_t s, CURL *e, int act, int oldact, GlobalInfo_t *g) {
  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(s);

  if(it == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "setsock: socket  %#X not found\n, s");
    return;
  }

  boost::asio::ip::tcp::socket * tcp_socket = it->second;

  *fdp = act;

  if(act == CURL_POLL_IN) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_OUT) {
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_INOUT) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
}

static void addsock(curl_socket_t s, CURL *easy, int action, GlobalInfo_t *g) {
  /* fdp is used to store current action */
  int *fdp = (int *) calloc(sizeof(int), 1);

  setsock(fdp, s, easy, action, 0, g);
  curl_multi_assign(g->multi, s, fdp);
}

static int sock_cb(CURL *e, curl_socket_t s, int what, void *cbp, void *sockp) {
  GlobalInfo_t *g = &global;

  int *actionp = (int *) sockp;
  static const char *whatstr[] = { "none", "IN", "OUT", "INOUT", "REMOVE"};

  if(what == CURL_POLL_REMOVE) {
    *actionp = what;
  }
  else {
    if(!actionp) {
      addsock(s, e, what, g);
    }
    else {
      setsock(actionp, s, e, what, *actionp, g);
    }
  }
  return 0;  
}

static void threadFunc() {
  /* to make sure the event loop doesn't terminate when there is no work to do */
  io_service.reset() ;
  boost::asio::io_service::work work(io_service);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgram_tts: threadFunc - starting\n");

  for(;;) {

    try {
      io_service.run() ;
      break ;
    }
    catch( std::exception& e) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: threadFunc - Error: %s\n", e.what());
    }
  }
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgram_tts: threadFunc - ending\n");
}


/* Called by asio when our timeout expires */
static void timer_cb(const boost::system::error_code & error, GlobalInfo_t *g)
{
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "timer_cb\n");

  if(!error) {
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, CURL_SOCKET_TIMEOUT, 0, &g->still_running);

    mcode_test("timer_cb: curl_multi_socket_action", rc);
    check_multi_info(g);
  }
}

int multi_timer_cb(CURLM *multi, long timeout_ms, GlobalInfo_t *g) {

  /* cancel running timer */
  timer.cancel();

  if(timeout_ms >= 0) {
    // from libcurl 7.88.1-10+deb12u4 does not allow call curl_multi_socket_action or curl_multi_perform in curl_multi callback directly
    timer.expires_from_now(boost::posix_time::millisec(timeout_ms ? timeout_ms : 1));
    timer.async_wait(boost::bind(&timer_cb, boost::placeholders::_1, g));
  }

  return 0;
}

/* CURLOPT_WRITEFUNCTION */
static size_t write_cb(void *ptr, size_t size, size_t nmemb, ConnInfo_t *conn) {
  std::chrono::high_resolution_clock::time_point start_time;
  if (profile_write_cb) {
    start_time = std::chrono::high_resolution_clock::now();
  }

  const char *data = (const char *) ptr;
  size_t bytes_received = size * nmemb;
  size_t total_bytes_to_process = bytes_received;
  auto p = conn->deepgram;
  if (!p) return 0;
  bool fireEvent = false;
  AudioPlayer *pAudioPlayer = (AudioPlayer *) p->getAudioPlayer();


  if (conn->flushed) {
    /* this will abort the transfer */
    return 0;
  }

  if (pAudioPlayer == nullptr) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "%s write_cb: audio player is null, aborting transfer\n",
                      p->getSessionId().c_str());
    return 0;
  }

  // Buffer to hold combined data if there is unprocessed byte from the last call.
  std::unique_ptr<char[]> combinedData;

  if (conn->has_last_byte) {
    conn->has_last_byte = false;  // We'll handle the last_byte now, so toggle the flag off

    // Allocate memory for the new data array
    combinedData.reset(new char[bytes_received + 1]);

    // Prepend the last byte from previous call
    combinedData[0] = conn->last_byte;

    // Copy the new data following the prepended byte
    memcpy(combinedData.get() + 1, data, bytes_received);

    // Point our data pointer to the new array
    data = combinedData.get();

    total_bytes_to_process = bytes_received + 1;
  }

  // If we now have an odd total, save the last byte for next time
  if ((total_bytes_to_process % sizeof(int16_t)) != 0) {
    conn->last_byte = data[total_bytes_to_process - 1];
    conn->has_last_byte = true;
    total_bytes_to_process--;
  }

  if (p->getResponseCode() > 0 && p->getResponseCode() != 200) {
    std::string body((char *) ptr, bytes_received);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: received error body %s\n",
                      p->getSessionId().c_str(), body.c_str());
    p->setErrorMessage(body);
    return 0;
  }

  int reads = p->getReads();
  p->setReads(reads + 1);
  if (0 == reads) {
    fireEvent = true;
    // Deepgram return PCM linear16 WAV file which contains 44 bytes headers, remove that.
    data += 44;
    total_bytes_to_process -= 44;
  }

  {
    std::lock_guard<std::mutex> lock(p->getMutex());

    // buffer audio under mutex lock to make sure we don't add data to freed buffer.
    if (p->getAudioPlayer()) {
      pAudioPlayer = (AudioPlayer *) p->getAudioPlayer();
      pAudioPlayer->bufferAudio(data, total_bytes_to_process);
    }
  }

  if (fireEvent && !p->getSessionId().empty()) {
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - conn->startTime);
    auto time_to_first_byte_ms = std::to_string(duration.count());
    switch_core_session_t* session = switch_core_session_locate(p->getSessionId().c_str());
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_core_session_rwunlock(session);
      if (channel) {
        send_playback_start_event(conn->deepgram_handle, channel, time_to_first_byte_ms.c_str());
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s, write_cb: channel not found\n", p->getSessionId().c_str());
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: session not found\n", p->getSessionId().c_str());
    }
  }

  if (profile_write_cb) {
    auto end_time = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end_time - start_time);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
      "write_cb: session %s, %zu bytes, %ld us, reads=%d\n",
      p->getSessionId().c_str(), bytes_received, duration.count(), p->getReads());
  }

  return bytes_received;
}

static bool parseHeader(const std::string& str, std::string& header, std::string& value) {
    std::vector<std::string> parts;
    boost::split(parts, str, boost::is_any_of(":"), boost::token_compress_on);

    if (parts.size() != 2)
        return false;

    header = boost::trim_copy(parts[0]);
    value = boost::trim_copy(parts[1]);
    return true;
}

static int extract_response_code(const std::string& input) {
  std::size_t space_pos = input.find(' ');
  if (space_pos == std::string::npos) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: Invalid HTTP response format %s\n", input.c_str());
    return 0;
  }

  std::size_t code_start_pos = space_pos + 1;
  std::size_t code_end_pos = input.find(' ', code_start_pos);
  if (code_end_pos == std::string::npos) {
    code_end_pos = input.length();
  }

  std::string code_str = input.substr(code_start_pos, code_end_pos - code_start_pos);
  int response_code = std::stoi(code_str);
  return response_code;
}

static size_t header_callback(char *buffer, size_t size, size_t nitems, ConnInfo_t *conn) {
  size_t bytes_received = size * nitems;
  const std::string prefix = "HTTP/";
  auto p = conn->deepgram;
  if (!p) return bytes_received;
  std::string header, value;
  std::string input(buffer, bytes_received);
  if (parseHeader(input, header, value)) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s recv header: %s with value %s\n", p->getSessionId().c_str(), header.c_str(), value.c_str());
    if (0 == header.compare("dg-request-id")) p->setRequestId(value);
    else if (0 == header.compare("dg-model-name")) p->setReportedModelName(value);
    else if (0 == header.compare("dg-model-uuid")) p->setReportedModelUuid(value);
    else if (0 == header.compare("dg-char-count")) p->setReportedCharCount(value);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s header_callback: %s\n",  p->getSessionId().c_str(), input.c_str());
    if (input.rfind(prefix, 0) == 0) {
      try {
        long response_code = extract_response_code(input);
        p->setResponseCode(response_code);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s header_callback: parsed response code: %ld\n",
                          p->getSessionId().c_str(), response_code);
      } catch (const std::invalid_argument& e) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s header_callback: invalid response code %s\n",
                          p->getSessionId().c_str(), input.substr(prefix.length()).c_str());
      }
    }
  }
  return bytes_received;
}

/* CURLOPT_OPENSOCKETFUNCTION */
static curl_socket_t opensocket(void *clientp, curlsocktype purpose, struct curl_sockaddr *address) {
  curl_socket_t sockfd = CURL_SOCKET_BAD;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "opensocket: %d\n", purpose);
  /* restrict to IPv4 */
  if(purpose == CURLSOCKTYPE_IPCXN && address->family == AF_INET) {
    /* create a tcp socket object */
    boost::asio::ip::tcp::socket *tcp_socket = new boost::asio::ip::tcp::socket(io_service);

    /* open it and get the native handle*/
    boost::system::error_code ec;
    tcp_socket->open(boost::asio::ip::tcp::v4(), ec);

    if(ec) {
      /* An error occurred */
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: opensocket: Couldn't open socket [%d][%s]\n", ec.value(), ec.message().c_str());
    }
    else {
      sockfd = tcp_socket->native_handle();

      /* save it for monitoring */
      socket_map.insert(std::pair<curl_socket_t, boost::asio::ip::tcp::socket *>(sockfd, tcp_socket));
    }
  }
  return sockfd;
}

/* CURLOPT_CLOSESOCKETFUNCTION */
static int close_socket(void *clientp, curl_socket_t item) {
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "close_socket : %#X\n", item);

  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(item);
  if(it != socket_map.end()) {
    delete it->second;
    socket_map.erase(it);
  }
  return 0;
}


extern "C" {
  switch_status_t deepgram_speech_load() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "mod_deepgram_tts: deepgram_speech_load: starting..\n");
    memset(&global, 0, sizeof(GlobalInfo_t));
    global.multi = curl_multi_init();

     if (!global.multi) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: deepgram_speech_load: curl_multi_init() failed, exiting!\n");
      return SWITCH_STATUS_FALSE;
    }

    curl_multi_setopt(global.multi, CURLMOPT_SOCKETFUNCTION, sock_cb);
    curl_multi_setopt(global.multi, CURLMOPT_SOCKETDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERFUNCTION, multi_timer_cb);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);

    /* check if write_cb profiling is enabled */
    profile_write_cb = switch_true(std::getenv("DEEPGRAM_TTS_PROFILE_WRITE_CB"));
    if (profile_write_cb) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
        "mod_deepgram_tts: write_cb profiling enabled via DEEPGRAM_TTS_PROFILE_WRITE_CB\n");
    }

    /* create temp folder for cache files */
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) {
      baseDir = "/tmp/";
    }
    if (strcmp(baseDir, "/") == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: deepgram_speech_load: invalid base directory %s\n", baseDir);
      return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    // Create the directory with read, write, and execute permissions for everyone
    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);
    if (result != 0) {
      if (errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_deepgram_tts: deepgram_speech_load: failed to create folder %s\n", fullDirPath.c_str());
        fullDirPath = "";
      }
      else switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgram_tts: deepgram_speech_load: folder %s already exists\n", fullDirPath.c_str());
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgram_tts: deepgram_speech_load: created folder %s\n", fullDirPath.c_str());
    }

    /* start worker thread that handles transfers*/
    std::thread t(threadFunc) ;
    worker_thread.swap( t ) ;

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "mod_deepgram_tts: deepgram_speech_load: completed\n");


    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t deepgram_speech_unload() {
    /* stop the ASIO IO service */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgram_tts: deepgram_speech_unload: stopping io service\n");
    io_service.stop();

    /* Join the worker thread */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgram_tts: deepgram_speech_unload: wait for worker thread to complete\n");
    if (worker_thread.joinable()) {
        worker_thread.join();
    }

    /* cleanup curl multi handle*/
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgram_tts: deepgram_speech_unload: release curl multi\n");
    curl_multi_cleanup(global.multi);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgram_tts: deepgram_speech_unload: completed\n");

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t deepgram_speech_open(deepgram_handle_t handle) {
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t deepgram_speech_feed_tts(deepgram_handle_t handle, char* text, switch_speech_flag_t *flags) {
    // Get shared_ptr for thread-safe access
    std::shared_ptr<Deepgram> p = deepgram_get_shared_ptr(handle);
    if (!p) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "deepgram_speech_feed_tts: invalid handle\n");
      return SWITCH_STATUS_FALSE;
    }
    CURLMcode rc;

    const int MAX_CHARS = 20;
    char tempText[MAX_CHARS + 4]; // +4 for the ellipsis and null terminator

    if (strlen(text) > MAX_CHARS) {
        strncpy(tempText, text, MAX_CHARS);
        strcpy(tempText + MAX_CHARS, "...");
    } else {
        strcpy(tempText, text);
    }

    /* generate cache filename if needed */
    if (p->isCacheAudio() && fullDirPath.length() > 0) {
      switch_uuid_t uuid;
      char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
      char outfile[512] = "";

      switch_uuid_get(&uuid);
      switch_uuid_format(uuid_str, &uuid);

      switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
      p->setCacheFilename(outfile);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s cache file will be: %s\n",
                        p->getSessionId().c_str(), p->getCacheFilename().c_str());
    }

    if (p->getApiKey().empty()) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s deepgram_speech_feed_tts: no api_key provided\n",
                        p->getSessionId().c_str());
      return SWITCH_STATUS_FALSE;
    }
    /* format url*/
    std::string url;
    std::ostringstream url_stream;
    url_stream << (!p->getEndpoint().empty() ? p->getEndpoint() : "https://api.deepgram.com") << "/v1/speak?model=" << p->getVoiceName() << "&encoding=linear16&sample_rate=8000";
    url = url_stream.str();

    /* create the JSON body */
    cJSON * jResult = cJSON_CreateObject();
    cJSON_AddStringToObject(jResult, "text", text);
    char *json = cJSON_PrintUnformatted(jResult);

    cJSON_Delete(jResult);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s deepgram_speech_feed_tts: [%s] [%s]\n",
                      p->getSessionId().c_str(), url.c_str(), tempText);

    ConnInfo_t *conn = new ConnInfo_t();
    memset(conn, 0, sizeof(ConnInfo_t));

    CURL* easy = createEasyHandle();
    p->setConnection((void *) conn);
    
    // CRITICAL: Store both handle and shared_ptr for thread safety
    // The handle is retained here and released in cleanupConn
    deepgram_retain(handle);
    conn->deepgram_handle = handle;
    conn->deepgram = p;  // Store shared_ptr for async operations
    
    conn->easy = easy;
    conn->global = &global;
    conn->hdr_list = NULL ;
    conn->body = json;
    conn->flushed = false;
    conn->has_last_byte = false;
    conn->last_byte = 0;

    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(p->getMutex(), playoutBuffer);
    audioPlayer->setResampling(8000, p->getRate());

    if (!p->getCacheFilename().empty()) {
      audioPlayer->setCacheFilePath(p->getCacheFilename());
    }

    p->setPlayoutBuffer((void *) playoutBuffer);
    p->setAudioPlayer((void *) audioPlayer);

    std::ostringstream api_key_stream;
    api_key_stream << "Authorization: Token " << p->getApiKey();

    curl_easy_setopt(easy, CURLOPT_URL, url.c_str());
    curl_easy_setopt(easy, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(easy, CURLOPT_WRITEDATA, conn);
    curl_easy_setopt(easy, CURLOPT_ERRORBUFFER, conn->error);
    curl_easy_setopt(easy, CURLOPT_PRIVATE, conn);
    curl_easy_setopt(easy, CURLOPT_VERBOSE, 0L);
    curl_easy_setopt(easy, CURLOPT_NOPROGRESS, 1L);
    curl_easy_setopt(easy, CURLOPT_HEADERFUNCTION, header_callback);
    curl_easy_setopt(easy, CURLOPT_HEADERDATA, conn);
    
    /* call this function to get a socket */
    curl_easy_setopt(easy, CURLOPT_OPENSOCKETFUNCTION, opensocket);

    /* call this function to close a socket */
    curl_easy_setopt(easy, CURLOPT_CLOSESOCKETFUNCTION, close_socket);

    conn->hdr_list = curl_slist_append(conn->hdr_list, api_key_stream.str().c_str());
    conn->hdr_list = curl_slist_append(conn->hdr_list, "Content-Type: application/json");
    curl_easy_setopt(easy, CURLOPT_HTTPHEADER, conn->hdr_list);

    curl_easy_setopt(easy, CURLOPT_POSTFIELDS, conn->body);
    //curl_easy_setopt(easy, CURLOPT_POSTFIELDSIZE, body.length());

    // libcurl adding random byte to the response body that creates white noise to audio file
    // https://github.com/curl/curl/issues/10525
    const bool disable_http_2 = switch_true(std::getenv("DISABLE_HTTP2_FOR_TTS_STREAMING"));
    curl_easy_setopt(easy, CURLOPT_HTTP_VERSION, disable_http_2 ? CURL_HTTP_VERSION_1_1 : CURL_HTTP_VERSION_2_0);

    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    rc = curl_multi_add_handle(global.multi, conn->easy);

    mcode_test("new_conn: curl_multi_add_handle", rc);

    /* start a timer to measure the duration until we receive first byte of audio */
    conn->startTime = std::chrono::high_resolution_clock::now();

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s deepgram_speech_feed_tts: called curl_multi_add_handle\n",
                      p->getSessionId().c_str());

    // Log connection start details if debug is enabled
    const bool verbose_curl_debug = switch_true(std::getenv("DEEPGRAM_TTS_CURL_DEBUG"));
    if (verbose_curl_debug) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
            "%s mod_deepgram_tts: Starting connection with timeouts - connect: 3s, total: %lds, low_speed: 1 byte/s for 5s\n",
            p->getSessionId().c_str(), getConnectionTimeout());
        logCurlTimingDetails(easy, "Connection Start", p->getSessionId().c_str());
    }


    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t deepgram_speech_read_tts(deepgram_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    // Get shared_ptr for thread-safe access
    std::shared_ptr<Deepgram> p = deepgram_get_shared_ptr(handle);
    if (!p) {
      memset(data, 255, *datalen);
      return SWITCH_STATUS_SUCCESS;
    }
    CircularBuffer *playoutBuffer = (CircularBuffer *) p->getPlayoutBuffer();
    int samplesToCopy = 0;

    // Try lock approach with std::mutex
    std::unique_lock<std::mutex> lock(p->getMutex(), std::try_to_lock);
    if (lock.owns_lock()) {
      ConnInfo_t *conn = (ConnInfo_t *) p->getConnection();
      if (p->getResponseCode() > 0 && p->getResponseCode() != 200) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s deepgram_speech_read_tts, returning failure\n",
                          p->getSessionId().c_str());
        return SWITCH_STATUS_FALSE;
      }

      if (conn && conn->flushed) {
        return SWITCH_STATUS_BREAK;
      }

      if (playoutBuffer->size() == 0) {
        if (p->isDraining()) {
          return SWITCH_STATUS_BREAK;
        }
        /* no audio available yet so send silence */
        memset(data, 255, *datalen);
        return SWITCH_STATUS_SUCCESS;
      }
      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(*datalen / sizeof(int16_t)));

      auto count = playoutBuffer->getBlock(reinterpret_cast<int16_t*>(data), samplesToCopy);
      if (count != samplesToCopy) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s deepgram_speech_read_tts - failed to get %d samples from playout buffer, got %d\n",
                          p->getSessionId().c_str(), samplesToCopy, count);
      }
      *datalen = count * sizeof(int16_t);
    } else {
      /* no audio available yet so send silence */
      memset(data, 255, *datalen);
      return SWITCH_STATUS_SUCCESS;
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s deepgram_speech_read_tts failed to lock mutex\n",
                        p->getSessionId().c_str());
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t deepgram_speech_flush_tts(deepgram_handle_t handle) {
    // Get shared_ptr for thread-safe access
    std::shared_ptr<Deepgram> p = deepgram_get_shared_ptr(handle);
    if (!p) {
      return SWITCH_STATUS_SUCCESS;
    }
    bool download_complete = p->getResponseCode() == 200;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s deepgram_speech_flush_tts, download complete? %s\n",
                      p->getSessionId().c_str(), download_complete ? "yes" : "no");  

    ConnInfo_t *conn = nullptr;
    {
      std::lock_guard<std::mutex> lock(curl_mutex);
      conn = (ConnInfo_t *) p->getConnection();
      if (conn) {
        conn->flushed = true;  // Set this while we have curl_mutex
      }
    }

    // Extract pointers while holding lock, then delete outside lock to avoid deadlock
    // The consumer thread needs p->getMutex() to finish, so we can't hold it during thread join
    AudioPlayer* audioPlayer = nullptr;
    CircularBuffer* playoutBuffer = nullptr;

    {
      std::lock_guard<std::mutex> lock(p->getMutex());

      // Get pointers and clear them while holding lock
      if (p->getAudioPlayer()) {
        audioPlayer = static_cast<AudioPlayer*>(p->getAudioPlayer());
        p->setAudioPlayer(nullptr);  // Clear pointer first
      }

      if (p->getPlayoutBuffer()) {
        playoutBuffer = static_cast<CircularBuffer*>(p->getPlayoutBuffer());
        p->setPlayoutBuffer(nullptr);  // Clear pointer first
      }
    }  // Release p->getMutex() here - consumer thread can now finish and exit

    // Delete outside the lock - this allows consumer thread to complete its work and exit
    // delete audioPlayer will call consumer_thread.join() which waits for the thread to exit
    if (audioPlayer) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s destroying audio player\n",
                        p->getSessionId().c_str());
      delete audioPlayer;  // This closes the cache file after consumer thread finishes
    }

    if (playoutBuffer) {
      delete playoutBuffer;
    }

    // If download was incomplete, delete the cache file
    if (!p->getCacheFilename().empty() && !download_complete) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s removing incomplete cache file %s (response code: %ld)\n",
        p->getSessionId().c_str(), p->getCacheFilename().c_str(), p->getResponseCode());
      if (unlink(p->getCacheFilename().c_str()) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s error removing incomplete cache file %s: %d:%s\n",
          p->getSessionId().c_str(), p->getCacheFilename().c_str(), errno, strerror(errno));
      }
      p->setCacheFilename("");  // Clear filename so we don't report it in PLAYBACK_STOP event
    }
    if (!p->getSessionId().empty()) {
      switch_core_session_t* session = switch_core_session_locate(p->getSessionId().c_str());
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);
        switch_core_session_rwunlock(session);
        if (channel) {
          // Check if PLAYBACK_START was never sent and send it now if needed
          if (!p->isPlaybackStartSent()) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s deepgram_speech_flush_tts: callback was never called, sending delayed playback-started event\n",
                              p->getSessionId().c_str());
            send_playback_start_event(handle, channel, "0");

            // Add 100ms delay before sending PLAYBACK_STOP
            switch_yield(100000);
          }

          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);

            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s write_cb: firing playback-stopped,playbackId %s\n", p->getSessionId().c_str(),
              !p->getPlaybackId().empty() ? p->getPlaybackId().c_str() : "no-playback-id");

            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (!p->getPlaybackId().empty()) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", p->getPlaybackId().c_str());
            }
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_deepgram_response_code", std::to_string(p->getResponseCode()).c_str());
            if (!p->getCacheFilename().empty() && p->getResponseCode() == 200) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", p->getCacheFilename().c_str());
            }
            if (p->getResponseCode() != 200 && !p->getErrorMessage().empty()) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", p->getErrorMessage().c_str());
            }
            switch_event_fire(&event);
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: failed to create event\n",
                              p->getSessionId().c_str());
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s write_cb: channel not found\n",
                            p->getSessionId().c_str());
        }
      }
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t deepgram_speech_close(deepgram_handle_t handle) {
    // Get shared_ptr for thread-safe access
    std::shared_ptr<Deepgram> p = deepgram_get_shared_ptr(handle);
    if (!p) {
      return SWITCH_STATUS_SUCCESS;
    }
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s deepgram_speech_close\n",
                      p->getSessionId().c_str());
		return SWITCH_STATUS_SUCCESS;
	}
}