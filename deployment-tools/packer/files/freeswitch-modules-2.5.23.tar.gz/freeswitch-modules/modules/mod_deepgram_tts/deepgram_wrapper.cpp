#include "deepgram_wrapper.h"
#include "deepgram.hpp"
#include <memory>
#include <mutex>
#include <unordered_map>

// Internal handle structure
struct deepgram_handle {
    std::shared_ptr<Deepgram> instance;
    int ref_count;
    std::mutex ref_mutex;
    
    deepgram_handle(std::shared_ptr<Deepgram> inst)
        : instance(std::move(inst)), ref_count(1) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s deepgram_handle initialized with ref_count %d\n",
                              instance ? instance->getSessionId().c_str() : "", ref_count);
        }
};

// Thread-safe handle management
static std::mutex g_handle_mutex;
static std::unordered_map<deepgram_handle_t, std::unique_ptr<deepgram_handle>> g_handles;

// Helper function to validate handle
static deepgram_handle* get_handle(deepgram_handle_t handle) {
    if (!handle) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second.get() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
std::shared_ptr<Deepgram> deepgram_get_shared_ptr(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance : nullptr;
}

// Private internal function to get handle from shared_ptr
deepgram_handle_t deepgram_get_handle_from_shared_ptr(const std::shared_ptr<Deepgram>& ptr) {
    if (!ptr) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->instance == ptr) {
            return pair.first;
        }
    }
    return nullptr;
}

// C API Implementation
extern "C" {

deepgram_handle_t deepgram_create(void) {
    try {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "mod_deepgram_tts: deepgram_create\n");

        auto instance = Deepgram::create();
        auto handle = std::make_unique<deepgram_handle>(instance);
        deepgram_handle_t handle_ptr = handle.get();
        
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles[handle_ptr] = std::move(handle);
        
        return handle_ptr;
    } catch (...) {
        return nullptr;
    }
}

void deepgram_retain(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    if (h) {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s deepgram_retain, ref count %d\n",
                          h->instance ? h->instance->getSessionId().c_str() : "", h->ref_count);
    }
}

void deepgram_release(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    if (!h) return;

    bool should_delete = false;
    std::string session_id;
    {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        if (h->instance) {
            session_id = h->instance->getSessionId();
        }
        h->ref_count--;
        should_delete = (h->ref_count <= 0);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s deepgram_release, ref count %d\n",
                          session_id.c_str(), h->ref_count);
    }

    if (should_delete) {
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles.erase(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s deepgram_release, handle erased\n",
                          session_id.c_str());
    }
}

// Getters
const char* deepgram_get_voice_name(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceName().c_str() : nullptr;
}

const char* deepgram_get_api_key(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getApiKey().c_str() : nullptr;
}

const char* deepgram_get_endpoint(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getEndpoint().c_str() : nullptr;
}

// Result data getters
long deepgram_get_response_code(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getResponseCode() : 0;
}

const char* deepgram_get_content_type(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getContentType().c_str() : nullptr;
}

const char* deepgram_get_reported_model_name(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReportedModelName().c_str() : nullptr;
}

const char* deepgram_get_reported_model_uuid(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReportedModelUuid().c_str() : nullptr;
}

const char* deepgram_get_reported_char_count(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReportedCharCount().c_str() : nullptr;
}

const char* deepgram_get_request_id(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRequestId().c_str() : nullptr;
}

const char* deepgram_get_name_lookup_time_ms(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getNameLookupTimeMs().c_str() : nullptr;
}

const char* deepgram_get_connect_time_ms(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnectTimeMs().c_str() : nullptr;
}

const char* deepgram_get_final_response_time_ms(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFinalResponseTimeMs().c_str() : nullptr;
}

const char* deepgram_get_error_message(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getErrorMessage().c_str() : nullptr;
}

const char* deepgram_get_cache_filename(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCacheFilename().c_str() : nullptr;
}

const char* deepgram_get_session_id(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSessionId().c_str() : nullptr;
}

// State getters
int deepgram_get_rate(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRate() : 0;
}

int deepgram_is_draining(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isDraining() ? 1 : 0) : 0;
}

int deepgram_get_reads(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReads() : 0;
}

int deepgram_is_cache_audio(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isCacheAudio() ? 1 : 0) : 0;
}

int deepgram_is_playback_start_sent(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isPlaybackStartSent() ? 1 : 0) : 0;
}

// Resource getters
void* deepgram_get_connection(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnection() : nullptr;
}

void* deepgram_get_audio_player(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getAudioPlayer() : nullptr;
}

void* deepgram_get_playout_buffer(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlayoutBuffer() : nullptr;
}

// Mutex getter function removed - std::mutex is now managed internally by Deepgram class

FILE* deepgram_get_file(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFile() : nullptr;
}

const char* deepgram_get_playback_id(deepgram_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlaybackId().c_str() : nullptr;
}

// Setters
void deepgram_set_voice_name(deepgram_handle_t handle, const char* voice_name) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setVoiceName(voice_name ? voice_name : "");
    }
}

void deepgram_set_api_key(deepgram_handle_t handle, const char* api_key) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setApiKey(api_key ? api_key : "");
    }
}

void deepgram_set_endpoint(deepgram_handle_t handle, const char* endpoint) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setEndpoint(endpoint ? endpoint : "");
    }
}

// Result data setters
void deepgram_set_response_code(deepgram_handle_t handle, long response_code) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setResponseCode(response_code);
    }
}

void deepgram_set_content_type(deepgram_handle_t handle, const char* content_type) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setContentType(content_type ? content_type : "");
    }
}

void deepgram_set_reported_model_name(deepgram_handle_t handle, const char* model_name) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReportedModelName(model_name ? model_name : "");
    }
}

void deepgram_set_reported_model_uuid(deepgram_handle_t handle, const char* model_uuid) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReportedModelUuid(model_uuid ? model_uuid : "");
    }
}

void deepgram_set_reported_char_count(deepgram_handle_t handle, const char* char_count) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReportedCharCount(char_count ? char_count : "");
    }
}

void deepgram_set_request_id(deepgram_handle_t handle, const char* request_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setRequestId(request_id ? request_id : "");
    }
}

void deepgram_set_name_lookup_time_ms(deepgram_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setNameLookupTimeMs(time_ms ? time_ms : "");
    }
}

void deepgram_set_connect_time_ms(deepgram_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setConnectTimeMs(time_ms ? time_ms : "");
    }
}

void deepgram_set_final_response_time_ms(deepgram_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setFinalResponseTimeMs(time_ms ? time_ms : "");
    }
}

void deepgram_set_error_message(deepgram_handle_t handle, const char* error_msg) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setErrorMessage(error_msg ? error_msg : "");
    }
}

void deepgram_set_cache_filename(deepgram_handle_t handle, const char* cache_filename) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCacheFilename(cache_filename ? cache_filename : "");
    }
}

void deepgram_set_session_id(deepgram_handle_t handle, const char* session_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setSessionId(session_id ? session_id : "");
    }
}

// State setters
void deepgram_set_rate(deepgram_handle_t handle, int rate) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setRate(rate);
    }
}

void deepgram_set_draining(deepgram_handle_t handle, int draining) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setDraining(draining != 0);
    }
}

void deepgram_set_reads(deepgram_handle_t handle, int reads) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReads(reads);
    }
}

void deepgram_set_cache_audio(deepgram_handle_t handle, int cache_audio) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCacheAudio(cache_audio != 0);
    }
}

void deepgram_set_playback_start_sent(deepgram_handle_t handle, int playback_start_sent) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackStartSent(playback_start_sent != 0);
    }
}

// Resource setters
void deepgram_set_connection(deepgram_handle_t handle, void* conn) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setConnection(conn);
    }
}

void deepgram_set_audio_player(deepgram_handle_t handle, void* audio_player) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setAudioPlayer(audio_player);
    }
}

void deepgram_set_playout_buffer(deepgram_handle_t handle, void* playout_buffer) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlayoutBuffer(playout_buffer);
    }
}

void deepgram_set_file(deepgram_handle_t handle, FILE* file) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setFile(file);
    }
}

void deepgram_set_playback_id(deepgram_handle_t handle, const char* playback_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackId(playback_id ? playback_id : "");
    }
}

// Mutex initialization
// Mutex initialization function removed - std::mutex is now managed internally by Deepgram class

} // extern "C"