#ifndef __DEEPGRAM_GLUE_H__
#define __DEEPGRAM_GLUE_H__

#include "deepgram_wrapper.h"

#ifdef __cplusplus
extern "C" {
#endif

switch_status_t deepgram_speech_load();
switch_status_t deepgram_speech_open(deepgram_handle_t handle);
switch_status_t deepgram_speech_feed_tts(deepgram_handle_t handle, char* text, switch_speech_flag_t *flags);
switch_status_t deepgram_speech_read_tts(deepgram_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t deepgram_speech_flush_tts(deepgram_handle_t handle);
switch_status_t deepgram_speech_close(deepgram_handle_t handle);
switch_status_t deepgram_speech_unload();

#ifdef __cplusplus
}
#endif

#endif