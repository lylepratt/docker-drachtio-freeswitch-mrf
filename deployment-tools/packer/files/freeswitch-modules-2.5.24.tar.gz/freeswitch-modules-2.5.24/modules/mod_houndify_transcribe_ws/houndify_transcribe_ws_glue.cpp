#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <sstream>
#include <memory>

#include "mod_houndify_transcribe_ws.h"
#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /* 20ms frame at 8kHz, 16-bit mono = 320 bytes */

namespace {
  static const char* static_access_id = nullptr;
  static const char* static_access_key = nullptr;
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static unsigned int idxCallCount = 0;

  static std::shared_ptr<houndify_ws::AudioPipe> getAP(void *pAudioPipe) {
    if (pAudioPipe) {
      return *reinterpret_cast<std::shared_ptr<houndify_ws::AudioPipe>*>(pAudioPipe);
    }
    return nullptr;
  }

  static void destroy_tech_pvt(struct cap_cb *cb) {
    if (cb) {
      if (cb->streamer) {
        auto pAp = getAP(cb->streamer);
        if (pAp && pAp->getLwsState() == houndify_ws::AudioPipe::LWS_CLIENT_CONNECTED) {
          pAp->finish();
        }
        delete reinterpret_cast<std::shared_ptr<houndify_ws::AudioPipe>*>(cb->streamer);
        cb->streamer = nullptr;
      }
      if (cb->resampler) {
        speex_resampler_destroy(cb->resampler);
        cb->resampler = NULL;
      }
      if (cb->vad) {
        switch_vad_destroy(&cb->vad);
        cb->vad = NULL;
      }
    }
  }

  static void parse_ws_uri(const char* uri, std::string &host, int &port,
    std::string &path, int &useTls) {
    const char* p = uri;
    struct { const char* scheme; int len; int tls; int port; } schemes[] = {
      {"wss://", 6, 1, 443}, {"ws://", 5, 0, 80},
      {"https://", 8, 1, 443}, {"http://", 7, 0, 80}
    };
    for (auto &s : schemes) {
      if (strncasecmp(p, s.scheme, s.len) == 0) {
        useTls = s.tls; port = s.port; p += s.len; break;
      }
    }

    const char* colon = nullptr;
    const char* slash = nullptr;
    for (const char* c = p; *c && !slash; c++) {
      if (*c == ':' && !colon) colon = c;
      else if (*c == '/') slash = c;
    }

    host.assign(p, (colon ? colon : (slash ? slash : p + strlen(p))));
    if (colon && (!slash || colon < slash))
      port = atoi(colon + 1);
    if (slash)
      path.assign(slash);
  }

  static std::string buildRequestInfoJson(switch_core_session_t *session,
    uint32_t sampleRate, uint32_t channels, const char* lang, int interim,
    const char* accessId) {

    switch_channel_t *channel = switch_core_session_get_channel(session);
    cJSON *ri = cJSON_CreateObject();
    const char *tmp;

    /* Required fields */
    cJSON_AddStringToObject(ri, "client_id", accessId);
    cJSON_AddStringToObject(ri, "sdk", "freeswitch-c");

    /* Audio format */
    cJSON *audiofmt = cJSON_CreateObject();
    cJSON_AddStringToObject(audiofmt, "type", "S16LE");
    cJSON_AddNumberToObject(audiofmt, "sample_rate", sampleRate);
    cJSON_AddItemToObject(ri, "audiofmt", audiofmt);

    /* Segmentation - use semantic by default for server-side VAD */
    cJSON *segmentation = cJSON_CreateObject();
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_SEGMENTATION_MODE"))) {
      cJSON_AddStringToObject(segmentation, "mode", tmp);
    } else {
      cJSON_AddStringToObject(segmentation, "mode", "semantic");
    }
    cJSON_AddItemToObject(ri, "segmentation", segmentation);

    /* Voice activity detection - enable by default for server-side VAD */
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_VOICE_ACTIVITY_DETECTION"))) {
      cJSON_AddBoolToObject(ri, "voice_activity_detection", switch_true(tmp));
    } else {
      cJSON_AddBoolToObject(ri, "voice_activity_detection", cJSON_False);
    }

    /* Model - default to base_8k */
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_MODEL"))) {
      cJSON_AddStringToObject(ri, "model", tmp);
    }
    /* Boost phrases */
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_BOOST_PHRASES"))) {
      cJSON *phrases = cJSON_CreateArray();
      std::string input(tmp);
      std::stringstream ss(input);
      std::string item;
      while (std::getline(ss, item, ',')) {
        /* trim whitespace */
        size_t start = item.find_first_not_of(" \t");
        size_t end = item.find_last_not_of(" \t");
        if (start != std::string::npos) {
          cJSON_AddItemToArray(phrases, cJSON_CreateString(item.substr(start, end - start + 1).c_str()));
        }
      }
      cJSON_AddItemToObject(ri, "boost_phrases", phrases);
    }

    /* Grammar */
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_GRAMMAR"))) {
      cJSON *grammar = cJSON_Parse(tmp);
      if (grammar) {
        cJSON_AddItemToObject(ri, "grammar", grammar);
      }
    }

    /* LLM Rewrite */
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_LLM_REWRITE"))) {
      cJSON *llm = cJSON_CreateObject();
      cJSON_AddBoolToObject(llm, "enabled", switch_true(tmp));
      cJSON_AddItemToObject(ri, "llm_rewrite", llm);
    }

    /* Contextual Biasing */
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_CTX_BIASING"))) {
      cJSON *ctx = cJSON_CreateObject();
      cJSON_AddBoolToObject(ctx, "enabled", switch_true(tmp));
      cJSON_AddItemToObject(ri, "ctx_biasing", ctx);
    }

    /* Smart Formatting */
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_SMART_FORMATTING"))) {
      cJSON *sf = cJSON_CreateObject();
      cJSON_AddBoolToObject(sf, "enabled", switch_true(tmp));
      cJSON_AddItemToObject(ri, "smart_formatting", sf);
    }

    /* Custom RequestInfo JSON override - merge on top */
    if ((tmp = switch_channel_get_variable(channel, "HOUNDIFY_REQUEST_INFO"))) {
      cJSON *custom = cJSON_Parse(tmp);
      if (custom) {
        cJSON *item = custom->child;
        while (item) {
          cJSON *next = item->next;
          cJSON_DetachItemViaPointer(custom, item);
          /* Replace if exists, add if not */
          cJSON_DeleteItemFromObject(ri, item->string);
          cJSON_AddItemToObject(ri, item->string, item);
          item = next;
        }
        cJSON_Delete(custom);
      }
    }

    char *jsonStr = cJSON_PrintUnformatted(ri);
    std::string result(jsonStr);
    free(jsonStr);
    cJSON_Delete(ri);

    return result;
  }

  static bool eventCallback(const char* sessionId, unsigned int id,
    const char* bugname, houndify_ws::AudioPipe::NotifyEvent_t event,
    const char* message, bool finished) {

    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (!session) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
        "session %s gone, event %d\n", sessionId, event);
      return false;
    }

    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

    if (bug) {
      struct cap_cb *cb = (struct cap_cb*) switch_core_media_bug_get_user_data(bug);
      if (cb) {
        switch (event) {
          case houndify_ws::AudioPipe::CONNECT_SUCCESS:
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
              "(%s) (%u) connected to Houndify WS\n", bugname, id);
            cb->responseHandler(session, TRANSCRIBE_EVENT_CONNECT, NULL, cb->bugname, 0);
            break;

          case houndify_ws::AudioPipe::CONNECT_FAIL:
          {
            std::string json = "{\"reason\":\"";
            json += (message ? message : "unknown");
            json += "\"}";
            cb->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_FAIL, json.c_str(), cb->bugname, finished);
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
              "(%s) (%u) connection failed: %s\n", bugname, id, message ? message : "unknown");
            break;
          }

          case houndify_ws::AudioPipe::CONNECTION_DROPPED:
            if (message && strlen(message) > 0) {
              cb->responseHandler(session, TRANSCRIBE_EVENT_ERROR, message, cb->bugname, finished);
            }
            cb->responseHandler(session, TRANSCRIBE_EVENT_DISCONNECT, NULL, cb->bugname, finished);
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE,
              "(%s) (%u) connection dropped\n", bugname, id);
            break;

          case houndify_ws::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
              "(%s) (%u) connection closed gracefully\n", bugname, id);
            break;

          case houndify_ws::AudioPipe::MESSAGE:
            cb->responseHandler(session, TRANSCRIBE_EVENT_RESULTS, message, cb->bugname, finished);
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
              "(%s) (%u) houndify message: %s\n", bugname, id, message);
            break;

          default:
            break;
        }
      }
    }

    switch_core_session_rwunlock(session);
    return true;
  }

  void lws_logger(int level, const char *line) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}

extern "C" {

  switch_status_t houndify_transcribe_ws_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
      "mod_houndify_transcribe_ws: audio buffer (in secs): %d secs\n", nAudioBufferSecs);

    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    houndify_ws::AudioPipe::initialize(logs, lws_logger);

    static_access_id = std::getenv("HOUNDIFY_CLIENT_ID");
    static_access_key = std::getenv("HOUNDIFY_CLIENT_KEY");

    if (!static_access_id || !static_access_key) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
        "\"HOUNDIFY_CLIENT_ID\" and \"HOUNDIFY_CLIENT_KEY\" env vars not set; "
        "authentication will expect channel variables of same names to be set\n");
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t houndify_transcribe_ws_cleanup() {
    bool cleanup = houndify_ws::AudioPipe::deinitialize();
    return cleanup ? SWITCH_STATUS_SUCCESS : SWITCH_STATUS_FALSE;
  }

  switch_status_t houndify_transcribe_ws_session_init(
    switch_core_session_t *session,
    responseHandler_t responseHandler,
    uint32_t samples_per_second,
    uint32_t channels,
    char* lang,
    int interim,
    char* bugname,
    void **ppUserData)
  {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    auto uuid = switch_core_session_get_uuid(session);
    switch_codec_implementation_t read_impl;
    switch_core_session_get_read_impl(session, &read_impl);
    int err;

    /* Houndify WS supports 8000 or 16000 Hz */
    uint32_t desiredSampling = 8000;
    const char* samplingStr = switch_channel_get_variable(channel, "HOUNDIFY_SAMPLING_RATE");
    if (samplingStr) {
      int rate = atoi(samplingStr);
      if (rate == 8000 || rate == 16000) {
        desiredSampling = rate;
      } else {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_WARNING,
          "Invalid HOUNDIFY_SAMPLING_RATE %s, must be 8000 or 16000. Using 8000.\n", samplingStr);
      }
    }

    const char* accessId = static_access_id;
    const char* accessKey = static_access_key;
    if (!accessId) accessId = switch_channel_get_variable(channel, "HOUNDIFY_CLIENT_ID");
    if (!accessKey) accessKey = switch_channel_get_variable(channel, "HOUNDIFY_CLIENT_KEY");

    if (!accessId || !accessKey) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
        "HOUNDIFY_CLIENT_ID and HOUNDIFY_CLIENT_KEY must be set in environment or channel variables.\n");
      return SWITCH_STATUS_FALSE;
    }

    /* Endpoint configuration */
    std::string host = "apiws-polaris.houndify.com";
    int port = 443;
    std::string path = "/v2/transcription";
    int useTls = 1;

    const char* endpoint = switch_channel_get_variable(channel, "HOUNDIFY_AUDIO_ENDPOINT");
    if (endpoint) {
      parse_ws_uri(endpoint, host, port, path, useTls);

      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
        "parsed HOUNDIFY_AUDIO_ENDPOINT: host=%s, port=%d, path=%s, tls=%d\n",
        host.c_str(), port, path.c_str(), useTls);

      const char* customPath = switch_channel_get_variable(channel, "HOUNDIFY_AUDIO_ENDPOINT_PATH");
      if (customPath) path = customPath;
      const char* tlsStr = switch_channel_get_variable(channel, "HOUNDIFY_AUDIO_ENDPOINT_USE_TLS");
      if (tlsStr) useTls = switch_true(tlsStr);
    }

    /* Build RequestInfo JSON */
    std::string requestInfoJson = buildRequestInfoJson(session, desiredSampling, channels, lang, interim, accessId);
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
      "RequestInfo: %s\n", requestInfoJson.c_str());

    /* Allocate per-session data */
    struct cap_cb *cb = (struct cap_cb*) switch_core_session_alloc(session, sizeof(*cb));
    memset(cb, 0, sizeof(*cb));
    strncpy(cb->sessionId, uuid, MAX_SESSION_ID);
    strncpy(cb->bugname, bugname, MAX_BUG_LEN);
    if (lang) strncpy(cb->lang, lang, MAX_LANG);
    cb->interim = interim;
    cb->channels = channels;
    cb->responseHandler = responseHandler;

    switch_mutex_init(&cb->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));

    /* Setup resampler if needed */
    if (samples_per_second != desiredSampling) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
        "resampling from %u to %u\n", samples_per_second, desiredSampling);
      cb->resampler = speex_resampler_init(channels, samples_per_second, desiredSampling,
        SWITCH_RESAMPLE_QUALITY, &err);
      if (err != 0) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
          "Error initializing resampler: %s.\n", speex_resampler_strerror(err));
        return SWITCH_STATUS_FALSE;
      }
    }

    /* Create AudioPipe */
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * desiredSampling / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);
    unsigned int id = ++idxCallCount;

    try {
      auto apShared = std::make_shared<houndify_ws::AudioPipe>(
        uuid, bugname, host.c_str(), port, path.c_str(),
        buflen, read_impl.decoded_bytes_per_packet,
        accessId, accessKey,
        useTls, eventCallback, id,
        requestInfoJson.c_str());

      /* Set eoq/vad thresholds for client-side end-of-query detection */
      double eoqThreshold = -1.0;
      double vadStopThreshold = -1.0;

      const char* eoqStr = switch_channel_get_variable(channel, "HOUNDIFY_EOQ_THRESHOLD");
      const char* vadStopStr = switch_channel_get_variable(channel, "HOUNDIFY_VAD_STOP_THRESHOLD");
      if (eoqStr && strcmp(eoqStr, "UNDEF") != 0) {
        eoqThreshold = atof(eoqStr);
      }
      if (vadStopStr && strcmp(vadStopStr, "UNDEF") != 0) {
        vadStopThreshold = atof(vadStopStr);
      }

      /* Detect segmentation mode from the final RequestInfo JSON */
      bool segNone = false;
      cJSON *riJson = cJSON_Parse(requestInfoJson.c_str());
      if (riJson) {
        cJSON *seg = cJSON_GetObjectItem(riJson, "segmentation");
        if (seg) {
          cJSON *mode = cJSON_GetObjectItem(seg, "mode");
          if (mode && mode->valuestring && strcasecmp(mode->valuestring, "none") == 0) {
            segNone = true;
          }
        }
        cJSON_Delete(riJson);
      }

      /* When segmentation is "none", apply default thresholds if not explicitly set */
      if (segNone) {
        if (eoqThreshold <= 0) eoqThreshold = 0.95;
        if (vadStopThreshold <= 0) vadStopThreshold = 0.01;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
          "segmentation=none: using eoqThreshold=%.2f, vadStopThreshold=%.4f\n",
          eoqThreshold, vadStopThreshold);
      }

      if (eoqThreshold > 0) apShared->setEoqThreshold(eoqThreshold);
      if (vadStopThreshold > 0) apShared->setVadStopThreshold(vadStopThreshold);

      cb->streamer = new std::shared_ptr<houndify_ws::AudioPipe>(apShared);
    } catch (const std::exception& e) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
        "Error creating AudioPipe: %s\n", e.what());
      if (cb->resampler) {
        speex_resampler_destroy(cb->resampler);
        cb->resampler = NULL;
      }
      return SWITCH_STATUS_FALSE;
    }

    /* Check for VAD settings (local VAD to delay connection) */
    const char* voice_ms = switch_channel_get_variable(channel, "HOUNDIFY_VAD_VOICE_MS");
    const char* mode = switch_channel_get_variable(channel, "HOUNDIFY_VAD_MODE");
    const char* silence_ms_str = switch_channel_get_variable(channel, "HOUNDIFY_VAD_SILENCE_MS");
    const char* vad_debug = switch_channel_get_variable(channel, "HOUNDIFY_VAD_DEBUG");

    if (voice_ms && mode) {
      int ms = atoi(voice_ms);
      int vad_mode = atoi(mode);
      int silence_ms = silence_ms_str ? atoi(silence_ms_str) : 0;
      int debug = vad_debug ? atoi(vad_debug) : 0;

      if (ms > 0 && vad_mode > 0) {
        cb->vad = switch_vad_init(desiredSampling, channels);
        if (cb->vad) {
          switch_vad_set_mode(cb->vad, vad_mode);
          switch_vad_set_param(cb->vad, "voice_ms", ms);
          if (silence_ms_str) switch_vad_set_param(cb->vad, "silence_ms", silence_ms);
          if (debug) switch_vad_set_param(cb->vad, "debug", debug);
        }
      }
    }

    /* If no local VAD, connect immediately */
    if (!cb->vad) {
      auto pAp = getAP(cb->streamer);
      if (pAp) pAp->connect();
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
        "No local VAD - connecting immediately\n");
    }

    *ppUserData = cb;
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t houndify_transcribe_ws_session_stop(
    switch_core_session_t *session, int channelIsClosing, char* bugname) {

    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

    if (bug) {
      struct cap_cb *cb = (struct cap_cb*) switch_core_media_bug_get_user_data(bug);
      if (!cb) return SWITCH_STATUS_FALSE;

      switch_mutex_lock(cb->mutex);
      switch_channel_set_private(channel, bugname, NULL);
      if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

      destroy_tech_pvt(cb);
      switch_mutex_unlock(cb->mutex);

      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
        "houndify_transcribe_ws_session_stop completed\n");
      return SWITCH_STATUS_SUCCESS;
    }

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
      "%s Bug is not attached.\n", switch_channel_get_name(channel));
    return SWITCH_STATUS_FALSE;
  }

  switch_bool_t houndify_transcribe_ws_frame(switch_media_bug_t *bug, void* user_data) {
    switch_core_session_t *session = switch_core_media_bug_get_session(bug);
    struct cap_cb *cb = (struct cap_cb*) user_data;

    if (!cb || !cb->streamer) return SWITCH_TRUE;

    if (switch_mutex_trylock(cb->mutex) == SWITCH_STATUS_SUCCESS) {
      auto pAudioPipe = getAP(cb->streamer);
      if (!pAudioPipe) {
        switch_mutex_unlock(cb->mutex);
        return SWITCH_TRUE;
      }

      /* If local VAD is enabled and not yet connected, process VAD first */
      if (cb->vad && pAudioPipe->getLwsState() != houndify_ws::AudioPipe::LWS_CLIENT_CONNECTED &&
          pAudioPipe->getLwsState() != houndify_ws::AudioPipe::LWS_CLIENT_CONNECTING) {
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = {};
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;

        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
          if (frame.datalen) {
            switch_vad_state_t state = switch_vad_process(cb->vad, (int16_t*)frame.data, frame.samples);
            if (state == SWITCH_VAD_STATE_START_TALKING) {
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
                "detected speech, connecting to Houndify WS now\n");
              pAudioPipe->connect();
              cb->responseHandler(session, TRANSCRIBE_EVENT_VAD_DETECTED, NULL, cb->bugname, 0);
              break;
            }
          }
        }
        switch_mutex_unlock(cb->mutex);
        return SWITCH_TRUE;
      }

      /* Only send audio when protocol is in STREAMING state */
      if (pAudioPipe->getLwsState() != houndify_ws::AudioPipe::LWS_CLIENT_CONNECTED ||
          pAudioPipe->getProtocolState() != houndify_ws::AudioPipe::PROTO_STREAMING) {
        /* Still drain the media bug buffer even if we can't send yet */
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = {};
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;
        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {}
        switch_mutex_unlock(cb->mutex);
        return SWITCH_TRUE;
      }

      pAudioPipe->lockAudioBuffer();
      size_t available = pAudioPipe->binarySpaceAvailable();

      if (cb->resampler == NULL) {
        /* No resampling needed */
        switch_frame_t frame = {};
        frame.data = pAudioPipe->binaryWritePtr();
        frame.buflen = available;

        while (true) {
          if (available < pAudioPipe->binaryMinSpace()) {
            if (!cb->buffer_overrun_notified) {
              cb->buffer_overrun_notified = 1;
              cb->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, cb->bugname, 0);
            }
            pAudioPipe->binaryWritePtrResetToZero();
            frame.data = pAudioPipe->binaryWritePtr();
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          }

          switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
          if (rv != SWITCH_STATUS_SUCCESS) break;
          if (frame.datalen) {
            pAudioPipe->binaryWritePtrAdd(frame.datalen);
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
            frame.data = pAudioPipe->binaryWritePtr();
          }
        }
      } else {
        /* Resampling needed */
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = {};
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;

        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
          if (frame.datalen) {
            spx_uint32_t out_len = available >> 1;
            spx_uint32_t in_len = frame.samples;
            speex_resampler_process_interleaved_int(cb->resampler,
              (const spx_int16_t*) frame.data, &in_len,
              (spx_int16_t*) pAudioPipe->binaryWritePtr(), &out_len);

            if (out_len > 0) {
              size_t bytes_written = out_len * 2 * cb->channels;
              pAudioPipe->binaryWritePtrAdd(bytes_written);
              available = pAudioPipe->binarySpaceAvailable();
            }
            if (available < pAudioPipe->binaryMinSpace()) {
              if (!cb->buffer_overrun_notified) {
                cb->buffer_overrun_notified = 1;
                cb->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, cb->bugname, 0);
              }
              pAudioPipe->binaryWritePtrResetToZero();
              available = pAudioPipe->binarySpaceAvailable();
            }
          }
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(cb->mutex);
    }

    return SWITCH_TRUE;
  }
}
