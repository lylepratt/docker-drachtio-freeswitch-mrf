#ifndef __MOD_HOUNDIFY_TRANSCRIBE_WS_H__
#define __MOD_HOUNDIFY_TRANSCRIBE_WS_H__

#include <switch.h>
#include <speex/speex_resampler.h>

#include <unistd.h>

#define MY_BUG_NAME "houndify_transcribe"
#define MAX_BUG_LEN (64)
#define MAX_SESSION_ID (256)
#define TRANSCRIBE_EVENT_RESULTS        "houndify_transcribe::transcription"
#define TRANSCRIBE_EVENT_ERROR          "jambonz_transcribe::error"
#define TRANSCRIBE_EVENT_CONNECT        "houndify_transcribe::connect"
#define TRANSCRIBE_EVENT_CONNECT_FAIL   "houndify_transcribe::connect_failed"
#define TRANSCRIBE_EVENT_DISCONNECT     "houndify_transcribe::disconnect"
#define TRANSCRIBE_EVENT_BUFFER_OVERRUN "houndify_transcribe::buffer_overrun"
#define TRANSCRIBE_EVENT_VAD_DETECTED   "houndify::vad_detected"

#define MAX_LANG (12)
#define MAX_REGION (32)

/* per-channel data */
typedef void (*responseHandler_t)(switch_core_session_t* session, const char* event,
  const char* json, const char* bugname, int finished);

struct cap_cb {
	switch_mutex_t *mutex;
	char sessionId[MAX_SESSION_ID+1];
	char bugname[MAX_BUG_LEN+1];
	uint32_t channels;
	SpeexResamplerState *resampler;
	void* streamer;
	responseHandler_t responseHandler;
	int interim;

	char lang[MAX_LANG];

	int transcription_counter;
	int buffer_overrun_notified;

	switch_vad_t *vad;
};

#endif
