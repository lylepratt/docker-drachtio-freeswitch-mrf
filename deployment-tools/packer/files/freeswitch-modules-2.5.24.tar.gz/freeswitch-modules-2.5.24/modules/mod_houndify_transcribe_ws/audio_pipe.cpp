#include "audio_pipe.hpp"
#include <switch.h>
#include <switch_json.h>

#include <cassert>
#include <iostream>
#include <sstream>
#include <cstring>

#include <openssl/hmac.h>
#include <openssl/evp.h>

/* discard incoming text messages over the socket that are longer than this */
#define MAX_RECV_BUF_SIZE (65 * 1024 * 10)
#define RECV_BUF_REALLOC_SIZE (8 * 1024)

using namespace houndify_ws;

struct ev_loop *AudioPipe::m_loop = nullptr;
struct ev_async *AudioPipe::m_stop_watcher = nullptr;

namespace {
  static const char *requestedTcpKeepaliveSecs = std::getenv("MOD_AUDIO_FORK_TCP_KEEPALIVE_SECS");
  static int nTcpKeepaliveSecs = requestedTcpKeepaliveSecs ? ::atoi(requestedTcpKeepaliveSecs) : 55;

  static const char b64_table[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

  static int b64_decode_char(char c) {
    if (c >= 'A' && c <= 'Z') return c - 'A';
    if (c >= 'a' && c <= 'z') return c - 'a' + 26;
    if (c >= '0' && c <= '9') return c - '0' + 52;
    if (c == '+' || c == '-') return 62;
    if (c == '/' || c == '_') return 63;
    return -1;
  }

  /* Base64 URL-safe decode: handles both standard and URL-safe base64 */
  static std::vector<uint8_t> base64UrlDecode(const std::string& input) {
    std::vector<uint8_t> result;
    result.reserve(input.size() * 3 / 4);

    int val = 0, bits = 0;
    for (char c : input) {
      if (c == '=' || c == '\n' || c == '\r') continue;
      int d = b64_decode_char(c);
      if (d < 0) continue;
      val = (val << 6) | d;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        result.push_back((val >> bits) & 0xFF);
      }
    }
    return result;
  }

  /* Standard base64 encode, then convert to URL-safe */
  static std::string base64UrlEncode(const uint8_t* data, size_t len) {
    std::string result;
    result.reserve(((len + 2) / 3) * 4);

    for (size_t i = 0; i < len; i += 3) {
      uint32_t n = ((uint32_t)data[i]) << 16;
      if (i + 1 < len) n |= ((uint32_t)data[i + 1]) << 8;
      if (i + 2 < len) n |= ((uint32_t)data[i + 2]);

      result += b64_table[(n >> 18) & 0x3F];
      result += b64_table[(n >> 12) & 0x3F];
      result += (i + 1 < len) ? b64_table[(n >> 6) & 0x3F] : '=';
      result += (i + 2 < len) ? b64_table[n & 0x3F] : '=';
    }

    /* Convert to URL-safe: + -> -, / -> _ */
    for (auto& c : result) {
      if (c == '+') c = '-';
      else if (c == '/') c = '_';
    }
    /* Keep padding - server expects it */
    return result;
  }
}

std::string AudioPipe::signNonce(const std::string& nonce) {
  /* Decode URL-safe base64 access key.
   * The access key from Houndify is base64url-encoded (uses - and _ instead of + and /).
   * We convert to standard base64, decode to binary, then use as HMAC key. */
  std::vector<uint8_t> keyBin = base64UrlDecode(m_accessKey);
  if (keyBin.empty()) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
      "%s (%u) failed to decode access key (length=%zu)\n",
      m_uuid.c_str(), m_id, m_accessKey.size());
    return "";
  }

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
    "%s (%u) signing nonce (nonce_len=%zu, key_len=%zu, key_bin_len=%zu)\n",
    m_uuid.c_str(), m_id, nonce.size(), m_accessKey.size(), keyBin.size());

  /* Log the nonce being signed (for debugging auth issues) */
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
    "%s (%u) nonce to sign: [%s]\n", m_uuid.c_str(), m_id, nonce.c_str());

  /* HMAC-SHA256 sign the nonce */
  uint8_t digest[EVP_MAX_MD_SIZE];
  unsigned int digestLen = 0;
  HMAC(EVP_sha256(), keyBin.data(), keyBin.size(),
    (const uint8_t*)nonce.data(), nonce.size(),
    digest, &digestLen);

  /* Base64 URL-safe encode the result */
  std::string sig = base64UrlEncode(digest, digestLen);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
    "%s (%u) signature generated (len=%zu)\n",
    m_uuid.c_str(), m_id, sig.size());

  return sig;
}

void AudioPipe::handleTextMessage(const char* msg, size_t len) {
  std::string message(msg, len);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
    "%s (%u) handleTextMessage proto_state=%d: %s\n",
    m_uuid.c_str(), m_id, m_protoState, message.c_str());

  switch (m_protoState) {
    case PROTO_AWAITING_NONCE:
    {
      /* Parse nonce from server: {"status":"ok","nonce":"xxxxxxx"} */
      cJSON *json = cJSON_Parse(message.c_str());
      if (!json) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
          "%s (%u) failed to parse nonce message: %s\n",
          m_uuid.c_str(), m_id, message.c_str());
        return;
      }

      cJSON *nonceItem = cJSON_GetObjectItem(json, "nonce");
      if (!nonceItem || !nonceItem->valuestring) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
          "%s (%u) no nonce in server message: %s\n",
          m_uuid.c_str(), m_id, message.c_str());
        cJSON_Delete(json);
        return;
      }

      std::string nonce(nonceItem->valuestring);
      cJSON_Delete(json);

      /* Sign the nonce */
      std::string signature = signNonce(nonce);
      if (signature.empty()) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
          "%s (%u) failed to sign nonce\n", m_uuid.c_str(), m_id);
        return;
      }

      /* Send auth message: {"version":"1.1","access_id":"...","signature":"..."} */
      cJSON *authMsg = cJSON_CreateObject();
      cJSON_AddStringToObject(authMsg, "version", "1.1");
      cJSON_AddStringToObject(authMsg, "access_id", m_accessId.c_str());
      cJSON_AddStringToObject(authMsg, "signature", signature.c_str());
      char *authStr = cJSON_PrintUnformatted(authMsg);
      cJSON_Delete(authMsg);

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s (%u) sending auth message: %s\n", m_uuid.c_str(), m_id, authStr);

      /* Queue auth message for sending */
      {
        std::lock_guard<std::mutex> lk(m_text_mutex);
        m_metadata = authStr;
      }
      free(authStr);

      /* Store RequestInfo to send on next WRITEABLE after auth is sent */
      m_pendingRequestInfo = m_requestInfoJson;

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s (%u) queued RequestInfo: %s\n",
        m_uuid.c_str(), m_id, m_requestInfoJson.c_str());

      m_protoState = PROTO_AWAITING_QUERY_ID;
      addPendingWrite(shared_from_this());
      break;
    }

    case PROTO_AWAITING_QUERY_ID:
    {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s (%u) awaiting QueryID, received: %s\n",
        m_uuid.c_str(), m_id, message.c_str());

      /* Check for auth error */
      cJSON *json = cJSON_Parse(message.c_str());
      if (json) {
        cJSON *errorItem = cJSON_GetObjectItem(json, "error");
        if (errorItem && errorItem->valuestring) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "%s (%u) server error: %s\n",
            m_uuid.c_str(), m_id, errorItem->valuestring);
          cJSON_Delete(json);
          break;
        }

        cJSON *typeItem = cJSON_GetObjectItem(json, "type");
        if (typeItem && typeItem->valuestring && strcmp(typeItem->valuestring, "QueryIDMessage") == 0) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO,
            "%s (%u) received QueryIDMessage, entering streaming state\n",
            m_uuid.c_str(), m_id);
          m_protoState = PROTO_STREAMING;
        }
        cJSON_Delete(json);
      }
      break;
    }

    case PROTO_STREAMING:
    {
      /* Parse JSON to check event type before forwarding */
      cJSON *json = cJSON_Parse(message.c_str());
      if (json) {
        cJSON *typeItem = cJSON_GetObjectItem(json, "type");
        const char *type = typeItem ? typeItem->valuestring : nullptr;

        /* Filter out VadMessage (but check vadStopThreshold first) */
        if (type && strcmp(type, "VadMessage") == 0) {
          if (m_vadStopThreshold > 0 && !m_lastPartialText.empty() && !m_finished) {
            cJSON *vadItem = cJSON_GetObjectItem(json, "vad");
            if (vadItem && vadItem->valuedouble <= m_vadStopThreshold) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO,
                "%s (%u) vad %.4f <= threshold %.4f with partial text, sending Done\n",
                m_uuid.c_str(), m_id, vadItem->valuedouble, m_vadStopThreshold);
              cJSON_Delete(json);
              finish();
              break;
            }
          }
          cJSON_Delete(json);
          break;
        }
        if (type && strcmp(type, "PartialTranscript") == 0) {
          /* Check eoq threshold first (before filtering) — eoq can be high on empty-text partials */
          if (m_eoqThreshold > 0 && !m_lastPartialText.empty() && !m_finished) {
            cJSON *eoqItem = cJSON_GetObjectItem(json, "eoq");
            if (eoqItem && eoqItem->valuedouble >= m_eoqThreshold) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO,
                "%s (%u) eoq %.2f >= threshold %.2f, sending Done\n",
                m_uuid.c_str(), m_id, eoqItem->valuedouble, m_eoqThreshold);
              cJSON_Delete(json);
              finish();
              break;
            }
          }

          cJSON *textItem = cJSON_GetObjectItem(json, "text");
          const char *text = textItem ? textItem->valuestring : nullptr;
          if (!text || text[0] == '\0') {
            cJSON_Delete(json);
            break;
          }
          if (m_lastPartialText == text) {
            cJSON_Delete(json);
            break;
          }
          m_lastPartialText = text;
        }

        /* On final transcripts, reset partial tracking and mark finished */
        if (type && (strcmp(type, "FinalSegmentTranscript") == 0 ||
                     strcmp(type, "FinalTranscript") == 0)) {
          m_lastPartialText.clear();
          if (strcmp(type, "FinalTranscript") == 0) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO,
              "%s (%u) received FinalTranscript\n", m_uuid.c_str(), m_id);
            m_protoState = PROTO_DONE;
            m_finished = true;
          }
        }
        cJSON_Delete(json);
      }

      /* Forward transcription results to the callback */
      bool sessionValid = m_callback(m_uuid.c_str(), m_id, m_bugname.c_str(),
        AudioPipe::MESSAGE, message.c_str(), m_finished);
      if (!sessionValid) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO,
          "%s (%u) session gone during transcription - closing\n",
          m_uuid.c_str(), m_id);
        m_state = LWS_CLIENT_DISCONNECTING;
      }
      break;
    }

    case PROTO_DONE:
      /* Ignore messages after final transcript */
      break;
  }
}

int AudioPipe::lws_callback(struct lws *wsi,
  enum lws_callback_reasons reason,
  void *user, void *in, size_t len) {

  struct AudioPipe::lws_per_vhost_data *vhd =
    (struct AudioPipe::lws_per_vhost_data *) lws_protocol_vh_priv_get(
      lws_get_vhost(wsi), lws_get_protocol(wsi));

  std::shared_ptr<AudioPipe> ** ppAp = (std::shared_ptr<AudioPipe> **) user;

  switch (reason) {
    case LWS_CALLBACK_PROTOCOL_INIT:
      vhd = (struct AudioPipe::lws_per_vhost_data *) lws_protocol_vh_priv_zalloc(
        lws_get_vhost(wsi), lws_get_protocol(wsi),
        sizeof(struct AudioPipe::lws_per_vhost_data));
      vhd->context = lws_get_context(wsi);
      vhd->protocol = lws_get_protocol(wsi);
      vhd->vhost = lws_get_vhost(wsi);
      break;

    case LWS_CALLBACK_EVENT_WAIT_CANCELLED:
      processPendingConnects(vhd);
      processPendingDisconnects(vhd);
      processPendingWrites();
      break;

    case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
    {
      auto ap = findAndRemovePendingConnect(wsi);
      int rc = lws_http_client_http_response(wsi);
      if (ap) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
          "%s (%u) LWS_CALLBACK_CLIENT_CONNECTION_ERROR: %s, status %d\n",
          ap->m_uuid.c_str(), ap->m_id, in ? (char*)in : "(null)", rc);
        ap->m_state = LWS_CLIENT_FAILED;
        ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(),
          houndify_ws::AudioPipe::CONNECT_FAIL, (char*)in, ap->isFinished());
      }
    }
    break;

    case LWS_CALLBACK_CLIENT_ESTABLISHED:
    {
      std::shared_ptr<AudioPipe> ap = findAndRemovePendingConnect(wsi);
      if (ap) {
        std::shared_ptr<AudioPipe>* p = new std::shared_ptr<AudioPipe>(ap);
        *ppAp = p;
        ap->m_vhd = vhd;
        ap->m_state = LWS_CLIENT_CONNECTED;
        ap->m_protoState = PROTO_AWAITING_NONCE;

        bool sessionValid = ap->m_callback(ap->m_uuid.c_str(), ap->m_id,
          ap->m_bugname.c_str(), houndify_ws::AudioPipe::CONNECT_SUCCESS,
          NULL, ap->isFinished());
        if (!sessionValid) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO,
            "%s (%u) session gone during connect - closing\n",
            ap->m_uuid.c_str(), ap->m_id);
          ap->m_state = LWS_CLIENT_DISCONNECTING;
          delete *ppAp;
          *ppAp = nullptr;
          return -1;
        }
      }
    }
    break;

    case LWS_CALLBACK_WS_PEER_INITIATED_CLOSE:
    {
      if (ppAp && *ppAp) {
        std::shared_ptr<AudioPipe> ap = **ppAp;
        if (!ap) return 0;
        uint16_t close_code = (in && len >= 2) ?
          (((unsigned char*)in)[0] << 8) | ((unsigned char*)in)[1] : 0;
        std::string close_reason;
        if (in && len > 2) close_reason = std::string((char*)in + 2, len - 2);
        ap->setCloseReason(close_code, close_reason.c_str());
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
          "%s (%u) WebSocket peer initiated close, code: %d, reason: %s, proto_state: %d\n",
          ap->m_uuid.c_str(), ap->m_id, close_code, close_reason.c_str(), ap->m_protoState);
      }
    }
    break;

    case LWS_CALLBACK_CLIENT_CLOSED:
    {
      if (!ppAp || !*ppAp) return 0;
      std::shared_ptr<AudioPipe> ap = **ppAp;
      if (!ap) {
        delete *ppAp;
        return 0;
      }
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "%s (%u) LWS_CALLBACK_CLIENT_CLOSED, state: %d, close_code: %d, close_reason: %s\n",
        ap->m_uuid.c_str(), ap->m_id, ap->m_state, ap->getCloseCode(), ap->getCloseReason().c_str());
      if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
        ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(),
          houndify_ws::AudioPipe::CONNECTION_CLOSED_GRACEFULLY, NULL, ap->isFinished());
      } else if (ap->m_state == LWS_CLIENT_CONNECTED) {
        uint16_t close_code = ap->getCloseCode();
        std::string close_reason = ap->getCloseReason();
        if (close_code != 1000 && close_code != 0) {
          std::stringstream json;
          json << "{\"code\": \"" << close_code << "\", \"reason\":\"" << close_reason << "\"}";
          ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(),
            houndify_ws::AudioPipe::CONNECTION_DROPPED, json.str().c_str(), ap->isFinished());
        } else {
          ap->m_callback(ap->m_uuid.c_str(), ap->m_id, ap->m_bugname.c_str(),
            houndify_ws::AudioPipe::CONNECTION_DROPPED, NULL, ap->isFinished());
        }
      }
      ap->m_state = LWS_CLIENT_DISCONNECTED;
      delete *ppAp;
      *ppAp = nullptr;
    }
    break;

    case LWS_CALLBACK_CLIENT_RECEIVE:
    {
      if (!ppAp || !*ppAp) return 0;
      std::shared_ptr<AudioPipe> ap = **ppAp;
      if (!ap) return 0;

      if (lws_frame_is_binary(wsi)) {
        /* Houndify WS only sends text frames; discard binary */
        return 0;
      }

      if (lws_is_first_fragment(wsi)) {
        assert(nullptr == ap->m_recv_buf);
        ap->m_recv_buf_len = len + lws_remaining_packet_payload(wsi);
        ap->m_recv_buf = (uint8_t*) malloc(ap->m_recv_buf_len);
        ap->m_recv_buf_ptr = ap->m_recv_buf;
      }

      size_t write_offset = ap->m_recv_buf_ptr - ap->m_recv_buf;
      size_t remaining_space = ap->m_recv_buf_len - write_offset;
      if (remaining_space < len) {
        size_t newlen = ap->m_recv_buf_len + RECV_BUF_REALLOC_SIZE;
        if (newlen > MAX_RECV_BUF_SIZE) {
          free(ap->m_recv_buf);
          ap->m_recv_buf = ap->m_recv_buf_ptr = nullptr;
          ap->m_recv_buf_len = 0;
        } else {
          ap->m_recv_buf = (uint8_t*) realloc(ap->m_recv_buf, newlen);
          if (ap->m_recv_buf) {
            ap->m_recv_buf_len = newlen;
            ap->m_recv_buf_ptr = ap->m_recv_buf + write_offset;
          }
        }
      }

      if (ap->m_recv_buf) {
        if (len > 0) {
          memcpy(ap->m_recv_buf_ptr, in, len);
          ap->m_recv_buf_ptr += len;
        }
        if (lws_is_final_fragment(wsi)) {
          size_t msgLen = ap->m_recv_buf_ptr - ap->m_recv_buf;
          ap->handleTextMessage((const char*)ap->m_recv_buf, msgLen);
          free(ap->m_recv_buf);
          ap->m_recv_buf = ap->m_recv_buf_ptr = nullptr;
          ap->m_recv_buf_len = 0;

          /* If protocol state machine needs a disconnect, do it */
          if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
            return -1;
          }
        }
      }
    }
    break;

    case LWS_CALLBACK_CLIENT_WRITEABLE:
    {
      if (!ppAp || !*ppAp) return 0;
      std::shared_ptr<AudioPipe> ap = **ppAp;
      if (!ap) return 0;

      /* Send text frames first (auth, requestInfo, Done) */
      {
        std::lock_guard<std::mutex> lk(ap->m_text_mutex);
        if (ap->m_metadata.length() > 0) {
          size_t n = ap->m_metadata.length();
          uint8_t buf[n + LWS_PRE];
          memcpy(buf + LWS_PRE, ap->m_metadata.c_str(), n);
          int m = lws_write(wsi, buf + LWS_PRE, n, LWS_WRITE_TEXT);
          ap->m_metadata.clear();
          if (m < (int)n) return -1;

          /* If there's a pending RequestInfo, queue it for next write */
          if (!ap->m_pendingRequestInfo.empty()) {
            ap->m_metadata = ap->m_pendingRequestInfo;
            ap->m_pendingRequestInfo.clear();
          }

          lws_callback_on_writable(wsi);
          return 0;
        }
      }

      if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
        lws_close_reason(wsi, LWS_CLOSE_STATUS_NORMAL, NULL, 0);
        return -1;
      }

      /* Only send audio when we're in STREAMING state */
      if (ap->m_protoState == PROTO_STREAMING) {
        std::lock_guard<std::mutex> lk(ap->m_audio_mutex);
        if (ap->m_audio_buffer_write_offset > LWS_PRE) {
          size_t datalen = ap->m_audio_buffer_write_offset - LWS_PRE;
          int sent = lws_write(wsi,
            (unsigned char*) ap->m_audio_buffer + LWS_PRE,
            datalen, LWS_WRITE_BINARY);
          if (sent < (int)datalen) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
              "%s (%u) attempted to send %zu only sent %d\n",
              ap->m_uuid.c_str(), ap->m_id, datalen, sent);
          }
          ap->m_audio_buffer_write_offset = LWS_PRE;
        }
      }

      return 0;
    }
    break;

    default:
      break;
  }
  return lws_callback_http_dummy(wsi, reason, user, in, len);
}


/* static members */
static const lws_retry_bo_t retry = {
    nullptr, 0, 0, UINT16_MAX, UINT16_MAX, 0
};

struct lws_context *AudioPipe::context = nullptr;
std::thread AudioPipe::serviceThread;
std::mutex AudioPipe::mutex_connects;
std::mutex AudioPipe::mutex_disconnects;
std::mutex AudioPipe::mutex_writes;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingConnects;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingDisconnects;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingWrites;
AudioPipe::log_emit_function AudioPipe::logger;
std::mutex AudioPipe::mapMutex;
bool AudioPipe::stopFlag;

void AudioPipe::processPendingConnects(lws_per_vhost_data *vhd) {
  std::list<std::shared_ptr<AudioPipe>> connects;
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    for (auto it = pendingConnects.begin(); it != pendingConnects.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_IDLE) {
        connects.push_back(*it);
        (*it)->m_state = LWS_CLIENT_CONNECTING;
      }
    }
  }
  for (auto& ap : connects) {
    ap->connect_client(vhd);
  }
}

void AudioPipe::processPendingDisconnects(lws_per_vhost_data *vhd) {
  std::list<std::shared_ptr<AudioPipe>> disconnects;
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    for (auto it = pendingDisconnects.begin(); it != pendingDisconnects.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_DISCONNECTING) disconnects.push_back(*it);
    }
    pendingDisconnects.clear();
  }
  for (auto& ap : disconnects) {
    lws_callback_on_writable(ap->m_wsi);
  }
}

void AudioPipe::processPendingWrites() {
  std::list<std::shared_ptr<AudioPipe>> writes;
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    for (auto it = pendingWrites.begin(); it != pendingWrites.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_CONNECTED) writes.push_back(*it);
    }
    pendingWrites.clear();
  }
  for (auto& ap : writes) {
    lws_callback_on_writable(ap->m_wsi);
  }
}

void AudioPipe::removeFromAllPendingLists(AudioPipe* ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    pendingConnects.remove_if([ap](const std::shared_ptr<AudioPipe>& ptr) {
      return ptr.get() == ap;
    });
  }
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    pendingDisconnects.remove_if([ap](const std::shared_ptr<AudioPipe>& ptr) {
      return ptr.get() == ap;
    });
  }
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    pendingWrites.remove_if([ap](const std::shared_ptr<AudioPipe>& ptr) {
      return ptr.get() == ap;
    });
  }
}

std::shared_ptr<AudioPipe> AudioPipe::findAndRemovePendingConnect(struct lws *wsi) {
  std::shared_ptr<AudioPipe> ap = nullptr;
  std::lock_guard<std::mutex> guard(mutex_connects);
  std::list<std::shared_ptr<AudioPipe>> toRemove;

  for (auto it = pendingConnects.begin(); it != pendingConnects.end() && !ap; ++it) {
    if ((*it)->m_wsi == nullptr)
      toRemove.push_back(*it);
    if (((*it)->m_state == LWS_CLIENT_CONNECTING) && (*it)->m_wsi == wsi) {
      ap = *it;
      pendingConnects.erase(it);
      break;
    }
  }
  for (auto& sharedPtr : toRemove)
    pendingConnects.remove(sharedPtr);

  return ap;
}

std::shared_ptr<AudioPipe> AudioPipe::findPendingConnect(struct lws *wsi) {
  std::shared_ptr<AudioPipe> ap = nullptr;
  std::lock_guard<std::mutex> guard(mutex_connects);
  for (auto it = pendingConnects.begin(); it != pendingConnects.end() && !ap; ++it) {
    if (((*it)->m_state == LWS_CLIENT_CONNECTING) && (*it)->m_wsi == wsi)
      ap = *it;
  }
  return ap;
}

void AudioPipe::addPendingConnect(std::shared_ptr<AudioPipe> ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    pendingConnects.push_back(ap);
  }
  lws_cancel_service(context);
}

void AudioPipe::addPendingDisconnect(std::shared_ptr<AudioPipe> ap) {
  ap->m_state = LWS_CLIENT_DISCONNECTING;
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    pendingDisconnects.push_back(ap);
  }
  lws_cancel_service(ap->m_vhd->context);
}

void AudioPipe::addPendingWrite(std::shared_ptr<AudioPipe> ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    pendingWrites.push_back(ap);
  }
  lws_cancel_service(ap->m_vhd->context);
}

bool AudioPipe::lws_service_thread() {
  struct lws_context_creation_info info;
  struct ev_loop *loop;
  struct ev_async stop_watcher;

  const struct lws_protocols protocols[] = {
    {
      "",
      AudioPipe::lws_callback,
      sizeof(std::shared_ptr<AudioPipe>*),
      8192,
    },
    { NULL, NULL, 0, 0 }
  };

  loop = ev_loop_new(EVFLAG_NOSIGMASK);
  if (!loop) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
      "AudioPipe::lws_service_thread failed to create ev loop\n");
    return false;
  }

  memset(&info, 0, sizeof info);
  info.port = CONTEXT_PORT_NO_LISTEN;
  info.options = LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT |
                 LWS_SERVER_OPTION_LIBEV;

  void *foreign_loops[1] = { loop };
  info.foreign_loops = foreign_loops;
  info.protocols = protocols;
  info.ka_time = nTcpKeepaliveSecs;
  info.ka_probes = 4;
  info.ka_interval = 5;
  info.timeout_secs = 10;
  info.keepalive_timeout = 5;
  info.timeout_secs_ah_idle = 10;
  info.retry_and_idle_policy = &retry;

  context = lws_create_context(&info);
  if (!context) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
      "AudioPipe::lws_service_thread failed creating context\n");
    ev_loop_destroy(loop);
    return false;
  }

  ev_async_init(&stop_watcher, [](EV_P_ ev_async *w, int revents) {});
  ev_async_start(loop, &stop_watcher);

  m_loop = loop;
  m_stop_watcher = &stop_watcher;

  while (!stopFlag) {
    ev_run(loop, EVRUN_ONCE);
  }

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
    "AudioPipe::lws_service_thread ending\n");

  ev_async_stop(loop, &stop_watcher);
  lws_context_destroy(context);
  ev_loop_destroy(loop);

  return true;
}

void AudioPipe::initialize(int loglevel, log_emit_function logger) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
    "houndify_ws AudioPipe::initialize starting\n");
  std::lock_guard<std::mutex> lock(mapMutex);
  stopFlag = false;
  serviceThread = std::thread(&AudioPipe::lws_service_thread);
}

bool AudioPipe::deinitialize() {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
    "houndify_ws AudioPipe::deinitialize\n");
  std::lock_guard<std::mutex> lock(mapMutex);
  stopFlag = true;

  if (m_loop && m_stop_watcher) {
    ev_async_send(m_loop, m_stop_watcher);
  }

  if (serviceThread.joinable()) {
    serviceThread.join();
  }

  return true;
}

/* instance members */
AudioPipe::AudioPipe(const char* uuid, const char* bugname, const char* host,
  unsigned int port, const char* path,
  size_t bufLen, size_t minFreespace,
  const char* accessId, const char* accessKey,
  int useTls, notifyHandler_t callback, unsigned int id,
  const char* requestInfoJson) :
  m_uuid(uuid), m_host(host), m_port(port), m_path(path),
  m_finished(false), m_bugname(bugname),
  m_audio_buffer_min_freespace(minFreespace),
  m_audio_buffer_max_len(bufLen), m_gracefulShutdown(false),
  m_audio_buffer_write_offset(LWS_PRE),
  m_recv_buf(nullptr), m_recv_buf_ptr(nullptr), m_recv_buf_len(0),
  m_useTls(useTls),
  m_state(LWS_CLIENT_IDLE), m_protoState(PROTO_AWAITING_NONCE),
  m_wsi(nullptr), m_vhd(nullptr),
  m_callback(callback),
  m_close_code(0), m_id(id),
  m_eoqThreshold(-1.0), m_vadStopThreshold(-1.0) {

  if (accessId) m_accessId = accessId;
  if (accessKey) m_accessKey = accessKey;
  if (requestInfoJson) m_requestInfoJson = requestInfoJson;

  m_audio_buffer = new uint8_t[m_audio_buffer_max_len];
}

AudioPipe::~AudioPipe() {
  if (m_audio_buffer) delete[] m_audio_buffer;
  if (m_recv_buf) free(m_recv_buf);
}

void AudioPipe::connect(void) {
  addPendingConnect(shared_from_this());
}

bool AudioPipe::connect_client(struct lws_per_vhost_data *vhd) {
  assert(m_audio_buffer != nullptr);
  assert(m_vhd == nullptr);
  struct lws_client_connect_info i;

  memset(&i, 0, sizeof(i));
  i.context = vhd->context;
  i.port = m_port;
  i.address = m_host.c_str();
  i.path = m_path.c_str();
  i.host = i.address;
  i.origin = i.address;
  if (m_useTls) i.ssl_connection = LCCSCF_USE_SSL;
  i.pwsi = &(m_wsi);

  m_state = LWS_CLIENT_CONNECTING;
  m_vhd = vhd;

  m_wsi = lws_client_connect_via_info(&i);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
    "%s (%u) attempting connection to %s:%d%s, wsi is %p\n",
    m_uuid.c_str(), m_id, m_host.c_str(), m_port, m_path.c_str(), m_wsi);

  return nullptr != m_wsi;
}

void AudioPipe::bufferForSending(const char* text) {
  if (m_state != LWS_CLIENT_CONNECTED) return;
  {
    std::lock_guard<std::mutex> lk(m_text_mutex);
    m_metadata.append(text);
  }
  addPendingWrite(shared_from_this());
}

void AudioPipe::unlockAudioBuffer() {
  if (m_audio_buffer_write_offset > LWS_PRE) addPendingWrite(shared_from_this());
  m_audio_mutex.unlock();
}

void AudioPipe::close() {
  if (m_state != LWS_CLIENT_CONNECTED) return;
  addPendingDisconnect(shared_from_this());
}

void AudioPipe::finish() {
  if (m_finished || m_state != LWS_CLIENT_CONNECTED) return;
  m_finished = true;
  /* Send the "Done" message per Houndify WS protocol */
  bufferForSending("Done");
}
