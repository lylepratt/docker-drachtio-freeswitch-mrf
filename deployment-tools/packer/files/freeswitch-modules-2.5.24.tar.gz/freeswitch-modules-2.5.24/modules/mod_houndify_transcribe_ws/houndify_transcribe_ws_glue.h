#ifndef __HOUNDIFY_WS_GLUE_H__
#define __HOUNDIFY_WS_GLUE_H__

switch_status_t houndify_transcribe_ws_init();
switch_status_t houndify_transcribe_ws_cleanup();
switch_status_t houndify_transcribe_ws_session_init(switch_core_session_t *session,
  responseHandler_t responseHandler,
  uint32_t samples_per_second, uint32_t channels,
  char* lang, int interim, char* bugname, void **ppUserData);
switch_status_t houndify_transcribe_ws_session_stop(switch_core_session_t *session,
  int channelIsClosing, char* bugname);
switch_bool_t houndify_transcribe_ws_frame(switch_media_bug_t *bug, void* user_data);

#endif
