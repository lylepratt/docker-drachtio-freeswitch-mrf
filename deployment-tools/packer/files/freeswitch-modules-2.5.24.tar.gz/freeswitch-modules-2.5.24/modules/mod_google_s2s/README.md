# mod_google_s2s

A Freeswitch module that integrates with Google's Gemini Live speech-to-speech APIs. Both the Gemini Developer API (`generativelanguage.googleapis.com`) and the Vertex AI Live API (`{LOCATION}-aiplatform.googleapis.com`) are supported — they share the same JSON wire format, so the only difference at the module surface is the host, the WebSocket path, and the `setup.model` string the caller sends in `client.event`.

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_google_s2s <uuid> session.create apiKey [host] [path]
```
where:
- `apiKey`: API key (appended to the URL as `?key=...`). For Vertex AI use a [Vertex Express Mode](https://cloud.google.com/vertex-ai/generative-ai/docs/start/express-mode/overview) key.
- `host` (optional): WebSocket host. Default: `generativelanguage.googleapis.com`. For Vertex AI use e.g. `us-central1-aiplatform.googleapis.com`.
- `path` (optional): WebSocket path WITHOUT the `?key=...` query param — the module appends the key. Default: `/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent`. For Vertex AI use `/ws/google.cloud.aiplatform.v1beta1.LlmBidiService/BidiGenerateContent`.

#### Legacy `version` argument (backward compatible)

The 5th argument was historically a Gemini Developer API *version* string (`v1`, `v1beta`, `v1alpha`). That form is still supported: if the value does not start with `/`, the module treats it as a version and reconstructs the path as `/ws/google.ai.generativelanguage.{version}.GenerativeService.BidiGenerateContent`. So a caller passing `v1beta` produces exactly the same URL as one passing the full default path. Use whichever fits your code generator — for Vertex AI you must pass a full path because that API has a different service name.

Examples:

```
# Gemini Developer API (defaults)
uuid_google_s2s <uuid> session.create AIza...

# Gemini Developer API with explicit version (legacy, backward compatible)
uuid_google_s2s <uuid> session.create AIza... generativelanguage.googleapis.com v1beta

# Gemini Developer API with explicit full path
uuid_google_s2s <uuid> session.create AIza... generativelanguage.googleapis.com /ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent

# Vertex AI Live API (Express Mode key) — full path required
uuid_google_s2s <uuid> session.create AQ.xxxxx us-central1-aiplatform.googleapis.com /ws/google.cloud.aiplatform.v1beta1.LlmBidiService/BidiGenerateContent
```

This api call establishes a websocket connection to the Google endpoint.  If the connection is successfully established, which the caller will know through the 'google_s2s::connect' event, then the caller must next send a `client.event` client event with the [BidiGenerateContentSetup](https://ai.google.dev/api/live#bidigeneratecontentsetup) json payload.

Note on the `setup.model` field — the format depends on which API is targeted:
- Gemini Developer API: `models/gemini-2.0-flash-exp` (or other published model id)
- Vertex AI: `projects/{PROJECT}/locations/{LOCATION}/publishers/google/models/{MODEL_ID}`

```
uuid_google_s2s <uuid> client.event client-event-json
```
where
- client-event-json: a json string conforming to the [syntax described here](https://ai.google.dev/api/live).

```
uuid_google_s2s <uuid> session.delete
```
Ends the session.

### Events
This module fires the following events:
- google_s2s::connect - fired when the websocket connection is established
- google_s2s::connect_failed - fired if the websocket connection fails
- google_s2s::disconnect - fired when when the connection is dropped from far end (includes `close_code` and `close_reason` in JSON body)
- google_s2s::server_event - fired when a message is received from the server

### Assistant Speaking Events
The module emits synthetic events for assistant audio playback status via `google_s2s::server_event`:
- `{"type": "output_audio.playback_started"}` - fired when the assistant starts speaking (first audio frame)
- `{"type": "output_audio.playback_stopped", "completion_reason": "completed"}` - fired when the assistant finishes speaking normally
- `{"type": "output_audio.playback_stopped", "completion_reason": "interrupted"}` - fired when the user interrupts the assistant

### Session Resumption
The Gemini Live API supports session resumption. To enable it, include `sessionResumption` in your BidiGenerateContentSetup:

```json
{
  "setup": {
    "model": "models/gemini-2.0-flash-exp",
    "sessionResumption": {}
  }
}
```

The server will send `sessionResumptionUpdate` events via `google_s2s::server_event`:

```json
{
  "sessionResumptionUpdate": {
    "newHandle": "abc123...",
    "resumable": true
  }
}
```

To resume a previous session, include the stored handle in a new connection:

```json
{
  "setup": {
    "model": "models/gemini-2.0-flash-exp",
    "sessionResumption": {
      "handle": "abc123..."
    }
  }
}
```

**Important constraints:**
- Session resumption is not possible during model generation or function execution (`resumable` will be `false`)
- The model cannot be changed when resuming a session
- Always store the latest `newHandle` from `sessionResumptionUpdate` events
- Data loss may occur if resuming during active operations

