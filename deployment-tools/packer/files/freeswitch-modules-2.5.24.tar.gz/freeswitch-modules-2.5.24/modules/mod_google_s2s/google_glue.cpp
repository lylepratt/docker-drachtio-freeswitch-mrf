#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <atomic>
#include <cstring>

#include <boost/algorithm/string/replace.hpp>

#include "mod_google_s2s.h"
#include "jambonz/simple_json_parser.hpp"
#include "jambonz/vector_math.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/
#define BUFFER_GROW_SIZE (16384)

namespace {
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static unsigned int idxCallCount = 0;

  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      if (tech_pvt->audioPlayer) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroying audio player\n", tech_pvt->sessionId, tech_pvt->id);
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        delete p;
        tech_pvt->audioPlayer = nullptr;
      }
      if (tech_pvt->playoutBuffer) {
        CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
        delete playoutBuffer;
        tech_pvt->playoutBuffer = nullptr;
      }
      if (tech_pvt->resampler_in) {
        speex_resampler_destroy(tech_pvt->resampler_in);
        tech_pvt->resampler_in = nullptr;
      }
      /* mutex allocated from session pool - automatically cleaned up */
    }
  }

  static void handleInterruption(private_t* tech_pvt, switch_core_session_t* session) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    p->clear(false);
    // Set flag to emit interrupted event in write_frame
    tech_pvt->process_interrupt = true;
  }

  static void eventCallback(const char* sessionId, const char* bugname, 
    google_s2s::AudioPipe::NotifyEvent_t event, const char* message, const char* binary, size_t len) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case google_s2s::AudioPipe::CONNECT_SUCCESS:
              tech_pvt->state = SESSION_STATE_WS_CONNECTED;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) successful\n", tech_pvt->bugname);
              tech_pvt->responseHandler(session, GS2S_EVENT_CONNECT_SUCCESS, NULL, tech_pvt->bugname);
            break;
            case google_s2s::AudioPipe::CONNECT_FAIL:
              tech_pvt->state = SESSION_STATE_NONE;
              {
                // first thing: we can no longer access the AudioPipe
                std::stringstream json;
                json << "{\"reason\":\"" << message << "\"}";
                tech_pvt->pAudioPipe = nullptr;
                tech_pvt->responseHandler(session, GS2S_EVENT_CONNECT_FAIL, (char *) json.str().c_str(), tech_pvt->bugname);
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
              }
            break;
            case google_s2s::AudioPipe::CONNECTION_DROPPED:
              tech_pvt->state = SESSION_STATE_NONE;

              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              // message contains close_code and close_reason as JSON
              tech_pvt->responseHandler(session, GS2S_EVENT_DISCONNECT, message, tech_pvt->bugname);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) dropped from far end: %s\n", tech_pvt->bugname, message ? message : "");
            break;
            case google_s2s::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              tech_pvt->state = SESSION_STATE_NONE;

              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully: %s\n", tech_pvt->bugname, message ? message : "");
            break;
            case google_s2s::AudioPipe::MESSAGE:
            {
              cJSON* json = parse_json_string(session, message) ;
              if (!json) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "failed to parse json for message %s\n", message);
              }
              else {
                bool forward = true;
                bool hasAudio = false;
                if (cJSON_HasObjectItem(json, "setupComplete")) {
                  forward = false;
                  tech_pvt->state = SESSION_STATE_CONVERSATION_STARTED;
                } else if (cJSON_HasObjectItem(json, "sessionResumptionUpdate")) {
                  // Forward to application so it can store handle for future resumption.
                } else if (cJSON_HasObjectItem(json, "serverContent")) {
                  auto serverContent = cJSON_GetObjectItem(json, "serverContent");
                  if (serverContent) {
                    // Check if serverContent has an interrupted field
                    cJSON* interrupted = cJSON_GetObjectItem(serverContent, "interrupted");
                    if (interrupted && cJSON_IsTrue(interrupted)) {
                      // Handle the interruption
                      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "Detected interruption in serverContent\n");
                      
                      // Call the existing handleInterruption function
                      handleInterruption(tech_pvt, session);
                    }

                    // Check if serverContent has a modelTurn field
                    cJSON* modelTurn = cJSON_GetObjectItem(serverContent, "modelTurn");
                    if (modelTurn && cJSON_IsObject(modelTurn)) {
                      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "Received modelTurn object\n");

                      // The AI is now speaking - only set flag if not already speaking
                      if (!tech_pvt->asssistant_is_speaking) {
                        tech_pvt->assistant_started_speaking = 1;
                      }
                      
                      // Check for parts array in modelTurn
                      cJSON* parts = cJSON_GetObjectItem(modelTurn, "parts");
                      if (parts && cJSON_IsArray(parts)) {
                        int partsCount = cJSON_GetArraySize(parts);

                        // Process each part - extract audio for playout, remove audio parts from JSON
                        for (int i = partsCount - 1; i >= 0; i--) {
                          cJSON* part = cJSON_GetArrayItem(parts, i);
                          cJSON* inlineData = cJSON_GetObjectItem(part, "inlineData");

                          if (inlineData) {
                            cJSON* mimeType = cJSON_GetObjectItem(inlineData, "mimeType");
                            cJSON* data = cJSON_GetObjectItem(inlineData, "data");

                            if (mimeType && cJSON_IsString(mimeType) && data && cJSON_IsString(data)) {
                              if (strncmp(mimeType->valuestring, "audio/pcm", 9) == 0) {
                                // Send base64 data directly to the audio player
                                if (tech_pvt->audioPlayer && data->valuestring[0] != '\0') {
                                  AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
                                  p->bufferAudio(data->valuestring, strlen(data->valuestring));
                                }
                                cJSON_DeleteItemFromArray(parts, i);
                                hasAudio = true;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

                if (forward) {
                  if (hasAudio) {
                    // Re-serialize JSON with audio data stripped
                    char* cleaned = cJSON_PrintUnformatted(json);
                    if (cleaned) {
                      tech_pvt->responseHandler(session, GS2S_EVENT_SERVER, cleaned, tech_pvt->bugname);
                      cJSON_free(cleaned);
                    }
                  } else {
                    tech_pvt->responseHandler(session, GS2S_EVENT_SERVER, message, tech_pvt->bugname);
                  }
                }

                cJSON_Delete(json);
              }
            }
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from google_s2s %d:%s\n", event, message);
              break;
          }
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event callback sessionId %s bugname %s not found for message %s\n", sessionId, bugname, message);
      }
      switch_core_session_rwunlock(session);
    }
  }

  /* Gemini Live API input is PCM16 mono 16kHz. */
  static const int GOOGLE_LIVE_INPUT_SAMPLE_RATE = 16000;

  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, int sampling, const char* apiKey,
    const char* host, const char* path, responseHandler_t responseHandler) {
    /* OAuth tokens start with "ya29." -> Authorization: Bearer header.
       API keys ("AIza...") -> ?key= in URL.
       Revisit if Google changes token format (e.g. workload identity).

       Note: OAuth tokens expire ~1hr. Caller must mint fresh token per session;
       there is no mid-session refresh. Existing WS connection survives token
       expiry, but a dropped/reconnected session with a stale token will fail. */
    const bool useBearer = apiKey && strncmp(apiKey, "ya29.", 5) == 0;

    std::ostringstream oss;
    if (useBearer) {
      oss << path;
    } else {
      oss << path << (strchr(path, '?') ? '&' : '?') << "key=" << apiKey;
    }
    switch_codec_t* read_codec = switch_core_session_get_read_codec(session);

    const int channels = 1;
    const int port = 443;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * read_codec->implementation->samples_per_second / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_codec_implementation_t read_impl;
    switch_core_session_get_read_impl(session, &read_impl);

    /* Init resampler first — if it fails, no AudioPipe to leak. */
    const int codec_rate = read_codec->implementation->samples_per_second;
    if (codec_rate != GOOGLE_LIVE_INPUT_SAMPLE_RATE) {
      int err = 0;
      tech_pvt->resampler_in = speex_resampler_init(1, codec_rate, GOOGLE_LIVE_INPUT_SAMPLE_RATE, SWITCH_RESAMPLE_QUALITY, &err);
      if (err != 0) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
          "resampler init %d->%d failed: %s\n", codec_rate, GOOGLE_LIVE_INPUT_SAMPLE_RATE, speex_resampler_strerror(err));
        return SWITCH_STATUS_FALSE;
      }
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
        "(%u) input resampler %d -> %d Hz\n", tech_pvt->id, codec_rate, GOOGLE_LIVE_INPUT_SAMPLE_RATE);
    }

    /* Bearer mode -> token goes to AudioPipe (used in handshake header).
       Key mode -> credential already in URL, pass nullptr.
       Sample rate is always 16000 (Live API requirement, not codec rate). */
    google_s2s::AudioPipe* ap = new google_s2s::AudioPipe(tech_pvt->sessionId, tech_pvt->bugname, host, port, oss.str().c_str(),
      buflen, read_impl.decoded_bytes_per_packet, useBearer ? apiKey : nullptr, GOOGLE_LIVE_INPUT_SAMPLE_RATE, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }

    tech_pvt->pAudioPipe = static_cast<void *>(ap);

    auto playoutBuffer = new CircularBuffer(64000);
    auto audioPlayer = new AudioPlayer(tech_pvt->mutex, playoutBuffer, tech_pvt->sessionId);
    // Gemini returns audio at 24kHz; resample to codec rate for playout.
    audioPlayer->setResampling(24000, codec_rate);
    audioPlayer->enableBase64Encoding(true);
    tech_pvt->audioPlayer = (void *) audioPlayer;
    tech_pvt->playoutBuffer = (void *) playoutBuffer;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now\n");
    ap->connect();
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) fork_data_init\n", tech_pvt->id);

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, llevel, "%s\n", line);
  }
}


extern "C" {

  switch_status_t google_s2s_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_google_s2s: audio buffer (in secs): %d secs\n", nAudioBufferSecs);
 
    int logs = LLL_ERR | LLL_WARN ;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    google_s2s::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t google_s2s_cleanup() {
    bool cleanup = false;
    cleanup = google_s2s::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }
	
  switch_status_t google_s2s_session_create(switch_core_session_t *session, responseHandler_t responseHandler,
		uint32_t samples_per_second, const char* bugname, const char* apiKey, const char* host, const char* path, void **ppUserData)
  {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    private_t* tech_pvt;

    if (bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "google_s2s_session_create failed because connection already in progress\n");
      return SWITCH_STATUS_FALSE;
    }

    tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }
    memset(tech_pvt, 0, sizeof(private_t));
    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));

    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->id = ++idxCallCount;

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second, apiKey, host, path, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t google_s2s_send_client_event(switch_core_session_t *session, const char* bugname, cJSON* json) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "google_s2s_send_client_event failed because no bug\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
  
    if (!tech_pvt) return SWITCH_STATUS_FALSE;
    google_s2s::AudioPipe *pAudioPipe = static_cast<google_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
    if (pAudioPipe) {
      char *json_string = cJSON_PrintUnformatted(json);
      if (!json_string) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "google_s2s_send_client_event failed to serialize json\n");
        return SWITCH_STATUS_FALSE;
      }
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "google_s2s_send_client_event sending: %s\n", json_string);
      pAudioPipe->bufferForSending(json_string);
      free(json_string);
    }

    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t google_s2s_session_delete(switch_core_session_t *session, const char* bugname, int channelIsClosing) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "google_s2s_session_delete: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    if (!tech_pvt) return SWITCH_STATUS_FALSE;

    uint32_t id = tech_pvt->id;

    google_s2s::AudioPipe *pAudioPipe = static_cast<google_s2s::AudioPipe *>(tech_pvt->pAudioPipe);

    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);

    // get the bug again, now that we are under lock
    {
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        switch_channel_set_private(channel, bugname, NULL);
        if (!channelIsClosing) {
          switch_core_media_bug_remove(session, &bug);
        }
      }
    }

    if (pAudioPipe) pAudioPipe->close();

    switch_mutex_unlock(tech_pvt->mutex);

    destroy_tech_pvt(tech_pvt);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) google_s2s_session_delete complete\n", id);
    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_bool_t google_s2s_write_frame(switch_media_bug_t *bug, void* user_data) {
    private_t* tech_pvt = (private_t*) user_data;
    if (!tech_pvt) return SWITCH_TRUE;

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
      if (!playoutBuffer) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }

      // Handle interruption - emit interrupted event and clear buffer
      if (tech_pvt->process_interrupt) {
        switch_core_session_t* session = switch_core_session_locate(tech_pvt->sessionId);
        tech_pvt->process_interrupt = false;

        if (session) {
          tech_pvt->responseHandler(session, GS2S_EVENT_SERVER,
            "{\"type\": \"output_audio.playback_stopped\", \"completion_reason\": \"interrupted\"}", tech_pvt->bugname);
          switch_core_session_rwunlock(session);
        }
        tech_pvt->asssistant_is_speaking = false;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) assistant stopped speaking (interrupted)\n", tech_pvt->sessionId, tech_pvt->id);
      }

      if (playoutBuffer->size() > 0) {
        switch_frame_t* rframe = switch_core_media_bug_get_write_replace_frame(bug);
        int16_t *fp = reinterpret_cast<int16_t*>(rframe->data);

        rframe->channels = 1;
        rframe->datalen = rframe->samples * sizeof(int16_t);

        int16_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        memset(data, 0, sizeof(data));

        int samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(rframe->samples));
        auto count = playoutBuffer->getBlock(data, samplesToCopy);
        if (count != samplesToCopy) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s (%u) el_dub_speech_frame - failed to get %d samples from playout buffer, got %d\n", tech_pvt->sessionId, tech_pvt->id, samplesToCopy, count);
        }
        else {
          vector_add(fp, data, rframe->samples);
          vector_normalize(fp, rframe->samples);
          switch_core_media_bug_set_write_replace_frame(bug, rframe);
        }

        // notify when assistant starts speaking
        if (tech_pvt->assistant_started_speaking) {
          switch_core_session_t* session = switch_core_session_locate(tech_pvt->sessionId);
          if (session) {
            tech_pvt->responseHandler(session, GS2S_EVENT_SERVER,
              "{\"type\": \"output_audio.playback_started\"}", tech_pvt->bugname);
            switch_core_session_rwunlock(session);
          }
          tech_pvt->assistant_started_speaking = 0;
          tech_pvt->asssistant_is_speaking = true;
        }

        // notify when assistant stops speaking
        if (playoutBuffer->size() == 0 && tech_pvt->asssistant_is_speaking) {
          switch_core_session_t* session = switch_core_session_locate(tech_pvt->sessionId);
          if (session) {
            tech_pvt->responseHandler(session, GS2S_EVENT_SERVER,
              "{\"type\": \"output_audio.playback_stopped\", \"completion_reason\": \"completed\"}", tech_pvt->bugname);
            switch_core_session_rwunlock(session);
          }
          tech_pvt->asssistant_is_speaking = false;

          if (!tech_pvt->initial_assistant_response_completed) {
            tech_pvt->initial_assistant_response_completed = 1;
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) initial assistant greeting finished\n", tech_pvt->sessionId, tech_pvt->id);
          }
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) assistant stopped speaking (completed)\n", tech_pvt->sessionId, tech_pvt->id);
        }
      }
      switch_mutex_unlock(tech_pvt->mutex);
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) google_s2s_write_frame failed to lock mutex\n", tech_pvt->sessionId, tech_pvt->id);
    }

    return SWITCH_TRUE;
  }

	switch_bool_t google_s2s_read_frame(switch_core_session_t *session, switch_media_bug_t *bug, void* user_data) {
    private_t* tech_pvt = (private_t*) user_data;

    if (!tech_pvt) return SWITCH_TRUE;

    /* dont send audio until initial response.created is received */
    if (tech_pvt->state != SESSION_STATE_CONVERSATION_STARTED) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, conversation not started\n");
      return SWITCH_TRUE;
    }

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      if (!tech_pvt->pAudioPipe) {
        switch_mutex_unlock(tech_pvt->mutex);
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, no tech_pvt\n");
        return SWITCH_TRUE;
      }
      google_s2s::AudioPipe *pAudioPipe = static_cast<google_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
      if (pAudioPipe->getLwsState() != google_s2s::AudioPipe::LWS_CLIENT_CONNECTED) {
        switch_mutex_unlock(tech_pvt->mutex);
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, LWS client not connected\n");
        return SWITCH_TRUE;
      }
      pAudioPipe->lockAudioBuffer();
      size_t available = pAudioPipe->binarySpaceAvailable();

      if (NULL == tech_pvt->resampler_in) {
        switch_frame_t frame = { 0 };
        frame.data = pAudioPipe->binaryWritePtr();
        frame.buflen = available;

        while (true) {
          if (available < pAudioPipe->binaryMinSpace()) {
            if (!tech_pvt->buffer_overrun_notified) {
              tech_pvt->buffer_overrun_notified = 1;
              tech_pvt->responseHandler(session, GS2S_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname);
            }
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "dropping packets!\n");
            pAudioPipe->binaryWritePtrResetToZero();
            frame.data = pAudioPipe->binaryWritePtr();
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          }

          switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
          if (rv != SWITCH_STATUS_SUCCESS) break;
          if (frame.datalen) {
            pAudioPipe->binaryWritePtrAdd(frame.datalen);
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
            frame.data = pAudioPipe->binaryWritePtr();
          }
        }
      } else {
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = { 0 };
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;

        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
          if (frame.datalen) {
            spx_uint32_t out_len = available >> 1;
            spx_uint32_t in_len = frame.samples;

            speex_resampler_process_int(tech_pvt->resampler_in, 0,
              (const spx_int16_t *) frame.data,
              (spx_uint32_t *) &in_len,
              (spx_int16_t *) ((char *) pAudioPipe->binaryWritePtr()),
              &out_len);

            if (out_len > 0) {
              pAudioPipe->binaryWritePtrAdd(out_len << 1);
              available = pAudioPipe->binarySpaceAvailable();
            }
            if (available < pAudioPipe->binaryMinSpace()) {
              if (!tech_pvt->buffer_overrun_notified) {
                tech_pvt->buffer_overrun_notified = 1;
                tech_pvt->responseHandler(session, GS2S_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname);
              }
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "dropping packets!\n");
              pAudioPipe->binaryWritePtrResetToZero();
              available = pAudioPipe->binarySpaceAvailable();
            }
          }
          frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}
