#include <switch.h>
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <vector>

#include "audio_pipe.hpp"
#include "jambonz/base64.hpp"

/* discard incoming text messages over the socket that are longer than this */
#define MAX_RECV_BUF_SIZE (65 * 1024 * 10)
#define RECV_BUF_REALLOC_SIZE (8 * 1024)

// lets send audio every 60ms
// at 24k samples/sec, with 20 ms packetization, we send 480 samples every 20 ms
// each sample is 2 bytes, so 960 bytes every 20 ms
// 960 * 3 = 2880 bytes every 60 ms
#define MIN_AUDIO_BYTES (2880)

/*
 * The OpenAI-Alpha header is MANDATORY on the /v1/live handshake. Without it the
 * upgrade is refused before the websocket is established:
 *
 *   400 {"code":"invalid_websocket_query",
 *        "message":"OpenAI-Alpha must be \"quicksilver=v2\" for /v1/live"}
 *
 * The value is an alpha protocol-version tag, so it will churn; the env override
 * lets an operator track a bump without waiting for a module rebuild. Kept in
 * lockstep with mediajam's internal/s2s/gptlive.go.
 */
#define GPTLIVE_ALPHA_HEADER "OpenAI-Alpha:"
#define GPTLIVE_ALPHA_VALUE  "quicksilver=v2"

using namespace gptlive_s2s;

namespace {
  static const char *requestedTcpKeepaliveSecs = std::getenv("MOD_AUDIO_FORK_TCP_KEEPALIVE_SECS");
  static int nTcpKeepaliveSecs = requestedTcpKeepaliveSecs ? ::atoi(requestedTcpKeepaliveSecs) : 55;

  static const char *alphaOverride = std::getenv("JAMBONES_GPTLIVE_ALPHA");
  static const char *gptliveAlphaValue = (alphaOverride && *alphaOverride) ? alphaOverride : GPTLIVE_ALPHA_VALUE;
}

int AudioPipe::lws_callback(struct lws *wsi,
  enum lws_callback_reasons reason,
  void *user, void *in, size_t len) {

  struct AudioPipe::lws_per_vhost_data *vhd =
    (struct AudioPipe::lws_per_vhost_data *) lws_protocol_vh_priv_get(lws_get_vhost(wsi), lws_get_protocol(wsi));

  AudioPipe ** ppAp = (AudioPipe **) user;

  switch (reason) {
    case LWS_CALLBACK_PROTOCOL_INIT:
      vhd = (struct AudioPipe::lws_per_vhost_data *) lws_protocol_vh_priv_zalloc(lws_get_vhost(wsi), lws_get_protocol(wsi), sizeof(struct AudioPipe::lws_per_vhost_data));
      vhd->context = lws_get_context(wsi);
      vhd->protocol = lws_get_protocol(wsi);
      vhd->vhost = lws_get_vhost(wsi);
      break;

    case LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER:
      {
        AudioPipe* ap = findPendingConnect(wsi);
        if (ap) {
          unsigned char **p = (unsigned char **)in, *end = (*p) + len;

          /* the alpha opt-in rides along on every auth mode, so it is added
             before (and independently of) the Authorization header */
          if (lws_add_http_header_by_name(wsi, (const unsigned char *) GPTLIVE_ALPHA_HEADER,
                                          (const unsigned char *) gptliveAlphaValue,
                                          strlen(gptliveAlphaValue), p, end)) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                              "LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER: failed to add OpenAI-Alpha header\n");
            return -1;
          }

          std::string apiKey = ap->getApiKey();
          if (apiKey.length() > 0) {
            std::string authHeaderStr = "Bearer " + apiKey;

            const char *authHeaderName = "Authorization:";
            if (lws_add_http_header_by_name(wsi, (const unsigned char *)authHeaderName,
                                            (const unsigned char *)authHeaderStr.c_str(),
                                            authHeaderStr.length(), p, end)) {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                                  "LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER: failed to add Authorization header\n");
                return -1;
            }
          }
        }
      }
      break;

    case LWS_CALLBACK_EVENT_WAIT_CANCELLED:
      processPendingConnects(vhd);
      processPendingDisconnects(vhd);
      processPendingWrites();
      break;

    case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
      {
        AudioPipe* ap = findAndRemovePendingConnect(wsi);
        int rc = lws_http_client_http_response(wsi);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CONNECTION_ERROR: %s, response status %d\n", in ? (char *)in : "(null)", rc);
        if (ap) {
          ap->m_state = LWS_CLIENT_FAILED;
          ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), gptlive_s2s::AudioPipe::CONNECT_FAIL, (char *) in);
          /* Nobody else will ever free it: *ppAp was only ever set on
             CLIENT_ESTABLISHED, so LWS_CALLBACK_CLIENT_CLOSED sees a null ap and
             returns early, and the glue has just dropped its pointer in the
             callback above. Without this every failed connect leaks the object
             plus its multi-hundred-KB m_audio_buffer. The callback runs FIRST so
             the glue has released its reference (under tech_pvt->mutex) before
             the memory goes away. */
          delete ap;
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CONNECTION_ERROR unable to find wsi %p..\n", wsi);
        }
      }
      break;

    case LWS_CALLBACK_CLIENT_ESTABLISHED:
      {
        AudioPipe* ap = findAndRemovePendingConnect(wsi);

        if (ap) {
          *ppAp = ap;
          ap->m_vhd = vhd;
          ap->m_state = LWS_CLIENT_CONNECTED;
          ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), gptlive_s2s::AudioPipe::CONNECT_SUCCESS, NULL);
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_ESTABLISHED unable to find wsi %p..\n", wsi);
        }
      }
      break;

    case LWS_CALLBACK_WS_PEER_INITIATED_CLOSE:
      {
        AudioPipe* ap = *ppAp;
        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_WS_PEER_INITIATED_CLOSE unable to find wsi %p..\n", wsi);
          return 0;
        }
        // Extract close code and reason
        uint16_t close_code = (in && len >= 2) ? (((unsigned char *)in)[0] << 8) | ((unsigned char *)in)[1] : 0;
        std::string close_reason;
        if (in && len > 2) {
          close_reason = std::string((char *)in + 2, len - 2);
        }
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s WebSocket closed with code: %d, reason: %s\n",
          ap->m_uuid.c_str(), close_code, close_reason.c_str());
      }
      break;

    case LWS_CALLBACK_CLIENT_CLOSED:
      {
        AudioPipe* ap = *ppAp;

        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CLOSED unable to find wsi %p..\n", wsi);
          return 0;
        }
        if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
          // closed by us
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s socket closed by us\n", ap->m_uuid.c_str());
          ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), gptlive_s2s::AudioPipe::CONNECTION_CLOSED_GRACEFULLY, NULL);
        }
        else if (ap->m_state == LWS_CLIENT_CONNECTED) {
          // closed by far end
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s socket closed by far end\n", ap->m_uuid.c_str());
          ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), gptlive_s2s::AudioPipe::CONNECTION_DROPPED, NULL);
        }
        ap->m_state = LWS_CLIENT_DISCONNECTED;

        //NB: after receiving any of the events above, any holder of a
        //pointer or reference to this object must treat is as no longer valid

        *ppAp = NULL;
        delete ap;
      }
      break;

    case LWS_CALLBACK_CLIENT_RECEIVE:
      {
        AudioPipe* ap = *ppAp;

        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE unable to find wsi %p..\n", wsi);
          return 0;
        }

        /* GPT Live is an all-JSON protocol in both directions: agent audio arrives
           base64-encoded inside output_audio.delta, never as a binary frame. */
        if (lws_frame_is_binary(wsi)) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE received binary frame, discarding.\n");
          return 0;
        }

        if (lws_is_first_fragment(wsi)) {
          // allocate a buffer for the entire chunk of memory needed
          assert(nullptr == ap->m_recv_buf);
          ap->m_recv_buf_len = len + lws_remaining_packet_payload(wsi);
          ap->m_recv_buf = (uint8_t*) malloc(ap->m_recv_buf_len);
          ap->m_recv_buf_ptr = ap->m_recv_buf;
        }

        if (nullptr == ap->m_recv_buf) {
          /* a mid-message fragment arriving after we gave up on the message */
          return 0;
        }

        size_t write_offset = ap->m_recv_buf_ptr - ap->m_recv_buf;
        size_t remaining_space = ap->m_recv_buf_len - write_offset;
        if (remaining_space < len) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE buffer realloc needed.\n");
          size_t newlen = ap->m_recv_buf_len + (len - remaining_space) + RECV_BUF_REALLOC_SIZE;
          if (newlen > MAX_RECV_BUF_SIZE) {
            free(ap->m_recv_buf);
            ap->m_recv_buf = ap->m_recv_buf_ptr = nullptr;
            ap->m_recv_buf_len = 0;
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE max buffer exceeded, discarding message.\n");
            return 0;
          }
          uint8_t* newbuf = (uint8_t*) realloc(ap->m_recv_buf, newlen);
          if (nullptr == newbuf) {
            free(ap->m_recv_buf);
            ap->m_recv_buf = ap->m_recv_buf_ptr = nullptr;
            ap->m_recv_buf_len = 0;
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE realloc failed, discarding message.\n");
            return 0;
          }
          ap->m_recv_buf = newbuf;
          ap->m_recv_buf_len = newlen;
          ap->m_recv_buf_ptr = ap->m_recv_buf + write_offset;
        }

        if (len > 0) {
          memcpy(ap->m_recv_buf_ptr, in, len);
          ap->m_recv_buf_ptr += len;
        }
        if (lws_is_final_fragment(wsi)) {
          std::string msg((char *)ap->m_recv_buf, ap->m_recv_buf_ptr - ap->m_recv_buf);
          free(ap->m_recv_buf);
          ap->m_recv_buf = ap->m_recv_buf_ptr = nullptr;
          ap->m_recv_buf_len = 0;
          ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), gptlive_s2s::AudioPipe::MESSAGE, msg.c_str());
        }
      }
      break;

    case LWS_CALLBACK_CLIENT_WRITEABLE:
      {
        AudioPipe* ap = *ppAp;

        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE unable to find wsi %p..\n", wsi);
          return 0;
        }

        /* check for text frames to send.
           Note this runs BEFORE the disconnect check below, and re-arms
           writability, which is what lets the graceful {"type":"session.close"}
           queued by close() actually reach the server before we shut down. */
        {
          std::string text;
          {
            std::lock_guard<std::mutex> lk(ap->m_text_mutex);
            if (!ap->m_pending_text.empty()) {
              text = std::move(ap->m_pending_text.front());
              ap->m_pending_text.pop_front();
            }
          }
          if (!text.empty()) {
            std::vector<uint8_t> buf(LWS_PRE + text.length());
            memcpy(buf.data() + LWS_PRE, text.c_str(), text.length());
            int n = text.length();
            int m = lws_write(wsi, buf.data() + LWS_PRE, n, LWS_WRITE_TEXT);
            if (m < n) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE %s ERROR sending text frames %d %d\n", ap->m_uuid.c_str(), m, n);
              return -1;
            }

            // there may be more text, and there may be audio data, but only one
            // write per writeable event - get them next time
            lws_callback_on_writable(wsi);

            return 0;
          }
        }

        if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
          lws_close_reason(wsi, LWS_CLOSE_STATUS_NORMAL, NULL, 0);
          return -1;
        }

        // check for audio packets
        {
          std::lock_guard<std::mutex> lk(ap->m_audio_mutex);

          if (ap->m_audio_buffer_write_offset > LWS_PRE) {
            size_t datalen = ap->m_audio_buffer_write_offset - LWS_PRE;

            if (datalen >= MIN_AUDIO_BYTES) {
              /* GPT Live: input_audio.append, NOT input_audio_buffer.append (the
                 Realtime API's name), carrying base64 raw headerless mono pcm16
                 LE at a fixed 24 kHz. */
              std::ostringstream oss;
              oss << "{\"type\":\"input_audio.append\",\"audio\":\""
                  << drachtio::base64_encode((unsigned char const *) ap->m_audio_buffer + LWS_PRE, datalen) << "\"}";
              std::string result = oss.str();
              std::vector<uint8_t> buf(LWS_PRE + result.length());
              memcpy(buf.data() + LWS_PRE, result.c_str(), result.length());
              int n = result.length();
              int m = lws_write(wsi, buf.data() + LWS_PRE, n, LWS_WRITE_TEXT);
              if (m < n) {
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE attemped to send %d bytes only sent %d wsi %p..\n",
                  n, m, wsi);
              }
              ap->m_audio_buffer_write_offset = LWS_PRE;
            }
          }
        }

        return 0;
      }
      break;

    default:
      break;
  }
  return lws_callback_http_dummy(wsi, reason, user, in, len);
}


// static members
static const lws_retry_bo_t retry = {
    nullptr,   // retry_ms_table
    0,         // retry_ms_table_count
    0,         // conceal_count
    UINT16_MAX,         // secs_since_valid_ping
    UINT16_MAX,        // secs_since_valid_hangup
    0          // jitter_percent
};

struct lws_context *AudioPipe::context = nullptr;
std::thread AudioPipe::serviceThread;
std::mutex AudioPipe::mutex_connects;
std::mutex AudioPipe::mutex_disconnects;
std::mutex AudioPipe::mutex_writes;
std::list<AudioPipe*> AudioPipe::pendingConnects;
std::list<AudioPipe*> AudioPipe::pendingDisconnects;
std::list<AudioPipe*> AudioPipe::pendingWrites;
AudioPipe::log_emit_function AudioPipe::logger;
std::mutex AudioPipe::mapMutex;
bool AudioPipe::stopFlag;

void AudioPipe::processPendingConnects(lws_per_vhost_data *vhd) {
  std::list<AudioPipe*> connects;
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    for (auto it = pendingConnects.begin(); it != pendingConnects.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_IDLE) {
        connects.push_back(*it);
        (*it)->m_state = LWS_CLIENT_CONNECTING;
      }
    }
  }
  for (auto it = connects.begin(); it != connects.end(); ++it) {
    AudioPipe* ap = *it;
    if (ap->connect_client(vhd)) continue;

    /* lws_client_connect_via_info failed synchronously, so no wsi exists and no
       LWS_CALLBACK_CLIENT_CONNECTION_ERROR will ever arrive for it. Left alone
       the pipe sits in pendingConnects forever (leaked, with its audio buffer)
       and the glue never learns the connect failed, so the verb hangs until the
       call ends. Report it and reclaim it here. */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
      "%s AudioPipe::processPendingConnects failed to create a client connection\n", ap->m_uuid.c_str());
    /* ~AudioPipe retires it from pendingConnects for us */
    ap->m_state = LWS_CLIENT_FAILED;
    ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), gptlive_s2s::AudioPipe::CONNECT_FAIL,
      "failed to create client connection");
    delete ap;
  }
}

void AudioPipe::processPendingDisconnects(lws_per_vhost_data *vhd) {
  std::list<AudioPipe*> disconnects;
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    for (auto it = pendingDisconnects.begin(); it != pendingDisconnects.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_DISCONNECTING) disconnects.push_back(*it);
    }
    pendingDisconnects.clear();
  }
  for (auto it = disconnects.begin(); it != disconnects.end(); ++it) {
    AudioPipe* ap = *it;
    lws_callback_on_writable(ap->m_wsi);
  }
}

void AudioPipe::processPendingWrites() {
  std::list<AudioPipe*> writes;
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    for (auto it = pendingWrites.begin(); it != pendingWrites.end(); ++it) {
       if ((*it)->m_state == LWS_CLIENT_CONNECTED) writes.push_back(*it);
    }
    pendingWrites.clear();
  }
  for (auto it = writes.begin(); it != writes.end(); ++it) {
    AudioPipe* ap = *it;
    lws_callback_on_writable(ap->m_wsi);
  }
}

AudioPipe* AudioPipe::findAndRemovePendingConnect(struct lws *wsi) {
  AudioPipe* ap = NULL;
  std::lock_guard<std::mutex> guard(mutex_connects);
  std::list<AudioPipe* > toRemove;

  for (auto it = pendingConnects.begin(); it != pendingConnects.end() && !ap; ++it) {
    int state = (*it)->m_state;

    if ((*it)->m_wsi == nullptr)
      toRemove.push_back(*it);

    if ((state == LWS_CLIENT_CONNECTING) &&
      (*it)->m_wsi == wsi) ap = *it;
  }

  for (auto it = toRemove.begin(); it != toRemove.end(); ++it)
    pendingConnects.remove(*it);

  if (ap) {
    pendingConnects.remove(ap);
  }

  return ap;
}

AudioPipe* AudioPipe::findPendingConnect(struct lws *wsi) {
  AudioPipe* ap = NULL;
  std::lock_guard<std::mutex> guard(mutex_connects);

  for (auto it = pendingConnects.begin(); it != pendingConnects.end() && !ap; ++it) {
    int state = (*it)->m_state;
    if ((state == LWS_CLIENT_CONNECTING) &&
      (*it)->m_wsi == wsi) ap = *it;
  }
  return ap;
}

void AudioPipe::addPendingConnect(AudioPipe* ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    pendingConnects.push_back(ap);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s after adding connect there are %zu pending connects\n",
      ap->m_uuid.c_str(), pendingConnects.size());
  }
  lws_cancel_service(context);
}
void AudioPipe::addPendingDisconnect(AudioPipe* ap) {
  ap->m_state = LWS_CLIENT_DISCONNECTING;
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    pendingDisconnects.push_back(ap);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s after adding disconnect there are %zu pending disconnects\n",
      ap->m_uuid.c_str(), pendingDisconnects.size());
  }
  lws_cancel_service(ap->m_vhd->context);
}
void AudioPipe::addPendingWrite(AudioPipe* ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    pendingWrites.push_back(ap);
  }
  lws_cancel_service(ap->m_vhd->context);
}

bool AudioPipe::lws_service_thread() {
  struct lws_context_creation_info info;

  const struct lws_protocols protocols[] = {
    {
      "",
      AudioPipe::lws_callback,
      sizeof(void *),
      1024,
    },
    { NULL, NULL, 0, 0 }
  };

  memset(&info, 0, sizeof info);
  info.port = CONTEXT_PORT_NO_LISTEN;
  info.options = LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT ;
  info.protocols = protocols;
  info.ka_time = nTcpKeepaliveSecs;      // tcp keep-alive timer
  info.ka_probes = 4;                   // number of times to try ka before closing connection
  info.ka_interval = 5;                 // time between ka's
  info.timeout_secs = 10;               // doc says timeout for "various processes involving network roundtrips"
  info.keepalive_timeout = 5;           // seconds to allow remote client to hold on to an idle HTTP/1.1 connection
  info.timeout_secs_ah_idle = 10;       // secs to allow a client to hold an ah without using it
  info.retry_and_idle_policy = &retry;

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::lws_service_thread creating context\n");

  context = lws_create_context(&info);
  if (!context) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread failed creating context\n");
    return false;
  }

  int n;
  do {
    n = lws_service(context, 10);
  } while (n >= 0 && !stopFlag);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::lws_service_thread ending\n");
  lws_context_destroy(context);

  return true;
}

void AudioPipe::initialize(int loglevel, log_emit_function logger) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize starting\n");
  std::lock_guard<std::mutex> lock(mapMutex);
  stopFlag = false;
  serviceThread = std::thread(&AudioPipe::lws_service_thread);
}

bool AudioPipe::deinitialize() {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::deinitialize\n");
  std::lock_guard<std::mutex> lock(mapMutex);
  stopFlag = true;
  if (serviceThread.joinable()) {
    serviceThread.join();
  }

  return true;
}

// instance members
AudioPipe::AudioPipe(const char* uuid, const char* bugname, const char* host, unsigned int port, const char* path,
  size_t bufLen, size_t minFreespace, const char* apiKey, notifyHandler_t callback) :
  /* declaration order, so the compiler does not have to warn about it */
  m_state(LWS_CLIENT_IDLE), m_uuid(uuid), m_host(host), m_port(port), m_path(path),
  m_wsi(nullptr), m_audio_buffer(nullptr), m_audio_buffer_max_len(bufLen),
  m_audio_buffer_write_offset(LWS_PRE), m_audio_buffer_min_freespace(minFreespace),
  m_recv_buf(nullptr), m_recv_buf_ptr(nullptr), m_recv_buf_len(0),
  m_vhd(nullptr), m_callback(callback), m_bugname(bugname) {

  if (apiKey) m_apiKey = apiKey;
  else m_apiKey = "";

  m_audio_buffer = new uint8_t[m_audio_buffer_max_len];
}
AudioPipe::~AudioPipe() {
  /*
   * The three pending lists hold raw pointers, and an entry can outlive the
   * object: the media thread pushes onto pendingWrites from unlockAudioBuffer,
   * and if the socket closes before the service loop next drains that list,
   * processPendingWrites would read m_state off freed memory. Retiring ourselves
   * from all three here makes that impossible however we are destroyed.
   *
   * Safe against self-deadlock: every drainer copies what it needs out from
   * under its mutex and releases it before doing work that could delete a pipe.
   */
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    pendingConnects.remove(this);
  }
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    pendingDisconnects.remove(this);
  }
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    pendingWrites.remove(this);
  }

  if (m_audio_buffer) delete [] m_audio_buffer;
  /* m_recv_buf comes from malloc/realloc, so it must be freed - not delete[]d */
  if (m_recv_buf) free(m_recv_buf);
}

void AudioPipe::connect(void) {
  addPendingConnect(this);
}

bool AudioPipe::connect_client(struct lws_per_vhost_data *vhd) {
  assert(m_audio_buffer != nullptr);
  struct lws_client_connect_info i;

  memset(&i, 0, sizeof(i));
  i.context = vhd->context;
  i.port = m_port;
  i.address = m_host.c_str();
  i.path = m_path.c_str();
  i.host = i.address;
  /*
   * i.origin is deliberately LEFT UNSET, unlike every sibling module.
   *
   * lws emits an "Origin:" header only when i.origin is non-NULL
   * (lib/roles/http/client/client-http.c), and because LCCSCF_USE_SSL is set it
   * would send "Origin: https://api.openai.com". /v1/live REFUSES any handshake
   * carrying an Origin header - it reads as a browser request, which is required
   * to authenticate with an ephemeral token rather than a raw api key - and the
   * upgrade comes back 403 Forbidden. Measured against the live endpoint:
   *
   *   Authorization + OpenAI-Alpha, no Origin            -> 101
   *   Authorization + OpenAI-Alpha + Origin: https://...  -> 403
   *   Authorization, no OpenAI-Alpha                      -> 400
   *
   * /v1/realtime tolerates Origin, which is why the identical `i.origin =
   * i.address` line is harmless in mod_openai_s2s. Do not "restore" it here.
   */
  i.ssl_connection = LCCSCF_USE_SSL;
  i.pwsi = &(m_wsi);

  m_state = LWS_CLIENT_CONNECTING;
  m_vhd = vhd;

  m_wsi = lws_client_connect_via_info(&i);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s attempting connection, path: %s, wsi is %p\n", m_uuid.c_str(), m_path.c_str(), m_wsi);

  return nullptr != m_wsi;
}

void AudioPipe::bufferForSending(const char* text) {
  if (m_state != LWS_CLIENT_CONNECTED) return;
  if (!text || '\0' == *text) return;
  {
    std::lock_guard<std::mutex> lk(m_text_mutex);
    m_pending_text.emplace_back(text);
  }
  addPendingWrite(this);
}

void AudioPipe::unlockAudioBuffer() {
  if (m_audio_buffer_write_offset > LWS_PRE) addPendingWrite(this);
  m_audio_mutex.unlock();
}

void AudioPipe::close() {
  if (m_state != LWS_CLIENT_CONNECTED) {
    return;
  }
  /* Ask GPT Live to shut down gracefully first. The server acknowledges with
     session.closed and then closes the transport; we do not wait for it - the
     writeable handler flushes this text frame and only then acts on the
     DISCONNECTING state. Matches mediajam's gptliveDialect.Goodbye(). */
  bufferForSending("{\"type\":\"session.close\"}");
  addPendingDisconnect(this);
}
