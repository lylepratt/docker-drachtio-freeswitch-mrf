#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <sstream>

#include "mod_gptlive_s2s.h"

#include "jambonz/simple_json_parser.hpp"
#include "jambonz/vector_math.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/

/* GPT Live has no audio-format negotiation: the event schema mandates raw
   headerless mono pcm16 LE at 24 kHz in both directions. */
#define GPTLIVE_SAMPLE_RATE (24000)

namespace {
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static unsigned int idxCallCount = 0;

  /* The per-call objects whose lifetime is shorter than tech_pvt's. tech_pvt
     itself comes from the session pool and is never freed by us. */
  struct detached_media {
    AudioPlayer *player;
    CircularBuffer *playoutBuffer;
    SpeexResamplerState *resampler;
  };

  /**
   * Unpublish the media objects, to be called WITH tech_pvt->mutex held.
   *
   * Everything that dereferences them - the websocket thread's audio buffering
   * and barge-in, the write_replace thread's playout, the read thread's
   * resampler - does so under that mutex and null-checks first. So once this
   * returns, no other thread can reach them and they can be destroyed safely
   * once the lock is dropped. Without this handoff a caller hanging up while the
   * agent is speaking can free the AudioPlayer under the websocket thread.
   */
  static void detach_media(private_t *tech_pvt, detached_media *out) {
    out->player = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    out->playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
    out->resampler = tech_pvt->resampler_in;
    tech_pvt->audioPlayer = nullptr;
    tech_pvt->playoutBuffer = nullptr;
    tech_pvt->resampler_in = nullptr;
  }

  /**
   * Destroy what detach_media handed back. MUST run with tech_pvt->mutex NOT
   * held: ~AudioPlayer joins its consumer thread, and that thread takes the
   * mutex to write into the playout buffer, so destroying under the lock would
   * deadlock. The player is destroyed before the buffer it writes into.
   */
  static void destroy_media(private_t *tech_pvt, const detached_media& m) {
    if (m.player) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroying audio player\n", tech_pvt->sessionId, tech_pvt->id);
      delete m.player;
    }
    if (m.playoutBuffer) delete m.playoutBuffer;
    if (m.resampler) speex_resampler_destroy(m.resampler);
  }

  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      detached_media m = {nullptr, nullptr, nullptr};

      switch_mutex_lock(tech_pvt->mutex);
      detach_media(tech_pvt, &m);
      switch_mutex_unlock(tech_pvt->mutex);

      destroy_media(tech_pvt, m);
      /* mutex allocated from session pool - automatically cleaned up */
    }
  }

  /* cJSON stores every number in valuedouble; valueint is a plain int and would
     truncate a server-timeline value that outgrows 2^31 ms. */
  static bool getInt64(cJSON* obj, const char* name, int64_t* out) {
    cJSON* item = obj ? cJSON_GetObjectItem(obj, name) : nullptr;
    if (!item || !cJSON_IsNumber(item)) return false;
    *out = (int64_t) item->valuedouble;
    return true;
  }

  /* Both of these run on the websocket thread and touch tech_pvt->audioPlayer,
     which session.delete detaches. Callers hold tech_pvt->mutex, so a non-null
     pointer here is guaranteed to stay alive for the duration of the call. */
  static void processIncomingAudio(private_t* tech_pvt, const char* base64_data) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    if (!p) return;
    p->bufferAudio(base64_data, strlen(base64_data));
  }

  static void handleInterruption(private_t* tech_pvt, switch_core_session_t* session) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    if (!p) return;
    tech_pvt->process_interrupt = 1;
    /* clear(false) drops what the player has decoded so far; the write_replace
       thread clears the playout buffer again when it sees process_interrupt,
       which catches anything decoded between here and there. */
    p->clear(false);
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "interrupt the assistant\n");
  }

  /**
   * turn.created is the ONLY caller-speech signal in the GPT Live schema - there
   * is no input_audio_buffer.speech_started - so barge-in is taken from it.
   *
   * It needs a guard. Turn events are a projection over transcript fragments
   * whose boundaries "reflect cadence, not semantic turn boundaries", so ONE
   * caller utterance can be projected into several user turns and a later
   * projection can arrive after the agent has already started answering.
   * Barging in on that would drain the playout and cut off the very reply the
   * caller is listening to.
   *
   * The discriminator is the turn's own start_ms on the shared server timeline:
   * caller speech that STARTED BEFORE the agent's current audio burst is the
   * question being re-projected, while speech starting at or after the burst is
   * a real interruption. The comparison is against the burst START rather than
   * the newest delta because the vendor generates audio faster than realtime -
   * deltas are stamped seconds ahead of what the caller has actually heard, so
   * comparing against the latest delta would suppress genuine interruptions.
   *
   * Kept in lockstep with mediajam's internal/s2s/gptlive.go.
   */
  static void handleTurnCreated(private_t* tech_pvt, switch_core_session_t* session, cJSON* json) {
    cJSON* turn = cJSON_GetObjectItem(json, "turn");
    const char* role = turn ? cJSON_GetObjectCstr(turn, "role") : nullptr;

    /* an assistant turn is the agent starting to talk; it must not clear its own playout */
    if (!role || 0 != strcmp(role, "user") || !tech_pvt->agent_burst_active) return;

    /* A turn with no start_ms at all cannot be placed on the timeline, so fall
       back to treating it as barge-in: failing open keeps interruption working
       on an unexpected shape, where failing closed would let the agent talk over
       the caller. */
    int64_t turnStartMs = 0;
    if (getInt64(turn, "start_ms", &turnStartMs) && turnStartMs < tech_pvt->burst_start_ms) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG,
        "user turn at %lldms predates the current agent burst at %lldms; re-projection, not barge-in\n",
        (long long) turnStartMs, (long long) tech_pvt->burst_start_ms);
      return;
    }

    /* The burst anchor is consumed whether or not anything is actually being
       heard right now, so the next delta re-anchors it. */
    tech_pvt->agent_burst_active = 0;

    /* Only disturb the playout if the caller is in fact hearing the agent. */
    if (tech_pvt->assistant_is_speaking) handleInterruption(tech_pvt, session);
  }

  static void eventCallback(const char* sessionId, const char* bugname,
    gptlive_s2s::AudioPipe::NotifyEvent_t event, const char* message) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (!session) return;

    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    private_t* tech_pvt = bug ? (private_t*) switch_core_media_bug_get_user_data(bug) : nullptr;

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event callback sessionId %s bugname %s not found for message %s\n",
        sessionId, bugname, message);
      switch_core_session_rwunlock(session);
      return;
    }

    /* What to hand the application once the lock is released. fireBody is
       borrowed (it usually points straight at `message`, so a multi-KB server
       event is never copied); fireBodyOwned backs the one case that has to build
       its own payload. */
    const char* fireEvent = nullptr;
    const char* fireBody = nullptr;
    std::string fireBodyOwned;

    /* Everything below touches tech_pvt's media objects or its AudioPipe
       pointer, and session.delete detaches those under this same mutex. Holding
       it is what makes a non-null pointer safe to dereference here instead of a
       use-after-free racing a teardown. The websocket thread already blocks on
       this mutex during barge-in (AudioPlayer::clear takes it), so this is not a
       new lock-ordering relationship. The event itself is fired after unlocking,
       to keep the hold short - the media threads only trylock. */
    switch_mutex_lock(tech_pvt->mutex);

    switch (event) {
      case gptlive_s2s::AudioPipe::CONNECT_SUCCESS:
        tech_pvt->state = SESSION_STATE_WS_CONNECTED;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) successful\n", tech_pvt->bugname);
        fireEvent = GPTLIVE_EVENT_CONNECT_SUCCESS;
      break;

      case gptlive_s2s::AudioPipe::CONNECT_FAIL:
        {
          tech_pvt->state = SESSION_STATE_NONE;
          /* the AudioPipe frees itself as soon as this callback returns */
          tech_pvt->pAudioPipe = nullptr;

          cJSON* reason = cJSON_CreateObject();
          cJSON_AddStringToObject(reason, "reason", message ? message : "unknown");
          char* json_string = cJSON_PrintUnformatted(reason);
          if (json_string) {
            fireBodyOwned = json_string;
            fireBody = fireBodyOwned.c_str();
            free(json_string);
          }
          cJSON_Delete(reason);

          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n",
            tech_pvt->bugname, message ? message : "unknown");
          fireEvent = GPTLIVE_EVENT_CONNECT_FAIL;
        }
      break;

      case gptlive_s2s::AudioPipe::CONNECTION_DROPPED:
        tech_pvt->state = SESSION_STATE_NONE;
        /* the AudioPipe frees itself as soon as this callback returns */
        tech_pvt->pAudioPipe = nullptr;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) dropped from far end\n", tech_pvt->bugname);
        fireEvent = GPTLIVE_EVENT_DISCONNECT;
      break;

      case gptlive_s2s::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
        tech_pvt->state = SESSION_STATE_NONE;
        /* the AudioPipe frees itself as soon as this callback returns */
        tech_pvt->pAudioPipe = nullptr;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
      break;

      case gptlive_s2s::AudioPipe::MESSAGE:
          {
            cJSON* json = parse_json_string(session, message);
            if (!json) {
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "failed to parse json for message %s\n", message);
            }
            else {
              bool forward = true;
              const char* type = cJSON_GetObjectCstr(json, "type");

              /* No usable type means we cannot handle the frame at all - it also
                 covers valid-JSON-but-not-an-object. Drop it rather than
                 forwarding a shape the application cannot dispatch on. */
              if (!type) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
                  "server event has no type, discarding: %s\n", message);
                forward = false;
              }
              else if (0 == strcmp(type, "output_audio.delta")) {
                /* Agent audio is consumed (played out), not forwarded: relaying
                   megabytes of base64 to the application would flood the event
                   hook for no benefit. */
                forward = false;

                const char* b64 = cJSON_GetObjectCstr(json, "audio");
                if (!b64 || '\0' == *b64) {
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
                    "output_audio.delta with no audio payload, discarding\n");
                }
                else {
                  /* the first delta of a new burst anchors the barge-in comparison */
                  if (!tech_pvt->agent_burst_active) {
                    tech_pvt->agent_burst_active = 1;
                    tech_pvt->burst_start_ms = 0;
                    getInt64(json, "start_ms", &tech_pvt->burst_start_ms);
                  }
                  processIncomingAudio(tech_pvt, b64);
                }
              }
              else if (0 == strcmp(type, "session.started")) {
                /* The input gate. GPT Live withholds session.started until our
                   startup session.update is accepted, and caller audio sent
                   before it is rejected. There is no session.created /
                   session.updated startup handshake as in the Realtime API. */
                if (!tech_pvt->session_started) {
                  tech_pvt->session_started = 1;
                  tech_pvt->state = SESSION_STATE_CONVERSATION_STARTED;
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
                    "got session.started; streaming caller audio now\n");
                }
              }
              else if (0 == strcmp(type, "turn.created")) {
                handleTurnCreated(tech_pvt, session, json);
              }

              if (forward) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gptlive server event (%s): %s\n", tech_pvt->bugname, message);
                /* borrowed, not copied - server events can be multi-KB */
                fireEvent = GPTLIVE_EVENT_SERVER;
                fireBody = message;
              }

              cJSON_Delete(json);
            }
          }
          break;

      default:
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from gptlive %d:%s\n", event, message);
      break;
    }

    switch_mutex_unlock(tech_pvt->mutex);

    if (fireEvent) tech_pvt->responseHandler(session, fireEvent, fireBody, tech_pvt->bugname);

    switch_core_session_rwunlock(session);
  }

  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, int sampling,
    const char* host, const char *path, const char* authType, const char* apiKey,
    responseHandler_t responseHandler) {
    int err;
    int channels = 1;
    std::string fullPath = path;
    switch_codec_t* read_codec = switch_core_session_get_read_codec(session);
    bool useAuthHeader = (0 != strcmp(authType, "query"));

    if (!read_codec || !read_codec->implementation) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR,
        "no read codec on this channel; cannot size the audio buffer\n");
      return SWITCH_STATUS_FALSE;
    }
    int sampleRate = read_codec->implementation->actual_samples_per_second;

    if (!useAuthHeader && std::string::npos == fullPath.find("api-key=") && apiKey) {
      // append api key to path if not there and we are using query args to authenticate
      fullPath += (std::string::npos == fullPath.find('?')) ? "?api-key=" : "&api-key=";
      fullPath += apiKey;
    }
    int port = 443;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * sampleRate / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_codec_implementation_t read_impl;
    switch_core_session_get_read_impl(session, &read_impl);

    gptlive_s2s::AudioPipe* ap = new gptlive_s2s::AudioPipe(tech_pvt->sessionId, tech_pvt->bugname, host, port, fullPath.c_str(),
      buflen, read_impl.decoded_bytes_per_packet, useAuthHeader ? apiKey : nullptr, eventCallback);

    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(tech_pvt->mutex, playoutBuffer, tech_pvt->sessionId);
    audioPlayer->enableBase64Encoding(true);
    audioPlayer->setResampling(GPTLIVE_SAMPLE_RATE, sampleRate);

    tech_pvt->audioPlayer = (void *) audioPlayer;
    tech_pvt->playoutBuffer = (void *) playoutBuffer;

    if (GPTLIVE_SAMPLE_RATE != sampling) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) resampling user audio from %u to %u\n",
        tech_pvt->id, sampling, GPTLIVE_SAMPLE_RATE);
      tech_pvt->resampler_in = speex_resampler_init(1, sampling, GPTLIVE_SAMPLE_RATE, SWITCH_RESAMPLE_QUALITY, &err);
      if (0 != err) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing resampler: %s.\n", speex_resampler_strerror(err));
        /* The pipe has not been connected yet, so nothing will ever call back
           into it and close() would be a no-op - it has to be freed right here.
           destroy_tech_pvt cannot do it: on the normal path ownership has passed
           to the lws thread by then. */
        delete ap;
        return SWITCH_STATUS_FALSE;
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) no resampling needed for this call\n", tech_pvt->id);
    }

    /* Published only now that every fallible step has succeeded: from the moment
       connect() is called (which is deliberately NOT here - see
       gptlive_s2s_session_connect) the lws thread owns the pipe's lifetime. */
    tech_pvt->pAudioPipe = static_cast<void *>(ap);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) fork_data_init\n", tech_pvt->id);

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, llevel, "%s\n", line);
  }
}


extern "C" {

  switch_status_t gptlive_s2s_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_gptlive_s2s: audio buffer (in secs):    %d secs\n", nAudioBufferSecs);

    int logs = LLL_ERR | LLL_WARN ;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;

    gptlive_s2s::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t gptlive_s2s_cleanup() {
    bool cleanup = gptlive_s2s::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }

  switch_status_t gptlive_s2s_session_create(switch_core_session_t *session, responseHandler_t responseHandler,
		uint32_t samples_per_second, const char* bugname,
    const char* host, const char *path, const char* authType, const char* apiKey, void **ppUserData)
  {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    private_t* tech_pvt;

    if (bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "gptlive_s2s_session_create failed because connection already in progress\n");
      return SWITCH_STATUS_FALSE;
    }

    tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }
    memset(tech_pvt, 0, sizeof(private_t));
    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));

    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->sampling = samples_per_second;
    tech_pvt->id = ++idxCallCount;

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second,
      host, path, authType, apiKey, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;

    return SWITCH_STATUS_SUCCESS;
  }

  /**
   * Start connecting. Split out from session.create on purpose: every callback
   * from the pipe reaches us through the media bug (eventCallback looks
   * tech_pvt up via the channel's private data), so the bug MUST already be
   * attached before the first one can arrive.
   *
   * Connecting inside session.create races the caller's
   * switch_core_media_bug_add: a fast CONNECT_SUCCESS would be dropped and the
   * verb would wait forever for a connect event, and a fast CONNECT_FAIL would
   * leave tech_pvt->pAudioPipe dangling at a pipe that had already freed itself.
   */
  switch_status_t gptlive_s2s_session_connect(switch_core_session_t *session, const char* bugname) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "gptlive_s2s_session_connect failed because no bug\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    if (!tech_pvt) return SWITCH_STATUS_FALSE;

    gptlive_s2s::AudioPipe *pAudioPipe = static_cast<gptlive_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
    if (!pAudioPipe) return SWITCH_STATUS_FALSE;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now\n");
    pAudioPipe->connect();
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");

    return SWITCH_STATUS_SUCCESS;
  }

  /**
   * Forward one application client event to GPT Live, untouched.
   *
   * Unlike the Realtime API there is nothing to rewrite on the way out: the
   * function-call result event (delegation.function_call_output.create) already
   * carries item.output as a string, so there is no object-to-string coercion to
   * do. GPT Live accepts exactly five client event types - session.update,
   * session.context.append, delegation.context.append,
   * delegation.function_call_output.create and session.close - and rejects
   * anything else with an error event; validation is left to the server so this
   * module does not have to track an alpha allow-list.
   */
  switch_status_t gptlive_s2s_send_client_event(switch_core_session_t *session, const char* bugname, cJSON* json) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "gptlive_s2s_send_client_event failed because no bug\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    if (!tech_pvt) return SWITCH_STATUS_FALSE;

    const char* type = cJSON_GetObjectCstr(json, "type");
    if (!type) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "gptlive_s2s_send_client_event must have 'type' property\n");
      return SWITCH_STATUS_FALSE;
    }

    /* Take the pipe under the same mutex session.delete uses, so a teardown
       racing this call cannot free the AudioPipe between the null check and the
       send. */
    switch_mutex_lock(tech_pvt->mutex);
    gptlive_s2s::AudioPipe *pAudioPipe = static_cast<gptlive_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
    if (!pAudioPipe) {
      switch_mutex_unlock(tech_pvt->mutex);
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO,
        "gptlive_s2s_send_client_event: connection is gone, dropping %s\n", type);
      return SWITCH_STATUS_FALSE;
    }

    char* json_string = cJSON_PrintUnformatted(json);
    if (!json_string) {
      switch_mutex_unlock(tech_pvt->mutex);
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "gptlive_s2s_send_client_event failed to serialize json\n");
      return SWITCH_STATUS_FALSE;
    }
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gptlive_s2s_send_client_event sending %s\n", type);
    pAudioPipe->bufferForSending(json_string);
    switch_mutex_unlock(tech_pvt->mutex);

    free(json_string);

    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t gptlive_s2s_session_delete(switch_core_session_t *session, const char* bugname, int channelIsClosing) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "gptlive_s2s_session_delete: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    if (!tech_pvt) return SWITCH_STATUS_FALSE;

    uint32_t id = tech_pvt->id;
    detached_media m = {nullptr, nullptr, nullptr};

    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);

    gptlive_s2s::AudioPipe *pAudioPipe = static_cast<gptlive_s2s::AudioPipe *>(tech_pvt->pAudioPipe);

    // get the bug again, now that we are under lock
    {
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        switch_channel_set_private(channel, bugname, NULL);
        if (!channelIsClosing) {
          switch_core_media_bug_remove(session, &bug);
        }
      }
    }

    /* close() queues the graceful {"type":"session.close"} before disconnecting.
       After this the lws thread still owns the pipe and will free it once the
       socket closes, so drop our pointer rather than deleting it. */
    if (pAudioPipe) pAudioPipe->close();
    tech_pvt->pAudioPipe = nullptr;

    /* Unpublish the media objects under the same lock the websocket thread uses
       to reach them, so the destruction below cannot race an in-flight
       output_audio.delta or barge-in. */
    detach_media(tech_pvt, &m);

    switch_mutex_unlock(tech_pvt->mutex);

    destroy_media(tech_pvt, m);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) gptlive_s2s_session_delete complete\n", id);
    return SWITCH_STATUS_SUCCESS;
  }

  /**
   * Mix queued agent audio into the caller's stream and report the
   * playback_started / playback_stopped transitions.
   *
   * These two events are synthesized by the media server, not by OpenAI: GPT
   * Live has no output_audio.done, so "the agent finished speaking" can only be
   * observed here, when the playout drains. They are the FS-module counterpart
   * of mediajam's playout goroutine.
   */
  switch_bool_t gptlive_s2s_write_frame(switch_media_bug_t *bug, void* user_data) {
    private_t* tech_pvt = (private_t*) user_data;

    /* The bug owns a reference to its session for as long as this callback runs,
       so take it from there. The sibling modules call
       switch_core_session_locate(tech_pvt->sessionId) at each notification point
       instead, which costs a hash lookup plus a session rwlock and - because it
       is taken while holding tech_pvt->mutex - inverts the lock order that the
       media-bug close path (session rwlock, then tech_pvt->mutex) uses. */
    switch_core_session_t* session = switch_core_media_bug_get_session(bug);

    if (switch_mutex_trylock(tech_pvt->mutex) != SWITCH_STATUS_SUCCESS) return SWITCH_TRUE;

    CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;

    /* detached by a concurrent teardown - nothing to play out */
    if (!playoutBuffer) {
      switch_mutex_unlock(tech_pvt->mutex);
      return SWITCH_TRUE;
    }

    /* Did the websocket thread ask us to interrupt the assistant? It has already
       dropped what the player had decoded; this clears what already made it into
       the playout buffer, which is ours alone to touch. */
    if (tech_pvt->process_interrupt) {
      tech_pvt->process_interrupt = 0;
      playoutBuffer->clear();

      if (tech_pvt->assistant_is_speaking) {
        tech_pvt->assistant_is_speaking = 0;
        tech_pvt->responseHandler(session, GPTLIVE_EVENT_SERVER,
          "{\"type\": \"output_audio.playback_stopped\", \"completion_reason\": \"interrupted\"}", tech_pvt->bugname);
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "assistant stopped speaking (interrupted)\n");
      }
    }

    if (playoutBuffer->size() > 0) {
      switch_frame_t* rframe = switch_core_media_bug_get_write_replace_frame(bug);
      int16_t *fp = reinterpret_cast<int16_t*>(rframe->data);
      int samples = (int) rframe->samples;

      rframe->channels = 1;
      rframe->datalen = rframe->samples * sizeof(int16_t);

      int16_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
      int samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), samples);

      if (samplesToCopy > 0) {
        int count = (int) playoutBuffer->getBlock(data, samplesToCopy);
        if (count != samplesToCopy) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s gptlive_s2s_write_frame - failed to get %d samples from playout buffer, got %d\n",
            tech_pvt->sessionId, samplesToCopy, count);
        }
        else {
          /* getBlock filled [0, samplesToCopy); vector_add reads `samples`, so
             only the shortfall needs zeroing. Clearing the whole array instead
             would memset 16KB on every 20ms frame of every call. */
          if (samplesToCopy < samples) {
            memset(data + samplesToCopy, 0, (samples - samplesToCopy) * sizeof(int16_t));
          }
          vector_add(fp, data, samples);
          vector_normalize(fp, samples);
          switch_core_media_bug_set_write_replace_frame(bug, rframe);
        }

        // notify when assistant starts speaking
        if (!tech_pvt->assistant_is_speaking) {
          tech_pvt->assistant_is_speaking = 1;
          tech_pvt->responseHandler(session, GPTLIVE_EVENT_SERVER,
            "{\"type\": \"output_audio.playback_started\"}", tech_pvt->bugname);
        }
      }
    }
    else if (tech_pvt->assistant_is_speaking) {
      // notify when assistant stops speaking
      tech_pvt->assistant_is_speaking = 0;
      tech_pvt->responseHandler(session, GPTLIVE_EVENT_SERVER,
        "{\"type\": \"output_audio.playback_stopped\", \"completion_reason\": \"completed\"}", tech_pvt->bugname);
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "assistant stopped speaking (completed normally)\n");
    }

    switch_mutex_unlock(tech_pvt->mutex);

    return SWITCH_TRUE;
  }

	switch_bool_t gptlive_s2s_read_frame(switch_core_session_t *session, switch_media_bug_t *bug, void* user_data) {
    private_t* tech_pvt = (private_t*) user_data;
    size_t available;

    if (!tech_pvt) return SWITCH_TRUE;

    /* The input gate: GPT Live rejects caller audio sent before session.started,
       so hold off until the server has accepted our startup session.update. */
    if (tech_pvt->state != SESSION_STATE_CONVERSATION_STARTED) {
      return SWITCH_TRUE;
    }

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      if (!tech_pvt->pAudioPipe) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      gptlive_s2s::AudioPipe *pAudioPipe = static_cast<gptlive_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
      if (pAudioPipe->getLwsState() != gptlive_s2s::AudioPipe::LWS_CLIENT_CONNECTED) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      pAudioPipe->lockAudioBuffer();
      available = pAudioPipe->binarySpaceAvailable();
      if (NULL == tech_pvt->resampler_in) {
        switch_frame_t frame = { 0 };
        frame.data = pAudioPipe->binaryWritePtr();
        frame.buflen = available;
        while (true) {

          // check if buffer would be overwritten; dump packets if so
          if (available < pAudioPipe->binaryMinSpace()) {
            if (!tech_pvt->buffer_overrun_notified) {
              tech_pvt->buffer_overrun_notified = 1;
              tech_pvt->responseHandler(session, GPTLIVE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname);
            }
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n",
              tech_pvt->id);
            pAudioPipe->binaryWritePtrReset();

            frame.data = pAudioPipe->binaryWritePtr();
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          }

          switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
          if (rv != SWITCH_STATUS_SUCCESS) break;
          if (frame.datalen) {
            pAudioPipe->binaryWritePtrAdd(frame.datalen);
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
            frame.data = pAudioPipe->binaryWritePtr();
          }
        }
      }
      else {
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = { 0 };
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;
        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
          if (frame.datalen) {
            spx_uint32_t out_len = available >> 1;  // space for samples which are 2 bytes
            spx_uint32_t in_len = frame.samples;

            speex_resampler_process_int(tech_pvt->resampler_in, 0,
              (const spx_int16_t *) frame.data,
              (spx_uint32_t *) &in_len,
              (spx_int16_t *) ((char *) pAudioPipe->binaryWritePtr()),
              &out_len);

            if (out_len > 0) {
              size_t bytes_written = out_len << 1;
              pAudioPipe->binaryWritePtrAdd(bytes_written);
              available = pAudioPipe->binarySpaceAvailable();
            }
            if (available < pAudioPipe->binaryMinSpace()) {
              if (!tech_pvt->buffer_overrun_notified) {
                tech_pvt->buffer_overrun_notified = 1;
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n",
                  tech_pvt->id);
                tech_pvt->responseHandler(session, GPTLIVE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname);
              }
              break;
            }
          }
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}
