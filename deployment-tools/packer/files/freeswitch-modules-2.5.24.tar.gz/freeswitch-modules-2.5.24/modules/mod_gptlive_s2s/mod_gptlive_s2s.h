#ifndef __MOD_GPTLIVE_S2S_H__
#define __MOD_GPTLIVE_S2S_H__

#include <switch.h>
#include <speex/speex_resampler.h>

#include <stdint.h>
#include <unistd.h>

#define MY_BUG_NAME "gptlive_s2s"

#define GPTLIVE_EVENT_SERVER "gptlive_s2s::server_event"

#define GPTLIVE_EVENT_CONNECT_SUCCESS "gptlive_s2s::connect"
#define GPTLIVE_EVENT_CONNECT_FAIL    "gptlive_s2s::connect_failed"
#define GPTLIVE_EVENT_BUFFER_OVERRUN  "gptlive_s2s::buffer_overrun"
#define GPTLIVE_EVENT_DISCONNECT      "gptlive_s2s::disconnect"

#define MAX_SESSION_ID (256)
#define MAX_BUG_LEN (64)

typedef void (*responseHandler_t)(switch_core_session_t* session, const char* eventName, const char* json, const char* bugname);

typedef enum {
    SESSION_STATE_NONE = 0,
    SESSION_STATE_WS_CONNECTED,
    SESSION_STATE_CONVERSATION_STARTED
} SessionState_t;

struct private_data {
	switch_mutex_t *mutex;
	char sessionId[MAX_SESSION_ID+1];
  char bugname[MAX_BUG_LEN+1];
  SessionState_t state;
  SpeexResamplerState *resampler_in;
  responseHandler_t responseHandler;
  void *pAudioPipe;
  int sampling;
  unsigned int id;

  /* These flags are deliberately PLAIN ints, not the `int x:1` bitfields the
   * sibling modules use, because they are not all written by the same thread.
   * Bitfields packed into one storage unit are not independently addressable:
   * updating one is a read-modify-write of the whole unit, so a websocket-thread
   * `process_interrupt = 1` and a media-thread `assistant_is_speaking = 0` can
   * clobber each other. A lost process_interrupt means barge-in silently does
   * not happen and the agent talks over the caller. Separate ints are each
   * aligned and independently addressable, so no cross-field clobbering. */
  int buffer_overrun_notified;

  /* the input gate: GPT Live withholds session.started until our startup
   * session.update is accepted, and caller audio sent before it is rejected.
   * Written on the websocket thread, read on the media threads. */
  int session_started;

  /* playout state, driven from the write_replace thread: whether the caller is
   * currently hearing agent audio. This is what gates barge-in and what the
   * playback_started/playback_stopped events report. */
  int assistant_is_speaking;

  /* set by the websocket thread on barge-in, consumed by the write_replace
   * thread (the only thread that may touch the playout buffer) */
  int process_interrupt;

  /* Protocol-timeline state for the barge-in guard, websocket thread only.
   * agent_burst_active says a run of output_audio.delta frames has begun since
   * the last barge-in, and burst_start_ms is the start_ms of the first delta in
   * that run. See handleTurnCreated() for why the comparison is against the
   * burst START rather than the newest delta. */
  int agent_burst_active;
  int64_t burst_start_ms;

  // audio output
  void *audioPlayer;
  void *playoutBuffer;
};

typedef struct private_data private_t;

#endif
