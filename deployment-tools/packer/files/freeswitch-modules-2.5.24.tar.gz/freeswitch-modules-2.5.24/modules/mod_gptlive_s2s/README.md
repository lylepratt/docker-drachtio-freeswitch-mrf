# mod_gptlive_s2s

A Freeswitch module that integrates with OpenAI's **GPT Live** speech-to-speech API (alpha).

> GPT Live is a *different wire protocol* from the OpenAI Realtime API, even though both are
> served from `api.openai.com`. This is a standalone module rather than a mode of
> `mod_openai_s2s`; see [Protocol differences](#protocol-differences-from-mod_openai_s2s) below
> before copying anything across.

## API

### Commands

```
uuid_gptlive_s2s <uuid> session.create host path auth-type [api-key]
```
where:
- host: URL host value for the websocket connection (e.g. `api.openai.com`)
- path: URL path (e.g. `v1/live?model=gpt-live-1-boulder-alpha`)
- auth-type: `bearer` or `query`, indicating whether to provide the api key in an `Authorization`
  header or as an `api-key` query parameter
- api-key: the api key to use to authenticate

This establishes a websocket connection to the GPT Live endpoint. The mandatory
`OpenAI-Alpha: quicksilver=v2` handshake header is added by the module (see
[Alpha header](#alpha-header)). When the connection is up the caller is notified with the
`gptlive_s2s::connect` event, and must then send a `session.update` client event — the server
withholds `session.started`, and therefore does not accept caller audio, until startup
configuration has arrived.

```
uuid_gptlive_s2s <uuid> client.event client-event-json
```
The event is forwarded to the server untouched. GPT Live accepts exactly five client event
types; anything else comes back as an `error` server event:

- `session.update`
- `session.context.append`
- `delegation.context.append`
- `delegation.function_call_output.create`
- `session.close`

```
uuid_gptlive_s2s <uuid> session.delete
```
Ends the session. A graceful `{"type":"session.close"}` is sent before the websocket is closed.

### Events

- `gptlive_s2s::connect` — the websocket connection is established
- `gptlive_s2s::connect_failed` — the websocket connection failed; body is `{"reason": "..."}`
- `gptlive_s2s::disconnect` — the far end dropped the connection
- `gptlive_s2s::buffer_overrun` — caller audio is being dropped because the send buffer is full
- `gptlive_s2s::server_event` — a server event; the body is the raw JSON

Every event carries `llm-vendor: gptlive` and `media-bugname: gptlive_s2s` headers.

`output_audio.delta` is **not** forwarded — it is consumed and played out. Relaying megabytes
of base64 to the application would flood the event hook for no benefit.

Two additional `gptlive_s2s::server_event` types are synthesized by this module rather than
sent by OpenAI, because GPT Live has no `output_audio.done` and therefore no way to observe
"the agent finished speaking" from the protocol alone:

- `{"type": "output_audio.playback_started"}`
- `{"type": "output_audio.playback_stopped", "completion_reason": "completed"|"interrupted"}`

Note that a playback event is **not** evidence the agent said anything audible: when the model
declines to open a conversation it streams digital silence, and this module plays that
faithfully. Only the recording amplitude tells you whether the caller heard speech.

## Basic overview of operation

1. Connect with `session.create`.
2. On `gptlive_s2s::connect`, send a `session.update` client event carrying the startup
   configuration. The session schema is small: `instructions`, `audio.output.voice`,
   `delegation`, `include`. (There is no `tools`, `tool_choice`, `turn_detection`,
   `output_modalities` or `max_output_tokens` — those are Realtime API fields and are rejected.)

```js
{
  type: 'session.update',
  session: {
    instructions: 'You are a helpful assistant.',
    audio: { output: { voice: 'marin' } },
    delegation: {
      type: 'responses',
      responses: {
        model: 'gpt-5.5',
        tools: [
          {
            type: 'function',
            name: 'get_weather',
            description: 'Get the weather at a given location',
            parameters: { /* ... */ }
          }
        ]
      }
    }
  }
}
```

3. On `session.started` the module opens the input gate and caller audio begins streaming.
4. Agent audio arrives as `output_audio.delta` and is played out to the caller.

### Getting the agent to speak first

There is no API parameter that forces an opening turn, and `instructions` alone is not
reliable. The working pattern is to send a `session.context.append` immediately on
`session.started`, containing both the intended wording and when to speak:

```js
{
  type: 'session.context.append',
  content: [{
    type: 'input_text',
    text: 'Immediately greet the caller using the exact text below. Do not wait for the ' +
          'caller to speak first. After the greeting, pause and listen.\n\n' +
          'Thanks for calling, how can I help?'
  }]
}
```

Per OpenAI, a context append *guides* the model — it is not a guaranteed playback command, and
the model may stay silent, paraphrase, or be interrupted. Where exact wording is required,
play it with application-controlled playback instead.

### Interruptions

There is no `input_audio_buffer.speech_started` in this API, so barge-in is taken from
`turn.created` with `role: "user"`. Turn events are a projection over transcript fragments
whose boundaries reflect cadence rather than semantic turn boundaries, so one caller utterance
can produce several user turns and a later one can arrive mid-answer. The module therefore
compares the turn's `start_ms` against the start of the agent's current audio burst on the
shared server timeline, and only treats speech starting at or after the burst as an
interruption. When it is one, the queued playout is flushed and
`output_audio.playback_stopped` with `completion_reason: "interrupted"` is fired.

There is no `response.cancel` to send: the model self-drives, so flushing the playout is the
whole of the interruption handling.

### Tool calls

Tools only exist on a **Responses-targeted delegation**. Declare them at
`session.delegation.responses.tools` (not `delegation.tools`) using the flat Responses shape
`{type: 'function', name, description, parameters}`; `delegation.responses.model` is required
by the server.

It is up to the caller to execute the tool. Listen for a `response.output_item.done` server
event with an `item.type` of `function_call`, run the tool, and return the result with a
`delegation.function_call_output.create` client event:

```js
{
  type: 'delegation.function_call_output.create',
  item: { type: 'function_call_output', call_id: '<call_id>', output: '<string>' }
}
```

`output` must be a string. There is no follow-on `response.create` to send — the server resumes
the delegation itself.

A `client` delegation instead asks the application for free-form text, which is answered with
`delegation.context.append`.

## Protocol differences from mod_openai_s2s

| | Realtime (`mod_openai_s2s`) | GPT Live (`mod_gptlive_s2s`) |
|---|---|---|
| caller audio | `input_audio_buffer.append` | `input_audio.append` |
| agent audio | `response.output_audio.delta`, base64 in `delta` | `output_audio.delta`, base64 in `audio`, plus `start_ms`/`end_ms` |
| end of agent audio | `response.output_audio.done` | *(none — inferred from playout)* |
| input gate lifts on | first `session.updated` | `session.started` |
| soliciting a turn | `response.create` | *(none — the model self-drives)* |
| cancelling a turn | `response.cancel` | *(none)* |
| caller speech signal | `input_audio_buffer.speech_started` | `turn.created` with `role: "user"` |
| tool results | `conversation.item.create` + `response.create` | `delegation.function_call_output.create` |
| audio format | negotiable | fixed at pcm16 mono 24 kHz |

## Alpha header

The `OpenAI-Alpha: quicksilver=v2` header is **mandatory** on the `/v1/live` handshake. Without
it the upgrade is refused before the websocket is established:

```
400 {"code":"invalid_websocket_query",
     "message":"OpenAI-Alpha must be \"quicksilver=v2\" for /v1/live"}
```

The value is an alpha protocol-version tag and will churn. Set `JAMBONES_GPTLIVE_ALPHA` to
override it without rebuilding the module.

Note also that a successful handshake does not mean access: an api key that is not enrolled in
the alpha completes the upgrade and is then refused at the application layer with
`{"type":"error","error":{"code":"forbidden","message":"Voice session access denied."}}`.

## No Origin header

`/v1/live` refuses any handshake that carries an `Origin` header — it reads as a browser
request, which must authenticate with an ephemeral token rather than a raw api key — and
answers `403 Forbidden`. This module therefore leaves `i.origin` unset in
`connect_client()`, unlike every sibling module. Measured against the live endpoint:

| request | result |
|---|---|
| `Authorization` + `OpenAI-Alpha`, no `Origin` | `101` |
| `Authorization` + `OpenAI-Alpha` + `Origin: https://api.openai.com` | `403` |
| `Authorization`, no `OpenAI-Alpha` | `400` |

`/v1/realtime` tolerates `Origin`, which is why `mod_openai_s2s` sets it without trouble.
A 403 on the upgrade is the signature of this header coming back.

## Environment variables

- `JAMBONES_GPTLIVE_ALPHA` — override the `OpenAI-Alpha` header value (default `quicksilver=v2`)
- `MOD_AUDIO_FORK_BUFFER_SECS` — seconds of caller audio to buffer for sending (1–5, default 2)
- `MOD_AUDIO_FORK_TCP_KEEPALIVE_SECS` — websocket TCP keepalive (default 55)
