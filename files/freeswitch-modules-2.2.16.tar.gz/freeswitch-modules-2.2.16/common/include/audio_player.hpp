#ifndef __AUDIO_PLAYER_HPP__
#define __AUDIO_PLAYER_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <vector>
#include <atomic>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include "jambonz/circular_buffer.h"

class __attribute__((visibility("default"))) AudioPlayer {
public:
  AudioPlayer(switch_mutex_t* mutex, CircularBuffer* playout_buffer);
  ~AudioPlayer() ;

  // Disable copying and moving
  AudioPlayer(const AudioPlayer&) = delete;
  AudioPlayer& operator=(const AudioPlayer&) = delete;
  AudioPlayer(AudioPlayer&&) = delete;
  AudioPlayer& operator=(AudioPlayer&&) = delete;

  // optional: base64 decode the incoming audio data
  void enableBase64Encoding(bool b) { base64_encoding = b; }

  // optional: resample the incoming audio data
  void setResampling (int from, int to);

  // main api called when we have incoming audio to buffer
  void bufferAudio(const char* data, size_t length);

  // clear any queued audio data
  void clear( bool sticky = true);

  // change state from cleared to sending audio
  void open() { cleared = false; }

  bool isCleared() { return cleared; }

  // Signals the thread to finish and stops audio consumption
  void finish();

  // for debugging use only
  void enableAudioLogging(std::string& filepath);

private:
  void consumeAudio() ;

  switch_mutex_t *session_mutex;
  CircularBuffer* playout_buffer;
  bool cleared;
  int sample_rate_in;
  int sample_rate_out;
  bool base64_encoding;
  SpeexResamplerState *resampler;
  std::vector<char> buffer;
  std::mutex buffer_mutex; 
  std::condition_variable data_ready_cv;
  std::thread consumer_thread;
  std::atomic<bool> done;
  std::string audio_logging_filename;
  bool audio_logging_enabled;
  std::ofstream audio_file;
};

#endif // __AUDIO_PLAYER_HPP__