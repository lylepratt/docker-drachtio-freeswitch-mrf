#ifndef __JBZ_PARSER_H__
#define __JBZ_PARSER_H__

#include <string>
#include <switch_json.h>

SWITCH_DECLARE(cJSON*) parse_json_string(switch_core_session_t* session, const std::string& data) ;

#endif
