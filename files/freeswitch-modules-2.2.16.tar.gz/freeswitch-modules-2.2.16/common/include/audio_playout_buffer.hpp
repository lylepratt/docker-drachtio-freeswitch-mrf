#ifndef __AUDIO_PLAYOUT_BUFFER_HPP__
#define __AUDIO_PLAYOUT_BUFFER_HPP__

#include <boost/circular_buffer.hpp>
typedef boost::circular_buffer<uint16_t> AudioPlayoutBuffer_t;

#endif // __AUDIO_PLAYOUT_BUFFER_HPP__