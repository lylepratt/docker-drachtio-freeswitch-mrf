#ifndef CMD_PARSER_H
#define CMD_PARSER_H

#include <switch.h>
SWITCH_DECLARE(unsigned int) switch_separate_string_no_cleanup(_In_ char *buf, char delim, _Post_count_(return) char **array, unsigned int arraylen);

#endif