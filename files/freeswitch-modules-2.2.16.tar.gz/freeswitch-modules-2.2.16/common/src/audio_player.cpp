#include "jambonz/audio_player.hpp"
#include "jambonz/base64.hpp"

#define BUFFER_GROW_SIZE (80000)

AudioPlayer::AudioPlayer(switch_mutex_t* mutex, CircularBuffer* playout_buffer) :
  session_mutex(mutex), playout_buffer(playout_buffer), resampler(nullptr),
  done(false), cleared(false), sample_rate_in(0), sample_rate_out(0), base64_encoding(false) {
  // Start the consumer thread when the object is created
  consumer_thread = std::thread(&AudioPlayer::consumeAudio, this);
}

AudioPlayer::~AudioPlayer() {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::~AudioPlayer joining thread\n");
  finish();  // Ensure the consumer thread finishes before the object is destroyed
  consumer_thread.join();
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::~AudioPlayer joined thread\n");
}

void AudioPlayer::bufferAudio(const char* data, size_t length) {
  if (cleared) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::bufferAudio discarding audio\n");
    return;  // discard late-incoming audio after a clear
  }

  std::lock_guard<std::mutex> lock(buffer_mutex);
  buffer.insert(buffer.end(), data, data + length);

  // Notify the consumer that new data is available
  data_ready_cv.notify_one();
}

void AudioPlayer::clear(bool sticky) {
  if (sticky) cleared = true;
  {
    std::lock_guard<std::mutex> lock(buffer_mutex);
    buffer.clear();
  }
  {
    switch_mutex_lock(session_mutex);
    playout_buffer->clear();
    switch_mutex_unlock(session_mutex);
  }
}

void AudioPlayer::finish() {
  std::lock_guard<std::mutex> lock(buffer_mutex);
  done = true;
  data_ready_cv.notify_one();  // Wake up the consumer to allow it to exit
}

void AudioPlayer::setResampling (int from, int to) {
  sample_rate_in = from;
  sample_rate_out = to;
  resampler = speex_resampler_init(1, sample_rate_in, sample_rate_out, SWITCH_RESAMPLE_QUALITY, NULL);
}

void AudioPlayer::enableAudioLogging(std::string& filepath) {
  if (audio_logging_enabled) return;

  audio_logging_filename = filepath;
  audio_logging_enabled = true;

  audio_file.open(audio_logging_filename, std::ios::binary | std::ios::app);

  if (audio_file.is_open()) {
    audio_logging_enabled = true;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "Opened file %s for raw audio logging.\n", filepath);
  } else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to open %s for writing.\n", filepath);
  }
}

void AudioPlayer::consumeAudio() {
  std::string decodedData; // Reusable buffer for decoded audio data

  while (true) {
    std::unique_lock<std::mutex> lock(buffer_mutex);

    // Wait until data is ready or the producer is done
    data_ready_cv.wait(lock, [this] { return !buffer.empty() || done; });

    if (!buffer.empty()) {
      // Move the buffer contents to local storage for processing
      std::vector<char> audioData(std::move(buffer));
      lock.unlock(); // Allow producer to continue buffering

      const char* rawDataPtr = audioData.data();
      size_t rawDataSize = audioData.size();

      // If base64 decoding is enabled, decode the audio data
      if (base64_encoding) {
        decodedData = drachtio::base64_decode(std::string(audioData.data(), audioData.size()));
        rawDataPtr = decodedData.data();
        rawDataSize = decodedData.size();
      }

      // Write raw data to log file if logging is enabled
      if (audio_logging_enabled && audio_file.is_open()) {
        audio_file.write(rawDataPtr, rawDataSize);
      }

      // Resample or directly process the audio
      const spx_int16_t* input = reinterpret_cast<const spx_int16_t*>(rawDataPtr);
      size_t inSamples = rawDataSize / 2; // Assuming 2 bytes per sample
      size_t outSamples = resampler ? (inSamples * sample_rate_out) / sample_rate_in : inSamples;

      const spx_int16_t* outputPtr = input;
      std::vector<spx_int16_t> outputBuffer;

      // If resampling is enabled, process the audio data
      if (resampler) {
        outputBuffer.resize(outSamples);
        spx_uint32_t in_len = inSamples;
        spx_uint32_t out_len = outSamples;

        int res = speex_resampler_process_int(resampler, 0, input, &in_len, outputBuffer.data(), &out_len);

        if (res != RESAMPLER_ERR_SUCCESS) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Resampler error: %d\n", res);
          return;
        }

        outputPtr = outputBuffer.data();
        outSamples = out_len;
      }

      // Push processed data into the playback buffer
      switch_mutex_lock(session_mutex);
  
      if (!cleared) {
        uint32_t start, end, size, capacity;
        playout_buffer->getState(start, end, size, capacity);

        if (playout_buffer->capacity() - playout_buffer->size() < outSamples) {
          size_t newCapacity = playout_buffer->size() + std::max(outSamples, (size_t) BUFFER_GROW_SIZE);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer increasing capacity to %d\n", newCapacity);
          playout_buffer->set_capacity(newCapacity);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer done increasing capacity\n");

          uint32_t start, end, size, capacity;
          playout_buffer->getState(start, end, size, capacity);
        }

        playout_buffer->add(outputPtr, outSamples);

        playout_buffer->getState(start, end, size, capacity);
      }

      auto playoutBufferSize = playout_buffer->size();

      switch_mutex_unlock(session_mutex);

      //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "consumeAudio: processed %d audio bytes, now have %u samples\n", rawDataSize, playoutBufferSize);
    } else if (done) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer consume thread exiting\n");
      break;
    }
  }
}
