# mod_rimelabs_tts

A Freeswitch module that allows speak text to speech audio from rimelabs stream.