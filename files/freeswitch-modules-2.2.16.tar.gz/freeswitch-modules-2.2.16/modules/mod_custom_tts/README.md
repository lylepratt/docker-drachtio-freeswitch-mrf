# mod_custom_tts

A Freeswitch module that allows speak text to speech audio from custom vendor stream.
