#ifndef __MOD_CUSTOM_TTS_H__
#define __MOD_CUSTOM_TTS_H__

#include <switch.h>
typedef struct custom_data {
  char *voice_name;
  char *auth_token;
  char *custom_tts_url;
  char *language;

  /* result data */
  long response_code;
  char *ct;
  char *name_lookup_time_ms;
  char *connect_time_ms;
  char *final_response_time_ms;
  char *err_msg;
  char *cache_filename;
  char *session_id;

  int rate;
  int draining;
  int reads;
  int cache_audio;

	void *conn;
  void *audioPlayer;
  void *playoutBuffer;
  switch_mutex_t *mutex;
  FILE *file;
} custom_t;
#endif