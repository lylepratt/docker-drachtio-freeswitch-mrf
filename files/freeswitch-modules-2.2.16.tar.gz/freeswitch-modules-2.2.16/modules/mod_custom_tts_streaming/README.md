# mod_custom_tts_streaming

`mod_custom_tts_streaming` is a FreeSWITCH module that enables real-time streaming of text to an external Text-to-Speech (TTS) service via WebSocket. This module facilitates integration with advanced LLM-based TTS systems to generate dynamic audio during calls.

## Features

- Stream text in real-time to a TTS WebSocket server.
- Receive generated audio for playback in FreeSWITCH calls.
- Supports both base64-encoded and raw audio formats.
- Flexible API for controlling the TTS workflow.

## Installation

1. Clone the repository or download the module.
2. Build the module as part of your FreeSWITCH installation.
3. Configure the necessary channel variables (detailed below).

## Configuration

Set the following channel variables to configure the module:

- `CUSTOM_TTS_STREAMING_VOICE_ID`: The voice profile or ID to use for TTS.
- `CUSTOM_TTS_STREAMING_LANGUAGE`: The language for text-to-speech conversion.
- `CUSTOM_TTS_STREAMING_HOST`: The WebSocket server endpoint (without the protocol `ws://` or `wss://`), e.g., `<domain>/<path>`.
- `CUSTOM_TTS_STREAMING_API_KEY`: The authorization token for the WebSocket server. This token will be sent as a `Bearer` token in the `Authorization` header.
- `CUSTOM_TTS_STREAMING_USE_TLS`: Set to `true` for secure WebSocket (`wss://`), or `false` for plain WebSocket (`ws://`).

## How It Works

1. **WebSocket Connection**:
   - When the module starts, it establishes a WebSocket connection to the specified TTS server using the configured variables.
   - The URL includes query parameters for `voice`, `language`, and `sampleRate`. Example:
     ```
     wss://yourserver.com/elevenlabs?voice=void1&language=en&sampleRate=16000
     ```

2. **Server Acknowledgment**:
   - The TTS server responds with a JSON payload to confirm the connection and specify audio settings, such as sample rate and encoding type (`base64` or raw audio).
   ```json
   {
      "type": "connect",
      "data": {
        "sample_rate": 16000,
        "base64_encoding": true
      }
    }
    ```

3. **Streaming Text**:
   - The FreeSWITCH module streams text to the TTS server and uses the following JSON formats:
     - `{"type": "stream", "text": "hello"}`: Sends text tokens.
     - `{"type": "flush"}`: Signals the server to begin audio generation.
     - `{"type": "stop"}`: Stops the audio stream.

4. **Receiving Audio**:
   - The TTS server sends audio data back to the FreeSWITCH module:
     - **Base64-Encoded Audio**:
       ```json
       {
         "type": "data",
         "data": {
           "audio": "base64AudioData"
         }
       }
       ```
     - **Raw Audio Buffer**: Sent as binary data over the WebSocket.

5. **Audio Playback**:
   - The module processes the received audio and plays it during the active call.

## API Commands

The module exposes the following API commands:

```plaintext
uuid_custom_tts_streaming <uuid> |connect|send|clear|flush|close [tokens]