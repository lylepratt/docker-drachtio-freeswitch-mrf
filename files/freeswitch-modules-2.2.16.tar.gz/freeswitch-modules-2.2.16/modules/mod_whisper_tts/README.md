# mod_whisper_tts

A Freeswitch module that allows speak text to speech audio from whisper stream.
