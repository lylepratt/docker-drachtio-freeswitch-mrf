#ifndef __MOD_CARTESIA_TTS_STREAMING_H__
#define __MOD_CARTESIA_TTS_STREAMING_H__

#include <switch.h>
#include <speex/speex_resampler.h>

#include <unistd.h>

#define MY_BUG_NAME                       "cartesia_tts_streaming"
#define TTS_STREAM_EVENT_EMPTY            "cartesia_tts_streaming::empty"
#define TTS_STREAM_EVENT_CONNECT_SUCCESS  "cartesia_tts_streaming::connect"
#define TTS_STREAM_EVENT_CONNECT_FAIL     "cartesia_tts_streaming::connect_failed"
#define TTS_STREAM_EVENT_DISCONNECT       "cartesia_tts_streaming::disconnect"

#define MAX_SESSION_ID (256)
#define MAX_WS_URL_LEN (512)
#define MAX_PATH_LEN (4096)
#define MAX_BUG_LEN (64)
#define MAX_CONTEXT_LEN (64)
#define MAX_MODEL_ID_LEN (64)
#define MAX_VOICE_ID_LEN (64)
#define MAX_LANGUAGE_LEN (5)

typedef void (*responseHandler_t)(switch_core_session_t* session, const char* eventName, const char* json);

typedef enum {
    UNKNOWN,
    STARTING,
    SENDING,
    FLUSHED,
    DONE,
    FINISHED
} ContextState;

struct private_data {
	switch_mutex_t *mutex;
	char sessionId[MAX_SESSION_ID+1];
  responseHandler_t responseHandler;
  void *pAudioPipe;
  char *bufferedTokens;
  char host[MAX_WS_URL_LEN+1];
  unsigned int port;
  char path[MAX_PATH_LEN+1];
  char bugname[MAX_BUG_LEN+1];
  char model_id[MAX_MODEL_ID_LEN+1];
  char voice_id[MAX_VOICE_ID_LEN+1];
  char language[MAX_LANGUAGE_LEN+1];
  char current_context[MAX_CONTEXT_LEN];
  ContextState current_context_state;
  int sampleRate;
  int active;

  void *audioPlayer;
  void *playoutBuffer;
  void *pastContexts;
};

typedef struct private_data private_t;

#endif