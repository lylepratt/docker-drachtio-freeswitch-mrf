#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <unordered_map>
#include <iomanip>
#include <cstring>
#include <cctype>
#include <iostream>
#include <random>
#include <array>

#include "mod_cartesia_tts_streaming.h"
#include "audio_pipe.hpp"
#include "jambonz/simple_json_parser.hpp"
#include "jambonz/vector_math.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"


namespace {

  static bool hasDefaultCredentials = false;
  static const char* defaultApiKey = nullptr;

  std::string generateShortUUID() {
    static const std::string characters = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    constexpr size_t uuid_length = 8;

    // Use a static generator to avoid re-initialization overhead
    static thread_local std::mt19937 gen(std::random_device{}());
    static std::uniform_int_distribution<size_t> dis(0, characters.size() - 1);

    // Build the UUID directly in a string
    std::string uuid;
    uuid.reserve(uuid_length); // Preallocate memory for performance
    for (size_t i = 0; i < uuid_length; ++i) {
        uuid += characters[dis(gen)];
    }
    return uuid;
  }

  const char* state2String(ContextState state) {
    switch (state) {
      case STARTING:
        return "STARTING";
      case SENDING:
        return "SENDING";
      case FLUSHED:
        return "FLUSHED";
      case DONE:
          return "DONE";
      case FINISHED:
        return "FINISHED";
      default:
        return "UNKNOWN STATUS";
    }
  }

  bool isPastContext(private_t* tech_pvt, const char* contextId) {
    if (tech_pvt->pastContexts) {
      std::unordered_map<std::string, std::string> *pastContexts = 
        static_cast<std::unordered_map<std::string, std::string> *>(tech_pvt->pastContexts);
      if (pastContexts->find(contextId) != pastContexts->end()) {
        return true;
      }
    }   
    return false;
  }

  ContextState getPastContextState(private_t* tech_pvt, const char* contextId) {
    if (tech_pvt->pastContexts) {
      // Cast the void pointer to the appropriate type
      std::unordered_map<std::string, ContextState>* pastContexts = 
        static_cast<std::unordered_map<std::string, ContextState>*>(tech_pvt->pastContexts);

      // Find the contextKey in the map
      auto it = pastContexts->find(contextId);
      if (it != pastContexts->end()) {
        return it->second;  // Return the associated ContextState
      }
    }
    return ContextState::UNKNOWN; 
  }

  /**
   * Given a contextID, update its state in the pastContexts map, 
   * returning true if the context was found and updated, false otherwise.
   * 
   */
  bool updatePastContextState(private_t* tech_pvt, const char* contextId, ContextState newState) {
    if (tech_pvt->pastContexts) {
      std::unordered_map<std::string, ContextState>* pastContexts = 
        static_cast<std::unordered_map<std::string, ContextState>*>(tech_pvt->pastContexts);

      auto it = pastContexts->find(contextId);
      if (it != pastContexts->end()) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "old context_id %s, %s -> %s\n",
          contextId, state2String(it->second), state2String(newState));
        it->second = newState;
        return true;
      }
    }
    return false;
  }

  void changeContextState(private_t* tech_pvt, ContextState newState) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "changeContextState: context_id %s, %s -> %s\n",
      tech_pvt->current_context, state2String(tech_pvt->current_context_state), state2String(newState));
    tech_pvt->current_context_state = newState;
  }

  cJSON *create_token_payload(const char *model_id, const char *transcript, const char *voice_id, const char *language, 
    const char *context_id, int flush) {
      // Create the root JSON object
      cJSON *root = cJSON_CreateObject();
      if (!root) {
          return NULL;
      }

      // Add model_id
      if (!cJSON_AddStringToObject(root, "model_id", model_id)) {
          cJSON_Delete(root);
          return NULL;
      }

      // Add transcript
      if (!cJSON_AddStringToObject(root, "transcript", transcript)) {
          cJSON_Delete(root);
          return NULL;
      }

      // Add voice object
      cJSON *voice = cJSON_CreateObject();
      if (!voice || !cJSON_AddStringToObject(voice, "mode", "id") || !cJSON_AddStringToObject(voice, "id", voice_id)) {
          cJSON_Delete(root);
          return NULL;
      }
      cJSON_AddItemToObject(root, "voice", voice);

      // Add language
      if (!cJSON_AddStringToObject(root, "language", language)) {
          cJSON_Delete(root);
          return NULL;
      }

      // Add context_id
      if (!cJSON_AddStringToObject(root, "context_id", context_id)) {
          cJSON_Delete(root);
          return NULL;
      }

      // Add output_format object
      cJSON *output_format = cJSON_CreateObject();
      if (!output_format || 
          !cJSON_AddStringToObject(output_format, "container", "raw") ||
          !cJSON_AddStringToObject(output_format, "encoding", "pcm_s16le") ||
          !cJSON_AddNumberToObject(output_format, "sample_rate", 8000)) {
          cJSON_Delete(root);
          return NULL;
      }
      cJSON_AddItemToObject(root, "output_format", output_format);

      // Add add_timestamps
      if (!cJSON_AddBoolToObject(root, "add_timestamps", false)) {
          cJSON_Delete(root);
          return NULL;
      }

      // Add continue
      if (!cJSON_AddBoolToObject(root, "continue", flush)) {
          cJSON_Delete(root);
          return NULL;
      }

      return root;
  }

    cJSON *create_cancel_payload(const char *context_id) {
      // Create the root JSON object
      cJSON *root = cJSON_CreateObject();
      if (!root) {
          return NULL;
      }

      // Add model_id
      if (!cJSON_AddStringToObject(root, "context_id", context_id)) {
          cJSON_Delete(root);
          return NULL;
      }

      // Add add_timestamps
      if (!cJSON_AddBoolToObject(root, "cancel", true)) {
          cJSON_Delete(root);
          return NULL;
      }
    
      return root;
  }


  void sendTokens(cartesia_tts::AudioPipe* ap, private_t* tech_pvt, const char* input) {
    cJSON* payload = create_token_payload(tech_pvt->model_id, input, tech_pvt->voice_id, tech_pvt->language, 
      tech_pvt->current_context, 1);

    if (!payload) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to create JSON message\n");
        return;
    }

    char *json_string = cJSON_PrintUnformatted(payload);
    if (!json_string) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to print JSON message\n");
        cJSON_Delete(payload);
        return;
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "sending tokens (context %s): %s\n", tech_pvt->current_context, input);
    ap->bufferForSending(json_string);

    free(json_string);
    cJSON_Delete(payload);  // Free the JSON object
  }

  void flushTokens(cartesia_tts::AudioPipe* ap, private_t* tech_pvt) {
    cJSON* payload = create_token_payload(tech_pvt->model_id, "", tech_pvt->voice_id, tech_pvt->language, 
      tech_pvt->current_context, 0);

    if (!payload) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to create JSON message\n");
        return;
    }

    char *json_string = cJSON_PrintUnformatted(payload);
    if (!json_string) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to print JSON message\n");
        cJSON_Delete(payload);
        return;
    }

    ap->bufferForSending(json_string);

    free(json_string);
    cJSON_Delete(payload);  // Free the JSON object
  }

  void clearTokens(cartesia_tts::AudioPipe* ap, private_t* tech_pvt) {
    cJSON* payload = create_cancel_payload(tech_pvt->current_context);
    if (!payload) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to create JSON message\n");
        return;
    }
    char* json_string = cJSON_PrintUnformatted(payload);
    if (!json_string) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to print JSON message\n");
        cJSON_Delete(payload);
        return;
    }

    ap->bufferForSending(json_string);

    free(json_string);
    cJSON_Delete(payload);  // Free the JSON object
  }

  void logPastContexts(private_t* tech_pvt) {
    if (tech_pvt->pastContexts) {
      std::unordered_map<std::string, ContextState>* pOldContexts =
        static_cast<std::unordered_map<std::string, ContextState>*>(tech_pvt->pastContexts);

      for (const auto& entry : *pOldContexts) {
        const std::string& context = entry.first;
        const ContextState& state = entry.second;

        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "past context_id %s, state %s\n", context.c_str(), state2String(state));
      }
    }
  }

  void rotateContext(private_t* tech_pvt) {
    // move the current context to the past contexts and save its state
    if (tech_pvt->pastContexts) {
      std::unordered_map<std::string, ContextState>* pastContexts = 
        static_cast<std::unordered_map<std::string, ContextState>*>(tech_pvt->pastContexts);
      pastContexts->insert({tech_pvt->current_context, tech_pvt->current_context_state});
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "moved context_id %s, state %s to past contexts\n",
        tech_pvt->current_context, state2String(tech_pvt->current_context_state));
    }
    std::string context = generateShortUUID();
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "deprecated context_id %s, new context_id is now %s\n", tech_pvt->current_context, context.c_str());
    strncpy(tech_pvt->current_context, context.c_str(), MAX_CONTEXT_LEN);
    tech_pvt->current_context_state = STARTING;
  }

  switch_status_t setModelData(switch_core_session_t *session, private_t* tech_pvt) {
    if (strlen(tech_pvt->model_id) == 0) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      const char *model_id = switch_channel_get_variable(channel, "CARTESIA_TTS_STREAMING_MODEL_ID");
      if (NULL == model_id) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no cartesia model_id specified, must set CARTESIA_TTS_STREAMING_MODEL_ID\n");
        return SWITCH_STATUS_FALSE;
      }
      const char *voice_id = switch_channel_get_variable(channel, "CARTESIA_TTS_STREAMING_VOICE_ID");
      if (NULL == voice_id) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no cartesia voice_id specified, must set CARTESIA_TTS_STREAMING_VOICE_ID\n");
        return SWITCH_STATUS_FALSE;
      }
      const char *language = switch_channel_get_variable(channel, "CARTESIA_TTS_STREAMING_LANGUAGE");
      if (NULL == language) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no cartesia model_id specified, must set CARTESIA_TTS_STREAMING_LANGUAGE\n");
        return SWITCH_STATUS_FALSE;
      }

      if (!tech_pvt) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
        return SWITCH_STATUS_FALSE;
      }
      strncpy(tech_pvt->model_id, model_id, MAX_MODEL_ID_LEN);
      strncpy(tech_pvt->voice_id, voice_id, MAX_VOICE_ID_LEN);
      strncpy(tech_pvt->language, language, MAX_LANGUAGE_LEN);
    }
    return SWITCH_STATUS_SUCCESS;
  }

  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s destroy_tech_pvt\n", tech_pvt->sessionId);
    if (tech_pvt) {
      tech_pvt->pAudioPipe = nullptr;
      if (tech_pvt->bufferedTokens) {
        free(tech_pvt->bufferedTokens);
        tech_pvt->bufferedTokens = nullptr;
      }

      if (tech_pvt->audioPlayer) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "destroying audio player\n");
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        delete p;
        tech_pvt->audioPlayer = nullptr;
      }

      if (tech_pvt->playoutBuffer) {
        CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
        delete playoutBuffer;
        tech_pvt->playoutBuffer = nullptr;
      }

      if (tech_pvt->pastContexts) {
        logPastContexts(tech_pvt);
        std::unordered_map<std::string, ContextState>* pastContexts = 
          static_cast<std::unordered_map<std::string, ContextState>*>(tech_pvt->pastContexts);
        pastContexts->clear();
        delete pastContexts;
        tech_pvt->pastContexts = nullptr;
      }

      // NB: do not destroy the mutex here, that is caller responsibility
    }
  }

  static void processIncomingAudio(private_t* tech_pvt, switch_core_session_t* session, const char* base64_data) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    p->bufferAudio(base64_data, strlen(base64_data));
  }

  switch_status_t processIncomingBinary(private_t* tech_pvt, switch_core_session_t* session, const char* message, size_t dataLength) {
   return SWITCH_STATUS_SUCCESS;
  }

  static void eventCallback(const char* sessionId, cartesia_tts::AudioPipe::NotifyEvent_t event, const char* message, const char* binary, size_t len) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, MY_BUG_NAME);

      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case cartesia_tts::AudioPipe::BINARY:
              processIncomingBinary(tech_pvt, session, binary, len);
            break;

            case cartesia_tts::AudioPipe::CONNECT_SUCCESS:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) successful\n", tech_pvt->bugname);

              tech_pvt->active = true;
              if (tech_pvt->bufferedTokens) {
                cartesia_tts::AudioPipe *pAudioPipe = static_cast<cartesia_tts::AudioPipe *>(tech_pvt->pAudioPipe);
                sendTokens(pAudioPipe, tech_pvt, tech_pvt->bufferedTokens);
                free(tech_pvt->bufferedTokens);
                tech_pvt->bufferedTokens = nullptr;
              }
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_CONNECT_SUCCESS, NULL);
            break;
            case cartesia_tts::AudioPipe::CONNECT_FAIL:
            {
              // first thing: we can no longer access the AudioPipe
              if (tech_pvt->bufferedTokens) {
                free(tech_pvt->bufferedTokens);
                tech_pvt->bufferedTokens = nullptr;
              }
              std::stringstream json;
              json << "{\"reason\":\"" << message << "\"}";
              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_CONNECT_FAIL, (char *) json.str().c_str());
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
            }
            break;
            case cartesia_tts::AudioPipe::CONNECTION_DROPPED:
              // first thing: we can no longer access the AudioPipe

              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_DISCONNECT, NULL);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) dropped from far end\n", tech_pvt->bugname);
            break;
            case cartesia_tts::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
            break;
            case cartesia_tts::AudioPipe::MESSAGE:
            {
              cJSON* json = parse_json_string(session, message) ;
              if (!json) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "failed to parse json for message %s\n", message);
              }
              else {
                const char* type = cJSON_GetObjectCstr(json, "type");
                if (0 == strcmp(type, "chunk")) {
                  const char* context_id = cJSON_GetObjectCstr(json, "context_id");
                  if (context_id && 0 == strcmp(context_id, tech_pvt->current_context)) {
                    if (tech_pvt->current_context_state != FINISHED) {
                      //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "processing audio context_id %s, state %s\n", context_id, state2String(tech_pvt->current_context_state));
                      processIncomingAudio(tech_pvt, session, cJSON_GetObjectCstr(json, "data"));
                    }
                    else {
                      //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "discarding audio for finished context_id %s\n", context_id);
                    }
                  }
                  else if (context_id) {
                    //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "discarding audio for old context_id %s\n", context_id);
                  }
                }
                else if (0 == strcmp(type, "done")) {
                  const char* context_id = cJSON_GetObjectCstr(json, "context_id");
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got message from cartesia %s\n", message);

                  if (0 == strcmp(context_id, tech_pvt->current_context)) {
                    changeContextState(tech_pvt, DONE);
                  }
                  else {
                    updatePastContextState(tech_pvt, context_id, DONE);
                  }
                }
                else {
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got message from cartesia %s\n", message);
                }
              }
            }
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got unexpected msg from cartesia %d:%s\n", event, message);
              break;
          }
        }
      }
      switch_core_session_rwunlock(session);
    }
  }
  switch_status_t make_streaming_connection(switch_core_session_t *session, private_t *tech_pvt) {
    int err;
    int useTls = true;
    std::string host;
    int port = 443;
		auto read_codec = switch_core_session_get_read_codec(session);
    std::string path = "/tts/websocket";
    switch_channel_t *channel = switch_core_session_get_channel(session);

    tech_pvt->sampleRate = read_codec->implementation->actual_samples_per_second;

    const char* apiKey = switch_channel_get_variable(channel, "CARTESIA_API_KEY");
    if (!apiKey && defaultApiKey) {
      apiKey = defaultApiKey;
    } else if (!apiKey) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no cartesia api key provided\n");
      return SWITCH_STATUS_FALSE;
    }

    host = "api.cartesia.ai";
    strncpy(tech_pvt->host, host.c_str(), MAX_WS_URL_LEN);
    tech_pvt->port = port;
    strncpy(tech_pvt->path, path.c_str(), MAX_PATH_LEN);   
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);

    std::string context = generateShortUUID();
    strncpy(tech_pvt->current_context, context.c_str(), MAX_CONTEXT_LEN);

    cartesia_tts::AudioPipe* ap = new cartesia_tts::AudioPipe(tech_pvt->sessionId, tech_pvt->host, tech_pvt->port, tech_pvt->path, 
      apiKey, useTls, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }
    tech_pvt->pAudioPipe = static_cast<void *>(ap);

    auto pastContext = new std::unordered_map<std::string, ContextState>();
    if (!pastContext) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating pastContext\n");
      return SWITCH_STATUS_FALSE;
    }
    tech_pvt->pastContexts = static_cast<void *>(pastContext);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now\n");
    ap->connect();

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_NOTICE;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_NOTICE; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {
  switch_status_t cartesia_tts_streaming_init() {
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    //| LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    cartesia_tts::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		const char* apiKey = std::getenv("CARTESIA_API_KEY");
		if (NULL == apiKey) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
				"\"CARTESIA_API_KEY\" env var not set; authentication will expect channel variables of same names to be set\n");
		}
		else {
			hasDefaultCredentials = true;
      defaultApiKey = apiKey;
		}

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t cartesia_tts_streaming_cleanup() {
    bool cleanup = false;
    cleanup = cartesia_tts::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }

  switch_status_t cartesia_tts_streaming_session_init(switch_core_session_t *session, responseHandler_t responseHandler, void **ppUserData) {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    private_t* tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    switch_codec_t* read_codec = switch_core_session_get_read_codec(session);

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }

    memset(tech_pvt, 0, sizeof(private_t));
    tech_pvt->pAudioPipe = NULL;
    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
    tech_pvt->responseHandler = responseHandler;
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(tech_pvt->mutex, playoutBuffer);
    audioPlayer->enableBase64Encoding(true);

    tech_pvt->audioPlayer = (void *) audioPlayer;
    tech_pvt->playoutBuffer = (void *) playoutBuffer;
    tech_pvt->active = false;
    tech_pvt->bufferedTokens = NULL;
    tech_pvt->current_context_state = STARTING;

    *ppUserData = tech_pvt;

    if (SWITCH_STATUS_SUCCESS != make_streaming_connection(session, tech_pvt)) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing dg streaming connection.\n");
      return SWITCH_STATUS_FALSE;
    }

    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_status_t cartesia_tts_streaming_session_send_tokens(switch_core_session_t *session, switch_media_bug_t *bug, char* tokens)
  {
    int err;
    switch_status_t status = SWITCH_STATUS_FALSE;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no tech_pvt for session\n");
      return SWITCH_STATUS_FALSE;
    }

    if (setModelData(session, tech_pvt) != SWITCH_STATUS_SUCCESS) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error setting model data\n");
      return SWITCH_STATUS_FALSE;
    }

    tech_pvt->active = true;

    /* do we have a ws connection to cartesia? */
    if (tech_pvt->pAudioPipe) {
      cartesia_tts::AudioPipe *pAudioPipe = static_cast<cartesia_tts::AudioPipe *>(tech_pvt->pAudioPipe);

      if (pAudioPipe->getLwsState() == cartesia_tts::AudioPipe::LWS_CLIENT_CONNECTED) {
        if (tech_pvt->current_context_state == STARTING) {
          changeContextState(tech_pvt, SENDING);
        }
        if (tech_pvt->current_context_state != SENDING) {
          rotateContext(tech_pvt);
        }
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        if (p && p->isCleared()) p->open();
        sendTokens(pAudioPipe, tech_pvt, tokens);
        return SWITCH_STATUS_SUCCESS;
      }
      else if (pAudioPipe->getLwsState() == cartesia_tts::AudioPipe::LWS_CLIENT_CONNECTING ||
        pAudioPipe->getLwsState() == cartesia_tts::AudioPipe::LWS_CLIENT_IDLE) {
        size_t currentLength = tech_pvt->bufferedTokens ? strlen(tech_pvt->bufferedTokens) : 0;
        size_t additionalLength = strlen(tokens);
        size_t newSize = currentLength + additionalLength + 1;
        char* newBuffer = (char*)realloc(tech_pvt->bufferedTokens, newSize);
        if (nullptr == newBuffer) {
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error reallocating memory for buffered tokens\n");
          free(tech_pvt->bufferedTokens); 
          tech_pvt->bufferedTokens = nullptr;
          return SWITCH_STATUS_FALSE;
        }
        strcat(newBuffer, tokens);
        tech_pvt->bufferedTokens = newBuffer;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "added additional tokens while connecting, now have %d chars\n", newSize);
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "cannot send tokens as websocket state is %d\n", pAudioPipe->getLwsState());
        return SWITCH_STATUS_FALSE;
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no websocket connection to cartesia\n");
      return SWITCH_STATUS_FALSE;
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t cartesia_tts_streaming_session_flush(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "cartesia_tts_streaming_session_flush\n");

    // this is a no-op in cartesia
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t cartesia_tts_streaming_session_clear(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "cartesia_tts_streaming_session_clear\n");
    if (tech_pvt) {
      switch_mutex_lock(tech_pvt->mutex);

      if (setModelData(session, tech_pvt) != SWITCH_STATUS_SUCCESS) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error setting model data\n");
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_STATUS_FALSE;
      }

      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
      AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);

      if (tech_pvt->current_context_state == SENDING) {
        if (tech_pvt->pAudioPipe) {
          cartesia_tts::AudioPipe *pAudioPipe = static_cast<cartesia_tts::AudioPipe *>(tech_pvt->pAudioPipe);
          clearTokens(pAudioPipe, tech_pvt);
          changeContextState(tech_pvt, FINISHED);
        }
      }
      else {
        changeContextState(tech_pvt, FINISHED);
        // no need to send cancel to cartesia if we have flushed
      }

      if (p) p->clear();
      tech_pvt->active = false;
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t cartesia_tts_streaming_session_stop(switch_core_session_t *session,int channelIsClosing, switch_media_bug_t* bug) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_transcribe_session_stop: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_transcribe_session_stop\n");

    if (!tech_pvt) return SWITCH_STATUS_FALSE;
      
    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);
    switch_channel_set_private(channel, MY_BUG_NAME, NULL);
    if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

    cartesia_tts::AudioPipe *pAudioPipe = static_cast<cartesia_tts::AudioPipe *>(tech_pvt->pAudioPipe);
    if (pAudioPipe) pAudioPipe->close();

    CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;

    if (playoutBuffer != nullptr) {
      playoutBuffer->clear();
    }
    destroy_tech_pvt(tech_pvt);
    
    switch_mutex_unlock(tech_pvt->mutex);
    switch_mutex_destroy(tech_pvt->mutex);
    tech_pvt->mutex = nullptr;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_transcribe_session_stop\n");
    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_bool_t cartesia_dub_speech_frame(switch_media_bug_t *bug, private_t* tech_pvt) {
    int samplesToCopy = 0;

    if (nullptr == tech_pvt->playoutBuffer || !tech_pvt->active) {
      return SWITCH_TRUE;
    }

    switch_frame_t* rframe = switch_core_media_bug_get_write_replace_frame(bug);
    int16_t *fp = reinterpret_cast<int16_t*>(rframe->data);

    rframe->channels = 1;
    rframe->datalen = rframe->samples * sizeof(int16_t);

    int16_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
    memset(data, 0, sizeof(data));

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;

      //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "(%u) cartesia_dub_speech_frame - samples to copy %u\n", tech_pvt->id, samplesToCopy); 
      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(rframe->samples));

      if (samplesToCopy > 0) {
        auto count = playoutBuffer->getBlock(data, samplesToCopy);
        if (count != samplesToCopy) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "cartesia_dub_speech_frame - failed to get %d samples from playout buffer, got %d\n", samplesToCopy, count);
        }
        else {
          vector_add(fp, data, rframe->samples);
          vector_normalize(fp, rframe->samples);
          switch_core_media_bug_set_write_replace_frame(bug, rframe);

          if (samplesToCopy > 0 && playoutBuffer->size() == 0) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cartesia_dub_speech_frame - playout buffer is empty\n");
            if (tech_pvt->current_context_state == DONE) {
              changeContextState(tech_pvt, FINISHED);
            }
            switch_core_session_t* session = switch_core_session_locate(tech_pvt->sessionId);
            if (session) {
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_EMPTY, NULL);
              switch_core_session_rwunlock(session);
            }
          }
        }
      }
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}
