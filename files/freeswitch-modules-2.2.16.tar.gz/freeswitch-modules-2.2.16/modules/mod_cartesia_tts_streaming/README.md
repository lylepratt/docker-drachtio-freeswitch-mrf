# mod_cartesia_tts_streaming

A Freeswitch module that enables streaming of text from LLMs

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_deepgram_tts_streaming <uuid> |connect|send|clear|flush|close [tokens]
```

- `connect` - connect to Cartesia TTS websocket server
- `send tokens` - sends text tokens
- `flush` - tells Cartesia to generate audio
- `clear` - tells Cartesia to clear any queued audio or tokens
- `close` - closes the websocket connection to Cartesia