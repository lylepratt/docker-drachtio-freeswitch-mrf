/* 
 *
 * mod_rimelabs_tts_streaming.c -- Freeswitch module for using rimelabs streaming transcribe api
 *
 */
#include "mod_rimelabs_tts_streaming.h"
#include "rml_tts_streaming_glue.h"
#include "jambonz/cmd_parser.h"

#include <stdio.h>

/* Prototypes */
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_rimelabs_tts_streaming_shutdown);
SWITCH_MODULE_LOAD_FUNCTION(mod_rimelabs_tts_streaming_load);

SWITCH_MODULE_DEFINITION(mod_rimelabs_tts_streaming, mod_rimelabs_tts_streaming_load, mod_rimelabs_tts_streaming_shutdown, NULL);

static switch_bool_t capture_callback(switch_media_bug_t *bug, void *user_data, switch_abc_type_t type)
{
	switch_core_session_t *session = switch_core_media_bug_get_session(bug);
  switch_bool_t ret = SWITCH_TRUE;

	switch (type) {
	case SWITCH_ABC_TYPE_INIT:
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "Got SWITCH_ABC_TYPE_INIT.\n");
		break;

	case SWITCH_ABC_TYPE_CLOSE:
		{
			rml_tts_streaming_session_stop(session, 1, bug);
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "Finished SWITCH_ABC_TYPE_CLOSE.\n");
		}
		break;
	
	case SWITCH_ABC_TYPE_WRITE_REPLACE:
		ret = rml_dub_speech_frame(bug, user_data);
		break;

	default:
		break;
	}

	return ret;
}

static void responseHandler(switch_core_session_t* session, const char* eventName, const char * json) {
	switch_event_t *event;
	switch_channel_t *channel = switch_core_session_get_channel(session);

	switch_event_create_subclass(&event, SWITCH_EVENT_CUSTOM, eventName);
	switch_channel_event_set_data(channel, event);
	switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "tts-streaming-vendor", "rimelabs");
	if (json) switch_event_add_body(event, "%s", json);
	switch_event_fire(&event);
}

static switch_status_t do_connect(switch_core_session_t *session)
{
	switch_channel_t *channel = switch_core_session_get_channel(session);
  switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, MY_BUG_NAME);
  void *pUserData;
  switch_media_bug_flag_t flags = SMBF_WRITE_REPLACE;

	if (switch_channel_pre_answer(channel) != SWITCH_STATUS_SUCCESS) {
		return SWITCH_STATUS_FALSE;
	}

  if (bug) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "Received user command command to connect tts streaming but bug exists.\n");
    return SWITCH_STATUS_FALSE;
  }
  if (SWITCH_STATUS_FALSE == rml_tts_streaming_session_init(session, responseHandler, &pUserData)) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error initializing rimelabs streaming session.\n");
    return SWITCH_STATUS_FALSE;
  }
  if (SWITCH_STATUS_FALSE == switch_core_media_bug_add(session, "e_transcribe", NULL, capture_callback, pUserData, 0, flags, &bug)) {
    return SWITCH_STATUS_FALSE;
  }

  switch_channel_set_private(channel, MY_BUG_NAME, bug);

	return SWITCH_STATUS_SUCCESS;
}

static switch_status_t send_tokens(switch_core_session_t *session, char* tokens)
{
	switch_channel_t *channel = switch_core_session_get_channel(session);
  switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, MY_BUG_NAME);

	if (switch_channel_pre_answer(channel) != SWITCH_STATUS_SUCCESS) {
		return SWITCH_STATUS_FALSE;
	}

  if (!bug) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "send_tokens called but connection not made to rimelabs.\n");
    return SWITCH_STATUS_FALSE;
  }

	if (SWITCH_STATUS_FALSE == rml_tts_streaming_session_send_tokens(session, bug, tokens)) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error initializing rimelabs speech session.\n");
		return SWITCH_STATUS_FALSE;
	}

	return SWITCH_STATUS_SUCCESS;
}

static switch_status_t do_stop(switch_core_session_t *session)
{
	switch_status_t status = SWITCH_STATUS_SUCCESS;

	switch_channel_t *channel = switch_core_session_get_channel(session);
	switch_media_bug_t *bug = switch_channel_get_private(channel, MY_BUG_NAME);

	if (bug) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "Received user command command to stop tts streaming.\n");
		status = rml_tts_streaming_session_stop(session, 0, bug);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "stopped tts streaming.\n");
	}
  else {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "do_stop: did not find bugname %s.\n", MY_BUG_NAME);
  }

	return status;
}

static switch_status_t do_flush(switch_core_session_t *session)
{
	switch_status_t status = SWITCH_STATUS_SUCCESS;

	switch_channel_t *channel = switch_core_session_get_channel(session);
	switch_media_bug_t *bug = switch_channel_get_private(channel, MY_BUG_NAME);

	if (bug) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "Received user command command to flush tts tokens.\n");
		status = rml_tts_streaming_session_flush(session, bug);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "flushed tts tokens.\n");
	}
  else {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "do_flush: did not find bugname %s.\n", MY_BUG_NAME);
  }

	return status;
}

static switch_status_t do_clear(switch_core_session_t *session)
{
	switch_status_t status = SWITCH_STATUS_SUCCESS;

	switch_channel_t *channel = switch_core_session_get_channel(session);
	switch_media_bug_t *bug = switch_channel_get_private(channel, MY_BUG_NAME);

	if (bug) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "Received user command command to clear tts tokens.\n");
		status = rml_tts_streaming_session_clear(session, bug);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "cleared tts tokens.\n");
	}
  else {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "do_clear: did not find bugname %s.\n", MY_BUG_NAME);
  }

	return status;
}


#define TTS_STREAMING_API_SYNTAX "<uuid> connect|send|clear|close [tokens]"
SWITCH_STANDARD_API(rml_tts_stream_function)
{
	char *mycmd = NULL, *argv[3] = { 0 };
	int argc = 0;
	switch_status_t status = SWITCH_STATUS_FALSE;

	if (!zstr(cmd) && (mycmd = strdup(cmd))) {
    //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "command %s\n", cmd);
    argc = switch_separate_string_no_cleanup(mycmd, ' ', argv, (sizeof(argv) / sizeof(argv[0])));
	}

	if (zstr(cmd) || 
      (!strcasecmp(argv[1], "send") && argc < 3) ||
      (!strcasecmp(argv[1], "clear") && argc < 2) ||
      (!strcasecmp(argv[1], "flush") && argc < 2) ||
      (!strcasecmp(argv[1], "connect") && argc < 2) ||
      (!strcasecmp(argv[1], "close") && argc < 2) ||
      zstr(argv[0])) {
		switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error with command %s %s %s.\n", cmd, argv[0], argv[1]);
		stream->write_function(stream, "-USAGE: %s\n", TTS_STREAMING_API_SYNTAX);
		goto done;
	} else {
		switch_core_session_t *lsession = NULL;

		if ((lsession = switch_core_session_locate(argv[0]))) {
			if (!strcasecmp(argv[1], "clear")) {
				status = do_clear(lsession);
			} 
			else if (!strcasecmp(argv[1], "flush")) {
				status = do_flush(lsession);
			} 
			else if (!strcasecmp(argv[1], "stop")) {
				status = do_stop(lsession);
			} 
			else if (!strcasecmp(argv[1], "stop")) {
				status = do_flush(lsession);
			} 
			else if (!strcasecmp(argv[1], "connect")) {
				status = do_connect(lsession);
			} 
      else if (!strcasecmp(argv[1], "send")) {
        char* tokens = argv[2];
        status = send_tokens(lsession, tokens);
			}
      else {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Invalid command '%s'\n", argv[1]);
      }
			switch_core_session_rwunlock(lsession);
		}
	}

	if (status == SWITCH_STATUS_SUCCESS) {
		stream->write_function(stream, "+OK Success\n");
	} else {
		stream->write_function(stream, "-ERR Operation Failed\n");
	}

  done:

	switch_safe_free(mycmd);
	return SWITCH_STATUS_SUCCESS;
}


SWITCH_MODULE_LOAD_FUNCTION(mod_rimelabs_tts_streaming_load)
{
	switch_api_interface_t *api_interface;

	/* create/register custom event message types */
	if (switch_event_reserve_subclass(TTS_STREAM_EVENT_EMPTY) != SWITCH_STATUS_SUCCESS) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't register subclass %s!\n", TTS_STREAM_EVENT_EMPTY);
		return SWITCH_STATUS_TERM;
	}
	if (switch_event_reserve_subclass(TTS_STREAM_EVENT_CONNECT_SUCCESS) != SWITCH_STATUS_SUCCESS) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't register subclass %s!\n", TTS_STREAM_EVENT_CONNECT_SUCCESS);
		return SWITCH_STATUS_TERM;
	}
	if (switch_event_reserve_subclass(TTS_STREAM_EVENT_CONNECT_FAIL) != SWITCH_STATUS_SUCCESS) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't register subclass %s!\n", TTS_STREAM_EVENT_CONNECT_FAIL);
		return SWITCH_STATUS_TERM;
	}
	if (switch_event_reserve_subclass(TTS_STREAM_EVENT_DISCONNECT) != SWITCH_STATUS_SUCCESS) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't register subclass %s!\n", TTS_STREAM_EVENT_DISCONNECT);
		return SWITCH_STATUS_TERM;
	}

	/* connect my internal structure to the blank pointer passed to me */
	*module_interface = switch_loadable_module_create_module_interface(pool, modname);

	switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "Rimelabs Streaming TTS loading..\n");

  if (SWITCH_STATUS_FALSE == rml_tts_streaming_init()) {
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_CRIT, "Failed initializing rimelabs tts streaming interface\n");
	}

	switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "Rimelabs Streaming TTS loading API successfully loaded\n");

	SWITCH_ADD_API(api_interface, "uuid_rimelabs_tts_streaming", "Rimelabs Streaming TTS loading API", rml_tts_stream_function, TTS_STREAMING_API_SYNTAX);
	switch_console_set_complete("add uuid_rimelabs_tts_streaming send [tokens]");
	switch_console_set_complete("add uuid_rimelabs_tts_streaming clear");
	switch_console_set_complete("add uuid_rimelabs_tts_streaming flush");
	switch_console_set_complete("add uuid_rimelabs_tts_streaming connect");

	/* indicate that the module should continue to be loaded */
	return SWITCH_STATUS_SUCCESS;
}

/*
  Called when the system shuts down
  Macro expands to: switch_status_t mod_rimelabs_tts_streaming_shutdown() */
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_rimelabs_tts_streaming_shutdown)
{
	rml_tts_streaming_cleanup();
	switch_event_free_subclass(TTS_STREAM_EVENT_EMPTY);
	switch_event_free_subclass(TTS_STREAM_EVENT_CONNECT_SUCCESS);
	switch_event_free_subclass(TTS_STREAM_EVENT_CONNECT_FAIL);
	switch_event_free_subclass(TTS_STREAM_EVENT_DISCONNECT);
	return SWITCH_STATUS_SUCCESS;
}
