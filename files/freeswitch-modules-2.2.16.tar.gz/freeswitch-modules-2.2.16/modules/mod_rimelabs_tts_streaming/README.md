# mod_rimelabs_tts_streaming

A Freeswitch module that enables streaming of text from LLMs

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_rimelabs_tts_streaming <uuid> |connect|send|clear|flush|close [tokens]
```

- `connect` - connect to Rimelabs TTS websocket server
- `send tokens` - sends text tokens
- `flush` - tells Rimelabs to generate audio
- `clear` - tells Rimelabs to clear any queued audio or tokens
- `close` - closes the websocket connection to Rimelabs