#ifndef __RML_TTS_STREAMING_GLUE_H__
#define __RML_TTS_STREAMING_GLUE_H__

// global
switch_status_t rml_tts_streaming_init();
switch_status_t rml_tts_streaming_cleanup();

// session-level
switch_status_t rml_tts_streaming_session_init(switch_core_session_t *session, responseHandler_t responseHandler, void **ppUserData);
switch_status_t rml_tts_streaming_session_send_tokens(switch_core_session_t *session, switch_media_bug_t *bug, char* tokens);
switch_status_t rml_tts_streaming_session_stop(switch_core_session_t *session, int channelIsClosing, switch_media_bug_t *bug);
switch_status_t rml_tts_streaming_session_clear(switch_core_session_t *session, switch_media_bug_t *bug);
switch_status_t rml_tts_streaming_session_flush(switch_core_session_t *session, switch_media_bug_t *bug);
switch_bool_t rml_dub_speech_frame(switch_media_bug_t *bug, private_t * tech_pvt);

#endif