#ifndef __MOD_RIMELABS_TTS_STREAMING_H__
#define __MOD_RIMELABS_TTS_STREAMING_H__

#include <switch.h>
#include <speex/speex_resampler.h>

#include <unistd.h>

#define MY_BUG_NAME                       "rimelabs_tts_streaming"
#define TTS_STREAM_EVENT_EMPTY            "rimelabs_tts_streaming::empty"
#define TTS_STREAM_EVENT_CONNECT_SUCCESS  "rimelabs_tts_streaming::connect"
#define TTS_STREAM_EVENT_CONNECT_FAIL     "rimelabs_tts_streaming::connect_failed"
#define TTS_STREAM_EVENT_DISCONNECT       "rimelabs_tts_streaming::disconnect"

#define MAX_SESSION_ID (256)
#define MAX_WS_URL_LEN (512)
#define MAX_PATH_LEN (4096)
#define MAX_BUG_LEN (64)

typedef void (*responseHandler_t)(switch_core_session_t* session, const char* eventName, const char* json);

struct private_data {
	switch_mutex_t *mutex;
	char sessionId[MAX_SESSION_ID+1];
  responseHandler_t responseHandler;
  void *pAudioPipe;
  char *bufferedTokens;
  char host[MAX_WS_URL_LEN+1];
  unsigned int port;
  char path[MAX_PATH_LEN+1];
  char bugname[MAX_BUG_LEN+1];
  int sampleRate;
  int active;
  int connection_retry_counter;
  int is_good_to_reconnect;
  int keep_alive_interval_counter;

  void *audioPlayer;
  void *playoutBuffer;
};

typedef struct private_data private_t;

#endif