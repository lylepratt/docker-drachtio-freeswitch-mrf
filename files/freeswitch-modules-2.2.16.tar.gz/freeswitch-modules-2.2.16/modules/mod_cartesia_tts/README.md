# mod_cartesia_tts

A Freeswitch module that allows speak text to speech audio from cartesia stream.