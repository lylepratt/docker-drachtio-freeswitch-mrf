#ifndef __CARTESIA_GLUE_H__
#define __CARTESIA_GLUE_H__

switch_status_t cartesia_speech_load();
switch_status_t cartesia_speech_open(cartesia_t* cartesia);
switch_status_t cartesia_speech_feed_tts(cartesia_t* cartesia, char* text, switch_speech_flag_t *flags);
switch_status_t cartesia_speech_read_tts(cartesia_t* cartesia, void *data, size_t *datalen, switch_speech_flag_t *flags);
switch_status_t cartesia_speech_flush_tts(cartesia_t* cartesia);
switch_status_t cartesia_speech_close(cartesia_t* cartesia);
switch_status_t cartesia_speech_unload();

#endif