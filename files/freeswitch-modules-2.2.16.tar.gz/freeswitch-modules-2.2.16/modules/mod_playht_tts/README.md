# mod_playht_tts

A Freeswitch module that allows speak text to speech audio from playht stream.