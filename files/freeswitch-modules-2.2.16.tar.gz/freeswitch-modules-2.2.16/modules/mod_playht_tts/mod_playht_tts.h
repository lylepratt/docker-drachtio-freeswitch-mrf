#ifndef __MOD_PLAYHT_TTS_H__
#define __MOD_PLAYHT_TTS_H__

#include <switch.h>
#include <speex/speex_resampler.h>
typedef struct playht_data {
  char *voice_name;
  char *api_key;
  char *user_id;
  char *quality;
  char *speed;
  char *seed;
  char *temperature;
  char *voice_engine;
  char *synthesize_url;
  char *language;
  char *emotion;
  char *voice_guidance;
  char *style_guidance;
  char *text_guidance;
  char *top_p;
  char *repetition_penalty;

  /* result data */
  long response_code;
  char *ct;
  char *request_id;
  char *name_lookup_time_ms;
  char *connect_time_ms;
  char *final_response_time_ms;
  char *err_msg;
  char *cache_filename;
  char *session_id;

  int rate;
  int draining;
  int reads;
  int cache_audio;
  int playback_start_sent;

	void *conn;
  void *audioPlayer;
  void *playoutBuffer;
  switch_mutex_t *mutex;
  FILE *file;
} playht_t;
#endif