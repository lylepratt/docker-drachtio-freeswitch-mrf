# mod_deepgram_voice_agent_s2s

A Freeswitch module that integrates with Deepgram Voice Agent service.

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_voice_agent_s2s <uuid> session.create host path auth-type [api-key]
```
where:
- host: URL host value for the websocket connection (e.g. agent.deepgram.com)
- path: URL path (e.g. /agent)
- auth-type: bearer 
- api-key: the api key to use to authenticate

This api call establishes a websocket connection to the openai realtime beta (supports connecting to either OpenAI or Azure).  If the connection is successfully established, which the caller will know through the 'openai_s2s::connect' event, then the caller must next send first a `session.create` and then a `session.update` client event to the server.  Only when the first `session.update` request is sent will input audio begin streaming to the openAI endpoint.  Client events are sent using the `client_event` api described below.

```
uuid_voice_agent_s2s <uuid> client.event client-event-json
```
where
- client-event-json: a json string conforming to the [syntax described here](https://platform.openai.com/docs/guides/realtime/client-events).

```
uuid_voice_agent_s2s <uuid> session.delete
```
Ends the session.

### Events
This module fires the following events:
- openai_s2s::connect - fired when the websocket connection is established
- openai_s2s::connect_failed - fired if the websocket connection fails
- openai_s2s:server_event - fired when a server event is received from openai

