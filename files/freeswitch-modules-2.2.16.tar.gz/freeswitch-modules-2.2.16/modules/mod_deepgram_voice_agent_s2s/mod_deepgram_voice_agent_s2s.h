#ifndef __MOD_VOICEAGENT_S2S_H__
#define __MOD_VOICEAGENT_S2S_H__

#include <switch.h>
#include <speex/speex_resampler.h>

#include <unistd.h>

#define MY_BUG_NAME "voice_agent_s2s"

#define VAS2S_EVENT_SERVER "voice_agent_s2s::server_event"

#define VAS2S_EVENT_VAD_DETECTED "voice_agent_s2s::vad_detected"
#define VAS2S_EVENT_CONNECT_SUCCESS "voice_agent_s2s::connect"
#define VAS2S_EVENT_CONNECT_FAIL    "voice_agent_s2s::connect_failed"
#define VAS2S_EVENT_BUFFER_OVERRUN  "voice_agent_s2s::buffer_overrun"
#define VAS2S_EVENT_DISCONNECT      "voice_agent_s2s::disconnect"

#define MAX_SESSION_ID (256)
#define MAX_PARM_LEN (4096)
#define MAX_BUG_LEN (64)

typedef void (*responseHandler_t)(switch_core_session_t* session, const char* eventName, const char* json, const char* bugname);

typedef enum {
    SESSION_STATE_NONE = 0,
    SESSION_STATE_WS_CONNECTED,
    SESSION_STATE_CONVERSATION_STARTED
} SessionState_t;


struct private_data {
	switch_mutex_t *mutex;
	char sessionId[MAX_SESSION_ID+1];
  char bugname[MAX_BUG_LEN+1];
  SessionState_t state;
  SpeexResamplerState *resampler_in;
  responseHandler_t responseHandler;
  void *pAudioPipe;
  int ws_state;
  int sampling;
  unsigned int id;
  int buffer_overrun_notified:1;
  int is_finished:1;
  int initial_assistant_response_completed:1;
  int assistant_started_speaking:1;

  // audio output
  void *audioPlayer;
  void *playoutBuffer;
};

typedef struct private_data private_t;

#endif