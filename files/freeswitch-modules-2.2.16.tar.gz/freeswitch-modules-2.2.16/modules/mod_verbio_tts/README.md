# mod_verbio_tts

A Freeswitch module that allows speak text to speech audio from Verbio stream.
