# mod_speechmatics_transcribe

A Freeswitch module that generates real-time transcriptions on a Freeswitch channel by using Speechmatics's streaming transcription API

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_speechmatics_transcribe <uuid> start <lang-code> [interim] [bugname]
```
Attaches media bug to channel and performs streaming recognize request.
- `uuid` - unique identifier of Freeswitch channel
- `lang-code` - a valid Speechmatics [language code](https://docs.speechmatics.com/introduction/supported-languages#languages) that is supported for streaming transcription
- `interim` - If the 'interim' keyword is present then both interim and final transcription results will be returned; otherwise only final transcriptions will be returned
- `bugname` - optional name of the media bug; useful when you need to have two speechmatics transcriptions going on the same channel for some reason.

```
uuid_speechmatics__transcribe <uuid> stop
```
Stop transcription on the channel.

### Channel Variables

| variable | Description |
| --- | ----------- |
| SPEECHMATICS_API_KEY | Speechmatics API key used to authenticate |
| SPEECHMATICS_HOST | Speechmatics host to connect to |
| SPEECHMATICS_PATH | Defaults to "\v2"|
| SPEECHMATICS_SPEECH_HINTS | comma-separated list of phrases or words to provided to the recognizer as hints |

### Events

- speechmatics_transcribe::transcription
- speechmatics_transcribe::recognition_started
- speechmatics_transcribe::info
- speechmatics_transcribe::error
- speechmatics_transcribe::connect
- speechmatics_transcribe::connect_failed
- speechmatics_transcribe::buffer_overrun
- speechmatics_transcribe::disconnect
