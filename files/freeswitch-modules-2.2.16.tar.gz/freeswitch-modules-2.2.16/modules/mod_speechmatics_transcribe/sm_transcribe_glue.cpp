#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>

#include "mod_speechmatics_transcribe.h"
#include "simple_buffer.h"
#include "parser.hpp"
#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/

namespace {
  static const char* emptyTranscript = "\"results\":[]";
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static const char* defaultApiKey = nullptr;
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static const char *requestedNumServiceThreads = std::getenv("MOD_AUDIO_FORK_SERVICE_THREADS");
  static unsigned int idxCallCount = 0;
  static uint32_t playCount = 0;


  /* speechmatics language has only the first part of the ISO lang code */
  static void copyUntilDash(const char* input, char* output, size_t outputSize) {
      size_t length = strlen(input);

      // Find the position of a dash in the 3rd or 4th character
      size_t copyLength = length;
      if (length >= 3 && input[2] == '-') {
          copyLength = 2; // Copy only the first two characters
      } else if (length >= 4 && input[3] == '-') {
          copyLength = 3; // Copy only the first three characters
      }

      // Ensure we do not exceed the size of the output buffer
      if (copyLength >= outputSize) {
          copyLength = outputSize - 1;
      }

      // Copy the characters and null-terminate the string
      strncpy(output, input, copyLength);
      output[copyLength] = '\0'; // Null-terminate the output string
  }

  static void reaper(private_t *tech_pvt) {
    std::string sessionId(tech_pvt->sessionId);
    unsigned int id = tech_pvt->id;
    std::shared_ptr<speechmatics::AudioPipe> pAp;

    pAp.reset((speechmatics::AudioPipe *)tech_pvt->pAudioPipe);
    tech_pvt->pAudioPipe = nullptr;

    std::thread t([pAp, sessionId, id]{
      pAp->finish();
      pAp->waitForClose();
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) got remote close\n", sessionId.c_str(), id);
    });
    t.detach();
  }

  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      if (tech_pvt->pAudioPipe) {
        speechmatics::AudioPipe* p = (speechmatics::AudioPipe *) tech_pvt->pAudioPipe;
        delete p;
        tech_pvt->pAudioPipe = nullptr;
      }

      // NB: do not destroy the mutex here, that is caller responsibility

      /*
      if (tech_pvt->vad) {
        switch_vad_destroy(&tech_pvt->vad);
        tech_pvt->vad = nullptr;
      }
      */
    }
  }

  static cJSON *build_start_recognition_request(switch_channel_t *channel, const char *language, int interim, int sampling,
  char *vocab[], int vocab_size) {
    const char* max_delay = switch_channel_get_variable(channel, "SPEECHMATICS_MAX_DELAY");
    const char* max_delay_mode = switch_channel_get_variable(channel, "SPEECHMATICS_MAX_DELAY_MODE");
    const char* diarization = switch_channel_get_variable(channel, "SPEECHMATICS_DIARIZATION");
    const char* diarization_speaker_sensitivity = switch_channel_get_variable(channel, "SPEECHMATICS_DIARIZATION_SPEAKER_SENSITIVITY"); 
    const char* diarization_max_speakers = switch_channel_get_variable(channel, "SPEECHMATICS_DIARIZATION_MAX_SPEAKERS"); 
    const char* output_locale = switch_channel_get_variable(channel, "SPEECHMATICS_OUTPUT_LOCALE");
    const char* punctuation_allowed = switch_channel_get_variable(channel, "SPEECHMATICS_PUNCTUATION_ALLOWED");
    const char* punctuation_sensitivity = switch_channel_get_variable(channel, "SPEECHMATICS_PUNCTUATION_SENSITIVITY");
    const char* operating_point = switch_channel_get_variable(channel, "SPEECHMATICS_OPERATING_POINT");
    const char* enable_entities = switch_channel_get_variable(channel, "SPEECHMATICS_ENABLE_ENTITIES");
    const char* volume_threshold = switch_channel_get_variable(channel, "SPEECHMATICS_VOLUME_THRESHOLD");
    const char* remove_disfluencies = switch_channel_get_variable(channel, "SPEECHMATICS_REMOVE_DISFLUENCIES");
    const char* translation_languages = switch_channel_get_variable(channel, "SPEECHMATICS_TRANSLATION_LANGUAGES");

    // Create the root object
    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "message", "StartRecognition");

    // "audio_format"
    cJSON *audio_format = cJSON_CreateObject();
    cJSON_AddStringToObject(audio_format, "type", "raw");
    cJSON_AddStringToObject(audio_format, "encoding", "pcm_s16le");
    cJSON_AddNumberToObject(audio_format, "sample_rate", sampling);
    cJSON_AddItemToObject(root, "audio_format", audio_format);

    // "transcription_config"
    cJSON *transcription_config = cJSON_CreateObject();
    cJSON_AddStringToObject(transcription_config, "language", language);  // language from variable
    cJSON *additional_vocab = cJSON_CreateArray();
    for (int i = 0; i < vocab_size; i++) {
        cJSON_AddItemToArray(additional_vocab, cJSON_CreateString(vocab[i]));
    }
    cJSON_AddItemToObject(transcription_config, "additional_vocab", additional_vocab);

    cJSON_AddBoolToObject(transcription_config, "enable_partials", interim);

    if (nullptr != diarization) {
      cJSON_AddStringToObject(transcription_config, "diarization", diarization);
      if (nullptr != diarization_max_speakers) {
        cJSON *speaker_diarization_config = cJSON_CreateObject();
        int max_speakers = atoi(diarization_max_speakers);
        cJSON_AddNumberToObject(speaker_diarization_config, "max_speakers", max_speakers);
        cJSON_AddItemToObject(transcription_config, "diarization_config", speaker_diarization_config);
      }
    }

    if (output_locale) {
      cJSON_AddStringToObject(transcription_config, "output_locale", output_locale );
    }
    if (operating_point) {
      cJSON_AddStringToObject(transcription_config, "operating_point", operating_point);
    }

    if (nullptr != punctuation_allowed) {
      cJSON *punctuation_overrides = cJSON_CreateObject();
      cJSON *permitted_marks = cJSON_CreateArray();

      // Split the punctuation_allowed string by commas
      std::string punctuation_str(punctuation_allowed);
      std::istringstream stream(punctuation_str);
      std::string mark;
      while (std::getline(stream, mark, ',')) {
          // Trim whitespace from the mark
          mark.erase(0, mark.find_first_not_of(" \t"));
          mark.erase(mark.find_last_not_of(" \t") + 1);

          // Add each trimmed mark to the array
          if (!mark.empty()) {
              cJSON_AddItemToArray(permitted_marks, cJSON_CreateString(mark.c_str()));
          }
      }

      // Add the permitted_marks array to the punctuation_overrides object
      cJSON_AddItemToObject(punctuation_overrides, "permitted_marks", permitted_marks);

      if (nullptr != punctuation_sensitivity) {
        float sensitivity = atof(punctuation_sensitivity);
        cJSON_AddNumberToObject(punctuation_overrides, "sensitivity", sensitivity);
      }

      cJSON_AddItemToObject(transcription_config, "punctuation_overrides", punctuation_overrides);
    }
    
    if (nullptr != enable_entities) {
      cJSON_AddBoolToObject(transcription_config, "enable_entities", switch_true(enable_entities));
    }

    if (nullptr != volume_threshold) {
      cJSON *audio_filtering_config = cJSON_CreateObject();
      cJSON_AddNumberToObject(audio_filtering_config, "volume_threshold", atof(volume_threshold));
      cJSON_AddItemToObject(transcription_config, "audio_filtering_config", audio_filtering_config);
    }

    if (nullptr != remove_disfluencies) {
      cJSON *transcript_filtering_config = cJSON_CreateObject();
      cJSON_AddBoolToObject(transcript_filtering_config, "remove_disfluencies", switch_true(remove_disfluencies));
      cJSON_AddItemToObject(transcription_config, "transcript_filtering_config", transcript_filtering_config);
    }

    if (nullptr != max_delay) {
      cJSON_AddNumberToObject(transcription_config, "max_delay", atof(max_delay));
    }
    else {
      cJSON_AddNumberToObject(transcription_config, "max_delay", 0.7);
    }

    if (nullptr != max_delay_mode) {
      cJSON_AddStringToObject(transcription_config, "max_delay_mode", max_delay_mode);
    }
    else {
      cJSON_AddStringToObject(transcription_config, "max_delay_mode", "flexible");
    }
    cJSON_AddItemToObject(root, "transcription_config", transcription_config);

    // translation_config
    if (translation_languages) {
      cJSON *translation_config = cJSON_CreateObject();
      cJSON *target_languages = cJSON_CreateArray();
      char *languages[10] = { 0 };
      int argc = switch_separate_string((char *)translation_languages, ',', languages, 10);
      for (int i = 0; i < argc; i++) {
        cJSON_AddItemToArray(target_languages, cJSON_CreateString(languages[i]));
      }
      cJSON_AddItemToObject(translation_config, "target_languages", target_languages);
      cJSON_AddItemToObject(root, "translation_config", translation_config);
    }

    return root;  // caller is responsible for deleting this object using cJSON_Delete
  }

  static void sendStartRecognitionRequest(switch_channel_t *channel, speechmatics::AudioPipe* pAudioPipe, private_t* tech_pvt) {
    char *phrases[500] = { 0 };
    int argc = 0;
    const char* hints = switch_channel_get_variable(channel, "SPEECHMATICS_SPEECH_HINTS");
		if (hints) {
      argc = switch_separate_string((char *)hints, ',', phrases, 500);
		}

    cJSON *json = build_start_recognition_request(channel, tech_pvt->lang, tech_pvt->interim, tech_pvt->sampling, phrases, argc);
    const char* jsonStr = cJSON_PrintUnformatted(json);
    
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "sendStartRecognitionRequest %s.\n", jsonStr);

    pAudioPipe->bufferForSending(jsonStr);

    free((void*)jsonStr);
    cJSON_Delete(json);
  }

  static void eventCallback(const char* sessionId, const char* bugname, 
    speechmatics::AudioPipe::NotifyEvent_t event, const char* message, bool finished) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case speechmatics::AudioPipe::CONNECT_SUCCESS:
            {
              auto *pAudioPipe = static_cast<speechmatics::AudioPipe*>(tech_pvt->pAudioPipe);
              tech_pvt->state = SESSION_STATE_WS_CONNECTED;
              sendStartRecognitionRequest(channel, pAudioPipe, tech_pvt);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) successful\n", tech_pvt->bugname);
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_SUCCESS, NULL, tech_pvt->bugname, finished);
            }
            break;
            case speechmatics::AudioPipe::CONNECT_FAIL:
            tech_pvt->state = SESSION_STATE_NONE;
            {
              // first thing: we can no longer access the AudioPipe
              std::stringstream json;
              json << "{\"reason\":\"" << message << "\"}";
              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_FAIL, (char *) json.str().c_str(), tech_pvt->bugname, finished);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
            }
            break;
            case speechmatics::AudioPipe::CONNECTION_DROPPED:
              // first thing: we can no longer access the AudioPipe

              /**
               * this is a bit tricky.  If we just closed a previos connection it may be returning final transcripts
               * and then a close event here as it is shutting down (in the reaper thread above).
               * In this scenario, the fact that the connection is dropped is not significant.
               */
              if (finished) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "old connection (%s) gracefully closed by Speechmatics\n", tech_pvt->bugname);
              }
              else {
                tech_pvt->state = SESSION_STATE_NONE;
                tech_pvt->pAudioPipe = nullptr;
                tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_DISCONNECT, NULL, tech_pvt->bugname, finished);
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) dropped from far end\n", tech_pvt->bugname);
              }
            break;
            case speechmatics::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              tech_pvt->state = SESSION_STATE_NONE;
              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
            break;
            case speechmatics::AudioPipe::MESSAGE:
              if( strstr(message, emptyTranscript)) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "discarding empty deepgram transcript\n");
              }
              else {
                bool notify = true;
                std::string eventType = TRANSCRIBE_EVENT_RESULTS;
                cJSON *msg = cJSON_Parse(message);
                if (!msg) {
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error parsing message from speechmatics %s\n", message);
                  return;
                }
                else {
                  const char* msgType = cJSON_GetStringValue(cJSON_GetObjectItem(msg, "message"));
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "speechmatics message (%s): %s\n", tech_pvt->bugname, message);

                  if (msgType && 0 == strcmp(msgType, "RecognitionStarted")) {
                    // we can now start sending audio
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "start sending audio\n");
                    tech_pvt->state = SESSION_STATE_CONVERSATION_STARTED;
                    eventType = TRANSCRIBE_EVENT_RECOGNITION_STARTED;
                  }
                  else if (msgType && 0 == strcmp(msgType, "Info")) {
                    eventType = TRANSCRIBE_EVENT_INFO;
                  }
                  else if (msgType && 0 == strcmp(msgType, "Error")) {
                    eventType = TRANSCRIBE_EVENT_ERROR;
                  }
                  else if (msgType && 0 == strcmp(msgType, "EndOfStream")) {
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got EndOfStream: %s: %s\n", tech_pvt->bugname, message);
                    notify = false;
                  }
                  else if (msgType && 0 == strcmp(msgType, "EndOfTranscript")) {
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got EndOfTranscript: %s: %s\n", tech_pvt->bugname, message);
                    notify = false;
                  }
                  else if (msgType && 0 == strcmp(msgType, "AddTranslation")) {
                    eventType = TRANSCRIBE_EVENT_TRANSLATION;
                  }

                  /* we do not send on empty transcripts */
                  cJSON *results = cJSON_GetObjectItem(msg, "results");
                  if (results && cJSON_IsArray(results) && cJSON_GetArraySize(results) == 0) {
                    notify = false;
                  }

                  if (notify) tech_pvt->responseHandler(session, eventType.c_str(), message, tech_pvt->bugname, finished);

                  cJSON_Delete(msg);
                }
              }
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from speechmatics %d:%s\n", event, message);
              break;
          }
        }
      }
      switch_core_session_rwunlock(session);
    }
  }
  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, 
    int sampling, int desiredSampling, int channels, char* lang, int interim, 
    char* bugname, responseHandler_t responseHandler) {

    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_codec_implementation_t read_impl;
    int err;

    const char* api_key = switch_channel_get_variable(channel, "SPEECHMATICS_API_KEY");
    if (!api_key) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no speechmatics api key provided!\n");
      return SWITCH_STATUS_FALSE;
    }
    const char* host = switch_channel_get_variable(channel, "SPEECHMATICS_HOST");
    if (!host) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no speechmatics host provided!\n");
      return SWITCH_STATUS_FALSE;
    }
    const char* path = switch_channel_get_variable(channel, "SPEECHMATICS_PATH");

    int port = 443;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * desiredSampling / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_core_session_get_read_impl(session, &read_impl);
  
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->host, host, MAX_WS_URL_LEN);
    tech_pvt->port = port;
    strncpy(tech_pvt->path, path ? path : "/v2", MAX_PATH_LEN);   
    tech_pvt->sampling = sampling;
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->channels = channels;
    tech_pvt->id = ++idxCallCount;
    tech_pvt->buffer_overrun_notified = 0;
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    copyUntilDash(lang, tech_pvt->lang, MAX_LANG);
    tech_pvt->interim = interim;

    speechmatics::AudioPipe* ap = new speechmatics::AudioPipe(tech_pvt->sessionId, bugname, tech_pvt->host, tech_pvt->port, tech_pvt->path, 
      buflen, read_impl.decoded_bytes_per_packet, api_key, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }

    tech_pvt->pAudioPipe = static_cast<void *>(ap);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now\n");
    ap->connect();
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");

    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
    
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) fork_data_init\n", tech_pvt->id);

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {
  switch_status_t sm_transcribe_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_speechmatics_transcribe: audio buffer (in secs):    %d secs\n", nAudioBufferSecs);
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    speechmatics::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t sm_transcribe_cleanup() {
    bool cleanup = false;
    cleanup = speechmatics::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }
	
  switch_status_t sm_transcribe_session_init(switch_core_session_t *session, 
    responseHandler_t responseHandler, uint32_t samples_per_second, uint32_t channels, 
    char* lang, int interim, char* bugname, void **ppUserData)
  {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    private_t* tech_pvt;

    tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }
    memset(tech_pvt, 0, sizeof(private_t));

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second, 8000, channels,
      lang, interim, bugname, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;

    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t sm_transcribe_session_stop(switch_core_session_t *session,int channelIsClosing, char* bugname) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "sm_transcribe_session_stop: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    uint32_t id = tech_pvt->id;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) sm_transcribe_session_stop\n", id);

    if (!tech_pvt) return SWITCH_STATUS_FALSE;
      
    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);
    switch_channel_set_private(channel, bugname, NULL);
    if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

    speechmatics::AudioPipe *pAudioPipe = static_cast<speechmatics::AudioPipe *>(tech_pvt->pAudioPipe);
    if (pAudioPipe) reaper(tech_pvt);
    destroy_tech_pvt(tech_pvt);
    switch_mutex_unlock(tech_pvt->mutex);
    switch_mutex_destroy(tech_pvt->mutex);
    tech_pvt->mutex = nullptr;
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) sm_transcribe_session_stop\n", id);
    return SWITCH_STATUS_SUCCESS;
  }
	
	switch_bool_t sm_transcribe_frame(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    size_t inuse = 0;
    bool dirty = false;
    char *p = (char *) "{\"msg\": \"buffer overrun\"}";

    if (!tech_pvt) return SWITCH_TRUE;
        
    /* dont send audio until initial response.created is received */
    if (tech_pvt->state != SESSION_STATE_CONVERSATION_STARTED) {
      return SWITCH_TRUE;
    }

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      if (!tech_pvt->pAudioPipe) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      speechmatics::AudioPipe *pAudioPipe = static_cast<speechmatics::AudioPipe *>(tech_pvt->pAudioPipe);
      if (pAudioPipe->getLwsState() != speechmatics::AudioPipe::LWS_CLIENT_CONNECTED) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      pAudioPipe->lockAudioBuffer();
      size_t available = pAudioPipe->binarySpaceAvailable();
      switch_frame_t frame = { 0 };
      frame.data = pAudioPipe->binaryWritePtr();
      frame.buflen = available;
      while (true) {

        // check if buffer would be overwritten; dump packets if so
        if (available < pAudioPipe->binaryMinSpace()) {
          if (!tech_pvt->buffer_overrun_notified) {
            tech_pvt->buffer_overrun_notified = 1;
            tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
          }
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n", 
            tech_pvt->id);
          pAudioPipe->binaryWritePtrResetToZero();

          frame.data = pAudioPipe->binaryWritePtr();
          frame.buflen = available = pAudioPipe->binarySpaceAvailable();
        }

        switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
        if (rv != SWITCH_STATUS_SUCCESS) break;
        if (frame.datalen) {
          pAudioPipe->binaryWritePtrAdd(frame.datalen);
          frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          frame.data = pAudioPipe->binaryWritePtr();
          dirty = true;
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}
