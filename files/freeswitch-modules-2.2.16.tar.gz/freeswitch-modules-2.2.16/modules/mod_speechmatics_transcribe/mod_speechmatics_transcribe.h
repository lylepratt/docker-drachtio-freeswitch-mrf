#ifndef __MOD_SM_TRANSCRIBE_H__
#define __MOD_SM_TRANSCRIBE_H__

#include <switch.h>
#include <speex/speex_resampler.h>

#include <unistd.h>

#define MY_BUG_NAME "speechmatics_transcribe"
#define TRANSCRIBE_EVENT_RESULTS "speechmatics_transcribe::transcription"
#define TRANSCRIBE_EVENT_TRANSLATION "speechmatics_transcribe::translation"
#define TRANSCRIBE_EVENT_RECOGNITION_STARTED "speechmatics_transcribe::recognition_started"
#define TRANSCRIBE_EVENT_INFO "speechmatics_transcribe::info"
#define TRANSCRIBE_EVENT_ERROR "speechmatics_transcribe::error"
#define TRANSCRIBE_EVENT_NO_AUDIO_DETECTED "speechmatics_transcribe::no_audio_detected"
#define TRANSCRIBE_EVENT_VAD_DETECTED "speechmatics_transcribe::vad_detected"
#define TRANSCRIBE_EVENT_CONNECT_SUCCESS "speechmatics_transcribe::connect"
#define TRANSCRIBE_EVENT_CONNECT_FAIL    "speechmatics_transcribe::connect_failed"
#define TRANSCRIBE_EVENT_BUFFER_OVERRUN  "speechmatics_transcribe::buffer_overrun"
#define TRANSCRIBE_EVENT_DISCONNECT      "speechmatics_transcribe::disconnect"

#define MAX_LANG (12)
#define MAX_SESSION_ID (256)
#define MAX_WS_URL_LEN (512)
#define MAX_PATH_LEN (4096)
#define MAX_BUG_LEN (64)

typedef void (*responseHandler_t)(switch_core_session_t* session, const char* eventName, const char* json, const char* bugname, int finished);

typedef enum {
    SESSION_STATE_NONE = 0,
    SESSION_STATE_WS_CONNECTED,
    SESSION_STATE_CONVERSATION_STARTED
} SessionState_t;


struct private_data {
	switch_mutex_t *mutex;
	char sessionId[MAX_SESSION_ID];
  responseHandler_t responseHandler;
  SessionState_t state;
  void *pAudioPipe;
  int ws_state;
  char host[MAX_WS_URL_LEN];
  unsigned int port;
  char path[MAX_PATH_LEN];
  char bugname[MAX_BUG_LEN+1];
  char lang[MAX_LANG];
  int sampling;
  int  channels;
  unsigned int id;
  int buffer_overrun_notified:1;
  int is_finished:1;
  int interim:1;
};

typedef struct private_data private_t;

#endif