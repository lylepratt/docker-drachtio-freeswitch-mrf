# mod_ultravox_s2s

A Freeswitch module that integrates with Ultravox AI.

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_ultravox_s2s <uuid> session.create host path
```
where:
- host: URL host value for the websocket connection (e.g. prod-voice-pgaenaxiea-uc.a.run.app)
- path: URL path (e.g. /calls/b0eb187f-7ec8-48f7-ab90-12f493b95759)

This api call establishes a websocket connection to the Ultravox. Client events are sent using the `client_event` api described below.

```
uuid_ultravox_s2s <uuid> client.event client-event-json
```
where
- client-event-json: a json string conforming to the [syntax described here](https://docs.ultravox.ai/datamessages).

```
uuid_ultravox_s2s <uuid> session.delete
```
Ends the session.

### Events
This module fires the following events:
- ultravox_s2s::connect - fired when the websocket connection is established
- ultravox_s2s::connect_failed - fired if the websocket connection fails
- ultravox_s2s:server_event - fired when a server event is received from openai

