#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <atomic>
#include <cstring>

#include <boost/algorithm/string/replace.hpp>

#include "mod_ultravox_s2s.h"
#include "jambonz/simple_json_parser.hpp"
#include "jambonz/vector_math.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/
#define BUFFER_GROW_SIZE (16384)

namespace {
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static const char *requestedNumServiceThreads = std::getenv("MOD_AUDIO_FORK_SERVICE_THREADS");
  static unsigned int idxCallCount = 0;
  static uint32_t playCount = 0;


  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      if (tech_pvt->resampler_in) {
          speex_resampler_destroy(tech_pvt->resampler_in);
          tech_pvt->resampler_in = nullptr;
      }
      if (tech_pvt->audioPlayer) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "destroying audio player\n");
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        delete p;
        tech_pvt->audioPlayer = nullptr;
      }
      if (tech_pvt->playoutBuffer) {
        CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
        delete playoutBuffer;
        tech_pvt->playoutBuffer = nullptr;
      }
      if (tech_pvt->mutex) {
        switch_mutex_destroy(tech_pvt->mutex);
        tech_pvt->mutex = nullptr;
      }
    }
  }

  static void processIncomingAudio(private_t* tech_pvt, switch_core_session_t* session, const char* data, size_t len) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "received %u bytes incoming audio\n", len);
    p->bufferAudio(data, len);
  }

  static void handleInterruption(private_t* tech_pvt, switch_core_session_t* session) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    p->clear(false);
    // note: with openai_s2s we would now send a response.cancel message to the server
    // in order to cause it to cancel the request.
    // Ultravox says they will stop sending automatically when they detect the user has started speaking
  }

  static void eventCallback(const char* sessionId, const char* bugname, 
    ultravox_s2s::AudioPipe::NotifyEvent_t event, const char* message, const char* binary, size_t len) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case ultravox_s2s::AudioPipe::BINARY:
              processIncomingAudio(tech_pvt, session, binary, len);
            break;

            case ultravox_s2s::AudioPipe::CONNECT_SUCCESS:
              tech_pvt->state = SESSION_STATE_WS_CONNECTED;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) successful\n", tech_pvt->bugname);
              tech_pvt->responseHandler(session, US2S_EVENT_CONNECT_SUCCESS, NULL, tech_pvt->bugname);
            break;
            case ultravox_s2s::AudioPipe::CONNECT_FAIL:
              tech_pvt->state = SESSION_STATE_NONE;
              {
                // first thing: we can no longer access the AudioPipe
                std::stringstream json;
                json << "{\"reason\":\"" << message << "\"}";
                tech_pvt->pAudioPipe = nullptr;
                tech_pvt->responseHandler(session, US2S_EVENT_CONNECT_FAIL, (char *) json.str().c_str(), tech_pvt->bugname);
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
              }
            break;
            case ultravox_s2s::AudioPipe::CONNECTION_DROPPED:
              tech_pvt->state = SESSION_STATE_NONE;

              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, US2S_EVENT_DISCONNECT, NULL, tech_pvt->bugname);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) dropped from far end\n", tech_pvt->bugname);
            break;
            case ultravox_s2s::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              tech_pvt->state = SESSION_STATE_NONE;

              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
            break;
            case ultravox_s2s::AudioPipe::MESSAGE:
            {
              cJSON* json = parse_json_string(session, message) ;
              if (!json) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "failed to parse json for message %s\n", message);
              }
              else {
                bool forward = true;
                const char* type = cJSON_GetObjectCstr(json, "type");

                // when the conversation starts, we can start streaming audio to the server
                if (0 == strcmp(type, "state")) {
                  cJSON *message_obj = cJSON_GetObjectItem(json, "state");
                  if (0 == strcmp(message_obj->valuestring, "listening")) {
                    tech_pvt->state = SESSION_STATE_CONVERSATION_STARTED;
                    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "conversation started\n");
                  }
                }
                else if (0 == strcmp(type, "playback_clear_buffer")) {
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "playback_clear_buffer received, clear audio\n");
                  if (tech_pvt->initial_assistant_response_completed) {
                    handleInterruption(tech_pvt, session);
                  }
                }

                if (forward) {
                  //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "ultravox server event (%s): %s\n", tech_pvt->bugname, message);
                  tech_pvt->responseHandler(session, US2S_EVENT_SERVER, message, tech_pvt->bugname);
                }

                cJSON_Delete(json);
              }
            }
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from voice agent %d:%s\n", event, message);
              break;
          }
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event callback sessionId %s bugname %s not found for message %s\n", sessionId, bugname, message);
      }
      switch_core_session_rwunlock(session);
    }
    else {
    }
  }
  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, int sampling, 
    const char* host, const char *path, responseHandler_t responseHandler) {
    int err;
    int channels = 1;
    std::string fullPath = path;
    int desiredSampling = 8000;
    switch_codec_t* read_codec = switch_core_session_get_read_codec(session);
    int port = 443;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * read_codec->implementation->samples_per_second / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_codec_implementation_t read_impl;
    switch_channel_t *channel = switch_core_session_get_channel(session);

    switch_core_session_get_read_impl(session, &read_impl);
  
    ultravox_s2s::AudioPipe* ap = new ultravox_s2s::AudioPipe(tech_pvt->sessionId, tech_pvt->bugname, host, port, path, 
      buflen, read_impl.decoded_bytes_per_packet, nullptr, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }

    tech_pvt->pAudioPipe = static_cast<void *>(ap);

    auto playoutBuffer = new CircularBuffer(64000);
    auto audioPlayer = new AudioPlayer(tech_pvt->mutex, playoutBuffer);
    audioPlayer->setResampling(desiredSampling, sampling);
    tech_pvt->audioPlayer = (void *) audioPlayer;
    tech_pvt->playoutBuffer = (void *) playoutBuffer;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now\n");
    ap->connect();
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");
    
    if (desiredSampling != sampling) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) resampling user audio from %u to %u\n", tech_pvt->id, sampling, desiredSampling);
      tech_pvt->resampler_in = speex_resampler_init(1, sampling, desiredSampling, SWITCH_RESAMPLE_QUALITY, &err);
      if (0 != err) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing resampler: %s.\n", speex_resampler_strerror(err));
        return SWITCH_STATUS_FALSE;
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) no resampling needed for this call\n", tech_pvt->id);
    }

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) fork_data_init\n", tech_pvt->id);

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {

  switch_status_t ultravox_s2s_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_ultravox_s2s: audio buffer (in secs): %d secs\n", nAudioBufferSecs);
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    ultravox_s2s::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t ultravox_s2s_cleanup() {
    bool cleanup = false;
    cleanup = ultravox_s2s::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }
	
  switch_status_t ultravox_s2s_session_create(switch_core_session_t *session, responseHandler_t responseHandler, 
		uint32_t samples_per_second, const char* bugname, 
    const char* host, const char *path, void **ppUserData)
  {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    private_t* tech_pvt;

    if (bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "ultravox_s2s_session_create failed because connection already in progress\n");
      return SWITCH_STATUS_FALSE;
    }
    
    tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }
    memset(tech_pvt, 0, sizeof(private_t));
    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));

    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->id = ++idxCallCount;
    tech_pvt->sampling = samples_per_second;

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second, 
      host, path, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t ultravox_s2s_send_client_event(switch_core_session_t *session, const char* bugname, cJSON* json) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "ultravox_s2s_send_client_event failed because no bug\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
  
    if (!tech_pvt) return SWITCH_STATUS_FALSE;
    ultravox_s2s::AudioPipe *pAudioPipe = static_cast<ultravox_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
    if (pAudioPipe) {
      char *json_string = nullptr;

      /* special case: when sending function_call_output the item.result needs to be jsonified string */
      const char* type = cJSON_GetObjectCstr(json, "type");
      if (!type) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "ultravox_s2s_send_client_event must have 'type' property\n");
        return SWITCH_STATUS_FALSE;
      }

      if (type && 0 == strcmp(type, "client_tool_result")) {
        // Now check if result is an object
        cJSON* output = cJSON_GetObjectItem(json, "result");
        if (output && cJSON_IsObject(output)) {
          char* outputStr = cJSON_PrintUnformatted(output);
          if (!outputStr) {
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "ultravox_s2s_session_update failed to serialize json\n");
            return SWITCH_STATUS_FALSE;
          }

          // Replace the "output" item with the stringified version of the object
          cJSON_ReplaceItemInObject(json, "result", cJSON_CreateString(outputStr));

          // Free the memory for the generated JSON string
          free(outputStr);
        }
      }

      if (nullptr == json_string) {
        json_string = cJSON_PrintUnformatted(json);
      }

      if (!json_string) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "ultravox_s2s_send_client_event failed to serialize json\n");
        return SWITCH_STATUS_FALSE;
      }
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "ultravox_s2s_send_client_event sending: %s\n", json_string);
      pAudioPipe->bufferForSending(json_string);
      free(json_string);
    }

    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t ultravox_s2s_session_delete(switch_core_session_t *session, const char* bugname, int channelIsClosing) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "ultravox_s2s_session_delete: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    if (!tech_pvt) return SWITCH_STATUS_FALSE;

    uint32_t id = tech_pvt->id;

    ultravox_s2s::AudioPipe *pAudioPipe = static_cast<ultravox_s2s::AudioPipe *>(tech_pvt->pAudioPipe);

    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);

    // get the bug again, now that we are under lock
    {
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        switch_channel_set_private(channel, bugname, NULL);
        if (!channelIsClosing) {
          switch_core_media_bug_remove(session, &bug);
        }
      }
    }

    if (pAudioPipe) pAudioPipe->close();
    destroy_tech_pvt(tech_pvt);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) ultravox_s2s_session_delete complete\n", id);
    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_bool_t ultravox_s2s_write_frame(switch_media_bug_t *bug, void* user_data) {
    switch_status_t status = SWITCH_STATUS_SUCCESS;
    private_t* tech_pvt = (private_t*) user_data;

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;

      if (playoutBuffer->size() > 0) {
        switch_frame_t* rframe = switch_core_media_bug_get_write_replace_frame(bug);
        int16_t *fp = reinterpret_cast<int16_t*>(rframe->data);

        rframe->channels = 1;
        rframe->datalen = rframe->samples * sizeof(int16_t);

        int16_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        memset(data, 0, sizeof(data));
        
        int samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(rframe->samples));
        auto count = playoutBuffer->getBlock(data, samplesToCopy);
        if (count != samplesToCopy) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "el_dub_speech_frame - failed to get %d samples from playout buffer, got %d\n", samplesToCopy, count);
        }
        else {
          vector_add(fp, data, rframe->samples);
          vector_normalize(fp, rframe->samples);
          switch_core_media_bug_set_write_replace_frame(bug, rframe);
        }

        // notify when assistant starts speaking
        if (tech_pvt->assistant_started_speaking) {
          tech_pvt->assistant_started_speaking = 0;
        }

        // notify when assistant stops speaking
        if (playoutBuffer->size() == 0) {
          if (!tech_pvt->initial_assistant_response_completed) {
            tech_pvt->initial_assistant_response_completed = 1;
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "(%u) initial assistant greeting finished\n", tech_pvt->id);
          }
        }
      }
      switch_mutex_unlock(tech_pvt->mutex);
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "ultravox_s2s_write_frame failed to lock mutex\n");
    }

    return SWITCH_TRUE;
  }

	switch_bool_t ultravox_s2s_read_frame(switch_core_session_t *session, switch_media_bug_t *bug, void* user_data) {
    private_t* tech_pvt = (private_t*) user_data;
    size_t inuse = 0;
    bool dirty = false;
    char *p = (char *) "{\"msg\": \"buffer overrun\"}";

    if (!tech_pvt) return SWITCH_TRUE;

    /* dont send audio until initial response.created is received */
    if (tech_pvt->state != SESSION_STATE_CONVERSATION_STARTED) {
      //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, conversation not started\n");
      return SWITCH_TRUE;
    }

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      if (!tech_pvt->pAudioPipe) {
        switch_mutex_unlock(tech_pvt->mutex);
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, no tech_pvt\n");
        return SWITCH_TRUE;
      }
      ultravox_s2s::AudioPipe *pAudioPipe = static_cast<ultravox_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
      if (pAudioPipe->getLwsState() != ultravox_s2s::AudioPipe::LWS_CLIENT_CONNECTED) {
        switch_mutex_unlock(tech_pvt->mutex);
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, LWS client not connected\n");
        return SWITCH_TRUE;
      }
      pAudioPipe->lockAudioBuffer();
      size_t available = pAudioPipe->binarySpaceAvailable();
      if (NULL == tech_pvt->resampler_in) {
        switch_frame_t frame = { 0 };
        frame.data = pAudioPipe->binaryWritePtr();
        frame.buflen = available;
         while (true) {
          // check if buffer would be overwritten; dump packets if so
          if (available < pAudioPipe->binaryMinSpace()) {
            if (!tech_pvt->buffer_overrun_notified) {
              tech_pvt->buffer_overrun_notified = 1;
              tech_pvt->responseHandler(session, US2S_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname);
            }
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n", 
              tech_pvt->id);
            pAudioPipe->binaryWritePtrResetToZero();

            frame.data = pAudioPipe->binaryWritePtr();
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          }

          switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
          if (rv != SWITCH_STATUS_SUCCESS) break;
          if (frame.datalen) {
            pAudioPipe->binaryWritePtrAdd(frame.datalen);
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
            frame.data = pAudioPipe->binaryWritePtr();
            dirty = true;
          }
         }

      } else {
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = { 0 };
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;
        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
          if (frame.datalen) {
            spx_uint32_t out_len = available >> 1;  // space for samples which are 2 bytes
            spx_uint32_t in_len = frame.samples;

            speex_resampler_process_int(tech_pvt->resampler_in, 0,
              (const spx_int16_t *) frame.data, 
              (spx_uint32_t *) &in_len, 
              (spx_int16_t *) ((char *) pAudioPipe->binaryWritePtr()),
              &out_len);

            if (out_len > 0) {
              size_t bytes_written = out_len << 1;
              pAudioPipe->binaryWritePtrAdd(bytes_written);
              available = pAudioPipe->binarySpaceAvailable();
              dirty = true;
            }
            if (available < pAudioPipe->binaryMinSpace()) {
              if (!tech_pvt->buffer_overrun_notified) {
                tech_pvt->buffer_overrun_notified = 1;
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "(%u) dropping packets!\n", 
                  tech_pvt->id);
                tech_pvt->responseHandler(session, US2S_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname);
              }
              break;
            }
          }
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}
