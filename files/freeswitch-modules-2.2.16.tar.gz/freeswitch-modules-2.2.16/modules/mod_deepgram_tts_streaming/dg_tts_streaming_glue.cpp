#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>
#include <iomanip>
#include <cstring>
#include <cctype>


#include "mod_deepgram_tts_streaming.h"

#include "jambonz/simple_json_parser.hpp"
#include "jambonz/vector_math.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"


#include "audio_pipe.hpp"


namespace {
  static bool hasDefaultCredentials = false;
  static const char* defaultApiKey = nullptr;
  static const char *requestedNumServiceThreads = std::getenv("MOD_AUDIO_FORK_SERVICE_THREADS");

  std::string escapeJson(const char *text) {
      std::ostringstream escaped;
      while (*text) {
          switch (*text) {
              case '\"': escaped << "\\\""; break;
              case '\\': escaped << "\\\\"; break;
              case '\b': escaped << "\\b"; break;
              case '\f': escaped << "\\f"; break;
              case '\n': escaped << "\\n"; break;
              case '\r': escaped << "\\r"; break;
              case '\t': escaped << "\\t"; break;
              default:
                  if (static_cast<unsigned char>(*text) < 0x20) {
                      escaped << "\\u" << std::hex << std::setw(4) << std::setfill('0')
                              << static_cast<int>(*text);
                  } else {
                      escaped << *text;
                  }
          }
          ++text;
      }
      return escaped.str();
  }

  std::string createSpeakPayload(const char *text) {
      std::ostringstream oss;
      oss << "{\"type\": \"Speak\", \"text\":\"" << escapeJson(text) << "\"}";
      return oss.str();
  }

  std::string createClearPayload() {
      std::ostringstream oss;
      oss << "{\"type\": \"Clear\"}";
      return oss.str();
  }

  void sendTokens(dg_tts::AudioPipe* ap, const char* input) {
    ap->bufferForSending(createSpeakPayload(input).c_str());
  }

  void sendClear(dg_tts::AudioPipe* ap) {
    ap->bufferForSending(createClearPayload().c_str());
  }


  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s destroy_tech_pvt\n", tech_pvt->sessionId);
    if (tech_pvt) {
      tech_pvt->pAudioPipe = nullptr;
      if (tech_pvt->bufferedTokens) {
        free(tech_pvt->bufferedTokens);
        tech_pvt->bufferedTokens = nullptr;
      }

      if (tech_pvt->audioPlayer) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "destroying audio player\n");
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        delete p;
        tech_pvt->audioPlayer = nullptr;
      }

      if (tech_pvt->playoutBuffer) {
        CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
        delete playoutBuffer;
        tech_pvt->playoutBuffer = nullptr;
      }

      // NB: do not destroy the mutex here, that is caller responsibility
    }
  }

  std::string constructPath(switch_core_session_t* session, std::string& path, 
    int sampleRate) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    const char *var ;
    std::ostringstream oss;

    oss << "/v1/speak?";

    // voice
    const char *model = switch_channel_get_variable(channel, "DEEPGRAM_TTS_STREAMING_MODEL");
    oss << "model=" << model;

    // encoding
    oss << "&encoding=linear16";

    // sample rate
    oss << "&sample_rate=" << sampleRate;

    oss << "&container=none";

   path = oss.str();
   return path;
  }

  switch_status_t processIncomingBinary(private_t* tech_pvt, switch_core_session_t* session, const char* message, size_t dataLength) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    p->bufferAudio(message, dataLength);
   return SWITCH_STATUS_SUCCESS;
  }

  static void eventCallback(const char* sessionId, dg_tts::AudioPipe::NotifyEvent_t event, const char* message, const char* binary, size_t len) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, MY_BUG_NAME);

      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case dg_tts::AudioPipe::BINARY:
              processIncomingBinary(tech_pvt, session, binary, len);
            break;

            case dg_tts::AudioPipe::CONNECT_SUCCESS:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) successful\n", tech_pvt->bugname);

              tech_pvt->active = true;
              if (tech_pvt->bufferedTokens) {
                dg_tts::AudioPipe *pAudioPipe = static_cast<dg_tts::AudioPipe *>(tech_pvt->pAudioPipe);
                sendTokens(pAudioPipe, tech_pvt->bufferedTokens);
                free(tech_pvt->bufferedTokens);
                tech_pvt->bufferedTokens = nullptr;
              }
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_CONNECT_SUCCESS, NULL);
            break;
            case dg_tts::AudioPipe::CONNECT_FAIL:
            {
              // first thing: we can no longer access the AudioPipe
              if (tech_pvt->bufferedTokens) {
                free(tech_pvt->bufferedTokens);
                tech_pvt->bufferedTokens = nullptr;
              }
              std::stringstream json;
              json << "{\"reason\":\"" << message << "\"}";
              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_CONNECT_FAIL, (char *) json.str().c_str());
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
            }
            break;
            case dg_tts::AudioPipe::CONNECTION_DROPPED:
              // first thing: we can no longer access the AudioPipe

              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_DISCONNECT, NULL);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) dropped from far end\n", tech_pvt->bugname);
            break;
            case dg_tts::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
            break;
            case dg_tts::AudioPipe::MESSAGE:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got message from deepgram %s\n", message);
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from deepgram %d:%s\n", event, message);
              break;
          }
        }
      }
      switch_core_session_rwunlock(session);
    }
  }
  switch_status_t make_streaming_connection(switch_core_session_t *session, private_t *tech_pvt) {
    int err;
    int useTls = true;
    std::string host;
    int port = 443;
		auto read_codec = switch_core_session_get_read_codec(session);
    std::string path;
    switch_channel_t *channel = switch_core_session_get_channel(session);

    tech_pvt->sampleRate = read_codec->implementation->actual_samples_per_second;

    constructPath(session, path, tech_pvt->sampleRate);
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "path: %s\n", path.c_str());

    const char* endpoint = switch_channel_get_variable(channel, "DEEPGRAM_URI");
    if (endpoint != nullptr) {
      std::string ep(endpoint);
      useTls = switch_true(switch_channel_get_variable(channel, "DEEPGRAM_USE_TLS"));

      size_t pos = ep.find(':');
      host = ep;
      if (pos != std::string::npos) {
        host = ep.substr(0, pos);
        std::string strPort = ep.substr(pos + 1);
        port = ::atoi(strPort.c_str());
      }
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, 
        "connecting to deepgram on-prem %s port %d, using tls? (%s)\n", host.c_str(), port, useTls ? "yes" : "no");
    } else {
      host = "api.deepgram.com";
    }

    const char* apiKey = switch_channel_get_variable(channel, "DEEPGRAM_API_KEY");
    if (!apiKey && defaultApiKey) {
      apiKey = defaultApiKey;
    } else if (!apiKey && endpoint == nullptr) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_WARNING, "no deepgram api key provided\n");
      return SWITCH_STATUS_FALSE;
    }

    strncpy(tech_pvt->host, host.c_str(), MAX_WS_URL_LEN);
    tech_pvt->port = port;
    strncpy(tech_pvt->path, path.c_str(), MAX_PATH_LEN);   
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);

    dg_tts::AudioPipe* ap = new dg_tts::AudioPipe(tech_pvt->sessionId, tech_pvt->host, tech_pvt->port, tech_pvt->path, 
      apiKey, useTls, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }
    tech_pvt->pAudioPipe = static_cast<void *>(ap);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now\n");
    ap->connect();
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {
  switch_status_t dg_tts_streaming_init() {
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE
    | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    dg_tts::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		const char* apiKey = std::getenv("DEEPGRAM_API_KEY");
		if (NULL == apiKey) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, 
				"\"DEEPGRAM_API_KEY\" env var not set; authentication will expect channel variables of same names to be set\n");
		}
		else {
			hasDefaultCredentials = true;
      defaultApiKey = apiKey;
		}
		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t dg_tts_streaming_cleanup() {
    bool cleanup = false;
    cleanup = dg_tts::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }

  switch_status_t dg_tts_streaming_session_init(switch_core_session_t *session, responseHandler_t responseHandler, void **ppUserData) {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    private_t* tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    switch_codec_t* read_codec = switch_core_session_get_read_codec(session);

    /* validate that we have a deepgram model (i.e. voice) to use */
    const char *model = switch_channel_get_variable(channel, "DEEPGRAM_TTS_STREAMING_MODEL");
    if (NULL == model) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_WARNING, "no deepgram model specified, must set DEEPGRAM_TTS_STREAMING_MODEL\n");
      return SWITCH_STATUS_FALSE;
    }

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }

    memset(tech_pvt, 0, sizeof(private_t));
    tech_pvt->pAudioPipe = NULL;
    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
    tech_pvt->responseHandler = responseHandler;
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);

    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(tech_pvt->mutex, playoutBuffer);

    tech_pvt->audioPlayer = (void *) audioPlayer;
    tech_pvt->playoutBuffer = (void *) playoutBuffer;
    tech_pvt->active = false;
    tech_pvt->bufferedTokens = NULL;

    *ppUserData = tech_pvt;

    /* need to create the websocket connection for this session since we don't have one */
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "establish websocket for session tts streaming\n");

    if (SWITCH_STATUS_SUCCESS != make_streaming_connection(session, tech_pvt)) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing dg streaming connection.\n");
      return SWITCH_STATUS_FALSE;
    }

    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_status_t dg_tts_streaming_session_send_tokens(switch_core_session_t *session, switch_media_bug_t *bug, char* tokens)
  {
    int err;
    switch_status_t status = SWITCH_STATUS_FALSE;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no tech_pvt for session\n");
      return SWITCH_STATUS_FALSE;
    }
    tech_pvt->active = true;

    /* do we have a ws connection to deepgram? */
    if (tech_pvt->pAudioPipe) {
      dg_tts::AudioPipe *pAudioPipe = static_cast<dg_tts::AudioPipe *>(tech_pvt->pAudioPipe);

      if (pAudioPipe->getLwsState() == dg_tts::AudioPipe::LWS_CLIENT_CONNECTED) {
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        if (p && p->isCleared()) p->open();

        sendTokens(pAudioPipe, tokens);
        return SWITCH_STATUS_SUCCESS;
      }
      else if (pAudioPipe->getLwsState() == dg_tts::AudioPipe::LWS_CLIENT_CONNECTING ||
        pAudioPipe->getLwsState() == dg_tts::AudioPipe::LWS_CLIENT_IDLE) {
        size_t currentLength = tech_pvt->bufferedTokens ? strlen(tech_pvt->bufferedTokens) : 0;
        size_t additionalLength = strlen(tokens);
        size_t newSize = currentLength + additionalLength + 1;
        char* newBuffer = (char*)realloc(tech_pvt->bufferedTokens, newSize);
        if (nullptr == newBuffer) {
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error reallocating memory for buffered tokens\n");
          free(tech_pvt->bufferedTokens); 
          tech_pvt->bufferedTokens = nullptr;
          return SWITCH_STATUS_FALSE;
        }
        strcat(newBuffer, tokens);
        tech_pvt->bufferedTokens = newBuffer;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "added additional tokens while connecting, now have %d chars\n", newSize);
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "cannot send tokens as websocket state is %d\n", pAudioPipe->getLwsState());
        return SWITCH_STATUS_FALSE;
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no websocket connection to deepgram\n");
      return SWITCH_STATUS_FALSE;
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t dg_tts_streaming_session_flush(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_tts_streaming_session_flush\n");
    if (tech_pvt) {
      dg_tts::AudioPipe *pAudioPipe = static_cast<dg_tts::AudioPipe *>(tech_pvt->pAudioPipe);
      if (pAudioPipe) pAudioPipe->flush();
    }
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t dg_tts_streaming_session_clear(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_tts_streaming_session_clear\n");
    if (tech_pvt) {
      switch_mutex_lock(tech_pvt->mutex);
      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
      AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
      dg_tts::AudioPipe *pAudioPipe = static_cast<dg_tts::AudioPipe *>(tech_pvt->pAudioPipe);
      sendClear(pAudioPipe);
      if (p) p->clear();
      tech_pvt->active = false;
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t dg_tts_streaming_session_stop(switch_core_session_t *session,int channelIsClosing, switch_media_bug_t* bug) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_transcribe_session_stop: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_transcribe_session_stop\n");

    if (!tech_pvt) return SWITCH_STATUS_FALSE;
      
    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);
    switch_channel_set_private(channel, MY_BUG_NAME, NULL);
    if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

    dg_tts::AudioPipe *pAudioPipe = static_cast<dg_tts::AudioPipe *>(tech_pvt->pAudioPipe);
    if (pAudioPipe) pAudioPipe->close();

    CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;

    if (playoutBuffer != nullptr) {
      playoutBuffer->clear();
    }
    destroy_tech_pvt(tech_pvt);
    
    switch_mutex_unlock(tech_pvt->mutex);
    switch_mutex_destroy(tech_pvt->mutex);
    tech_pvt->mutex = nullptr;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_transcribe_session_stop\n");
    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_bool_t dg_dub_speech_frame(switch_media_bug_t *bug, private_t* tech_pvt) {
    int samplesToCopy = 0;

    if (nullptr == tech_pvt->playoutBuffer || !tech_pvt->active) {
      return SWITCH_TRUE;
    }

    switch_frame_t* rframe = switch_core_media_bug_get_write_replace_frame(bug);
    int16_t *fp = reinterpret_cast<int16_t*>(rframe->data);

    rframe->channels = 1;
    rframe->datalen = rframe->samples * sizeof(int16_t);

    int16_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
    memset(data, 0, sizeof(data));

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;

      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(rframe->samples));

      if (samplesToCopy > 0) {
        auto count = playoutBuffer->getBlock(data, samplesToCopy);
        if (count != samplesToCopy) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "dg_dub_speech_frame - failed to get %d samples from playout buffer, got %d\n", samplesToCopy, count);
        }
        else {
          vector_add(fp, data, rframe->samples);
          vector_normalize(fp, rframe->samples);
          switch_core_media_bug_set_write_replace_frame(bug, rframe);
  
          if (samplesToCopy > 0 && playoutBuffer->size() == 0) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "dg_dub_speech_frame - playout buffer is empty\n");
            switch_core_session_t* session = switch_core_session_locate(tech_pvt->sessionId);
            if (session) {
              tech_pvt->responseHandler(session, TTS_STREAM_EVENT_EMPTY, NULL);
              switch_core_session_rwunlock(session);
            }
          }
        }
      }
      switch_mutex_unlock(tech_pvt->mutex);
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "dg_dub_speech_frame - failed to lock mutex\n");
    }
    return SWITCH_TRUE;
  }
}
