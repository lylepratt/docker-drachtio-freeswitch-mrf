#ifndef __DG_AUDIO_PIPE_HPP__
#define __DG_AUDIO_PIPE_HPP__

#include <string>
#include <list>
#include <mutex>
#include <future>
#include <queue>
#include <unordered_map>
#include <thread>

#include <libwebsockets.h>

namespace dg_tts {

  class AudioPipe {
  public:
    enum LwsState_t {
      LWS_CLIENT_IDLE,
      LWS_CLIENT_CONNECTING,
      LWS_CLIENT_CONNECTED,
      LWS_CLIENT_FAILED,
      LWS_CLIENT_DISCONNECTING,
      LWS_CLIENT_DISCONNECTED
    };
    enum NotifyEvent_t {
      CONNECT_SUCCESS,
      CONNECT_FAIL,
      CONNECTION_DROPPED,
      CONNECTION_CLOSED_GRACEFULLY,
      MESSAGE,
      BINARY
    };
    typedef void (*log_emit_function)(int level, const char *line);
    typedef void (*notifyHandler_t)(const char *sessionId, NotifyEvent_t event, const char* message, const char* binary, size_t binary_len );

    struct lws_per_vhost_data {
      struct lws_context *context;
      struct lws_vhost *vhost;
      const struct lws_protocols *protocol;
    };

    static void initialize(int loglevel, log_emit_function logger);
    static bool deinitialize();
    static bool lws_service_thread();

    // constructor
    AudioPipe(const char* uuid, const char* host, unsigned int port, const char* path, 
      const char* apiKey, int useTls, notifyHandler_t callback);
    ~AudioPipe();  

    LwsState_t getLwsState(void) { return m_state; }
    std::string& getApiKey(void) {
      return m_apiKey;
    }
    void connect(void);
    void bufferForSending(const char* text);

    void close() ;
    void clear() ;
    void flush() ;

    // no default constructor or copying
    AudioPipe() = delete;
    AudioPipe(const AudioPipe&) = delete;
    void operator=(const AudioPipe&) = delete;

  private:
    static std::thread serviceThread;

    static int lws_callback(struct lws *wsi, enum lws_callback_reasons reason, void *user, void *in, size_t len); 
    static struct lws_context *context;
    static std::mutex mutex_connects;
    static std::mutex mutex_disconnects;
    static std::mutex mutex_writes;
    static std::list<AudioPipe*> pendingConnects;
    static std::list<AudioPipe*> pendingDisconnects;
    static std::list<AudioPipe*> pendingWrites;
    static log_emit_function logger;

    static std::mutex mapMutex;
    static bool stopFlag;

    static AudioPipe* findAndRemovePendingConnect(struct lws *wsi);
    static AudioPipe* findPendingConnect(struct lws *wsi);
    static void addPendingConnect(AudioPipe* ap);
    static void addPendingDisconnect(AudioPipe* ap);
    static void addPendingWrite(AudioPipe* ap);
    static void processPendingConnects(lws_per_vhost_data *vhd);
    static void processPendingDisconnects(lws_per_vhost_data *vhd);
    static void processPendingWrites(void);
    
    bool connect_client(struct lws_per_vhost_data *vhd);

    LwsState_t m_state;
    std::string m_uuid;
    std::string m_host;
    unsigned int m_port;
    std::string m_path;
    std::list<std::string> m_metadata_list;
    std::mutex m_text_mutex;
    int m_sslFlags;
    struct lws *m_wsi;
    uint8_t* m_recv_buf;
    uint8_t* m_recv_buf_ptr;
    size_t m_recv_buf_len;
    struct lws_per_vhost_data* m_vhd;
    notifyHandler_t m_callback;
    log_emit_function m_logger;
    std::string m_apiKey;
    bool m_useTls;
  };

} // namespace deepgram
#endif
