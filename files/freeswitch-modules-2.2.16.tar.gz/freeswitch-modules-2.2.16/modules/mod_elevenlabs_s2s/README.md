# mod_elevenlabs_s2s

The `mod_elevenlabs_s2s` module for FreeSWITCH integrates with the ElevenLabs real-time speech-to-speech service.

## API Documentation

### Commands
The FreeSWITCH module exposes the following API commands:

#### Create a Session
```
uuid_elevenlabs_s2s <uuid> session.create <input_sample_rate> <output_sample_rate> <host> <path> <json>
```
**Parameters:**
- `uuid` – The unique identifier for the session.
- `input_sample_rate` – The sample rate configured for the ElevenLabs agent input.
- `output_sample_rate` – The sample rate configured for the ElevenLabs agent output.
- `host` – The host to connect to ElevenLabs.
- `path` – The path to use when connecting to ElevenLabs.
- `json` (optional) – A JSON string containing additional configuration settings.

This command establishes a WebSocket connection to the ElevenLabs real-time service. Client events can be sent using the `client_event` API described below.

#### Send a Client Event
```
uuid_elevenlabs_s2s <uuid> client.event <client_event_json>
```
**Parameters:**
- `uuid` – The unique identifier for the session.
- `client_event_json` – A JSON string that follows the [ElevenLabs WebSocket API syntax](https://elevenlabs.io/docs/conversational-ai/api-reference/conversational-ai/websocket).

#### End a Session
```
uuid_elevenlabs_s2s <uuid> session.delete
```
This command terminates the active session and closes the WebSocket connection.

### Events
The module generates the following events:
- `elevenlabs_s2s::connect` – Triggered when the WebSocket connection is successfully established.
- `elevenlabs_s2s::connect_failed` – Triggered if the WebSocket connection fails.
- `elevenlabs_s2s::server_event` – Triggered when a server event is received from ElevenLabs.

### Tool Calls
The module follows the [Client Tools](https://elevenlabs.io/docs/conversational-ai/customization/tools/client-tools) specification. When the application receives a `client_tool_call` event, it must respond with `client_tool_result` accordingly.

---
This documentation provides an overview of how to use `mod_elevenlabs_s2s` to interact with ElevenLabs' real-time speech-to-speech services within FreeSWITCH.

