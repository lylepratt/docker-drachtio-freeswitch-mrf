#include "jambonz/audio_player.hpp"
#include "jambonz/base64.hpp"

#define BUFFER_GROW_SIZE (80000)

AudioPlayer::AudioPlayer(switch_mutex_t* mutex, CircularBuffer* playout_buffer, const char* sessionId) :
  session_mutex(mutex), std_mutex_ref(nullptr), playout_buffer(playout_buffer), resampler(nullptr),
  done(false), cleared(false), sample_rate_in(0), sample_rate_out(0), base64_encoding(false),
  audio_logging_enabled(false), cache_file(nullptr) {
  if (sessionId) {
    strncpy(session_id, sessionId, sizeof(session_id) - 1);
    session_id[sizeof(session_id) - 1] = '\0';
  } else {
    session_id[0] = '\0';
  }
  // Start the consumer thread when the object is created
  consumer_thread = std::thread(&AudioPlayer::consumeAudio, this);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::AudioPlayer (%s) created with switch_mutex_t\n", session_id);
}

AudioPlayer::AudioPlayer(std::mutex& mutex, CircularBuffer* playout_buffer, const char* sessionId) :
  session_mutex(nullptr), std_mutex_ref(&mutex), playout_buffer(playout_buffer), resampler(nullptr),
  done(false), cleared(false), sample_rate_in(0), sample_rate_out(0), base64_encoding(false),
  audio_logging_enabled(false), cache_file(nullptr) {
  if (sessionId) {
    strncpy(session_id, sessionId, sizeof(session_id) - 1);
    session_id[sizeof(session_id) - 1] = '\0';
  } else {
    session_id[0] = '\0';
  }
  // Start the consumer thread when the object is created
  consumer_thread = std::thread(&AudioPlayer::consumeAudio, this);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::AudioPlayer (%s) created with std::mutex\n", session_id);
}

AudioPlayer::~AudioPlayer() {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::~AudioPlayer (%s) joining thread\n", session_id);
  finish();  // Ensure the consumer thread finishes before the object is destroyed
  consumer_thread.join();

  // Close cache file if it was set (after consumer thread has finished writing)
  if (cache_file) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::~AudioPlayer (%s) closing cache file\n", session_id);
    if (fclose(cache_file) != 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPlayer::~AudioPlayer (%s) error closing cache file: %s\n", session_id, strerror(errno));
    } else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::~AudioPlayer (%s) successfully closed cache file\n", session_id);
    }
    cache_file = nullptr;
  }

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::~AudioPlayer (%s) joined thread\n", session_id);
}

void AudioPlayer::bufferAudio(const char* data, size_t length) {
  if (cleared) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::bufferAudio discarding audio\n");
    return;  // discard late-incoming audio after a clear
  }

  std::lock_guard<std::mutex> lock(buffer_mutex);
  buffer.insert(buffer.end(), data, data + length);

  // Notify the consumer that new data is available
  data_ready_cv.notify_one();
}

void AudioPlayer::lockPlayout() {
  if (session_mutex) {
    switch_mutex_lock(session_mutex);
  } else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::lockPlayout (%s) about to lock std::mutex\n", session_id);
    std_mutex_ref->lock();
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer::lockPlayout (%s) locked std::mutex\n", session_id);
  }
}

void AudioPlayer::unlockPlayout() {
  if (session_mutex) {
    switch_mutex_unlock(session_mutex);
  } else {
    std_mutex_ref->unlock();
  }
}

void AudioPlayer::clear(bool sticky) {
  if (sticky) cleared = true;
  {
    std::lock_guard<std::mutex> lock(buffer_mutex);
    buffer.clear();
  }
  {
    lockPlayout();
    playout_buffer->clear();
    unlockPlayout();
  }
}

void AudioPlayer::finish() {
  std::lock_guard<std::mutex> lock(buffer_mutex);
  done = true;
  data_ready_cv.notify_one();  // Wake up the consumer to allow it to exit
}

void AudioPlayer::setResampling (int from, int to) {
  sample_rate_in = from;
  sample_rate_out = to;
  resampler = speex_resampler_init(1, sample_rate_in, sample_rate_out, SWITCH_RESAMPLE_QUALITY, NULL);
}

void AudioPlayer::enableAudioLogging(std::string& filepath) {
  if (audio_logging_enabled) return;

  audio_logging_filename = filepath;
  audio_logging_enabled = true;

  audio_file.open(audio_logging_filename, std::ios::binary | std::ios::app);

  if (audio_file.is_open()) {
    audio_logging_enabled = true;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "Opened file %s for raw audio logging.\n", filepath.c_str());
  } else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to open %s for writing.\n", filepath.c_str());
  }
}

void AudioPlayer::setCacheFilePath(const std::string& filepath) {
  if (cache_file) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "AudioPlayer: cache file already set, ignoring\n");
    return;
  }

  // Use ::open() with explicit permissions to ensure file is readable by other processes
  // Temporarily set umask to 0 to get exact permissions we want
  mode_t oldMask = umask(0);
  int fd = ::open(filepath.c_str(), O_WRONLY | O_CREAT | O_TRUNC,
                  S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
  umask(oldMask);

  if (fd == -1) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
      "AudioPlayer: failed to open cache file %s: %s\n", filepath.c_str(), strerror(errno));
    return;
  }

  cache_file = fdopen(fd, "wb");
  if (!cache_file) {
    ::close(fd);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
      "AudioPlayer: failed to fdopen cache file %s: %s\n", filepath.c_str(), strerror(errno));
  } else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
      "AudioPlayer: opened cache file %s with permissions 0666\n", filepath.c_str());
  }
}

void AudioPlayer::consumeAudio() {
  std::string decodedData; // Reusable buffer for decoded audio data

  while (true) {
    std::unique_lock<std::mutex> lock(buffer_mutex);

    // Wait until data is ready or the producer is done
    data_ready_cv.wait(lock, [this] { return !buffer.empty() || done; });

    if (!buffer.empty()) {
      // Move the buffer contents to local storage for processing
      std::vector<char> audioData(std::move(buffer));
      lock.unlock(); // Allow producer to continue buffering

      const char* rawDataPtr = audioData.data();
      size_t rawDataSize = audioData.size();

      // If base64 decoding is enabled, decode the audio data
      if (base64_encoding) {
        decodedData = drachtio::base64_decode(std::string(audioData.data(), audioData.size()));
        rawDataPtr = decodedData.data();
        rawDataSize = decodedData.size();
      }

      // Write raw data to log file if logging is enabled
      if (audio_logging_enabled && audio_file.is_open()) {
        audio_file.write(rawDataPtr, rawDataSize);
      }

      // Write raw data to cache file if caching is enabled
      // This writes the incoming audio BEFORE resampling (matches original behavior)
      if (cache_file) {
        size_t written = fwrite(rawDataPtr, sizeof(char), rawDataSize, cache_file);
        if (written != rawDataSize) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
            "AudioPlayer: cache file write failed, expected %zu bytes, wrote %zu\n", rawDataSize, written);
        }
      }

      // Resample or directly process the audio
      const spx_int16_t* input = reinterpret_cast<const spx_int16_t*>(rawDataPtr);
      size_t inSamples = rawDataSize / 2; // Assuming 2 bytes per sample
      size_t outSamples = resampler ? (inSamples * sample_rate_out) / sample_rate_in : inSamples;

      const spx_int16_t* outputPtr = input;
      std::vector<spx_int16_t> outputBuffer;

      // If resampling is enabled, process the audio data
      if (resampler) {
        outputBuffer.resize(outSamples);
        spx_uint32_t in_len = inSamples;
        spx_uint32_t out_len = outSamples;

        int res = speex_resampler_process_int(resampler, 0, input, &in_len, outputBuffer.data(), &out_len);

        if (res != RESAMPLER_ERR_SUCCESS) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Resampler error: %d\n", res);
          return;
        }

        outputPtr = outputBuffer.data();
        outSamples = out_len;
      }

      // Check if we're done before trying to acquire playout mutex
      if (done) {
        break;
      }

      // Push processed data into the playback buffer
      lockPlayout();

      if (!cleared) {
        uint32_t start, end, size, capacity;
        playout_buffer->getState(start, end, size, capacity);

        if (playout_buffer->capacity() - playout_buffer->size() < outSamples) {
          size_t newCapacity = playout_buffer->size() + std::max(outSamples, (size_t) BUFFER_GROW_SIZE);
          size_t actual = playout_buffer->set_capacity(newCapacity);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer increased capacity to 0x%08x (requested: 0x%08x)\n", actual, newCapacity);

          uint32_t start, end, size, capacity;
          playout_buffer->getState(start, end, size, capacity);
        }

        playout_buffer->add(outputPtr, outSamples);

        playout_buffer->getState(start, end, size, capacity);
      }

      auto playoutBufferSize = playout_buffer->size();

      unlockPlayout();

      //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "consumeAudio: processed %d audio bytes, now have %u samples\n", rawDataSize, playoutBufferSize);
    } else if (done) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AudioPlayer (%s) consume thread exiting\n", session_id);
      break;
    }
  }
}
