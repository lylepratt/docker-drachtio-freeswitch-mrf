#include "playht_wrapper.h"
#include "playht_glue.h"
#include <switch.h>
#include <switch_json.h>
#include <curl/curl.h>
#include <cstdlib>
#include <g711.h>
#include <mutex>

#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/bind/bind.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>
#include <boost/asio.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/algorithm/string.hpp>

#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

/* Global information, common to all connections */
typedef struct
{
  CURLM *multi;
  int still_running;
} GlobalInfo_t;
static GlobalInfo_t global;

/* Information associated with a specific easy handle */
typedef struct
{
  CURL *easy;
  std::shared_ptr<PlayHT> playht;
  char* body;
  struct curl_slist *hdr_list;
  GlobalInfo_t *global;
  char error[CURL_ERROR_SIZE];
  FILE* file;
  std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
  bool flushed;
} ConnInfo_t;


static std::map<curl_socket_t, boost::asio::ip::tcp::socket *> socket_map;
static boost::asio::io_service io_service;
static boost::asio::deadline_timer timer(io_service);
static std::string fullDirPath;
static std::thread worker_thread;
static std::mutex curl_mutex;

std::string secondsToMillisecondsString(double seconds) {
    // Convert to milliseconds
    double milliseconds = seconds * 1000.0;

    // Truncate to remove fractional part
    long milliseconds_long = static_cast<long>(milliseconds);

    // Convert to string
    return std::to_string(milliseconds_long);
}

static std::string getEnvVar(const std::string& varName) {
    const char* val = std::getenv(varName.c_str());
    return val ? std::string(val) : "";
}

static long getConnectionTimeout() {
    std::string connectTimeoutStr = getEnvVar("PLAYHT_TTS_CURL_CONNECT_TIMEOUT");

    if (connectTimeoutStr.empty()) {
        connectTimeoutStr = getEnvVar("TTS_CURL_CONNECT_TIMEOUT");
    }

    long connectTimeout = 20L;

    if (!connectTimeoutStr.empty()) {
        connectTimeout = std::stol(connectTimeoutStr);
    }

    return connectTimeout;
}

static CURL* createEasyHandle(void) {
  CURL* easy = curl_easy_init();
  if(!easy) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "curl_easy_init() failed!\n");
    return nullptr ;
  }  

  curl_easy_setopt(easy, CURLOPT_FOLLOWLOCATION, 1L);
  curl_easy_setopt(easy, CURLOPT_USERAGENT, "jambonz/0.8.5");

  // set connect timeout to 3 seconds and total timeout to 109 seconds
  curl_easy_setopt(easy, CURLOPT_CONNECTTIMEOUT_MS, 3000L);
  //For long text, PlayHT took more than 20 seconds to complete the download.
  curl_easy_setopt(easy, CURLOPT_TIMEOUT, getConnectionTimeout());

  return easy ;
}

static void cleanupConn(ConnInfo_t *conn) {
  auto p = conn->playht;
  playht_handle_t handle = playht_get_handle_from_shared_ptr(p);

  if( conn->hdr_list ) {
    curl_slist_free_all(conn->hdr_list);
    conn->hdr_list = nullptr ;
  }
  curl_easy_cleanup(conn->easy);

  if (p && handle) {
    SwitchMutexLock lock(playht_get_mutex_internal(handle));

    if (conn->file) {
      if (fclose(conn->file) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "cleanupConn: error closing audio cache file\n");
      }
      conn->file = nullptr ;
      playht_set_file(handle, nullptr);
    }
  }

  if (handle) {
    playht_set_connection(handle, nullptr);
    playht_set_draining(handle, 1);
  }

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cleanupConn: conn deleted\n");
  delete conn;
}

/* Check for completed transfers, and remove their easy handles */
void check_multi_info(GlobalInfo_t *g) {
  CURLMsg *msg;
  int msgs_left;
  ConnInfo_t *conn;
  CURL *easy;
  CURLcode res;
  
  while((msg = curl_multi_info_read(g->multi, &msgs_left))) {
    if(msg->msg == CURLMSG_DONE) {
      long response_code;
      double namelookup=0, connect=0, total=0 ;
      char *ct = NULL ;

      easy = msg->easy_handle;
      res = msg->data.result;
      curl_easy_getinfo(easy, CURLINFO_PRIVATE, &conn);
      curl_easy_getinfo(easy, CURLINFO_RESPONSE_CODE, &response_code);
      curl_easy_getinfo(easy, CURLINFO_CONTENT_TYPE, &ct);

      curl_easy_getinfo(easy, CURLINFO_NAMELOOKUP_TIME, &namelookup);
      curl_easy_getinfo(easy, CURLINFO_CONNECT_TIME, &connect);
      curl_easy_getinfo(easy, CURLINFO_TOTAL_TIME, &total);

      auto p = conn->playht;
      playht_handle_t handle = playht_get_handle_from_shared_ptr(p);
      if (handle) {
        playht_set_response_code(handle, response_code);
        if (ct) playht_set_content_type(handle, ct);

        std::string name_lookup_ms = secondsToMillisecondsString(namelookup);
        std::string connect_ms = secondsToMillisecondsString(connect);
        std::string final_response_time_ms = secondsToMillisecondsString(total);

        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
          "mod_playht_tts: response: %ld, content-type %s,"
          "dns(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
          "connect(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
          "total(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld\n",
          response_code, ct,
          (long)(namelookup), (long)(fmod(namelookup, 1.0) * 1000000),
          (long)(connect), (long)(fmod(connect, 1.0) * 1000000),
          (long)(total), (long)(fmod(total, 1.0) * 1000000));

        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "name lookup time: %s\n", name_lookup_ms.c_str());
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "connect time: %s\n", connect_ms.c_str());
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "final response time: %s\n", final_response_time_ms.c_str());

        playht_set_name_lookup_time_ms(handle, name_lookup_ms.c_str());
        playht_set_connect_time_ms(handle, connect_ms.c_str());
        playht_set_final_response_time_ms(handle, final_response_time_ms.c_str());
      }

      curl_multi_remove_handle(g->multi, easy);
      cleanupConn(conn);
    }
  }
}

int mcode_test(const char *where, CURLMcode code) {
  if(CURLM_OK != code) {
    const char *s;
    switch(code) {
    case CURLM_CALL_MULTI_PERFORM:
      s = "CURLM_CALL_MULTI_PERFORM";
      break;
    case CURLM_BAD_HANDLE:
      s = "CURLM_BAD_HANDLE";
      break;
    case CURLM_BAD_EASY_HANDLE:
      s = "CURLM_BAD_EASY_HANDLE";
      break;
    case CURLM_OUT_OF_MEMORY:
      s = "CURLM_OUT_OF_MEMORY";
      break;
    case CURLM_INTERNAL_ERROR:
      s = "CURLM_INTERNAL_ERROR";
      break;
    case CURLM_UNKNOWN_OPTION:
      s = "CURLM_UNKNOWN_OPTION";
      break;
    case CURLM_LAST:
      s = "CURLM_LAST";
      break;
    default:
      s = "CURLM_unknown";
      break;
    case CURLM_BAD_SOCKET:
      s = "CURLM_BAD_SOCKET";
      break;
    }
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mcode_test ERROR: %s returns %s:%d\n", where, s, code);

    return -1;
  }
  return 0 ;
}

static void remsock(int *f, GlobalInfo_t *g) {
  if(f) {
    free(f);
    f = NULL;
  }
}

/* Called by asio when there is an action on a socket */
static void event_cb(GlobalInfo_t *g, curl_socket_t s, int action, const boost::system::error_code & error, int *fdp) {
  int f = *fdp;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X has action %d\n", s, action) ; 

  // Socket already POOL REMOVED.
  if (f == CURL_POLL_REMOVE) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X removed\n", s); 
    remsock(fdp, g);
    return;
  }

  if(socket_map.find(s) == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb: socket  %#X already closed\n, s");
    return;
  }

  /* make sure the event matches what are wanted */
  if(f == action || f == CURL_POLL_INOUT) {
    if(error) {
      action = CURL_CSELECT_ERR;
    }
    
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, s, action, &g->still_running);

    mcode_test("event_cb: curl_multi_socket_action", rc);
    check_multi_info(g);

    if(g->still_running <= 0) {
      timer.cancel();
    }

    /* keep on watching.
      * the socket may have been closed and/or fdp may have been changed
      * in curl_multi_socket_action(), so check them both */
    if(!error && socket_map.find(s) != socket_map.end() &&
        (f == action || f == CURL_POLL_INOUT)) {
      boost::asio::ip::tcp::socket *tcp_socket = socket_map.find(s)->second;

      if(action == CURL_POLL_IN) {
        tcp_socket->async_read_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                                action, boost::placeholders::_1, fdp));
      }
      if(action == CURL_POLL_OUT) {
        tcp_socket->async_write_some(boost::asio::null_buffers(),
                                      boost::bind(&event_cb, g, s,
                                                  action, boost::placeholders::_1, fdp));
      } 
    }
  }
}

/* socket functions */
static void setsock(int *fdp, curl_socket_t s, CURL *e, int act, int oldact, GlobalInfo_t *g) {
  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(s);

  if(it == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "setsock: socket  %#X not found\n, s");
    return;
  }

  boost::asio::ip::tcp::socket * tcp_socket = it->second;

  *fdp = act;

  if(act == CURL_POLL_IN) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_OUT) {
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_INOUT) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
}

static void addsock(curl_socket_t s, CURL *easy, int action, GlobalInfo_t *g) {
  /* fdp is used to store current action */
  int *fdp = (int *) calloc(sizeof(int), 1);

  setsock(fdp, s, easy, action, 0, g);
  curl_multi_assign(g->multi, s, fdp);
}

static int sock_cb(CURL *e, curl_socket_t s, int what, void *cbp, void *sockp) {
  GlobalInfo_t *g = &global;

  int *actionp = (int *) sockp;
  static const char *whatstr[] = { "none", "IN", "OUT", "INOUT", "REMOVE"};

  if(what == CURL_POLL_REMOVE) {
    *actionp = what;
  }
  else {
    if(!actionp) {
      addsock(s, e, what, g);
    }
    else {
      setsock(actionp, s, e, what, *actionp, g);
    }
  }
  return 0;  
}

static void threadFunc() {      
  /* to make sure the event loop doesn't terminate when there is no work to do */
  io_service.reset() ;
  boost::asio::io_service::work work(io_service);
  
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_playht_tts threadFunc - starting\n");

  for(;;) {
      
    try {
      io_service.run() ;
      break ;
    }
    catch( std::exception& e) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_playht_tts threadFunc - Error: %s\n", e.what());
    }
  }
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_playht_tts threadFunc - ending\n");
}


/* Called by asio when our timeout expires */
static void timer_cb(const boost::system::error_code & error, GlobalInfo_t *g)
{
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "timer_cb\n");

  if(!error) {
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, CURL_SOCKET_TIMEOUT, 0, &g->still_running);
    
    mcode_test("timer_cb: curl_multi_socket_action", rc);
    check_multi_info(g);
  }
}

int multi_timer_cb(CURLM *multi, long timeout_ms, GlobalInfo_t *g) {

  /* cancel running timer */
  timer.cancel();

  if(timeout_ms >= 0) {
    // from libcurl 7.88.1-10+deb12u4 does not allow call curl_multi_socket_action or curl_multi_perform in curl_multi callback directly
    timer.expires_from_now(boost::posix_time::millisec(timeout_ms ? timeout_ms : 1));
    timer.async_wait(boost::bind(&timer_cb, boost::placeholders::_1, g));
  }

  return 0;
}

static std::vector<uint16_t> convert_ulaw_to_linear(uint8_t *data, size_t len) {
  std::vector<uint16_t> linear_data;
  linear_data.reserve(len); // Reserve space to avoid reallocation

  for (size_t i = 0; i < len; i++) {
    linear_data.push_back(ulaw_to_linear(data[i]));
  }
  return linear_data;
}

/* CURLOPT_WRITEFUNCTION */
static size_t write_cb(void *ptr, size_t size, size_t nmemb, ConnInfo_t *conn) {
  uint8_t *data = (uint8_t *) ptr;
  size_t bytes_received = size * nmemb;
  auto p = conn->playht;
  playht_handle_t handle = playht_get_handle_from_shared_ptr(p);
  
  if (!handle) {
    return 0;  // No valid handle, abort transfer
  }
  
  int current_reads = playht_get_reads(handle);
  bool fireEvent = 0 == current_reads;
  playht_set_reads(handle, current_reads + 1);
  AudioPlayer *pAudioPlayer = (AudioPlayer *) playht_get_audio_player(handle);
  std::vector<uint16_t> pcm_data;
  
  if (conn->flushed || pAudioPlayer == nullptr) {
    /* this will abort the transfer */
    return 0;
  }

  if (playht_get_response_code(handle) > 0 && playht_get_response_code(handle) != 200) {
    std::string body((char *) ptr, bytes_received);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: received body %s\n", body.c_str());
    playht_set_error_message(handle, body.c_str());
    return 0;
  }

  pcm_data = convert_ulaw_to_linear(data, bytes_received);
  size_t bytesResampled = pcm_data.size() * sizeof(uint16_t);

  /* cache same data to avoid streaming and cached audio quality is different*/
  if (p) {
    SwitchMutexLock lock(playht_get_mutex_internal(handle));
    if (conn->file) {
      fwrite(pcm_data.data(), sizeof(uint8_t), bytesResampled, conn->file);
    }
    pAudioPlayer = (AudioPlayer *) playht_get_audio_player(handle);
    if (pAudioPlayer) {
      pAudioPlayer->bufferAudio(reinterpret_cast<char*>(pcm_data.data()), bytesResampled);
    }
  }

  if (fireEvent && playht_get_session_id(handle)) {
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - conn->startTime);
    auto time_to_first_byte_ms = std::to_string(duration.count());
    switch_core_session_t* session = switch_core_session_locate(playht_get_session_id(handle));
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_core_session_rwunlock(session);
      if (channel) {
        switch_event_t *event;
        if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) == SWITCH_STATUS_SUCCESS) {
          switch_channel_event_set_data(channel, event);

          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "write_cb: firing playback-started %s\n", playht_get_playback_id(handle) ? playht_get_playback_id(handle) : "no-playback-id");

          switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
          if (playht_get_request_id(handle)) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playht_request_id", playht_get_request_id(handle));
          }
          if (playht_get_name_lookup_time_ms(handle)) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playht_name_lookup_time_ms", playht_get_name_lookup_time_ms(handle));
          }
          if (playht_get_connect_time_ms(handle)) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playht_connect_time_ms", playht_get_connect_time_ms(handle));
          }
          if (playht_get_final_response_time_ms(handle)) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playht_final_response_time_ms", playht_get_final_response_time_ms(handle));
          }
          if (playht_get_voice_name(handle)) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playht_voice_name", playht_get_voice_name(handle));
          }
          if (playht_get_cache_filename(handle)) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", playht_get_cache_filename(handle));
          }

          switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms.c_str());
          switch_event_fire(&event);
          playht_set_playback_start_sent(handle, 1);
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: failed to create event\n");
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: channel not found\n");
      }
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: session %s not found\n", playht_get_session_id(handle));
    }
  }
  return bytes_received;
}

static bool parseHeader(const std::string& str, std::string& header, std::string& value) {
    std::vector<std::string> parts;
    boost::split(parts, str, boost::is_any_of(":"), boost::token_compress_on);

    if (parts.size() != 2)
        return false;

    header = boost::trim_copy(parts[0]);
    value = boost::trim_copy(parts[1]);
    return true;
}

static int extract_response_code(const std::string& input) {
  std::size_t space_pos = input.find(' ');
  if (space_pos == std::string::npos) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Invalid HTTP response format %s\n", input.c_str());
    return 0;
  }

  std::size_t code_start_pos = space_pos + 1;
  std::size_t code_end_pos = input.find(' ', code_start_pos);
  if (code_end_pos == std::string::npos) {
    code_end_pos = input.length();
  }

  std::string code_str = input.substr(code_start_pos, code_end_pos - code_start_pos);
  int response_code = std::stoi(code_str);
  return response_code;
}

static size_t header_callback(char *buffer, size_t size, size_t nitems, ConnInfo_t *conn) {
  size_t bytes_received = size * nitems;
  const std::string prefix = "HTTP/";
  auto p = conn->playht;
  playht_handle_t handle = playht_get_handle_from_shared_ptr(p);
  
  if (!handle) {
    return bytes_received;  // No valid handle, continue
  }
  
  std::string header, value;
  std::string input(buffer, bytes_received);
  if (parseHeader(input, header, value)) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "recv header: %s with value %s\n", header.c_str(), value.c_str());
    if (0 == header.compare("x-job-ids")) playht_set_request_id(handle, value.c_str());
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "header_callback: %s\n", input.c_str());
    if (input.rfind(prefix, 0) == 0) {
      try {
        int response_code = extract_response_code(input);
        playht_set_response_code(handle, response_code);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "header_callback: parsed response code: %d\n", response_code);
      } catch (const std::invalid_argument& e) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "header_callback: invalid response code %s\n", input.substr(prefix.length()).c_str());
      }
    }
  }
  return bytes_received;
}

/* CURLOPT_OPENSOCKETFUNCTION */
static curl_socket_t opensocket(void *clientp, curlsocktype purpose, struct curl_sockaddr *address) {
  curl_socket_t sockfd = CURL_SOCKET_BAD;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "opensocket: %d\n", purpose);
  /* restrict to IPv4 */
  if(purpose == CURLSOCKTYPE_IPCXN && address->family == AF_INET) {
    /* create a tcp socket object */
    boost::asio::ip::tcp::socket *tcp_socket = new boost::asio::ip::tcp::socket(io_service);

    /* open it and get the native handle*/
    boost::system::error_code ec;
    tcp_socket->open(boost::asio::ip::tcp::v4(), ec);

    if(ec) {
      /* An error occurred */
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't open socket [%ld][%s]\n", ec, ec.message().c_str());
    }
    else {
      sockfd = tcp_socket->native_handle();

      /* save it for monitoring */
      socket_map.insert(std::pair<curl_socket_t, boost::asio::ip::tcp::socket *>(sockfd, tcp_socket));
    }
  }
  return sockfd;
}

/* CURLOPT_CLOSESOCKETFUNCTION */
static int close_socket(void *clientp, curl_socket_t item) {
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "close_socket : %#X\n", item);

  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(item);
  if(it != socket_map.end()) {
    delete it->second;
    socket_map.erase(it);
  }
  return 0;
}

extern "C" {
  switch_status_t playht_speech_load() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "playht_speech_loading..\n");
    memset(&global, 0, sizeof(GlobalInfo_t));
    global.multi = curl_multi_init();

     if (!global.multi) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "playht_speech_load curl_multi_init() failed, exiting!\n");
      return SWITCH_STATUS_FALSE;
    }

    curl_multi_setopt(global.multi, CURLMOPT_SOCKETFUNCTION, sock_cb);
    curl_multi_setopt(global.multi, CURLMOPT_SOCKETDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERFUNCTION, multi_timer_cb);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);

    /* create temp folder for cache files */
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) {
      baseDir = "/tmp/";
    }
    if (strcmp(baseDir, "/") == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", baseDir);
      return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    // Create the directory with read, write, and execute permissions for everyone
    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);
    if (result != 0) {
      if (errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", fullDirPath.c_str());
        fullDirPath = "";
      }
      else switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "folder %s already exists\n", fullDirPath.c_str());
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "created folder %s\n", fullDirPath.c_str());
    }

    /* start worker thread that handles transfers*/
    std::thread t(threadFunc) ;
    worker_thread.swap( t ) ;

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "playht_speech_loaded..\n");


    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t playht_speech_unload() {
    /* stop the ASIO IO service */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "playht_speech_unload: stopping io service\n");
    io_service.stop();

    /* Join the worker thread */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "playht_speech_unload: wait for worker thread to complete\n");
    if (worker_thread.joinable()) {
        worker_thread.join();
    }

    /* cleanup curl multi handle*/
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "playht_speech_unload: release curl multi\n");
    curl_multi_cleanup(global.multi);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "playht_speech_unload: completed\n");

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t playht_speech_open(playht_handle_t playht) {
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t playht_speech_feed_tts(playht_handle_t p, char* text, switch_speech_flag_t *flags) {
    CURLMcode rc;

    const int MAX_CHARS = 20;
    char tempText[MAX_CHARS + 4]; // +4 for the ellipsis and null terminator

    if (strlen(text) > MAX_CHARS) {
        strncpy(tempText, text, MAX_CHARS);
        strcpy(tempText + MAX_CHARS, "...");
    } else {
        strcpy(tempText, text);
    }

    /* open cache file */
    if (playht_is_cache_audio(p) && fullDirPath.length() > 0) {
      switch_uuid_t uuid;
      char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
      char outfile[512] = "";
      int fd;

      switch_uuid_get(&uuid);
      switch_uuid_format(uuid_str, &uuid);

      switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
      playht_set_cache_filename(p, outfile);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "writing audio cache file to %s\n", playht_get_cache_filename(p));

      mode_t oldMask = umask(0);
      fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
      umask(oldMask);
      if (fd == -1 ) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error opening cache file %s: %s\n", outfile, strerror(errno));
      }
      else {
        FILE* file = fdopen(fd, "wb");
        playht_set_file(p, file);
        if (!file) {
          close(fd);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error opening cache file %s: %s\n", outfile, strerror(errno));
        }
      }
    }

    if (!playht_get_api_key(p)) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "playht_speech_feed_tts: no api_key provided\n");
      return SWITCH_STATUS_FALSE;
    }
    if (!playht_get_user_id(p)) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "playht_speech_feed_tts: no user_id provided\n");
      return SWITCH_STATUS_FALSE;
    }

    /* format url*/
    std::string url = playht_get_synthesize_url(p) ? playht_get_synthesize_url(p) : "";

    /* create the JSON body */
    cJSON * jResult = cJSON_CreateObject();
    cJSON_AddStringToObject(jResult, "text", text);
    cJSON_AddStringToObject(jResult, "voice", playht_get_voice_name(p));
    cJSON_AddStringToObject(jResult, "output_format", "mulaw");
    cJSON_AddNumberToObject(jResult, "sample_rate", 8000);
    auto voice_engine = playht_get_voice_engine(p);
    auto quality = playht_get_quality(p);
    auto emotion = playht_get_emotion(p);
    auto speed = playht_get_speed(p);
    auto temperature = playht_get_temperature(p);
    auto voice_guidance = playht_get_voice_guidance(p);
    auto style_guidance = playht_get_style_guidance(p);
    auto text_guidance = playht_get_text_guidance(p);
    auto language = playht_get_language(p);
    auto repetition_penalty = playht_get_repetition_penalty(p);
    auto top_p = playht_get_top_p(p);

    if (strlen(voice_engine) > 0) {
      cJSON_AddStringToObject(jResult, "voice_engine", voice_engine);
    }
    if (strlen(quality) > 0) {
      cJSON_AddStringToObject(jResult, "quality", quality);
    }
    if (playht_get_speed(p)) {
      double val = strtod(playht_get_speed(p), NULL);
      if (val != 0.0) {
        cJSON_AddNumberToObject(jResult, "speed", val);
      }
    }
    if (temperature) {
      double val = strtod(temperature, NULL);
      if (val != 0.0) {
        cJSON_AddNumberToObject(jResult, "temperature", val);
      }
    }
    if (emotion) {
      cJSON_AddStringToObject(jResult, "emotion", emotion);
    }
    if (voice_guidance) {
      double val = strtod(voice_guidance, NULL);
      if (val != 0.0) {
        cJSON_AddNumberToObject(jResult, "voice_guidance", val);
      }
    }
    if (style_guidance) {
      double val = strtod(style_guidance, NULL);
      if (val != 0.0) {
        cJSON_AddNumberToObject(jResult, "style_guidance", val);
      }
    }
    if (text_guidance) {
      double val = strtod(text_guidance, NULL);
      if (val != 0.0) {
        cJSON_AddNumberToObject(jResult, "text_guidance", val);
      }
    }
    if (strlen(language) > 0 && 0 == strcmp(voice_engine, "Play3.0")) {
      cJSON_AddStringToObject(jResult, "language", language);
    }
    if (repetition_penalty) {
      double val = strtod(repetition_penalty, NULL);
      if (val != 0.0) {
        cJSON_AddNumberToObject(jResult, "repetition_penalty", val);
      }
    }
    if (top_p) {
      double val = strtod(top_p, NULL);
      if (val != 0.0) {
        cJSON_AddNumberToObject(jResult, "top_p", val);
      }
    }
    char *json = cJSON_PrintUnformatted(jResult);

    cJSON_Delete(jResult);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "playht_speech_feed_tts: [%s] [%s]\n", url.c_str(), json);

    ConnInfo_t *conn = new ConnInfo_t();

    CURL* easy = createEasyHandle();
    playht_set_connection(p, (void *) conn);
    conn->playht = playht_get_shared_ptr(p);  // Get shared_ptr from handle
    conn->easy = easy;
    conn->global = &global;
    conn->hdr_list = NULL ;
    conn->file = playht_get_file(p);
    conn->body = json;
    conn->flushed = false;
    
    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(playht_get_mutex_internal(p), playoutBuffer);
    audioPlayer->setResampling(8000, playht_get_rate(p));
    playht_set_playout_buffer(p, (void *) playoutBuffer);
    playht_set_audio_player(p, (void *) audioPlayer);

    std::ostringstream api_key_stream;
    api_key_stream << "AUTHORIZATION: " << playht_get_api_key(p);
    std::ostringstream user_id_stream;
    user_id_stream << "X-USER-ID: " << playht_get_user_id(p);

    curl_easy_setopt(easy, CURLOPT_URL, url.c_str());
    curl_easy_setopt(easy, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(easy, CURLOPT_WRITEDATA, conn);
    curl_easy_setopt(easy, CURLOPT_ERRORBUFFER, conn->error);
    curl_easy_setopt(easy, CURLOPT_PRIVATE, conn);
    curl_easy_setopt(easy, CURLOPT_VERBOSE, 0L);
    curl_easy_setopt(easy, CURLOPT_NOPROGRESS, 1L);
    curl_easy_setopt(easy, CURLOPT_HEADERFUNCTION, header_callback);
    curl_easy_setopt(easy, CURLOPT_HEADERDATA, conn);
    
    /* call this function to get a socket */
    curl_easy_setopt(easy, CURLOPT_OPENSOCKETFUNCTION, opensocket);

    /* call this function to close a socket */
    curl_easy_setopt(easy, CURLOPT_CLOSESOCKETFUNCTION, close_socket);
    // Play3.0 voice engine doesn't need authorization
    if (playht_get_voice_engine(p) && strcmp(playht_get_voice_engine(p), "Play3.0") != 0) {
      conn->hdr_list = curl_slist_append(conn->hdr_list, api_key_stream.str().c_str());
      conn->hdr_list = curl_slist_append(conn->hdr_list, user_id_stream.str().c_str());
    }

    // An 'accept' header or a 'format' query param are not needed when 'output_format' is present in the request.
    // conn->hdr_list = curl_slist_append(conn->hdr_list, "Accept: audio/mpeg");
    conn->hdr_list = curl_slist_append(conn->hdr_list, "Content-Type: application/json");
    curl_easy_setopt(easy, CURLOPT_HTTPHEADER, conn->hdr_list);

    curl_easy_setopt(easy, CURLOPT_POSTFIELDS, conn->body);
    //curl_easy_setopt(easy, CURLOPT_POSTFIELDSIZE, body.length());

    // libcurl adding random byte to the response body that creates white noise to audio file
    // https://github.com/curl/curl/issues/10525
    const bool disable_http_2 = switch_true(std::getenv("DISABLE_HTTP2_FOR_TTS_STREAMING"));
    curl_easy_setopt(easy, CURLOPT_HTTP_VERSION, disable_http_2 ? CURL_HTTP_VERSION_1_1 : CURL_HTTP_VERSION_2_0);

    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    rc = curl_multi_add_handle(global.multi, conn->easy);
    
    mcode_test("new_conn: curl_multi_add_handle", rc);

    /* start a timer to measure the duration until we receive first byte of audio */
    conn->startTime = std::chrono::high_resolution_clock::now();

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_speech_feed_tts: called curl_multi_add_handle\n");

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t playht_speech_read_tts(playht_handle_t p, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    CircularBuffer *playoutBuffer = (CircularBuffer *) playht_get_playout_buffer(p);
    int samplesToCopy = 0;

    if (p) {
      SwitchMutexLock lock(playht_get_mutex_internal(p));
      ConnInfo_t *conn = (ConnInfo_t *) playht_get_connection(p);
      if (playht_get_response_code(p) > 0 && playht_get_response_code(p) != 200) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "playht_speech_read_tts, returning failure\n") ;  
        return SWITCH_STATUS_FALSE;
      }

      if (conn && conn->flushed) {
        return SWITCH_STATUS_BREAK;
      }

      if (playoutBuffer->size() == 0) {
        if (playht_is_draining(p)) {
          return SWITCH_STATUS_BREAK;
        }
        /* no audio available yet so send silence */
        memset(data, 255, *datalen);
        return SWITCH_STATUS_SUCCESS;
      }
      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(*datalen / sizeof(int16_t)));

      auto count = playoutBuffer->getBlock(reinterpret_cast<int16_t*>(data), samplesToCopy);
      if (count != samplesToCopy) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "playht_speech_read_tts - failed to get %d samples from playout buffer, got %d\n", samplesToCopy, count);
      }
      *datalen = count * sizeof(int16_t);
    } else {
      /* no audio available yet so send silence */
      memset(data, 255, *datalen);
      return SWITCH_STATUS_SUCCESS;
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_speech_read_tts failed to lock mutex\n");
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t playht_speech_flush_tts(playht_handle_t p) {
    bool download_complete = playht_get_response_code(p) == 200;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_speech_flush_tts, download complete? %s\n", download_complete ? "yes" : "no") ;

    ConnInfo_t *conn = nullptr;
    {
      std::lock_guard<std::mutex> lock(curl_mutex);
      conn = (ConnInfo_t *) playht_get_connection(p);
      if (conn) {
        conn->flushed = true;  // Set this while we have curl_mutex
      }
    }

    if (p) {
      SwitchMutexLock lock(playht_get_mutex_internal(p));
      // always destroy audio player and playout buffer under mutex lock
      if (playht_get_audio_player(p)) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "destroying audio player\n");
        AudioPlayer* pAudioPlayer = static_cast<AudioPlayer*>(playht_get_audio_player(p));
        delete pAudioPlayer;
        playht_set_audio_player(p, nullptr);
      }

      if (playht_get_playout_buffer(p)) {
        CircularBuffer *playoutBuffer = (CircularBuffer *) playht_get_playout_buffer(p);
        delete playoutBuffer;
        playht_set_playout_buffer(p, nullptr);
      }
      if (conn && !download_complete && conn->file) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "closing audio cache file %s because download was interrupted\n", playht_get_cache_filename(p));
        if (fclose(conn->file) != 0) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "error closing audio cache file\n");
        }
        conn->file = nullptr;
        playht_set_file(p, nullptr);
      }
    }

    // if playback event has not been sent, delete the file.
    if (playht_get_cache_filename(p) && !playht_is_playback_start_sent(p)) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "removing audio cache file %s because download was interrupted\n", playht_get_cache_filename(p));
      if (unlink(playht_get_cache_filename(p)) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "playht_speech_flush_tts: error removing audio cache file %s: %d:%s\n", 
          playht_get_cache_filename(p), errno, strerror(errno));
      }
      playht_set_cache_filename(p, nullptr);
    }
    if (playht_get_session_id(p)) {
      switch_core_session_t* session = switch_core_session_locate(playht_get_session_id(p));
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);
        switch_core_session_rwunlock(session);
        if (channel) {
          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);

            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "write_cb: firing playback-stopped %s\n", playht_get_playback_id(p) ? playht_get_playback_id(p) : "no-playback-id");

            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (playht_get_playback_id(p)) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playht_get_playback_id(p));
            }
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playht_response_code", std::to_string(playht_get_response_code(p)).c_str());
            if (playht_get_cache_filename(p) && playht_get_response_code(p) == 200) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", playht_get_cache_filename(p));
            }
            if (playht_get_response_code(p) != 200 && playht_get_error_message(p)) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", playht_get_error_message(p));
            }
            switch_event_fire(&event);
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: failed to create event\n");
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: channel not found\n");
        }
      }
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t playht_speech_close(playht_handle_t p) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "playht_speech_close\n") ;
		return SWITCH_STATUS_SUCCESS;
	}
}
