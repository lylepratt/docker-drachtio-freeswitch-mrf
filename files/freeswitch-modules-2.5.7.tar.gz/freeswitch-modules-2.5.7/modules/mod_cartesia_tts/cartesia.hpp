#ifndef __CARTESIA_HPP__
#define __CARTESIA_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <string>
#include <memory>
#include <mutex>

class Cartesia {
private:
    // Configuration parameters
    std::string voice_name_;
    std::string api_key_;
    std::string model_id_;
    std::string speed_;
    std::string emotion_;
    std::string language_;
    std::string voice_mode_;
    std::string embedding_;

    // Result data
    long response_code_;
    std::string content_type_;
    std::string request_id_;
    std::string name_lookup_time_ms_;
    std::string connect_time_ms_;
    std::string final_response_time_ms_;
    std::string error_message_;
    std::string cache_filename_;
    std::string session_id_;

    // State and configuration
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool playback_start_sent_;

    // Pointers and resources
    void* conn_;
    void* circular_buffer_;
    mutable std::mutex mutex_;  // Now a member object, not a pointer
    FILE* file_;
    std::string playback_id_;
    SpeexResamplerState* resampler_;

public:
    // Constructor
    Cartesia();
    
    // Destructor
    ~Cartesia();
    
    // Static factory method
    static std::shared_ptr<Cartesia> create();
    
    // Copy constructor and assignment are now safe with shared_ptr
    Cartesia(const Cartesia& other) = default;
    Cartesia& operator=(const Cartesia& other) = default;
    
    // Move constructor and assignment
    Cartesia(Cartesia&& other) noexcept = default;
    Cartesia& operator=(Cartesia&& other) noexcept = default;

    // Getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getApiKey() const { return api_key_; }
    const std::string& getModelId() const { return model_id_; }
    const std::string& getSpeed() const { return speed_; }
    const std::string& getEmotion() const { return emotion_; }
    const std::string& getLanguage() const { return language_; }
    const std::string& getVoiceMode() const { return voice_mode_; }
    const std::string& getEmbedding() const { return embedding_; }
    
    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getContentType() const { return content_type_; }
    const std::string& getRequestId() const { return request_id_; }
    const std::string& getNameLookupTimeMs() const { return name_lookup_time_ms_; }
    const std::string& getConnectTimeMs() const { return connect_time_ms_; }
    const std::string& getFinalResponseTimeMs() const { return final_response_time_ms_; }
    const std::string& getErrorMessage() const { return error_message_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    const std::string& getSessionId() const { return session_id_; }
    
    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }
    
    // Resource getters
    void* getConnection() const { return conn_; }
    void* getCircularBuffer() const { return circular_buffer_; }
    std::mutex& getMutex() const { return mutex_; }  // Return reference to mutex
    FILE* getFile() const { return file_; }
    const std::string& getPlaybackId() const { return playback_id_; }
    SpeexResamplerState* getResampler() const { return resampler_; }

    // Setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setApiKey(const std::string& api_key) { api_key_ = api_key; }
    void setModelId(const std::string& model_id) { model_id_ = model_id; }
    void setSpeed(const std::string& speed) { speed_ = speed; }
    void setEmotion(const std::string& emotion) { emotion_ = emotion; }
    void setLanguage(const std::string& language) { language_ = language; }
    void setVoiceMode(const std::string& voice_mode) { voice_mode_ = voice_mode; }
    void setEmbedding(const std::string& embedding) { embedding_ = embedding; }
    
    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setContentType(const std::string& content_type) { content_type_ = content_type; }
    void setRequestId(const std::string& request_id) { request_id_ = request_id; }
    void setNameLookupTimeMs(const std::string& time_ms) { name_lookup_time_ms_ = time_ms; }
    void setConnectTimeMs(const std::string& time_ms) { connect_time_ms_ = time_ms; }
    void setFinalResponseTimeMs(const std::string& time_ms) { final_response_time_ms_ = time_ms; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    
    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setPlaybackStartSent(bool playback_start_sent) { playback_start_sent_ = playback_start_sent; }
    
    // Resource setters
    void setConnection(void* conn) { conn_ = conn; }
    void setCircularBuffer(void* circular_buffer) { circular_buffer_ = circular_buffer; }
    // Mutex setter removed - std::mutex is automatically initialized
    void setFile(FILE* file) { file_ = file; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }
    void setResampler(SpeexResamplerState* resampler) { resampler_ = resampler; }

    // Mutex initialization removed - std::mutex doesn't need explicit initialization

    // Utility methods
    void reset();
    bool isValid() const;
    
private:
    void cleanup();
};

#endif