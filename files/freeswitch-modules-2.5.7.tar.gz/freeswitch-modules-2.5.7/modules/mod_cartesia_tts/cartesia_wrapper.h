// cartesia_wrapper.h - C-compatible header
#ifndef __CARTESIA_WRAPPER_H__
#define __CARTESIA_WRAPPER_H__

#include <switch.h>

// Opaque handle for C code - hides the C++ implementation
typedef struct cartesia_handle* cartesia_handle_t;

#ifdef __cplusplus
#include <memory>

// Forward declaration
class Cartesia;

// Internal function for C++ code only (not exposed to C)
std::shared_ptr<Cartesia> cartesia_get_shared_ptr(cartesia_handle_t handle);

// Internal function to get handle from shared_ptr (for internal use)
cartesia_handle_t cartesia_get_handle_from_shared_ptr(const std::shared_ptr<Cartesia>& ptr);

extern "C" {
#endif

// C API functions
cartesia_handle_t cartesia_create(void);
void cartesia_retain(cartesia_handle_t handle);
void cartesia_release(cartesia_handle_t handle);

// Getters - C-style interface
const char* cartesia_get_voice_name(cartesia_handle_t handle);
const char* cartesia_get_api_key(cartesia_handle_t handle);
const char* cartesia_get_model_id(cartesia_handle_t handle);
const char* cartesia_get_speed(cartesia_handle_t handle);
const char* cartesia_get_emotion(cartesia_handle_t handle);
const char* cartesia_get_language(cartesia_handle_t handle);
const char* cartesia_get_voice_mode(cartesia_handle_t handle);
const char* cartesia_get_embedding(cartesia_handle_t handle);

// Result data getters
long cartesia_get_response_code(cartesia_handle_t handle);
const char* cartesia_get_content_type(cartesia_handle_t handle);
const char* cartesia_get_request_id(cartesia_handle_t handle);
const char* cartesia_get_name_lookup_time_ms(cartesia_handle_t handle);
const char* cartesia_get_connect_time_ms(cartesia_handle_t handle);
const char* cartesia_get_final_response_time_ms(cartesia_handle_t handle);
const char* cartesia_get_error_message(cartesia_handle_t handle);
const char* cartesia_get_cache_filename(cartesia_handle_t handle);
const char* cartesia_get_session_id(cartesia_handle_t handle);

// State getters
int cartesia_get_rate(cartesia_handle_t handle);
int cartesia_is_draining(cartesia_handle_t handle);
int cartesia_get_reads(cartesia_handle_t handle);
int cartesia_is_cache_audio(cartesia_handle_t handle);
int cartesia_is_playback_start_sent(cartesia_handle_t handle);

// Resource getters
void* cartesia_get_connection(cartesia_handle_t handle);
void* cartesia_get_circular_buffer(cartesia_handle_t handle);
// Mutex getter removed - std::mutex is now managed internally by Cartesia class
FILE* cartesia_get_file(cartesia_handle_t handle);
const char* cartesia_get_playback_id(cartesia_handle_t handle);
void* cartesia_get_resampler(cartesia_handle_t handle);

// Setters
void cartesia_set_voice_name(cartesia_handle_t handle, const char* voice_name);
void cartesia_set_api_key(cartesia_handle_t handle, const char* api_key);
void cartesia_set_model_id(cartesia_handle_t handle, const char* model_id);
void cartesia_set_speed(cartesia_handle_t handle, const char* speed);
void cartesia_set_emotion(cartesia_handle_t handle, const char* emotion);
void cartesia_set_language(cartesia_handle_t handle, const char* language);
void cartesia_set_voice_mode(cartesia_handle_t handle, const char* voice_mode);
void cartesia_set_embedding(cartesia_handle_t handle, const char* embedding);

// Result data setters
void cartesia_set_response_code(cartesia_handle_t handle, long response_code);
void cartesia_set_content_type(cartesia_handle_t handle, const char* content_type);
void cartesia_set_request_id(cartesia_handle_t handle, const char* request_id);
void cartesia_set_name_lookup_time_ms(cartesia_handle_t handle, const char* time_ms);
void cartesia_set_connect_time_ms(cartesia_handle_t handle, const char* time_ms);
void cartesia_set_final_response_time_ms(cartesia_handle_t handle, const char* time_ms);
void cartesia_set_error_message(cartesia_handle_t handle, const char* error_msg);
void cartesia_set_cache_filename(cartesia_handle_t handle, const char* cache_filename);
void cartesia_set_session_id(cartesia_handle_t handle, const char* session_id);

// State setters
void cartesia_set_rate(cartesia_handle_t handle, int rate);
void cartesia_set_draining(cartesia_handle_t handle, int draining);
void cartesia_set_reads(cartesia_handle_t handle, int reads);
void cartesia_set_cache_audio(cartesia_handle_t handle, int cache_audio);
void cartesia_set_playback_start_sent(cartesia_handle_t handle, int playback_start_sent);

// Resource setters
void cartesia_set_connection(cartesia_handle_t handle, void* conn);
void cartesia_set_circular_buffer(cartesia_handle_t handle, void* circular_buffer);
void cartesia_set_file(cartesia_handle_t handle, FILE* file);
void cartesia_set_playback_id(cartesia_handle_t handle, const char* playback_id);
void cartesia_set_resampler(cartesia_handle_t handle, void* resampler);

// Mutex initialization removed - std::mutex is now managed internally by Cartesia class

#ifdef __cplusplus
}
#endif

#endif