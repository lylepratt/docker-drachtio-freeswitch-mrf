#include "cartesia_wrapper.h"
#include "cartesia_glue.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_cartesia_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_cartesia_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_cartesia_tts, mod_cartesia_tts_load, mod_cartesia_tts_shutdown, NULL);

static void clearCartesia(cartesia_handle_t handle, int freeAll) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "clearCartesia\n");
  
  // Clear all string properties
  cartesia_set_api_key(handle, NULL);
  cartesia_set_model_id(handle, NULL);
  cartesia_set_speed(handle, NULL);
  cartesia_set_emotion(handle, NULL);
  cartesia_set_language(handle, NULL);
  cartesia_set_embedding(handle, NULL);
  cartesia_set_voice_mode(handle, NULL);

  // Clear result data
  cartesia_set_request_id(handle, NULL);
  cartesia_set_content_type(handle, NULL);
  cartesia_set_error_message(handle, NULL);
  cartesia_set_name_lookup_time_ms(handle, NULL);
  cartesia_set_connect_time_ms(handle, NULL);
  cartesia_set_final_response_time_ms(handle, NULL);
  cartesia_set_cache_filename(handle, NULL);

  if (freeAll) {
    cartesia_set_voice_name(handle, NULL);
    cartesia_set_session_id(handle, NULL);
  }
}

static cartesia_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  cartesia_handle_t handle = (cartesia_handle_t) sh->private_info;  
  if (!handle) {
    handle = cartesia_create();
    if (handle) {
      // Mutex initialization removed - std::mutex is now managed internally by Cartesia class
      sh->private_info = handle;
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "allocated cartesia_handle_t\n");
    }
  }
  return handle;
}

switch_status_t p_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  cartesia_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Failed to create cartesia handle\n");
    return SWITCH_STATUS_FALSE;
  }
  
  cartesia_set_voice_name(handle, voice_name);
  cartesia_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "p_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
  return cartesia_speech_open(handle);
}

static switch_status_t p_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  cartesia_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_close\n");

  rc = cartesia_speech_close(handle);
  clearCartesia(handle, 1);
  
  // Release the handle
  if (handle) {
    cartesia_release(handle);
    sh->private_info = NULL;
  }
  
  return rc;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t p_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  cartesia_handle_t handle = createOrRetrievePrivateData(sh);
  const char* playbackId = handle ? cartesia_get_playback_id(handle) : NULL;

  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "No cartesia handle available\n");
    return SWITCH_STATUS_FALSE;
  }
  
  cartesia_set_draining(handle, 0);
  cartesia_set_reads(handle, 0);
  cartesia_set_response_code(handle, 0);
  cartesia_set_error_message(handle, NULL);
  cartesia_set_playback_start_sent(handle, 0);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_feed_tts: %s\n", playbackId);

  return cartesia_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t p_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  cartesia_handle_t handle = createOrRetrievePrivateData(sh);
  return cartesia_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void p_speech_flush_tts(switch_speech_handle_t *sh)
{
  cartesia_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_speech_flush_tts\n");
  cartesia_speech_flush_tts(handle);

  clearCartesia(handle, 0);
}

static void p_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  cartesia_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "No cartesia handle available\n");
    return;
  }
  
  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_text_param_tts: %s=XXXXX\n", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "p_text_param_tts: %s=%s\n", param, val);
  }
  
  if (0 == strcmp(param, "api_key")) {
    cartesia_set_api_key(handle, val);
  } else if (0 == strcmp(param, "model_id")) {
    cartesia_set_model_id(handle, val);
  } else if (0 == strcmp(param, "speed")) {
    cartesia_set_speed(handle, val);
  } else if (0 == strcmp(param, "emotion")) {
    cartesia_set_emotion(handle, val);
  } else if (0 == strcmp(param, "language")) {
    cartesia_set_language(handle, val);
  } else if (0 == strcmp(param, "voice_mode")) {
    cartesia_set_voice_mode(handle, val);
  } else if (0 == strcmp(param, "embedding")) {
    cartesia_set_embedding(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    cartesia_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    cartesia_set_cache_audio(handle, 1);
  } else if (0 == strcmp(param, "playback_id")) {
    cartesia_set_playback_id(handle, val);
  }
}
static void p_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}
static void p_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_cartesia_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "cartesia";
  speech_interface->speech_open = p_speech_open;
  speech_interface->speech_close = p_speech_close;
  speech_interface->speech_feed_tts = p_speech_feed_tts;
  speech_interface->speech_read_tts = p_speech_read_tts;
	speech_interface->speech_flush_tts = p_speech_flush_tts;
	speech_interface->speech_text_param_tts = p_text_param_tts;
	speech_interface->speech_numeric_param_tts = p_numeric_param_tts;
	speech_interface->speech_float_param_tts = p_float_param_tts;
  return cartesia_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_cartesia_tts_shutdown)
{
  return cartesia_speech_unload();
}