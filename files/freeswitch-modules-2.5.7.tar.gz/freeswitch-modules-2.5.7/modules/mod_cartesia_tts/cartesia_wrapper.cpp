#include "cartesia_wrapper.h"
#include "cartesia.hpp"
#include <memory>
#include <mutex>
#include <unordered_map>

// Internal handle structure
struct cartesia_handle {
    std::shared_ptr<Cartesia> instance;
    int ref_count;
    std::mutex ref_mutex;
    
    cartesia_handle(std::shared_ptr<Cartesia> inst) 
        : instance(std::move(inst)), ref_count(1) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cartesia_handle initialized with ref_count %d\n", ref_count);
        }
};

// Thread-safe handle management
static std::mutex g_handle_mutex;
static std::unordered_map<cartesia_handle_t, std::unique_ptr<cartesia_handle>> g_handles;

// Helper function to validate handle
static cartesia_handle* get_handle(cartesia_handle_t handle) {
    if (!handle) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    auto it = g_handles.find(handle);
    return (it != g_handles.end()) ? it->second.get() : nullptr;
}

// Private internal function for C++ code only (not exposed to C)
std::shared_ptr<Cartesia> cartesia_get_shared_ptr(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance : nullptr;
}

// Private internal function to get handle from shared_ptr
cartesia_handle_t cartesia_get_handle_from_shared_ptr(const std::shared_ptr<Cartesia>& ptr) {
    if (!ptr) return nullptr;
    
    std::lock_guard<std::mutex> lock(g_handle_mutex);
    for (auto& pair : g_handles) {
        if (pair.second->instance == ptr) {
            return pair.first;
        }
    }
    return nullptr;
}

// C API Implementation
extern "C" {

cartesia_handle_t cartesia_create(void) {
    try {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cartesia_create\n");

        auto instance = Cartesia::create();
        auto handle = std::make_unique<cartesia_handle>(instance);
        cartesia_handle_t handle_ptr = handle.get();
        
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles[handle_ptr] = std::move(handle);
        
        return handle_ptr;
    } catch (...) {
        return nullptr;
    }
}

void cartesia_retain(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    if (h) {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count++;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cartesia_retain, ref count %d\n", h->ref_count);
    }
}

void cartesia_release(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    if (!h) return;
    
    bool should_delete = false;
    {
        std::lock_guard<std::mutex> lock(h->ref_mutex);
        h->ref_count--;
        should_delete = (h->ref_count <= 0);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cartesia_release, ref count %d\n", h->ref_count);
    }
    
    if (should_delete) {
        std::lock_guard<std::mutex> lock(g_handle_mutex);
        g_handles.erase(handle);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cartesia_release, handle erased\n");
    }
}

// Getters
const char* cartesia_get_voice_name(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceName().c_str() : nullptr;
}

const char* cartesia_get_api_key(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getApiKey().c_str() : nullptr;
}

const char* cartesia_get_model_id(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getModelId().c_str() : nullptr;
}

const char* cartesia_get_speed(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSpeed().c_str() : nullptr;
}

const char* cartesia_get_emotion(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getEmotion().c_str() : nullptr;
}

const char* cartesia_get_language(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getLanguage().c_str() : nullptr;
}

const char* cartesia_get_voice_mode(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getVoiceMode().c_str() : nullptr;
}

const char* cartesia_get_embedding(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getEmbedding().c_str() : nullptr;
}

// Result data getters
long cartesia_get_response_code(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getResponseCode() : 0;
}

const char* cartesia_get_content_type(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getContentType().c_str() : nullptr;
}

const char* cartesia_get_request_id(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRequestId().c_str() : nullptr;
}

const char* cartesia_get_name_lookup_time_ms(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getNameLookupTimeMs().c_str() : nullptr;
}

const char* cartesia_get_connect_time_ms(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnectTimeMs().c_str() : nullptr;
}

const char* cartesia_get_final_response_time_ms(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFinalResponseTimeMs().c_str() : nullptr;
}

const char* cartesia_get_error_message(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getErrorMessage().c_str() : nullptr;
}

const char* cartesia_get_cache_filename(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCacheFilename().c_str() : nullptr;
}

const char* cartesia_get_session_id(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getSessionId().c_str() : nullptr;
}

// State getters
int cartesia_get_rate(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getRate() : 0;
}

int cartesia_is_draining(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isDraining() ? 1 : 0) : 0;
}

int cartesia_get_reads(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getReads() : 0;
}

int cartesia_is_cache_audio(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isCacheAudio() ? 1 : 0) : 0;
}

int cartesia_is_playback_start_sent(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? (h->instance->isPlaybackStartSent() ? 1 : 0) : 0;
}

// Resource getters
void* cartesia_get_connection(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getConnection() : nullptr;
}

void* cartesia_get_circular_buffer(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getCircularBuffer() : nullptr;
}

// Mutex getter function removed - std::mutex is now managed internally by Cartesia class

FILE* cartesia_get_file(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getFile() : nullptr;
}

const char* cartesia_get_playback_id(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getPlaybackId().c_str() : nullptr;
}

void* cartesia_get_resampler(cartesia_handle_t handle) {
    auto* h = get_handle(handle);
    return h ? h->instance->getResampler() : nullptr;
}

// Setters
void cartesia_set_voice_name(cartesia_handle_t handle, const char* voice_name) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setVoiceName(voice_name ? voice_name : "");
    }
}

void cartesia_set_api_key(cartesia_handle_t handle, const char* api_key) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setApiKey(api_key ? api_key : "");
    }
}

void cartesia_set_model_id(cartesia_handle_t handle, const char* model_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setModelId(model_id ? model_id : "");
    }
}

void cartesia_set_speed(cartesia_handle_t handle, const char* speed) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setSpeed(speed ? speed : "");
    }
}

void cartesia_set_emotion(cartesia_handle_t handle, const char* emotion) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setEmotion(emotion ? emotion : "");
    }
}

void cartesia_set_language(cartesia_handle_t handle, const char* language) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setLanguage(language ? language : "");
    }
}

void cartesia_set_voice_mode(cartesia_handle_t handle, const char* voice_mode) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setVoiceMode(voice_mode ? voice_mode : "");
    }
}

void cartesia_set_embedding(cartesia_handle_t handle, const char* embedding) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setEmbedding(embedding ? embedding : "");
    }
}

// Result data setters
void cartesia_set_response_code(cartesia_handle_t handle, long response_code) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setResponseCode(response_code);
    }
}

void cartesia_set_content_type(cartesia_handle_t handle, const char* content_type) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setContentType(content_type ? content_type : "");
    }
}

void cartesia_set_request_id(cartesia_handle_t handle, const char* request_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setRequestId(request_id ? request_id : "");
    }
}

void cartesia_set_name_lookup_time_ms(cartesia_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setNameLookupTimeMs(time_ms ? time_ms : "");
    }
}

void cartesia_set_connect_time_ms(cartesia_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setConnectTimeMs(time_ms ? time_ms : "");
    }
}

void cartesia_set_final_response_time_ms(cartesia_handle_t handle, const char* time_ms) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setFinalResponseTimeMs(time_ms ? time_ms : "");
    }
}

void cartesia_set_error_message(cartesia_handle_t handle, const char* error_msg) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setErrorMessage(error_msg ? error_msg : "");
    }
}

void cartesia_set_cache_filename(cartesia_handle_t handle, const char* cache_filename) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCacheFilename(cache_filename ? cache_filename : "");
    }
}

void cartesia_set_session_id(cartesia_handle_t handle, const char* session_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setSessionId(session_id ? session_id : "");
    }
}

// State setters
void cartesia_set_rate(cartesia_handle_t handle, int rate) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setRate(rate);
    }
}

void cartesia_set_draining(cartesia_handle_t handle, int draining) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setDraining(draining != 0);
    }
}

void cartesia_set_reads(cartesia_handle_t handle, int reads) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setReads(reads);
    }
}

void cartesia_set_cache_audio(cartesia_handle_t handle, int cache_audio) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCacheAudio(cache_audio != 0);
    }
}

void cartesia_set_playback_start_sent(cartesia_handle_t handle, int playback_start_sent) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackStartSent(playback_start_sent != 0);
    }
}

// Resource setters
void cartesia_set_connection(cartesia_handle_t handle, void* conn) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setConnection(conn);
    }
}

void cartesia_set_circular_buffer(cartesia_handle_t handle, void* circular_buffer) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setCircularBuffer(circular_buffer);
    }
}

void cartesia_set_file(cartesia_handle_t handle, FILE* file) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setFile(file);
    }
}

void cartesia_set_playback_id(cartesia_handle_t handle, const char* playback_id) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setPlaybackId(playback_id ? playback_id : "");
    }
}

void cartesia_set_resampler(cartesia_handle_t handle, void* resampler) {
    auto* h = get_handle(handle);
    if (h) {
        h->instance->setResampler(static_cast<SpeexResamplerState*>(resampler));
    }
}

// Mutex initialization
// Mutex initialization function removed - std::mutex is now managed internally by Cartesia class

} // extern "C"