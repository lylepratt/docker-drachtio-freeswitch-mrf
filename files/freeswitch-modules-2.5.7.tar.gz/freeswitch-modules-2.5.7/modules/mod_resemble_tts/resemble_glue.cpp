#include <switch.h>
#include <switch_json.h>

#include "mod_resemble_tts.h"

#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

#include <sstream>
#include "audio_pipe.hpp"
#include "jambonz/simple_json_parser.hpp"

/* C api bindings */

typedef struct
{
  std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
  resemble_t* resemble;
} ConnInfo_t;

namespace {
  static std::string fullDirPath;

  switch_status_t processIncomingBinary(resemble_t* resemble, const char* message, size_t dataLength) {
    AudioPlayer* p = static_cast<AudioPlayer*>(resemble->audioPlayer);
    bool fireEvent = false;

    p->bufferAudio(message, dataLength);
    if (resemble->file) {
      fwrite(message, sizeof(char), dataLength, resemble->file);
    }
    if (0 == resemble->reads++) {
      resemble->response_code = 200;
      fireEvent = true;
    }

    if (fireEvent && resemble->session_id) {
      auto conn = static_cast<ConnInfo_t*>(resemble->conn);
      auto endTime = std::chrono::high_resolution_clock::now();
      auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - conn->startTime);
      auto time_to_first_byte_ms = std::to_string(duration.count());
      switch_core_session_t* session = switch_core_session_locate(resemble->session_id);
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);
        switch_core_session_rwunlock(session);
        if (channel) {
          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);

            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "write_cb: firing playback-started %s\n", resemble->playbackId ? resemble->playbackId : "no-playback-id");

            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (resemble->voice_name) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_rimelabs_voice_name", resemble->voice_name);
            }
            if (resemble->cache_filename) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", resemble->cache_filename);
            }

            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms.c_str());
            switch_event_fire(&event);
            resemble->playback_start_sent = 1;
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: failed to create event\n");
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: channel not found\n");
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: session %s not found\n", resemble->session_id);
      }
    }
    return SWITCH_STATUS_SUCCESS;
  }

  void processIncomingMessage(resemble_t* resemble, switch_core_session_t* session, const char* message) {
    std::string msg = message;
    cJSON* json = parse_json_string(session, msg);
    if (json) {
      cJSON* type = cJSON_GetObjectItem(json, "type");
      if (type && cJSON_IsString(type)) {
        const char* type_str = cJSON_GetStringValue(type);
        resemble_tts::AudioPipe *pAudioPipe = static_cast<resemble_tts::AudioPipe *>(resemble->pAudioPipe);
        if (type_str && strcmp(type_str, "audio_end") == 0) {
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, 
            "received audio_end message, setting draining flag\n");
          resemble->draining = 1;
          pAudioPipe->close();
        }
      }
      cJSON_Delete(json);
    }
  }

  static void eventCallback(resemble_t *resemble, resemble_tts::AudioPipe::NotifyEvent_t event, const char* message, const char* binary, size_t len) {
    switch_core_session_t* session = switch_core_session_locate(resemble->session_id);
    if (!session) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "session not found for id: %s\n", resemble->session_id);
      return;
    }

    resemble_tts::AudioPipe *pAudioPipe = static_cast<resemble_tts::AudioPipe *>(resemble->pAudioPipe);
    switch (event) {
      case resemble_tts::AudioPipe::BINARY:
        processIncomingBinary(resemble, binary, len);
      break;

      case resemble_tts::AudioPipe::CONNECT_SUCCESS:
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection resemble successful\n");

        if (resemble->body) {
          pAudioPipe->bufferForSending(resemble->body);
        }
      break;
      case resemble_tts::AudioPipe::CONNECT_FAIL:
      {
        // first thing: we can no longer access the AudioPipe
        if (resemble->body) {
          free(resemble->body);
          resemble->body = NULL;
        }
        resemble->response_code = 500; // Internal Server Error
        resemble->err_msg = strdup("Connection failed");
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message);
      }
      break;
      case resemble_tts::AudioPipe::CONNECTION_DROPPED:
        
        resemble->pAudioPipe = nullptr;
        resemble->draining = 1;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection resemble dropped from far end\n");
      break;
      case resemble_tts::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
        // first thing: we can no longer access the AudioPipe
        resemble->pAudioPipe = nullptr;
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection resemble closed gracefully\n");
      break;
      case resemble_tts::AudioPipe::MESSAGE:
        processIncomingMessage(resemble, session, message);
      break;

      default:
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from rimelabs %d:%s\n", event, message);
        break;
    }
    switch_core_session_rwunlock(session);
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, llevel, "%s\n", line);
  }
}



extern "C" {
	switch_status_t resemble_speech_load() {

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_loadng..\n");

    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE
    | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    resemble_tts::AudioPipe::initialize(logs, lws_logger);

    /* create temp folder for cache files */
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) {
      baseDir = "/tmp/";
    }
    if (strcmp(baseDir, "/") == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", baseDir);
      return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    // Create the directory with read, write, and execute permissions for everyone
    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);
    if (result != 0) {
      if (errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", fullDirPath.c_str());
        fullDirPath = "";
      }
      else switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "folder %s already exists\n", fullDirPath.c_str());
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "created folder %s\n", fullDirPath.c_str());
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_loaded..\n");

    return SWITCH_STATUS_SUCCESS;
	}

	switch_status_t resemble_speech_unload() {
    bool cleanup = false;
    cleanup = resemble_tts::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
	}

	switch_status_t resemble_speech_open() {
		return SWITCH_STATUS_SUCCESS;
	}

	switch_status_t resemble_speech_feed_tts(resemble_t* resemble, char* text, switch_speech_flag_t *flags) {
    const int MAX_CHARS = 20;
    char tempText[MAX_CHARS + 4]; // +4 for the ellipsis and null terminator

    if (strlen(text) > MAX_CHARS) {
        strncpy(tempText, text, MAX_CHARS);
        strcpy(tempText + MAX_CHARS, "...");
    } else {
        strcpy(tempText, text);
    }

    /* open cache file */
    if (resemble->cache_audio && fullDirPath.length() > 0) {
      switch_uuid_t uuid;
      char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
      char outfile[512] = "";
      int fd;

      switch_uuid_get(&uuid);
      switch_uuid_format(uuid_str, &uuid);

      switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
      resemble->cache_filename = strdup(outfile);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "writing audio cache file to %s\n", resemble->cache_filename);

      mode_t oldMask = umask(0);
      fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
      umask(oldMask);
      if (fd == -1 ) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error opening cache file %s: %s\n", outfile, strerror(errno));
      }
      else {
        resemble->file = fdopen(fd, "wb");
        if (!resemble->file) {
          close(fd);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error opening cache file %s: %s\n", outfile, strerror(errno));
        }
      }
    }

    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_feed_tts: text %s\n", text);

    if (!resemble->api_key) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "eevenlabs_speech_feed_tts: no api_key provided\n");
      return SWITCH_STATUS_FALSE;
    }

    /* format url*/
    std::string host = "websocket.cluster.resemble.ai";
    std::string path = "/stream";
    int port = 443;
    int useTls = true;

    if (resemble->endpoint) {
      std::string ep(resemble->endpoint);
      size_t pos = ep.find(':');
      host = ep;

      if (pos != std::string::npos) {
        host = ep.substr(0, pos);
        size_t pathPos = ep.find('/', pos + 1);
        if (pathPos != std::string::npos) {
          std::string strPort = ep.substr(pos + 1, pathPos - pos - 1);
          port = ::atoi(strPort.c_str());
          // Extract the path
          path = ep.substr(pathPos + 1);
        } else {
          // No path; extract the port after the colon
          std::string strPort = ep.substr(pos + 1);
          port = ::atoi(strPort.c_str());
        }
      } else {
        size_t pathPos = ep.find('/');
        if (pathPos != std::string::npos) {
            host = ep.substr(0, pathPos);
            path = ep.substr(pathPos + 1);
        }
      }

      if (resemble->use_tls) {
        useTls = switch_true(resemble->use_tls);
      }
    }

    /* create the JSON body */
    cJSON * jResult = cJSON_CreateObject();
    cJSON_AddStringToObject(jResult, "voice_uuid", resemble->voice_name);
    cJSON_AddStringToObject(jResult, "data", text);
    cJSON_AddStringToObject(jResult, "output_format", "wav");
    cJSON_AddStringToObject(jResult, "precision", "PCM_16");

    cJSON_AddBoolToObject(jResult, "binary_response", true);
    cJSON_AddBoolToObject(jResult, "no_audio_header", true);

    cJSON_AddNumberToObject(jResult, "sample_rate", 8000);
    if (resemble->project_uuid) {
      cJSON_AddStringToObject(jResult, "project_uuid", resemble->project_uuid);
    }
    resemble->body = cJSON_PrintUnformatted(jResult);

    cJSON_Delete(jResult);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_feed_tts: [%s] [%s]\n", host.c_str(), tempText);
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_feed_tts: %s\n", json);

    ConnInfo_t *conn = (ConnInfo_t*)malloc(sizeof(ConnInfo_t));
    conn->resemble = resemble;
    conn->startTime = std::chrono::high_resolution_clock::now();

    resemble->conn = (void *) conn;
    resemble_tts::AudioPipe* ap = new resemble_tts::AudioPipe(resemble, host.c_str(), port, path.c_str(), 
      resemble->api_key, useTls, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }
    resemble->pAudioPipe = static_cast<void *>(ap);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "connecting now\n");
    ap->connect();
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "connection in progress\n");

    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(resemble->mutex, playoutBuffer);
    audioPlayer->setResampling(8000, resemble->rate);
    resemble->playoutBuffer = (void *) playoutBuffer;
    resemble->audioPlayer = (void *) audioPlayer;

		return SWITCH_STATUS_SUCCESS;
	}

  switch_status_t resemble_speech_read_tts(resemble_t* resemble, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    CircularBuffer *playoutBuffer = (CircularBuffer *) resemble->playoutBuffer;
    int samplesToCopy = 0;

    if (resemble->mutex && switch_mutex_trylock(resemble->mutex) == SWITCH_STATUS_SUCCESS) {
      if (resemble->response_code > 0 && resemble->response_code != 200) {
        switch_mutex_unlock(resemble->mutex);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_read_tts, returning failure\n") ;  
        return SWITCH_STATUS_FALSE;
      }

      if (resemble->flushed) {
        switch_mutex_unlock(resemble->mutex);
        return SWITCH_STATUS_BREAK;
      }

      if (playoutBuffer->size() == 0) {
        if (resemble->draining) {
          switch_mutex_unlock(resemble->mutex);
          return SWITCH_STATUS_BREAK;
        }
        /* no audio available yet so send silence */
        memset(data, 255, *datalen);
        switch_mutex_unlock(resemble->mutex);
        return SWITCH_STATUS_SUCCESS;
      }
      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(*datalen / sizeof(int16_t)));

      auto count = playoutBuffer->getBlock(reinterpret_cast<int16_t*>(data), samplesToCopy);
      if (count != samplesToCopy) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "resemble_speech_read_tts - failed to get %d samples from playout buffer, got %d\n", samplesToCopy, count);
      }
      *datalen = count * sizeof(int16_t);
      switch_mutex_unlock(resemble->mutex);
    } else {
      /* no audio available yet so send silence */
      memset(data, 255, *datalen);
      return SWITCH_STATUS_SUCCESS;
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "resemble_speech_read_tts failed to lock mutex\n");
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t resemble_speech_flush_tts(resemble_t* resemble) {
    bool download_complete = resemble->response_code == 200;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "resemble_speech_flush_tts, download complete? %s\n", download_complete ? "yes" : "no") ;  

    resemble->flushed = true;
    resemble_tts::AudioPipe *pAudioPipe = static_cast<resemble_tts::AudioPipe *>(resemble->pAudioPipe);

    if (resemble->mutex && switch_mutex_lock(resemble->mutex) == SWITCH_STATUS_SUCCESS) {
      // only destroy audio resources under mutex lock for safety
      if (resemble->audioPlayer) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "destroying audio player\n");
        AudioPlayer* pAudioPlayer = static_cast<AudioPlayer*>(resemble->audioPlayer);
        delete pAudioPlayer;
        resemble->audioPlayer = nullptr;
      }

      if (resemble->playoutBuffer) {
        CircularBuffer *playoutBuffer = (CircularBuffer *) resemble->playoutBuffer;
        delete playoutBuffer;
        resemble->playoutBuffer = nullptr ;
      }

      if (pAudioPipe) {
        pAudioPipe->close();
      }
      if (resemble && !download_complete && resemble->file) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "closing audio cache file %s because download was interrupted\n", resemble->cache_filename);
        if (fclose(resemble->file) != 0) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "error closing audio cache file\n");
        }
        resemble->file = nullptr;
      }
      if (resemble->conn) {
        ConnInfo_t *conn = static_cast<ConnInfo_t*>(resemble->conn);
        free(conn);
        resemble->conn = nullptr;
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "freed connection info\n");
      }
      switch_mutex_unlock(resemble->mutex);
    }

    // If playback_start has not been sent, delete the file
    if (resemble->cache_filename && !resemble->playback_start_sent) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "removing audio cache file %s because download was interrupted\n", resemble->cache_filename);
      if (unlink(resemble->cache_filename) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "cleanupConn: error removing audio cache file %s: %d:%s\n", 
          resemble->cache_filename, errno, strerror(errno));
      }
      free(resemble->cache_filename);
      resemble->cache_filename = nullptr;
    }
    if (resemble->session_id) {
      switch_core_session_t* session = switch_core_session_locate(resemble->session_id);
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);
        if (channel) {
          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "write_cb: firing playback-stopped %s\n", resemble->playbackId ? resemble->playbackId : "no-playback-id");
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (resemble->playbackId) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", resemble->playbackId);
            }
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_resemble_response_code", std::to_string(resemble->response_code).c_str());
            if (resemble->cache_filename && resemble->response_code == 200) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", resemble->cache_filename);
            }
            if (resemble->response_code != 200 && resemble->err_msg) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", resemble->err_msg);
            }
            switch_event_fire(&event);
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: failed to create event\n");
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: channel not found\n");
        }
        switch_core_session_rwunlock(session);
      }
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t resemble_speech_close(resemble_t* el) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "resemble_speech_close\n") ;
		return SWITCH_STATUS_SUCCESS;
	}
}
