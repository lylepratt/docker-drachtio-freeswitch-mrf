#include "audio_pipe.hpp"
#include "transcribe_manager.hpp"
#include "crc.h"

#include <switch.h>

#include <cassert>
#include <iostream>
#include <sstream>
#include <netinet/in.h>

#include <fstream>
#include <string>

/* discard incoming text messages over the socket that are longer than this */
#define MAX_RECV_BUF_SIZE (65 * 1024 * 10)
#define RECV_BUF_REALLOC_SIZE (8 * 1024)

using namespace aws;

struct ev_loop *AudioPipe::m_loop = nullptr;
struct ev_async *AudioPipe::m_stop_watcher = nullptr;

namespace {
  static const char *requestedTcpKeepaliveSecs = std::getenv("MOD_AUDIO_FORK_TCP_KEEPALIVE_SECS");
  static int nTcpKeepaliveSecs = requestedTcpKeepaliveSecs ? ::atoi(requestedTcpKeepaliveSecs) : 55;

  void writeToFile(const char* buffer, size_t bufferSize) {
    static int writeCounter = 0; // Static variable to keep track of write count

    // Write only the first three times
    if (writeCounter >= 4) {
        return;
    }

    // Generate a unique file name using the writeCounter
    std::string filename = "/tmp/audio_data_" + std::to_string(writeCounter) + ".bin";

    // Open a file in binary mode
    std::ofstream outFile(filename, std::ios::binary);

    // Check if the file is open
    if (outFile.is_open()) {
        // Write the buffer to the file
        outFile.write(buffer, bufferSize);
        outFile.close();

        // Increment the write counter
        writeCounter++;
    } else {
        // Handle error in file opening
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
  }
}


int AudioPipe::aws_lws_callback(struct lws *wsi,
  enum lws_callback_reasons reason,
  void *user, void *in, size_t len) {

  struct AudioPipe::lws_per_vhost_data *vhd =
    (struct AudioPipe::lws_per_vhost_data *) lws_protocol_vh_priv_get(lws_get_vhost(wsi), lws_get_protocol(wsi));

  struct lws_vhost* vhost = lws_get_vhost(wsi);
  std::shared_ptr<AudioPipe> ** ppAp = (std::shared_ptr<AudioPipe> **) user;

  switch (reason) {
    case LWS_CALLBACK_PROTOCOL_INIT:
      vhd = (struct AudioPipe::lws_per_vhost_data *) lws_protocol_vh_priv_zalloc(lws_get_vhost(wsi), lws_get_protocol(wsi), sizeof(struct AudioPipe::lws_per_vhost_data));
      vhd->context = lws_get_context(wsi);
      vhd->protocol = lws_get_protocol(wsi);
      vhd->vhost = lws_get_vhost(wsi);
      break;

    case LWS_CALLBACK_EVENT_WAIT_CANCELLED:
      processPendingConnects(vhd);
      processPendingDisconnects(vhd);
      processPendingWrites();
      break;
    case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
      {
        std::shared_ptr<AudioPipe> ap = findAndRemovePendingConnect(wsi);
        int rc = lws_http_client_http_response(wsi);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,"AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CONNECTION_ERROR: %s, response status %d\n", in ? (char *)in : "(null)", rc);
        if (ap) {
          ap->m_state = LWS_CLIENT_FAILED;
          ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), AudioPipe::CONNECT_FAIL, (char *) in, ap->isFinished());
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,"AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CONNECTION_ERROR unable to find wsi %p..\n", wsi);
        }
      }
      break;

    case LWS_CALLBACK_CLIENT_ESTABLISHED:
      {
        std::shared_ptr<AudioPipe> ap = findAndRemovePendingConnect(wsi);
        if (ap) {
          // Allocate a shared_ptr* in LWS user data and store the AudioPipe shared_ptr
          *ppAp = new std::shared_ptr<AudioPipe>(ap);
          ap->m_vhd = vhd;
          ap->m_state = LWS_CLIENT_CONNECTED;

          // Check if session is still valid after successful connection
          bool sessionValid = ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), AudioPipe::CONNECT_SUCCESS, NULL,  ap->isFinished());
          if (!sessionValid) {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s: session gone during connect - closing connection\n", ap->m_uuid.c_str());
            ap->m_state = LWS_CLIENT_DISCONNECTING;

            // we will not get a LWS_CALLBACK_CLIENT_CLOSED in this case, we would get LWS_CALLBACK_CLIENT_CONNECTION_ERROR so we need to clean up here
            delete *ppAp;
            *ppAp = nullptr;

            return -1; // Close WebSocket
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,"AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_ESTABLISHED unable to find wsi %p..\n", wsi);
        }
      }
      break;
    case LWS_CALLBACK_WS_PEER_INITIATED_CLOSE:
      {
        if (!ppAp || !*ppAp) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_WS_PEER_INITIATED_CLOSE no AudioPipe for wsi %p\n", wsi);
          return 0;
        }
        std::shared_ptr<AudioPipe> ap = **ppAp;
        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_WS_PEER_INITIATED_CLOSE unable to find wsi %p..\n", wsi);
          return 0;
        }
        // Extract close code and reason
        uint16_t close_code = (in && len >= 2) ? (((unsigned char *)in)[0] << 8) | ((unsigned char *)in)[1] : 0;
        std::string close_reason;
        if (in && len > 2) {
          close_reason = std::string((char *)in + 2, len - 2);
        }
        if (close_code != 1000) {
          ap->setCloseReason(close_code, close_reason.c_str());
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s WebSocket closed with code: %d, reason: %s\n",
            ap->m_uuid.c_str(), close_code, close_reason.c_str());
        }
      }
      // Note: Do NOT delete the shared_ptr here - it will be deleted in LWS_CALLBACK_CLIENT_CLOSED
      break;
    case LWS_CALLBACK_CLIENT_CLOSED:
      {
        if (!ppAp || !*ppAp) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_WARNING, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CLOSED ppAp already null for wsi %p\n", wsi);
          return 0;
        }

        std::shared_ptr<AudioPipe> ap = **ppAp;
        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_CLOSED unable to find AudioPipe for wsi %p\n", wsi);
          delete *ppAp;
          return 0;
        }
        if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
          // closed by us

          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s socket closed by us\n", ap->m_uuid.c_str());
          ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), AudioPipe::CONNECTION_CLOSED_GRACEFULLY, NULL,  ap->isFinished());
        }
        else if (ap->m_state == LWS_CLIENT_CONNECTED) {
        // closed by far end
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s socket closed by far end\n", ap->m_uuid.c_str());
          uint16_t close_code = ap->getCloseCode();
          std::string close_reason = ap->getCloseReason();
          if (close_code != 1000 && close_code != 0) {
            std::stringstream json;
            json << "{\"code\": \"" << close_code << "\", \"reason\":\"" << close_reason << "\"}";
            ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), AudioPipe::CONNECTION_DROPPED, json.str().c_str(),  ap->isFinished());
          }
          else {
            ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), AudioPipe::CONNECTION_DROPPED, NULL,  ap->isFinished());
          }
        }
        ap->m_state = LWS_CLIENT_DISCONNECTED;

        // delete the shared_ptr we allocated in LWS_CALLBACK_CLIENT_ESTABLISHED
        delete *ppAp;
        // Set the pointer in LWS user data to null to prevent any accidental access
        *ppAp = nullptr;
      }
      break;

    case LWS_CALLBACK_CLIENT_RECEIVE:
      {
        if (!ppAp || !*ppAp) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,"AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE no AudioPipe for wsi %p\n", wsi);
          return 0;
        }
        std::shared_ptr<AudioPipe> ap = **ppAp;
        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,"AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE unable to find wsi %p..\n", wsi);
          return 0;
        }

        if (lws_is_first_fragment(wsi)) {
          // allocate a buffer for the entire chunk of memory needed
          assert(nullptr == ap->m_recv_buf);
          ap->m_recv_buf_len = len + lws_remaining_packet_payload(wsi);
          ap->m_recv_buf = (uint8_t*) malloc(ap->m_recv_buf_len);
          ap->m_recv_buf_ptr = ap->m_recv_buf;
        }

        size_t write_offset = ap->m_recv_buf_ptr - ap->m_recv_buf;
        size_t remaining_space = ap->m_recv_buf_len - write_offset;
        if (remaining_space < len) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,"AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE buffer realloc needed.\n");
          size_t newlen = ap->m_recv_buf_len + RECV_BUF_REALLOC_SIZE;
          if (newlen > MAX_RECV_BUF_SIZE) {
            free(ap->m_recv_buf);
            ap->m_recv_buf = ap->m_recv_buf_ptr = nullptr;
            ap->m_recv_buf_len = 0;
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_RECEIVE max buffer exceeded, truncating message.\n");
          }
          else {
            ap->m_recv_buf = (uint8_t*) realloc(ap->m_recv_buf, newlen);
            if (nullptr != ap->m_recv_buf) {
              ap->m_recv_buf_len = newlen;
              ap->m_recv_buf_ptr = ap->m_recv_buf + write_offset;
            }
          }
        }

        if (nullptr != ap->m_recv_buf) {
          if (len > 0) {
            memcpy(ap->m_recv_buf_ptr, in, len);
            ap->m_recv_buf_ptr += len;
          }
          if (lws_is_final_fragment(wsi)) {
            //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread - LWS_CALLBACK_CLIENT_RECEIVE received %d bytes.\n", len);
            if (nullptr != ap->m_recv_buf) {
              bool isError = false;
              std::string payload;
              std::string msg((char *)ap->m_recv_buf, ap->m_recv_buf_ptr - ap->m_recv_buf);

              TranscribeManager::parseResponse(msg, payload, isError, true);
              //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s AWS response: %s\n", ap->m_uuid.c_str(), payload.c_str());

              // Check for audio decode error from AWS
              if (payload.find("Could not decode the audio stream that you provided") != std::string::npos) {
                ap->m_audio_decode_error = true;
                switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "%s AWS audio decode error: %s\n", ap->m_uuid.c_str(), payload.c_str());
              } else if (0 != payload.compare("{\"Transcript\":{\"Results\":[]}}")) {
                // Check if session is still valid for transcription messages
                bool sessionValid = ap->m_callback(ap->m_uuid.c_str(), ap->m_bugname.c_str(), AudioPipe::MESSAGE, payload.c_str(),  ap->isFinished());
                if (!sessionValid) {
                  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s: session gone during transcription - closing connection\n", ap->m_uuid.c_str());
                  // Don't call ap->close() as it might cause issues with shared_from_this()
                  // Just return -1 to force LWS to close the connection
                  ap->m_state = LWS_CLIENT_DISCONNECTING;
                  return -1; // Close WebSocket
                }
              }
              if (nullptr != ap->m_recv_buf) free(ap->m_recv_buf);
            }
            ap->m_recv_buf = ap->m_recv_buf_ptr = nullptr;
            ap->m_recv_buf_len = 0;
          }
        }
      }
      break;

    case LWS_CALLBACK_CLIENT_WRITEABLE:
      {
        if (!ppAp || !*ppAp) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,"AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE no AudioPipe for wsi %p\n", wsi);
          return 0;
        }
        std::shared_ptr<AudioPipe> ap = **ppAp;
        if (!ap) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,"AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE unable to find wsi %p..\n", wsi);
          return 0;
        }

        if (ap->m_state == LWS_CLIENT_DISCONNECTING) {
          lws_close_reason(wsi, LWS_CLOSE_STATUS_NORMAL, NULL, 0);
          return -1;
        }

        // check for audio packets
        {
          std::lock_guard<std::mutex> lk(ap->m_audio_mutex);
          size_t audio_data_size = ap->m_audio_buffer_write_offset - (LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN);

          // Only send if we have enough audio data (40ms+) OR if stream is finished and we haven't sent the empty frame yet
          if (audio_data_size >= ap->m_audio_buffer_min_send_threshold || (ap->isFinished() && !ap->m_empty_frame_sent)) {

            // send a zero length audio packet to indicate end of stream
            if (ap->isFinished()) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s sending zero-length audio packet to indicate end of stream\n", ap->m_uuid.c_str());
              ap->m_empty_frame_sent = true;
              ap->m_audio_buffer_write_offset = LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN;
            }

            // AWS limits: max 1 second of audio per chunk
            // Calculate based on sampling rate: samples/sec * 2 bytes/sample * channels
            size_t audio_bytes_to_send = audio_data_size;
            bool has_more_data = false;
            uint8_t saved_bytes[4];

            if (audio_data_size > ap->m_max_audio_bytes_per_chunk) {
              audio_bytes_to_send = ap->m_max_audio_bytes_per_chunk;
              has_more_data = true;

              // If sending > 1 second, save the 4 bytes of audio where the message CRC is about to be written
              memcpy(saved_bytes, ap->m_audio_buffer + LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN + audio_bytes_to_send, 4);
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s chunking %lu bytes into %lu byte chunk (max per chunk: %lu)\n",
                ap->m_uuid.c_str(), audio_data_size, audio_bytes_to_send, ap->m_max_audio_bytes_per_chunk);
            }

            // Adjust write offset to only include the audio we're sending
            ap->m_audio_buffer_write_offset = LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN + audio_bytes_to_send;

            /**
             * fill in
             * [0..3] = total byte length
             * [8..11] = prelude crc
             * following the audio data: 4 bytes of Message CRC
             * 
             * Ref: https://docs.aws.amazon.com/transcribe/latest/dg/streaming-setting-up.html#streaming-websocket
             *
             */

            // copy in the prelude and headers
            memcpy(ap->m_audio_buffer + LWS_PRE, ap->m_aws_prelude_and_headers, AWS_PRELUDE_PLUS_HDRS_LEN);

            // fill in the total byte length
            uint32_t totalLen = ap->m_audio_buffer_write_offset - LWS_PRE + 4; // for the trailing Message CRC which is 4 bytes
            totalLen = htonl(totalLen);
            memcpy(ap->m_audio_buffer + LWS_PRE, &totalLen, sizeof(uint32_t));

            // fill in the prelude crc
            uint32_t preludeCRC = CRC::Calculate(ap->m_audio_buffer + LWS_PRE, 8, CRC::CRC_32());
            preludeCRC = htonl(preludeCRC);
            memcpy(ap->m_audio_buffer + LWS_PRE + 8, &preludeCRC, sizeof(uint32_t));

            // Generate message CRC and copy into place
            uint32_t messageCRC = CRC::Calculate(ap->m_audio_buffer + LWS_PRE, ap->m_audio_buffer_write_offset - LWS_PRE, CRC::CRC_32());
            messageCRC = htonl(messageCRC);
            memcpy(ap->m_audio_buffer + ap->m_audio_buffer_write_offset, &messageCRC, sizeof(uint32_t));

            size_t datalen = ap->m_audio_buffer_write_offset - LWS_PRE + 4;

            // Send the packet
            int sent = lws_write(wsi, (unsigned char *) ap->m_audio_buffer + LWS_PRE, datalen, LWS_WRITE_BINARY);
            if (sent < datalen) {
              switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AudioPipe::lws_service_thread LWS_CALLBACK_CLIENT_WRITEABLE %s attemped to send %lu only sent %d wsi %p..\n",
                ap->m_uuid.c_str(), datalen, sent, wsi);
            }

            if (has_more_data) {
              // Restore the 4 bytes of audio data that the message CRC overwrote
              memcpy(ap->m_audio_buffer + LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN + audio_bytes_to_send, saved_bytes, 4);

              // Move remaining audio to the beginning of the buffer
              size_t remaining_audio_bytes = audio_data_size - audio_bytes_to_send;
              memmove(ap->m_audio_buffer + LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN,
                      ap->m_audio_buffer + LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN + audio_bytes_to_send,
                      remaining_audio_bytes);
              ap->m_audio_buffer_write_offset = LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN + remaining_audio_bytes;

              // Request another writeable callback to send the remaining data
              lws_callback_on_writable(wsi);
            } else {
              ap->binaryWritePtrResetToZero();
            }
          }
        }

        return 0;
      }
      break;

    default:
      break;
  }
  return lws_callback_http_dummy(wsi, reason, user, in, len);
}


// static members
static const lws_retry_bo_t retry = {
    nullptr,   // retry_ms_table
    0,         // retry_ms_table_count
    0,         // conceal_count
    UINT16_MAX,         // secs_since_valid_ping
    UINT16_MAX,        // secs_since_valid_hangup
    0          // jitter_percent
};

struct lws_context *AudioPipe::context = nullptr;
std::thread AudioPipe::serviceThread;
std::mutex AudioPipe::mutex_connects;
std::mutex AudioPipe::mutex_disconnects;
std::mutex AudioPipe::mutex_writes;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingConnects;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingDisconnects;
std::list<std::shared_ptr<AudioPipe>> AudioPipe::pendingWrites;
AudioPipe::log_emit_function AudioPipe::logger;
std::mutex AudioPipe::mapMutex;
bool AudioPipe::stopFlag;


void AudioPipe::processPendingConnects(lws_per_vhost_data *vhd) {
  std::list<std::shared_ptr<AudioPipe>> connects;
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    for (auto it = pendingConnects.begin(); it != pendingConnects.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_IDLE) {
        connects.push_back(*it);
        (*it)->m_state = LWS_CLIENT_CONNECTING;
      }
    }
  }
  for (auto& ap : connects) {
    ap->connect_client(vhd);
  }
}

void AudioPipe::processPendingDisconnects(lws_per_vhost_data *vhd) {
  std::list<std::shared_ptr<AudioPipe>> disconnects;
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    for (auto it = pendingDisconnects.begin(); it != pendingDisconnects.end(); ++it) {
      if ((*it)->m_state == LWS_CLIENT_DISCONNECTING) disconnects.push_back(*it);
    }
    pendingDisconnects.clear();
  }
  for (auto& ap : disconnects) {
    lws_callback_on_writable(ap->m_wsi);
  }
}

void AudioPipe::processPendingWrites() {
  std::list<std::shared_ptr<AudioPipe>> writes;
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    for (auto it = pendingWrites.begin(); it != pendingWrites.end(); ++it) {
       if ((*it)->m_state == LWS_CLIENT_CONNECTED) writes.push_back(*it);
    }
    pendingWrites.clear();
  }
  for (auto& ap : writes) {
    lws_callback_on_writable(ap->m_wsi);
  }
}

std::shared_ptr<AudioPipe> AudioPipe::findAndRemovePendingConnect(struct lws *wsi) {
  std::shared_ptr<AudioPipe> ap = nullptr;
  std::lock_guard<std::mutex> guard(mutex_connects);
  std::list<std::shared_ptr<AudioPipe>> toRemove;

  for (auto it = pendingConnects.begin(); it != pendingConnects.end() && !ap; ++it) {
    int state = (*it)->m_state;

    if ((*it)->m_wsi == nullptr)
      toRemove.push_back(*it);

    if ((state == LWS_CLIENT_CONNECTING) &&
      (*it)->m_wsi == wsi) {
      ap = *it; // Keep the shared_ptr
      pendingConnects.erase(it); // Remove from list
      break;
    }
  }

  for (auto& sharedPtr : toRemove)
    pendingConnects.remove(sharedPtr);

  return ap;
}

std::shared_ptr<AudioPipe> AudioPipe::findPendingConnect(struct lws *wsi) {
  std::shared_ptr<AudioPipe> ap = nullptr;
  std::lock_guard<std::mutex> guard(mutex_connects);

  for (auto it = pendingConnects.begin(); it != pendingConnects.end() && !ap; ++it) {
    int state = (*it)->m_state;
    if ((state == LWS_CLIENT_CONNECTING) &&
      (*it)->m_wsi == wsi) ap = *it; // Return the shared_ptr
  }
  return ap;
}

void AudioPipe::addPendingConnect(std::shared_ptr<AudioPipe> ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_connects);
    pendingConnects.push_back(ap);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,"%s after adding connect there are %lu pending connects\n",
      ap->m_uuid.c_str(), pendingConnects.size());
  }
  lws_cancel_service(context);
}
void AudioPipe::addPendingDisconnect(std::shared_ptr<AudioPipe> ap) {
  ap->m_state = LWS_CLIENT_DISCONNECTING;
  {
    std::lock_guard<std::mutex> guard(mutex_disconnects);
    pendingDisconnects.push_back(ap);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,"%s after adding disconnect there are %lu pending disconnects\n",
      ap->m_uuid.c_str(), pendingDisconnects.size());
  }
  lws_cancel_service(ap->m_vhd->context);
}
void AudioPipe::addPendingWrite(std::shared_ptr<AudioPipe> ap) {
  {
    std::lock_guard<std::mutex> guard(mutex_writes);
    pendingWrites.push_back(ap);
  }
  lws_cancel_service(ap->m_vhd->context);
}

void AudioPipe::binaryWritePtrResetToZero(void) {
    m_audio_buffer_write_offset = LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN;
}

bool AudioPipe::lws_service_thread() {
  struct lws_context_creation_info info;
  struct ev_loop *loop;
  struct ev_async stop_watcher;

  const struct lws_protocols protocols[] = {
    {
      "",
      AudioPipe::aws_lws_callback,
      sizeof(std::shared_ptr<AudioPipe>*),
      8192,
    },
    { NULL, NULL, 0, 0 }
  };

  // CREATE YOUR OWN LIBEV LOOP WITHOUT SIGNAL HANDLING
  loop = ev_loop_new(EVFLAG_NOSIGMASK);
  if (!loop) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                     "AudioPipe::lws_service_thread failed to create ev loop\n");
    return false;
  }

  memset(&info, 0, sizeof info);
  info.port = CONTEXT_PORT_NO_LISTEN;

  // TELL LWS TO USE LIBEV
  info.options = LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT |
                 LWS_SERVER_OPTION_LIBEV;

  // PROVIDE YOUR LOOP TO LWS
  void *foreign_loops[1] = { loop };
  info.foreign_loops = foreign_loops;

  info.protocols = protocols;
  info.ka_time = nTcpKeepaliveSecs;                    // tcp keep-alive timer
  info.ka_probes = 4;                   // number of times to try ka before closing connection
  info.ka_interval = 5;                 // time between ka's
  info.timeout_secs = 10;                // doc says timeout for "various processes involving network roundtrips"
  info.keepalive_timeout = 5;           // seconds to allow remote client to hold on to an idle HTTP/1.1 connection
  info.timeout_secs_ah_idle = 10;       // secs to allow a client to hold an ah without using it
  info.retry_and_idle_policy = &retry;

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
                   "AudioPipe::lws_service_thread creating context with foreign libev loop\n");

  context = lws_create_context(&info);
  if (!context) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                     "AudioPipe::lws_service_thread failed creating context\n");
    ev_loop_destroy(loop);
    return false;
  }

  // SET UP ASYNC WATCHER FOR CLEAN SHUTDOWN
  ev_async_init(&stop_watcher, [](EV_P_ ev_async *w, int revents) {
    // Just waking up is enough - the while loop checks stopFlag
  });
  ev_async_start(loop, &stop_watcher);

  // Store for shutdown from other threads
  m_loop = loop;
  m_stop_watcher = &stop_watcher;

  // RUN YOUR EVENT LOOP - NO MORE lws_service() CALLS!
  while (!stopFlag) {
    ev_run(loop, EVRUN_ONCE);
  }

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE,
                   "AudioPipe::lws_service_thread ending\n");

  ev_async_stop(loop, &stop_watcher);
  lws_context_destroy(context);
  ev_loop_destroy(loop);

  return true;
}

void AudioPipe::initialize(int loglevel, log_emit_function logger) {
  AudioPipe::logger = logger;
  lws_set_log_level(loglevel, logger);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize starting\n");
  std::lock_guard<std::mutex> lock(mapMutex);
  stopFlag = false;
  serviceThread = std::thread(&AudioPipe::lws_service_thread);
}

bool AudioPipe::deinitialize() {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::deinitialize\n");
  std::lock_guard<std::mutex> lock(mapMutex);
  stopFlag = true;

  // Wake up the ev_run loop so it can exit
  if (m_loop && m_stop_watcher) {
    ev_async_send(m_loop, m_stop_watcher);
  }

  if (serviceThread.joinable()) {
    serviceThread.join();
  }

  return true;
}

// instance members
AudioPipe::AudioPipe(const char* uuid, const char* bugname, const char* host, unsigned int port, const char* path,
  size_t bufLen, size_t minFreespace, size_t minSendThreshold, uint32_t samplingRate, uint32_t channels, notifyHandler_t callback) :
  m_uuid(uuid), m_host(host), m_port(port), m_path(path), m_finished(false), m_bugname(bugname),
  m_audio_buffer_min_freespace(minFreespace), m_audio_buffer_min_send_threshold(minSendThreshold),
  m_audio_buffer_max_len(bufLen), m_gracefulShutdown(false), m_empty_frame_sent(false), m_audio_decode_error(false),
  m_max_audio_bytes_per_chunk(samplingRate * 2 * channels),
  m_recv_buf(nullptr), m_recv_buf_ptr(nullptr),
  m_state(LWS_CLIENT_IDLE), m_wsi(nullptr), m_vhd(nullptr), m_callback(callback), m_closeCode(0), m_closeReason("") {

  char headerBuffer[88];
  char* buffer = headerBuffer;
  m_audio_buffer = new uint8_t[m_audio_buffer_max_len];

  // stamp out the template for the prelude and headers
  memset(m_aws_prelude_and_headers, 0, AWS_PRELUDE_PLUS_HDRS_LEN);

  // m_aws_prelude_and_headers[0..3] = total byte length (not known till message send time)

  // m_aws_prelude_and_headers[4..7] = headers byte length
  uint32_t headerLen = sizeof(headerBuffer);
  headerLen = htonl(headerLen);
  memcpy(&m_aws_prelude_and_headers[4], &headerLen, sizeof(uint32_t));

  // m_aws_prelude_and_headers[8..11] = prelude crc (not known till message send time)

  // m_aws_prelude_and_headers[12..99] = headers
  TranscribeManager::writeHeader(&buffer, ":content-type", "application/octet-stream");
  TranscribeManager::writeHeader(&buffer, ":event-type", "AudioEvent");
  TranscribeManager::writeHeader(&buffer, ":message-type", "event");

  memcpy(&m_aws_prelude_and_headers[12], headerBuffer, sizeof(headerBuffer));

  // following this will be the audio data and a final message CRC (not known till message send time)

  memcpy(m_audio_buffer + LWS_PRE, m_aws_prelude_and_headers, AWS_PRELUDE_PLUS_HDRS_LEN);
  m_audio_buffer_write_offset = LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN;

  //writeToFile((const char *) m_audio_buffer + LWS_PRE, AWS_PRELUDE_PLUS_HDRS_LEN);

}

AudioPipe::~AudioPipe() {
  if (m_audio_buffer) delete [] m_audio_buffer;
  if (m_recv_buf) delete [] m_recv_buf;
}

void AudioPipe::connect(void) {
  addPendingConnect(shared_from_this());
}

bool AudioPipe::connect_client(struct lws_per_vhost_data *vhd) {
  assert(m_audio_buffer != nullptr);
  assert(m_vhd == nullptr);
  struct lws_client_connect_info i;

  memset(&i, 0, sizeof(i));
  i.context = vhd->context;
  i.port = m_port;
  i.address = m_host.c_str();
  i.path = m_path.c_str();
  i.host = i.address;
  i.origin = i.address;
  i.ssl_connection = LCCSCF_USE_SSL;
  //i.protocol = protocolName.c_str();
  i.pwsi = &(m_wsi);

  m_state = LWS_CLIENT_CONNECTING;
  m_vhd = vhd;

  m_wsi = lws_client_connect_via_info(&i);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,"%s attempting connection, wsi is %p\n", m_uuid.c_str(), m_wsi);

  return nullptr != m_wsi;
}

void AudioPipe::bufferForSending(const char* text) {
  if (m_state != LWS_CLIENT_CONNECTED) return;
  {
    std::lock_guard<std::mutex> lk(m_text_mutex);
    m_metadata.append(text);
  }
  addPendingWrite(shared_from_this());
}

void AudioPipe::unlockAudioBuffer() {
  size_t audio_data_size = m_audio_buffer_write_offset - (LWS_PRE + AWS_PRELUDE_PLUS_HDRS_LEN);
  if (audio_data_size >= m_audio_buffer_min_send_threshold) {
    addPendingWrite(shared_from_this());
  }
  m_audio_mutex.unlock();
}

void AudioPipe::close() {
  if (m_state != LWS_CLIENT_CONNECTED) return;
  addPendingDisconnect(shared_from_this());
}

void AudioPipe::finish() {
  if (m_finished || m_state != LWS_CLIENT_CONNECTED) return;
  m_finished = true;
  addPendingWrite(shared_from_this());
}
