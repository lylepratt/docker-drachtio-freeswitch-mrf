#include <switch.h>
#include <switch_json.h>
#include <g711.h>

#include <curl/curl.h>
#include <deque>
#include <map>
#include <cstdint>
#include <algorithm>
#include <fstream>
#include <chrono>
#include <string>
#include <cstdlib>
#include <sys/stat.h>
#include <iostream>
#include <cerrno>
#include <dirent.h>
#include <unistd.h>
#include <sys/types.h>
#include <mutex>

#include <boost/thread.hpp>
#include <boost/asio.hpp>
#include <boost/asio/ssl.hpp>
#include <boost/bind/bind.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>
#include <boost/asio.hpp>
#include <boost/assign/list_of.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/unordered_map.hpp>

#include "mod_elevenlabs_tts.h"
#include "elevenlabs_wrapper.h"
#include "elevenlabs.hpp"

#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

#include <sstream>

/* Global information, common to all connections */
typedef struct
{
  CURLM *multi;
  int still_running;
} GlobalInfo_t;
static GlobalInfo_t global;

/* Information associated with a specific easy handle */
typedef struct
{
  CURL *easy;
  elevenlabs_handle_t handle;
  char* body;
  struct curl_slist *hdr_list;
  GlobalInfo_t *global;
  char error[CURL_ERROR_SIZE];
  std::chrono::time_point<std::chrono::high_resolution_clock> startTime;
  bool flushed;
} ConnInfo_t;

/* static singletons shared by all sessions */
static boost::asio::io_service io_service;
static boost::asio::deadline_timer timer(io_service);
static std::map<curl_socket_t, boost::asio::ip::tcp::socket *> socket_map;
static std::thread worker_thread ;
static std::mutex curl_mutex;

/* statics */

static std::string fullDirPath;

static void timer_cb(const boost::system::error_code & error, GlobalInfo_t *g);

static bool removeDirectory(const std::string &dirPath) {
    DIR *dir = opendir(dirPath.c_str());
    if (dir) {
        struct dirent *entry;
        while ((entry = readdir(dir)) != nullptr) {
            std::string entryPath = dirPath + "/" + entry->d_name;
            struct stat statbuf;
            if (!stat(entryPath.c_str(), &statbuf)) {
                if (S_ISDIR(statbuf.st_mode)) {
                    if (std::string(entry->d_name) != "." && std::string(entry->d_name) != "..") {
                        if (!removeDirectory(entryPath)) {
                            closedir(dir);
                            return false;
                        }
                    }
                } else {
                    if (unlink(entryPath.c_str()) != 0) {
                        closedir(dir);
                        return false;
                    }
                }
            }
        }
        closedir(dir);
    }
    return rmdir(dirPath.c_str()) == 0;
}

static bool parseHeader(const std::string& str, std::string& header, std::string& value) {
    std::vector<std::string> parts;
    boost::split(parts, str, boost::is_any_of(":"), boost::token_compress_on);

    if (parts.size() != 2)
        return false;

    header = boost::trim_copy(parts[0]);
    value = boost::trim_copy(parts[1]);
    return true;
}

std::string secondsToMillisecondsString(double seconds) {
    // Convert to milliseconds
    double milliseconds = seconds * 1000.0;

    // Truncate to remove fractional part
    long milliseconds_long = static_cast<long>(milliseconds);

    // Convert to string
    return std::to_string(milliseconds_long);
}

static void cleanupConn(ConnInfo_t *conn) {
  elevenlabs_handle_t handle = conn->handle;
  auto p = elevenlabs_get_shared_ptr(handle);

  if( conn->hdr_list ) {
    curl_slist_free_all(conn->hdr_list);
    conn->hdr_list = nullptr ;
  }
  curl_easy_cleanup(conn->easy);

  elevenlabs_set_connection(handle, nullptr);
  elevenlabs_set_draining(handle, 1);

  elevenlabs_release(handle);

  delete conn;
}

int multi_timer_cb(CURLM *multi, long timeout_ms, GlobalInfo_t *g) {

  /* cancel running timer */
  timer.cancel();

  if(timeout_ms >= 0) {
    // from libcurl 7.88.1-10+deb12u4 does not allow call curl_multi_socket_action or curl_multi_perform in curl_multi callback directly
    timer.expires_from_now(boost::posix_time::millisec(timeout_ms ? timeout_ms : 1));
    timer.async_wait(boost::bind(&timer_cb, boost::placeholders::_1, g));
  }

  return 0;
}

static std::string getEnvVar(const std::string& varName) {
    const char* val = std::getenv(varName.c_str());
    return val ? std::string(val) : "";
}

static long getConnectionTimeout() {
    std::string connectTimeoutStr = getEnvVar("ELEVENLABS_TTS_CURL_CONNECT_TIMEOUT");

    if (connectTimeoutStr.empty()) {
        connectTimeoutStr = getEnvVar("TTS_CURL_CONNECT_TIMEOUT");
    }

    long connectTimeout = 10L;

    if (!connectTimeoutStr.empty()) {
        connectTimeout = std::stol(connectTimeoutStr);
    }

    return connectTimeout;
}

static CURL* createEasyHandle(void) {
  CURL* easy = curl_easy_init();
  if(!easy) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "curl_easy_init() failed!\n");
    return nullptr ;
  }  

  curl_easy_setopt(easy, CURLOPT_FOLLOWLOCATION, 1L);
  curl_easy_setopt(easy, CURLOPT_USERAGENT, "jambonz/0.8.5");

  // set connect timeout to 3 seconds and total timeout to 109 seconds
  curl_easy_setopt(easy, CURLOPT_CONNECTTIMEOUT_MS, 3000L);
  curl_easy_setopt(easy, CURLOPT_TIMEOUT, getConnectionTimeout());

  return easy ;    
}

int mcode_test(const char *where, CURLMcode code) {
  if(CURLM_OK != code) {
    const char *s;
    switch(code) {
    case CURLM_CALL_MULTI_PERFORM:
      s = "CURLM_CALL_MULTI_PERFORM";
      break;
    case CURLM_BAD_HANDLE:
      s = "CURLM_BAD_HANDLE";
      break;
    case CURLM_BAD_EASY_HANDLE:
      s = "CURLM_BAD_EASY_HANDLE";
      break;
    case CURLM_OUT_OF_MEMORY:
      s = "CURLM_OUT_OF_MEMORY";
      break;
    case CURLM_INTERNAL_ERROR:
      s = "CURLM_INTERNAL_ERROR";
      break;
    case CURLM_UNKNOWN_OPTION:
      s = "CURLM_UNKNOWN_OPTION";
      break;
    case CURLM_LAST:
      s = "CURLM_LAST";
      break;
    default:
      s = "CURLM_unknown";
      break;
    case CURLM_BAD_SOCKET:
      s = "CURLM_BAD_SOCKET";
      break;
    }
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mcode_test ERROR: %s returns %s:%d\n", where, s, code);

    return -1;
  }
  return 0 ;
}

static void remsock(int *f, GlobalInfo_t *g) {
  if(f) {
    free(f);
    f = NULL;
  }
}

/* Check for completed transfers, and remove their easy handles */
void check_multi_info(GlobalInfo_t *g) {
  CURLMsg *msg;
  int msgs_left;
  ConnInfo_t *conn;
  CURL *easy;
  CURLcode res;
  
  while((msg = curl_multi_info_read(g->multi, &msgs_left))) {
    if(msg->msg == CURLMSG_DONE) {
      long response_code;
      double namelookup=0, connect=0, total=0 ;
      char *ct = NULL ;

      easy = msg->easy_handle;
      res = msg->data.result;
      curl_easy_getinfo(easy, CURLINFO_PRIVATE, &conn);
      curl_easy_getinfo(easy, CURLINFO_RESPONSE_CODE, &response_code);
      curl_easy_getinfo(easy, CURLINFO_CONTENT_TYPE, &ct);

      curl_easy_getinfo(easy, CURLINFO_NAMELOOKUP_TIME, &namelookup);
      curl_easy_getinfo(easy, CURLINFO_CONNECT_TIME, &connect);
      curl_easy_getinfo(easy, CURLINFO_TOTAL_TIME, &total);

      elevenlabs_handle_t handle = conn->handle;
      elevenlabs_set_response_code(handle, response_code);
      if (ct) elevenlabs_set_content_type(handle, ct);

      std::string name_lookup_ms = secondsToMillisecondsString(namelookup);
      std::string connect_ms = secondsToMillisecondsString(connect);
      std::string final_response_time_ms = secondsToMillisecondsString(total);

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, 
        "mod_elevenlabs_tts: response: %ld, content-type %s,"
        "dns(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
        "connect(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld, "
        "total(ms): %"  CURL_FORMAT_CURL_OFF_T ".%06ld\n",
        response_code, ct,
        (long)(namelookup), (long)(fmod(namelookup, 1.0) * 1000000),
        (long)(connect), (long)(fmod(connect, 1.0) * 1000000),
        (long)(total), (long)(fmod(total, 1.0) * 1000000));

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "name lookup time: %s\n", name_lookup_ms.c_str());
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "connect time: %s\n", connect_ms.c_str());
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "final response time: %s\n", final_response_time_ms.c_str());

      elevenlabs_set_name_lookup_time_ms(handle, name_lookup_ms.c_str());
      elevenlabs_set_connect_time_ms(handle, connect_ms.c_str());
      elevenlabs_set_final_response_time_ms(handle, final_response_time_ms.c_str());

      curl_multi_remove_handle(g->multi, easy);
      cleanupConn(conn);
    }
  }
}


/* Called by asio when there is an action on a socket */
static void event_cb(GlobalInfo_t *g, curl_socket_t s, int action, const boost::system::error_code & error, int *fdp) {
  int f = *fdp;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X has action %d\n", s, action) ; 

  // Socket already POOL REMOVED.
  if (f == CURL_POLL_REMOVE) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb socket %#X removed\n", s); 
    remsock(fdp, g);
    return;
  }

  if(socket_map.find(s) == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event_cb: socket  %#X already closed\n, s");
    return;
  }

  /* make sure the event matches what are wanted */
  if(f == action || f == CURL_POLL_INOUT) {
    if(error) {
      action = CURL_CSELECT_ERR;
    }
    // Protect concurrent access to curl multi handle  
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, s, action, &g->still_running);

    mcode_test("event_cb: curl_multi_socket_action", rc);
    check_multi_info(g);

    if(g->still_running <= 0) {
      timer.cancel();
    }

    /* keep on watching.
      * the socket may have been closed and/or fdp may have been changed
      * in curl_multi_socket_action(), so check them both */
    if(!error && socket_map.find(s) != socket_map.end() &&
        (f == action || f == CURL_POLL_INOUT)) {
      boost::asio::ip::tcp::socket *tcp_socket = socket_map.find(s)->second;

      if(action == CURL_POLL_IN) {
        tcp_socket->async_read_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                                action, boost::placeholders::_1, fdp));
      }
      if(action == CURL_POLL_OUT) {
        tcp_socket->async_write_some(boost::asio::null_buffers(),
                                      boost::bind(&event_cb, g, s,
                                                  action, boost::placeholders::_1, fdp));
      } 
    }
  }
}

/* socket functions */
static void setsock(int *fdp, curl_socket_t s, CURL *e, int act, int oldact, GlobalInfo_t *g) {
  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(s);

  if(it == socket_map.end()) {
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "setsock: socket  %#X not found\n, s");
    return;
  }

  boost::asio::ip::tcp::socket * tcp_socket = it->second;

  *fdp = act;

  if(act == CURL_POLL_IN) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_OUT) {
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
  else if(act == CURL_POLL_INOUT) {
    if(oldact != CURL_POLL_IN && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_read_some(boost::asio::null_buffers(),
                                  boost::bind(&event_cb, g, s,
                                  CURL_POLL_IN, boost::placeholders::_1, fdp));
    }
    if(oldact != CURL_POLL_OUT && oldact != CURL_POLL_INOUT) {
      tcp_socket->async_write_some(boost::asio::null_buffers(),
                                    boost::bind(&event_cb, g, s,
                                    CURL_POLL_OUT, boost::placeholders::_1, fdp));
    }
  }
}

static void addsock(curl_socket_t s, CURL *easy, int action, GlobalInfo_t *g) {
  /* fdp is used to store current action */
  int *fdp = (int *) calloc(sizeof(int), 1);

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "addsock socket %#X\n", s); 

  setsock(fdp, s, easy, action, 0, g);
  curl_multi_assign(g->multi, s, fdp);
}


static int sock_cb(CURL *e, curl_socket_t s, int what, void *cbp, void *sockp) {
  GlobalInfo_t *g = &global;

  int *actionp = (int *) sockp;
  static const char *whatstr[] = { "none", "IN", "OUT", "INOUT", "REMOVE"};

  if(what == CURL_POLL_REMOVE) {
    *actionp = what;
  }
  else {
    if(!actionp) {
      addsock(s, e, what, g);
    }
    else {
      setsock(actionp, s, e, what, *actionp, g);
    }
  }
  return 0;  
}

/* Called by asio when our timeout expires */
static void timer_cb(const boost::system::error_code & error, GlobalInfo_t *g)
{
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "timer_cb\n");

  if(!error) {
    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    CURLMcode rc = curl_multi_socket_action(g->multi, CURL_SOCKET_TIMEOUT, 0, &g->still_running);
    mcode_test("timer_cb: curl_multi_socket_action", rc);
    check_multi_info(g);
  }
}

static std::vector<uint16_t> convert_ulaw_to_linear(uint8_t *data, size_t len) {
  std::vector<uint16_t> linear_data;
  linear_data.reserve(len); // Reserve space to avoid reallocation

  for (size_t i = 0; i < len; i++) {
    linear_data.push_back(ulaw_to_linear(data[i]));
  }
  return linear_data;
}


/* CURLOPT_WRITEFUNCTION */
static size_t write_cb(void *ptr, size_t size, size_t nmemb, ConnInfo_t *conn) {
  uint8_t *data = (uint8_t *) ptr;
  size_t bytes_received = size * nmemb;
  elevenlabs_handle_t handle = conn->handle;
  auto p = elevenlabs_get_shared_ptr(handle);
  int reads = elevenlabs_get_reads(handle);
  bool fireEvent = 0 == reads;
  elevenlabs_set_reads(handle, reads + 1);
  std::vector<uint16_t> pcm_data;
  AudioPlayer *pAudioPlayer = (AudioPlayer *) elevenlabs_get_audio_player(handle);
  
  if (conn->flushed || pAudioPlayer == nullptr) {
    /* this will abort the transfer */
    return 0;
  }

  long response_code = elevenlabs_get_response_code(handle);
  if (response_code > 0 && response_code != 200) {
    std::string body((char *) ptr, bytes_received);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: received body %s\n", body.c_str());
    elevenlabs_set_error_message(handle, body.c_str());
    return 0;
  }

  pcm_data = convert_ulaw_to_linear(data, bytes_received);
  size_t bytesResampled = pcm_data.size() * sizeof(uint16_t);

  // buffer audio under mutex lock to make sure we don't add data to freed buffer.
  // AudioPlayer will handle file caching in its consumer thread
  {
    std::lock_guard<std::mutex> lock(p->getMutex());
    void *audio_player = elevenlabs_get_audio_player(handle);
    if (audio_player) {
      pAudioPlayer = (AudioPlayer *) audio_player;
      pAudioPlayer->bufferAudio(reinterpret_cast<char*>(pcm_data.data()), bytesResampled);
    }
  }

  const char *session_id = elevenlabs_get_session_id(handle);
  if (fireEvent && session_id && strlen(session_id) > 0) {
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - conn->startTime);
    auto time_to_first_byte_ms = std::to_string(duration.count());
    switch_core_session_t* session = switch_core_session_locate(session_id);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      if (channel) {
        switch_event_t *event;
        if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) == SWITCH_STATUS_SUCCESS) {
          switch_channel_event_set_data(channel, event);

          const char *playback_id = elevenlabs_get_playback_id(handle);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "write_cb: firing playback-started %s\n", (playback_id && strlen(playback_id) > 0) ? playback_id : "no-playback-id");

          switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
          if (playback_id && strlen(playback_id) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
          }
          const char *reported_latency = elevenlabs_get_reported_latency(handle);
          if (reported_latency && strlen(reported_latency) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_reported_latency_ms", reported_latency);
          }
          const char *request_id = elevenlabs_get_request_id(handle);
          if (request_id && strlen(request_id) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_request_id", request_id);
          }
          const char *history_item_id = elevenlabs_get_history_item_id(handle);
          if (history_item_id && strlen(history_item_id) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_history_item_id", history_item_id);
          }
          const char *name_lookup_time_ms = elevenlabs_get_name_lookup_time_ms(handle);
          if (name_lookup_time_ms && strlen(name_lookup_time_ms) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_name_lookup_time_ms", name_lookup_time_ms);
          }
          const char *connect_time_ms = elevenlabs_get_connect_time_ms(handle);
          if (connect_time_ms && strlen(connect_time_ms) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_connect_time_ms", connect_time_ms);
          }
          const char *final_response_time_ms = elevenlabs_get_final_response_time_ms(handle);
          if (final_response_time_ms && strlen(final_response_time_ms) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_final_response_time_ms", final_response_time_ms);
          }
          const char *voice_name = elevenlabs_get_voice_name(handle);
          if (voice_name && strlen(voice_name) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_voice_name", voice_name);
          }
          const char *model_id = elevenlabs_get_model_id(handle);
          if (model_id && strlen(model_id) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_model_id", model_id);
          }
          const char *optimize_streaming_latency = elevenlabs_get_optimize_streaming_latency(handle);
          if (optimize_streaming_latency && strlen(optimize_streaming_latency) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_optimize_streaming_latency", optimize_streaming_latency);
          }
          const char *cache_filename = elevenlabs_get_cache_filename(handle);
          if (cache_filename && strlen(cache_filename) > 0) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);
          }

          switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms.c_str());
          switch_event_fire(&event);
          elevenlabs_set_playback_start_sent(handle, 1);
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: failed to create event\n");
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: channel not found\n");
      }
      switch_core_session_rwunlock(session);
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: session %s not found\n", session_id);
    }
  }
  return bytes_received;
}

static int extract_response_code(const std::string& input) {
  std::size_t space_pos = input.find(' ');
  if (space_pos == std::string::npos) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Invalid HTTP response format %s\n", input.c_str());
    return 0;
  }

  std::size_t code_start_pos = space_pos + 1;
  std::size_t code_end_pos = input.find(' ', code_start_pos);
  if (code_end_pos == std::string::npos) {
    code_end_pos = input.length();
  }

  std::string code_str = input.substr(code_start_pos, code_end_pos - code_start_pos);
  int response_code = std::stoi(code_str);
  return response_code;
}


static size_t header_callback(char *buffer, size_t size, size_t nitems, ConnInfo_t *conn) {
  size_t bytes_received = size * nitems;
  const std::string prefix = "HTTP/ ";
  elevenlabs_handle_t handle = conn->handle;
  std::string header, value;
  std::string input(buffer, bytes_received);
  if (parseHeader(input, header, value)) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "recv header: %s with value %s\n", header.c_str(), value.c_str());
    if (0 == header.compare("tts-latency-ms")) elevenlabs_set_reported_latency(handle, value.c_str());
    else if (0 == header.compare("request-id")) elevenlabs_set_request_id(handle, value.c_str());
    else if (0 == header.compare("history-item-id")) elevenlabs_set_history_item_id(handle, value.c_str());
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "header_callback: %s\n", input.c_str());
    if (input.rfind(prefix, 0) == 0) {
      try {
        int response_code = extract_response_code(input);
        elevenlabs_set_response_code(handle, response_code);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "header_callback: parsed response code: %d\n", response_code);
      } catch (const std::invalid_argument& e) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "header_callback: invalid response code %s\n", input.substr(prefix.length()).c_str());
      }
    }
  }
  return bytes_received;
}

/* CURLOPT_OPENSOCKETFUNCTION */
static curl_socket_t opensocket(void *clientp, curlsocktype purpose, struct curl_sockaddr *address) {
  curl_socket_t sockfd = CURL_SOCKET_BAD;

  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "opensocket: %d\n", purpose);
  /* restrict to IPv4 */
  if(purpose == CURLSOCKTYPE_IPCXN && address->family == AF_INET) {
    /* create a tcp socket object */
    boost::asio::ip::tcp::socket *tcp_socket = new boost::asio::ip::tcp::socket(io_service);

    /* open it and get the native handle*/
    boost::system::error_code ec;
    tcp_socket->open(boost::asio::ip::tcp::v4(), ec);

    if(ec) {
      /* An error occurred */
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Couldn't open socket [%ld][%s]\n", ec, ec.message().c_str());
    }
    else {
      sockfd = tcp_socket->native_handle();

      /* save it for monitoring */
      socket_map.insert(std::pair<curl_socket_t, boost::asio::ip::tcp::socket *>(sockfd, tcp_socket));
    }
  }
  return sockfd;
}

/* CURLOPT_CLOSESOCKETFUNCTION */
static int close_socket(void *clientp, curl_socket_t item) {
  //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "close_socket : %#X\n", item);

  std::map<curl_socket_t, boost::asio::ip::tcp::socket *>::iterator it = socket_map.find(item);
  if(it != socket_map.end()) {
    delete it->second;
    socket_map.erase(it);
  }
  return 0;
}

static void threadFunc() {      
  /* to make sure the event loop doesn't terminate when there is no work to do */
  io_service.reset() ;
  boost::asio::io_service::work work(io_service);
  
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_elevenlabs_tts threadFunc - starting\n");

  for(;;) {
      
    try {
      io_service.run() ;
      break ;
    }
    catch( std::exception& e) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_elevenlabs_tts threadFunc - Error: %s\n", e.what());
    }
  }
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_elevenlabs_tts threadFunc - ending\n");
}

/* C api bindings */

extern "C" {
	switch_status_t elevenlabs_speech_load() {
    memset(&global, 0, sizeof(GlobalInfo_t));

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "elevenlabs_speech_loadng..\n");

    global.multi = curl_multi_init();

    if (!global.multi) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "curl_multi_init() failed, exiting!\n");
      return SWITCH_STATUS_FALSE;
    }

    curl_multi_setopt(global.multi, CURLMOPT_SOCKETFUNCTION, sock_cb);
    curl_multi_setopt(global.multi, CURLMOPT_SOCKETDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERFUNCTION, multi_timer_cb);
    curl_multi_setopt(global.multi, CURLMOPT_TIMERDATA, &global);
    curl_multi_setopt(global.multi, CURLMOPT_PIPELINING, CURLPIPE_MULTIPLEX);

    /* create temp folder for cache files */
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) {
      baseDir = "/tmp/";
    }
    if (strcmp(baseDir, "/") == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", baseDir);
      return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    // Create the directory with read, write, and execute permissions for everyone
    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);
    if (result != 0) {
      if (errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", fullDirPath.c_str());
        fullDirPath = "";
      }
      else switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "folder %s already exists\n", fullDirPath.c_str());
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "created folder %s\n", fullDirPath.c_str());
    }

    /* start worker thread that handles transfers*/
    std::thread t(threadFunc) ;
    worker_thread.swap( t ) ;

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "elevenlabs_speech_loaded..\n");

    return SWITCH_STATUS_SUCCESS;
	}

	switch_status_t elevenlabs_speech_unload() {
    /* stop the ASIO IO service */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "elevenlabs_speech_unload: stopping io service\n");
    io_service.stop();

    /* Join the worker thread */
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "elevenlabs_speech_unload: wait for worker thread to complete\n");
    if (worker_thread.joinable()) {
        worker_thread.join();
    }

    /* cleanup curl multi handle*/
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "elevenlabs_speech_unload: release curl multi\n");
    curl_multi_cleanup(global.multi);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "elevenlabs_speech_unload: completed\n");
    
    /*
    if (!fullDirPath.empty()) {
      if (removeDirectory(fullDirPath)) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "elevenlabs_speech_unload: removed folder %s\n", fullDirPath.c_str());
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "elevenlabs_speech_unload: failed to remove folder %s\n", fullDirPath.c_str());
      }
    }
    */

		return SWITCH_STATUS_SUCCESS;
	}

	switch_status_t elevenlabs_speech_open(elevenlabs_handle_t handle) {
		return SWITCH_STATUS_SUCCESS;
	}

	switch_status_t elevenlabs_speech_feed_tts(elevenlabs_handle_t handle, char* text, switch_speech_flag_t *flags) {
    auto p = elevenlabs_get_shared_ptr(handle);
    elevenlabs_retain(handle);
    CURLMcode rc;
    const int MAX_CHARS = 20;
    char tempText[MAX_CHARS + 4]; // +4 for the ellipsis and null terminator

    if (strlen(text) > MAX_CHARS) {
        strncpy(tempText, text, MAX_CHARS);
        strcpy(tempText + MAX_CHARS, "...");
    } else {
        strcpy(tempText, text);
    }

    /* generate cache filename if needed */
    if (elevenlabs_is_cache_audio(handle) && fullDirPath.length() > 0) {
      switch_uuid_t uuid;
      char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
      char outfile[512] = "";

      switch_uuid_get(&uuid);
      switch_uuid_format(uuid_str, &uuid);

      switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
      elevenlabs_set_cache_filename(handle, outfile);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cache file will be: %s\n", outfile);
    }

    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "elevenlabs_speech_feed_tts: text %s\n", text);

    const char *api_key = elevenlabs_get_api_key(handle);
    if (!api_key || strlen(api_key) == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "eevenlabs_speech_feed_tts: no api_key provided\n");
      return SWITCH_STATUS_FALSE;
    }
    const char *model_id = elevenlabs_get_model_id(handle);
    if (!model_id || strlen(model_id) == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "elevenlabs_speech_feed_tts: no model_id provided\n");
      return SWITCH_STATUS_FALSE;
    }

    /* format url*/
    const char *voice_name = elevenlabs_get_voice_name(handle);
    const char *optimize_streaming_latency = elevenlabs_get_optimize_streaming_latency(handle);
    std::string url;
    std::ostringstream url_stream;
    const char *api_uri = elevenlabs_get_api_uri(handle);
    api_uri = (api_uri && strlen(api_uri) > 0) ? api_uri : "api.elevenlabs.io";
    url_stream  << "https://"
                << api_uri
                << "/v1/text-to-speech/"
                << (voice_name ? voice_name : "")
                << "/stream?output_format=ulaw_8000";
    // some latest models from elevenlabs (elevenlabs_v3) do not allow optimize_streaming_latency
    if (optimize_streaming_latency && strlen(optimize_streaming_latency) > 0) {
       url_stream << "&optimize_streaming_latency=" << optimize_streaming_latency;
    }
    url = url_stream.str();

    /* create the JSON body */
    cJSON * jResult = cJSON_CreateObject();
    cJSON_AddStringToObject(jResult, "model_id", model_id);
    cJSON_AddStringToObject(jResult, "text", text);
    const char *previous_text = elevenlabs_get_previous_text(handle);
    if (previous_text && strlen(previous_text) > 0) {
      cJSON_AddStringToObject(jResult, "previous_text", previous_text);
    }
    const char *next_text = elevenlabs_get_next_text(handle);
    if (next_text && strlen(next_text) > 0) {
      cJSON_AddStringToObject(jResult, "next_text", next_text);
    }
    const char *pronunciation_dictionary_locators = elevenlabs_get_pronunciation_dictionary_locators(handle);
    if (pronunciation_dictionary_locators && strlen(pronunciation_dictionary_locators) > 0) {
      cJSON *jPronunciationDictionaryLocators = cJSON_Parse(pronunciation_dictionary_locators);
      if (jPronunciationDictionaryLocators) {
        cJSON_AddItemToObject(jResult, "pronunciation_dictionary_locators", jPronunciationDictionaryLocators);
      } else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "elevenlabs_speech_feed_tts: failed to parse pronunciation dictionary locators %s\n", pronunciation_dictionary_locators);
      }
    }
    const char *similarity_boost = elevenlabs_get_similarity_boost(handle);
    const char *style = elevenlabs_get_style(handle);
    const char *use_speaker_boost = elevenlabs_get_use_speaker_boost(handle);
    const char *stability = elevenlabs_get_stability(handle);
    const char *speed = elevenlabs_get_speed(handle);
    if ((similarity_boost && strlen(similarity_boost) > 0) || 
        (style && strlen(style) > 0) || 
        (use_speaker_boost && strlen(use_speaker_boost) > 0) || 
        (stability && strlen(stability) > 0) || 
        (speed && strlen(speed) > 0)) {
      cJSON * jVoiceSettings = cJSON_CreateObject();
      cJSON_AddItemToObject(jResult, "voice_settings", jVoiceSettings);
      if (similarity_boost && strlen(similarity_boost) > 0) {
        cJSON_AddStringToObject(jVoiceSettings, "similarity_boost", similarity_boost);
      }
      if (style && strlen(style) > 0) {
        cJSON_AddStringToObject(jVoiceSettings, "style", style);
      }
      if (use_speaker_boost && strlen(use_speaker_boost) > 0) {
        cJSON_AddStringToObject(jVoiceSettings, "use_speaker_boost", use_speaker_boost);
      }
      if (stability && strlen(stability) > 0) {
        cJSON_AddStringToObject(jVoiceSettings, "stability", stability);
      }
      if (speed && strlen(speed) > 0) {
        cJSON_AddNumberToObject(jVoiceSettings, "speed", atof(speed));
      }
    }
    char *json = cJSON_PrintUnformatted(jResult);;

    cJSON_Delete(jResult);

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "elevenlabs_speech_feed_tts: [%s] [%s]\n", url.c_str(), tempText);
    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "elevenlabs_speech_feed_tts: %s\n", json);

    ConnInfo_t *conn = new ConnInfo_t();
    memset(conn, 0, sizeof(ConnInfo_t));

    //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "allocated Conn %p\n", conn);

    CURL* easy = createEasyHandle();

    elevenlabs_set_connection(handle, (void *) conn);
    conn->handle = handle;
    conn->easy = easy;
    conn->global = &global;
    conn->hdr_list = NULL ;
    conn->body = json;
    conn->flushed = false;

    auto playoutBuffer = new CircularBuffer(8192);
    auto audioPlayer = new AudioPlayer(p->getMutex(), playoutBuffer);
    int rate = elevenlabs_get_rate(handle);
    audioPlayer->setResampling(8000, rate);

    const char *cache_filename = elevenlabs_get_cache_filename(handle);
    if (cache_filename && strlen(cache_filename) > 0) {
      audioPlayer->setCacheFilePath(cache_filename);
    }

    elevenlabs_set_playout_buffer(handle, (void *) playoutBuffer);
    elevenlabs_set_audio_player(handle, (void *) audioPlayer);

    std::ostringstream api_key_stream;
    api_key_stream << "xi-api-key: " << api_key;

    curl_easy_setopt(easy, CURLOPT_URL, url.c_str());
    curl_easy_setopt(easy, CURLOPT_WRITEFUNCTION, write_cb);
    curl_easy_setopt(easy, CURLOPT_WRITEDATA, conn);
    curl_easy_setopt(easy, CURLOPT_ERRORBUFFER, conn->error);
    curl_easy_setopt(easy, CURLOPT_PRIVATE, conn);
    curl_easy_setopt(easy, CURLOPT_VERBOSE, 0L);
    curl_easy_setopt(easy, CURLOPT_NOPROGRESS, 1L);
    curl_easy_setopt(easy, CURLOPT_HEADERFUNCTION, header_callback);
    curl_easy_setopt(easy, CURLOPT_HEADERDATA, conn);
    
    /* call this function to get a socket */
    curl_easy_setopt(easy, CURLOPT_OPENSOCKETFUNCTION, opensocket);

    /* call this function to close a socket */
    curl_easy_setopt(easy, CURLOPT_CLOSESOCKETFUNCTION, close_socket);

    conn->hdr_list = curl_slist_append(conn->hdr_list, api_key_stream.str().c_str());
    conn->hdr_list = curl_slist_append(conn->hdr_list, "Content-Type: application/json");
    curl_easy_setopt(easy, CURLOPT_HTTPHEADER, conn->hdr_list);

    curl_easy_setopt(easy, CURLOPT_POSTFIELDS, conn->body);
    //curl_easy_setopt(easy, CURLOPT_POSTFIELDSIZE, body.length());

    // libcurl adding random byte to the response body that creates white noise to audio file
    // https://github.com/curl/curl/issues/10525
    const bool disable_http_2 = switch_true(std::getenv("DISABLE_HTTP2_FOR_TTS_STREAMING"));
    curl_easy_setopt(easy, CURLOPT_HTTP_VERSION, disable_http_2 ? CURL_HTTP_VERSION_1_1 : CURL_HTTP_VERSION_2_0);

    // Protect concurrent access to curl multi handle
    std::lock_guard<std::mutex> lock(curl_mutex);
    rc = curl_multi_add_handle(global.multi, conn->easy);
    mcode_test("new_conn: curl_multi_add_handle", rc);

    /* start a timer to measure the duration until we receive first byte of audio */
    conn->startTime = std::chrono::high_resolution_clock::now();

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "elevenlabs_speech_feed_tts: called curl_multi_add_handle\n");

    /* note that the add_handle() will set a time-out to trigger very soon so
       that the necessary socket_action() call will be called by this app */



		return SWITCH_STATUS_SUCCESS;
	}

  switch_status_t elevenlabs_speech_read_tts(elevenlabs_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    auto p = elevenlabs_get_shared_ptr(handle);
    CircularBuffer *playoutBuffer = (CircularBuffer *) elevenlabs_get_playout_buffer(handle);
    int samplesToCopy = 0;

    if (!p) {
      memset(data, 255, *datalen);
      return SWITCH_STATUS_SUCCESS;
    }

    {
      std::lock_guard<std::mutex> lock(p->getMutex());
      ConnInfo_t *conn = (ConnInfo_t *) elevenlabs_get_connection(handle);
      long response_code = elevenlabs_get_response_code(handle);
      if (response_code > 0 && response_code != 200) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "elevenlabs_speech_read_tts, returning failure\n");
        return SWITCH_STATUS_FALSE;
      }

      if (conn && conn->flushed) {
        return SWITCH_STATUS_BREAK;
      }

      if (playoutBuffer->size() == 0) {
        if (elevenlabs_is_draining(handle)) {
          return SWITCH_STATUS_BREAK;
        }
        /* no audio available yet so send silence */
        memset(data, 255, *datalen);
        return SWITCH_STATUS_SUCCESS;
      }
      samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(*datalen / sizeof(int16_t)));

      auto count = playoutBuffer->getBlock(reinterpret_cast<int16_t*>(data), samplesToCopy);
      if (count != samplesToCopy) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "elevenlabs_speech_read_tts - failed to get %d samples from playout buffer, got %d\n", samplesToCopy, count);
      }
      *datalen = count * sizeof(int16_t);
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t elevenlabs_speech_flush_tts(elevenlabs_handle_t handle) {
    auto p = elevenlabs_get_shared_ptr(handle);
    long response_code = elevenlabs_get_response_code(handle);
    bool download_complete = response_code == 200;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "elevenlabs_speech_flush_tts, download complete? %s\n", download_complete ? "yes" : "no") ;

    ConnInfo_t *conn = nullptr;
    {
      std::lock_guard<std::mutex> lock(curl_mutex);
      conn = (ConnInfo_t *) elevenlabs_get_connection(handle);
      if (conn) {
        conn->flushed = true;  // Set this while we have curl_mutex
      }
    }

    // Extract pointers while holding lock, then delete outside lock to avoid deadlock
    // The consumer thread needs p->getMutex() to finish, so we can't hold it during thread join
    AudioPlayer* audioPlayer = nullptr;
    CircularBuffer* playoutBuffer = nullptr;

    if (p) {
      std::lock_guard<std::mutex> lock(p->getMutex());

      // Get pointers and clear them while holding lock
      if (elevenlabs_get_audio_player(handle)) {
        audioPlayer = static_cast<AudioPlayer*>(elevenlabs_get_audio_player(handle));
        elevenlabs_set_audio_player(handle, nullptr);  // Clear pointer first
      }

      if (elevenlabs_get_playout_buffer(handle)) {
        playoutBuffer = static_cast<CircularBuffer*>(elevenlabs_get_playout_buffer(handle));
        elevenlabs_set_playout_buffer(handle, nullptr);  // Clear pointer first
      }
    }  // Release p->getMutex() here - consumer thread can now finish and exit

    // Delete outside the lock - this allows consumer thread to complete its work and exit
    if (audioPlayer) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "destroying audio player\n");
      delete audioPlayer;  // This closes the cache file after consumer thread finishes
    }

    if (playoutBuffer) {
      delete playoutBuffer;
    }

    // If playback_start has not been sent, delete the file
    const char *cache_filename = elevenlabs_get_cache_filename(handle);
    if (cache_filename && strlen(cache_filename) > 0 && !elevenlabs_is_playback_start_sent(handle)) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "removing audio cache file %s because download was interrupted\n", cache_filename);
      if (unlink(cache_filename) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "cleanupConn: error removing audio cache file %s: %d:%s\n", 
          cache_filename, errno, strerror(errno));
      }
      elevenlabs_set_cache_filename(handle, "");
    }
    const char *session_id = elevenlabs_get_session_id(handle);
    if (session_id && strlen(session_id) > 0) {
      switch_core_session_t* session = switch_core_session_locate(session_id);
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);
        if (channel) {
          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);
            const char *playback_id = elevenlabs_get_playback_id(handle);
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "write_cb: firing playback-stopped %s\n", (playback_id && strlen(playback_id) > 0) ? playback_id : "no-playback-id");
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (playback_id && strlen(playback_id) > 0) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
            }
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_elevenlabs_response_code", std::to_string(response_code).c_str());
            cache_filename = elevenlabs_get_cache_filename(handle);
            if (cache_filename && strlen(cache_filename) > 0 && response_code == 200) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);
            }
            const char *error_message = elevenlabs_get_error_message(handle);
            if (response_code != 200 && error_message && strlen(error_message) > 0) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", error_message);
            }
            switch_event_fire(&event);
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: failed to create event\n");
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: channel not found\n");
        }
        switch_core_session_rwunlock(session);
      }
    }
    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t elevenlabs_speech_close(elevenlabs_handle_t handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "elevenlabs_speech_close\n") ;
		return SWITCH_STATUS_SUCCESS;
	}
}
