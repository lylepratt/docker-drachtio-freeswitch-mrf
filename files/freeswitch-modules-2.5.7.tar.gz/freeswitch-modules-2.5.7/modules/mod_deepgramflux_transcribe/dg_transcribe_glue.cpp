#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <mutex>
#include <thread>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>
#include <memory>

#include "mod_deepgramflux_transcribe.h"
// #include "jambonz/parser.hpp"
#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/
#define DEEPGRAMFLUX_KEEP_ALIVE_INTERVAL_SECOND 8

namespace {
  static bool hasDefaultCredentials = false;
  static const char* defaultApiKey = nullptr;
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static const char *deepgramFluxUri = std::getenv("MOD_DEEPGRAMFLUX_URI");
  static unsigned int idxCallCount = 0;
  static uint32_t playCount = 0;

  static std::shared_ptr<deepgramflux::AudioPipe> getAP(void *pAudioPipe) {
    if (pAudioPipe) {
      auto pAp = reinterpret_cast<std::shared_ptr<deepgramflux::AudioPipe>*>(pAudioPipe);
      return *pAp;
    }
    return nullptr;
  }

  static bool isEmptyTranscript(const char* message) {
    return strstr(message, "\"event\":\"Update\"") && strstr(message, "\"transcript\":\"\"");
  }

  static int split_string(const char* input, char delimiter, char* output[], int max_tokens) {
    int count = 0;
    const char* start = input;
    const char* end = strchr(start, delimiter);
    
    while (end != nullptr && count < max_tokens) {
      int length = end - start;
      output[count] = new char[length + 1];
      strncpy(output[count], start, length);
      output[count][length] = '\0';
      count++;
      
      start = end + 1;
      end = strchr(start, delimiter);
    }
    
    // Add the last token if there's room
    if (count < max_tokens && *start != '\0') {
      output[count] = new char[strlen(start) + 1];
      strcpy(output[count], start);
      count++;
    }

    return count;
  }

  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      if (tech_pvt->pAudioPipe) {
        // Initiate graceful shutdown if connected
        auto pAp = getAP(tech_pvt->pAudioPipe);
        if (pAp && pAp->getLwsState() == deepgramflux::AudioPipe::LWS_CLIENT_CONNECTED) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "%s (%u) initiating graceful close\n", tech_pvt->sessionId, tech_pvt->id);
          pAp->finish();
        }
        // release our shared_ptr; lws maintains a shared_ptr in per-connection data until it gets close event
        delete reinterpret_cast<std::shared_ptr<deepgramflux::AudioPipe>*>(tech_pvt->pAudioPipe);
        tech_pvt->pAudioPipe = nullptr;
      }
      if (tech_pvt->resampler) {
          speex_resampler_destroy(tech_pvt->resampler);
          tech_pvt->resampler = NULL;
      }
    }
  }

  std::string encodeURIComponent(std::string decoded)
  {

      std::ostringstream oss;
      std::regex r("[!'\\(\\)*-.0-9A-Za-z_~:]");

      for (char &c : decoded)
      {
          if (std::regex_match((std::string){c}, r))
          {
              oss << c;
          }
          else
          {
              oss << "%" << std::uppercase << std::hex << (0xff & c);
          }
      }
      return oss.str();
  }

  std::string& constructPath(switch_core_session_t* session, std::string& path, 
    int sampleRate, int channels, const char* language, int interim) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    const char *var ;
    const char *eot_threshold = switch_channel_get_variable(channel, "DEEPGRAMFLUX_SPEECH_EOT_THRESHOLD");
    const char *eot_timeout_ms = switch_channel_get_variable(channel, "DEEPGRAMFLUX_SPEECH_EOT_TIMEOUT_MS");
    const char *mip_opt_out = switch_channel_get_variable(channel, "DEEPGRAMFLUX_SPEECH_MIP_OPT_OUT");
    const char *model = switch_channel_get_variable(channel, "DEEPGRAMFLUX_SPEECH_MODEL");
    const char *eager_eot_threshold = switch_channel_get_variable(channel, "DEEPGRAMFLUX_SPEECH_EAGER_EOT_THRESHOLD");
    const char *keyterms = switch_channel_get_variable(channel, "DEEPGRAMFLUX_SPEECH_KEYTERMS");
    std::ostringstream oss;

    oss << "/v2/listen?sample_rate=8000" << "&encoding=linear16&model=" << model;
    if (eot_threshold) {
      oss << "&eot_threshold=" << eot_threshold;
    }
    if (eot_timeout_ms) {
      oss << "&eot_timeout_ms=" << eot_timeout_ms;
    }
    if (mip_opt_out) {
      oss << "&mip_opt_out=" << mip_opt_out;
    }
    if (eager_eot_threshold) {
      oss << "&eager_eot_threshold=" << eager_eot_threshold;
    }
    if (keyterms) {
      // deepgram keyterms just support 100 words
      char *phrases[100] = { 0 };
      int argc = split_string((char *)keyterms, ',', phrases, 100);
      for (int i = 0; i < argc; i++) {
       oss <<  "&keyterm=";
       oss <<  encodeURIComponent(phrases[i]);
      }
    }
   path = oss.str();
   return path;
  }

  static bool eventCallback(const char* sessionId, const char* bugname,
    deepgramflux::AudioPipe::NotifyEvent_t event, const char* message, bool finished) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case deepgramflux::AudioPipe::CONNECT_SUCCESS:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) successful\n", tech_pvt->bugname);
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_SUCCESS, NULL, tech_pvt->bugname, finished);
            break;
            case deepgramflux::AudioPipe::CONNECT_FAIL:
            {
              std::stringstream json;
              json << "{\"reason\":\"" << message << "\"}";
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_CONNECT_FAIL, (char *) json.str().c_str(), tech_pvt->bugname, finished);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
            }
            break;
            case deepgramflux::AudioPipe::CONNECTION_DROPPED:

              /**
               * this is a bit tricky.  If we just closed a previous connection it may be returning final transcripts
               * In this scenario, the fact that the connection is dropped is not significant.
               */
              if (finished) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "old connection (%s) gracefully closed by Deepgram\n", tech_pvt->bugname);
              }
              else {
                if (message && strlen(message) > 0) {
                  tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_ERROR, (char *) message, tech_pvt->bugname, finished);
                }
                tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_DISCONNECT, NULL, tech_pvt->bugname, finished);
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) dropped from far end\n", tech_pvt->bugname);
              }
            break;
            case deepgramflux::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
            break;
            case deepgramflux::AudioPipe::MESSAGE:
              if (strstr(message, "\"type\":\"Connected\"")) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got Connected message\n");
                tech_pvt->turn_state = INITIAL;
                break;
              }
              if (strstr(message, "\"event\":\"StartOfTurn\"")) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got StartOfTurn message\n");
                tech_pvt->turn_state = TURN_ONGOING;
              }
              if (strstr(message, "\"event\":\"EagerEndOfTurn\"")) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got EagerEndOfTurn message\n");
                tech_pvt->turn_state = AWAITING_END;
              }
              if (strstr(message, "\"event\":\"TurnResumed\"")) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got TurnResumed message\n");
                tech_pvt->turn_state = TURN_ONGOING;
              }
              if (strstr(message, "\"event\":\"EndOfTurn\"")) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "got EndOfTurn message\n");
                tech_pvt->turn_state = INITIAL;
              }
              
              if(!isEmptyTranscript(message)) {
                tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_RESULTS, message, tech_pvt->bugname, finished);
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "deepgramflux message (%s): %s\n", tech_pvt->bugname, message);
              }
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from deepgramflux %d:%s\n", event, message);
              break;
          }
        }
      }
      switch_core_session_rwunlock(session);
      return true;  // Session found and processed
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "session %s gone, event %d:%s\n", sessionId, event, message);
      return false; // Session gone
    }
  }
  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, 
    int sampling, int desiredSampling, int channels, char *lang, int interim, 
    char* bugname, responseHandler_t responseHandler) {

    int err;
    int useTls = true;
    // Use the environment variable if set, otherwise use default host
    std::string host = deepgramFluxUri ? deepgramFluxUri : "api.deepgram.com";
    int port = 443;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * desiredSampling / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_codec_implementation_t read_impl;
    switch_channel_t *channel = switch_core_session_get_channel(session);

    switch_core_session_get_read_impl(session, &read_impl);
    const char* model = switch_channel_get_variable(channel, "DEEPGRAMFLUX_SPEECH_MODEL");
    if (!model) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no deepgramflux model provided\n");
      return SWITCH_STATUS_FALSE;
    }
    const char* apiKey = switch_channel_get_variable(channel, "DEEPGRAMFLUX_API_KEY");
    if (!apiKey && defaultApiKey) {
      apiKey = defaultApiKey;
    } else if (!apiKey) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "no deepgramflux api key provided\n");
      return SWITCH_STATUS_FALSE;
    }
  
    std::string path;
    constructPath(session, path, desiredSampling, channels, lang, interim);
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "path: %s\n", path.c_str());

    if (tech_pvt->pAudioPipe) {
      auto pAp = reinterpret_cast<std::shared_ptr<deepgramflux::AudioPipe>*>(tech_pvt->pAudioPipe);
      std::shared_ptr<deepgramflux::AudioPipe> pAudioPipe = *pAp;

      // Clean up the old connection - initiate graceful close if connected
      if (pAudioPipe->getLwsState() == deepgramflux::AudioPipe::LWS_CLIENT_CONNECTED) {
        pAudioPipe->finish();
      }

      // Delete the old shared_ptr
      delete reinterpret_cast<std::shared_ptr<deepgramflux::AudioPipe>*>(tech_pvt->pAudioPipe);
      tech_pvt->pAudioPipe = nullptr;
    } else {
      memset(tech_pvt, 0, sizeof(private_t));
    }

    tech_pvt->turn_state = INITIAL;
    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->host, host.c_str(), MAX_WS_URL_LEN);
    tech_pvt->port = port;
    strncpy(tech_pvt->path, path.c_str(), MAX_PATH_LEN);
    tech_pvt->sampling = desiredSampling;
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->channels = channels;
    tech_pvt->id = ++idxCallCount;
    tech_pvt->buffer_overrun_notified = 0;
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    if (!tech_pvt->mutex) {
      switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));
    }
    if (!tech_pvt->resampler) {
      if (desiredSampling != sampling) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) resampling from %u to %u\n", tech_pvt->id, sampling, desiredSampling);
        tech_pvt->resampler = speex_resampler_init(channels, sampling, desiredSampling, SWITCH_RESAMPLE_QUALITY, &err);
        if (0 != err) {
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error initializing resampler: %s.\n", speex_resampler_strerror(err));
          return SWITCH_STATUS_FALSE;
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) no resampling needed for this call\n", tech_pvt->id);
      }
    }

    // Create AudioPipe with shared_ptr for proper lifecycle management
    auto apShared = std::make_shared<deepgramflux::AudioPipe>(tech_pvt->sessionId, bugname, tech_pvt->host, tech_pvt->port, tech_pvt->path,
      buflen, read_impl.decoded_bytes_per_packet, apiKey, useTls, eventCallback);
    if (!apShared) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }

    // Store the shared_ptr itself (not the raw pointer)
    tech_pvt->pAudioPipe = new std::shared_ptr<deepgramflux::AudioPipe>(apShared);

    tech_pvt->initialized = 1;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connecting to deepgram now\n");
    apShared->connect();
    //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {
  switch_status_t dg_transcribe_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_deepgramflux_transcribe: audio buffer (in secs):    %d secs\n", nAudioBufferSecs);
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    deepgramflux::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		const char* apiKey = std::getenv("DEEPGRAMFLUX_API_KEY");
		if (NULL == apiKey) {
			switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, 
				"\"DEEPGRAMFLUX_API_KEY\" env var not set; authentication will expect channel variables of same names to be set\n");
		}
		else {
			hasDefaultCredentials = true;
      defaultApiKey = apiKey;
		}
		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t dg_transcribe_cleanup() {
    bool cleanup = false;
    cleanup = deepgramflux::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }
	
  switch_status_t dg_transcribe_session_init(switch_core_session_t *session,
    responseHandler_t responseHandler, uint32_t samples_per_second, uint32_t channels,
    char* lang, int interim, char* bugname, void **ppUserData)
  {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    private_t* tech_pvt;
    if (bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "reuse existing deepgramflux connection\n");
      tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    } else {
      tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
      tech_pvt->initialized = 0;
      tech_pvt->pAudioPipe = NULL;
      tech_pvt->mutex = NULL;
      tech_pvt->resampler = NULL;
    }

    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second, 8000, channels, lang, interim, bugname, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;

    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t dg_transcribe_session_stop(switch_core_session_t *session,int channelIsClosing, char* bugname) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "dg_transcribe_session_stop: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    uint32_t id = tech_pvt->id;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) dg_transcribe_session_stop\n", id);

    if (!tech_pvt) return SWITCH_STATUS_FALSE;

    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);
    switch_channel_set_private(channel, bugname, NULL);
    if (!channelIsClosing) switch_core_media_bug_remove(session, &bug);

    destroy_tech_pvt(tech_pvt);
    switch_mutex_unlock(tech_pvt->mutex);
    /* mutex allocated from session pool - automatically cleaned up */
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "(%u) dg_transcribe_session_stop\n", id);
    return SWITCH_STATUS_SUCCESS;
  }
	
	switch_bool_t dg_transcribe_frame(switch_core_session_t *session, switch_media_bug_t *bug) {
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    bool dirty = false;
    char *p = (char *) "{\"msg\": \"buffer overrun\"}";

    if (!tech_pvt || !tech_pvt->initialized) return SWITCH_TRUE;

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      if (!tech_pvt->pAudioPipe) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      auto pAudioPipe = getAP(tech_pvt->pAudioPipe);
      if (!pAudioPipe || pAudioPipe->getLwsState() != deepgramflux::AudioPipe::LWS_CLIENT_CONNECTED) {
        switch_mutex_unlock(tech_pvt->mutex);
        return SWITCH_TRUE;
      }
      pAudioPipe->lockAudioBuffer();
      size_t available = pAudioPipe->binarySpaceAvailable();
      if (NULL == tech_pvt->resampler) {
        switch_frame_t frame = { 0 };
        frame.data = pAudioPipe->binaryWritePtr();
        frame.buflen = available;
        while (true) {

          // check if buffer would be overwritten; dump packets if so
          if (available < pAudioPipe->binaryMinSpace()) {
            if (!tech_pvt->buffer_overrun_notified) {
              tech_pvt->buffer_overrun_notified = 1;
              tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
            }
            switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_WARNING, "(%u) dropping packets!\n", 
              tech_pvt->id);
            pAudioPipe->binaryWritePtrResetToZero();

            frame.data = pAudioPipe->binaryWritePtr();
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          }

          switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
          if (rv != SWITCH_STATUS_SUCCESS) break;
          if (frame.datalen) {
            pAudioPipe->binaryWritePtrAdd(frame.datalen);
            frame.buflen = available = pAudioPipe->binarySpaceAvailable();
            frame.data = pAudioPipe->binaryWritePtr();
            dirty = true;
          }
        }
      }
      else {
        uint8_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        switch_frame_t frame = { 0 };
        frame.data = data;
        frame.buflen = SWITCH_RECOMMENDED_BUFFER_SIZE;
        while (switch_core_media_bug_read(bug, &frame, SWITCH_TRUE) == SWITCH_STATUS_SUCCESS) {
          if (frame.datalen) {
            spx_uint32_t out_len = available >> 1;  // space for samples which are 2 bytes
            spx_uint32_t in_len = frame.samples;
            speex_resampler_process_interleaved_int(tech_pvt->resampler, 
              (const spx_int16_t *) frame.data, 
              (spx_uint32_t *) &in_len, 
              (spx_int16_t *) ((char *) pAudioPipe->binaryWritePtr()),
              &out_len);

            if (out_len > 0) {
              // bytes written = num samples * 2 * num channels
              size_t bytes_written = out_len << tech_pvt->channels;
              pAudioPipe->binaryWritePtrAdd(bytes_written);
              available = pAudioPipe->binarySpaceAvailable();
              dirty = true;
            }
            if (available < pAudioPipe->binaryMinSpace()) {
              if (!tech_pvt->buffer_overrun_notified) {
                tech_pvt->buffer_overrun_notified = 1;
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_WARNING, "(%u) dropping packets!\n", 
                  tech_pvt->id);
                tech_pvt->responseHandler(session, TRANSCRIBE_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname, 0);
              }
              break;
            }
          }
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}
