# mod_google_s2s

A Freeswitch module that integrates with Google Gemini speech-to-speech api

## API

### Commands
The freeswitch module exposes the following API commands:

```
uuid_google_s2s <uuid> session.create apiKey
```
where:
- apiKey: Google Gemini api key

This api call establishes a websocket connection to the Google Gemini endpoint (generativelanguage.googleapis.com).  If the connection is successfully established, which the caller will know through the 'google_s2s::connect' event, then the caller must next send a `client.event` client event with the [BidiGenerateContentSetup](https://ai.google.dev/api/live#bidigeneratecontentsetup) json payload

```
uuid_google_s2s <uuid> client.event client-event-json
```
where
- client-event-json: a json string conforming to the [syntax described here](https://ai.google.dev/api/live).

```
uuid_google_s2s <uuid> session.delete
```
Ends the session.

### Events
This module fires the following events:
- google_s2s::connect - fired when the websocket connection is established
- google_s2s::connect_failed - fired if the websocket connection fails
- google_s2s::disconnect - fired when when the connection is dropped from far end
- google_s2s::server_event - fired when a message is received from the server 

