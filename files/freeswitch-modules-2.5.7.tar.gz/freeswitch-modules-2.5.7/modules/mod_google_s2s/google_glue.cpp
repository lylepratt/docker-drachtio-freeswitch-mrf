#include <switch.h>
#include <switch_json.h>
#include <string.h>
#include <string>
#include <list>
#include <algorithm>
#include <functional>
#include <cassert>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <regex>
#include <iostream>
#include <unordered_map>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <atomic>
#include <cstring>

#include <boost/algorithm/string/replace.hpp>

#include "mod_google_s2s.h"
#include "jambonz/simple_json_parser.hpp"
#include "jambonz/vector_math.h"
#include "jambonz/circular_buffer.h"
#include "jambonz/audio_player.hpp"

#include "audio_pipe.hpp"

#define RTP_PACKETIZATION_PERIOD 20
#define FRAME_SIZE_8000  320 /*which means each 20ms frame as 320 bytes at 8 khz (1 channel only)*/
#define BUFFER_GROW_SIZE (16384)

namespace {
  static const char *requestedBufferSecs = std::getenv("MOD_AUDIO_FORK_BUFFER_SECS");
  static int nAudioBufferSecs = std::max(1, std::min(requestedBufferSecs ? ::atoi(requestedBufferSecs) : 2, 5));
  static const char *requestedNumServiceThreads = std::getenv("MOD_AUDIO_FORK_SERVICE_THREADS");
  static unsigned int idxCallCount = 0;
  static uint32_t playCount = 0;


  static void destroy_tech_pvt(private_t *tech_pvt) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "%s (%u) destroy_tech_pvt\n", tech_pvt->sessionId, tech_pvt->id);
    if (tech_pvt) {
      if (tech_pvt->audioPlayer) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "destroying audio player\n");
        AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
        delete p;
        tech_pvt->audioPlayer = nullptr;
      }
      if (tech_pvt->playoutBuffer) {
        CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;
        delete playoutBuffer;
        tech_pvt->playoutBuffer = nullptr;
      }
      /* mutex allocated from session pool - automatically cleaned up */
    }
  }

  static void processIncomingAudio(private_t* tech_pvt, switch_core_session_t* session, const char* data, size_t len) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "received %u bytes incoming audio\n", len);
    p->bufferAudio(data, len);
  }

  static void handleInterruption(private_t* tech_pvt, switch_core_session_t* session) {
    AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
    p->clear(false);
    // note: with openai_s2s we would now send a response.cancel message to the server
    // in order to cause it to cancel the request.
    // Deepgram says they will stop sending automatically when they detect the user has started speaking
  }

  static void eventCallback(const char* sessionId, const char* bugname, 
    google_s2s::AudioPipe::NotifyEvent_t event, const char* message, const char* binary, size_t len) {
    switch_core_session_t* session = switch_core_session_locate(sessionId);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
        if (tech_pvt) {
          switch (event) {
            case google_s2s::AudioPipe::BINARY:
              processIncomingAudio(tech_pvt, session, binary, len);
            break;

            case google_s2s::AudioPipe::CONNECT_SUCCESS:
              tech_pvt->state = SESSION_STATE_WS_CONNECTED;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_INFO, "connection (%s) successful\n", tech_pvt->bugname);
              tech_pvt->responseHandler(session, GS2S_EVENT_CONNECT_SUCCESS, NULL, tech_pvt->bugname);
            break;
            case google_s2s::AudioPipe::CONNECT_FAIL:
              tech_pvt->state = SESSION_STATE_NONE;
              {
                // first thing: we can no longer access the AudioPipe
                std::stringstream json;
                json << "{\"reason\":\"" << message << "\"}";
                tech_pvt->pAudioPipe = nullptr;
                tech_pvt->responseHandler(session, GS2S_EVENT_CONNECT_FAIL, (char *) json.str().c_str(), tech_pvt->bugname);
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "connection (%s) failed: %s\n", message, tech_pvt->bugname);
              }
            break;
            case google_s2s::AudioPipe::CONNECTION_DROPPED:
              tech_pvt->state = SESSION_STATE_NONE;

              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              tech_pvt->responseHandler(session, GS2S_EVENT_DISCONNECT, NULL, tech_pvt->bugname);
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) dropped from far end\n", tech_pvt->bugname);
            break;
            case google_s2s::AudioPipe::CONNECTION_CLOSED_GRACEFULLY:
              tech_pvt->state = SESSION_STATE_NONE;

              // first thing: we can no longer access the AudioPipe
              tech_pvt->pAudioPipe = nullptr;
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection (%s) closed gracefully\n", tech_pvt->bugname);
            break;
            case google_s2s::AudioPipe::MESSAGE:
            {
              //switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "google_s2s message: %s\n", message);
              cJSON* json = parse_json_string(session, message) ;
              if (!json) {
                switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "failed to parse json for message %s\n", message);
              }
              else {
                bool forward = true;
                if (cJSON_HasObjectItem(json, "setupComplete")) {
                  forward = false;
                  tech_pvt->state = SESSION_STATE_CONVERSATION_STARTED;
                } else if (cJSON_HasObjectItem(json, "serverContent")) {
                  auto serverContent = cJSON_GetObjectItem(json, "serverContent");
                  if (serverContent) {
                    // Check if serverContent has an interrupted field
                    cJSON* interrupted = cJSON_GetObjectItem(serverContent, "interrupted");
                    if (interrupted && cJSON_IsTrue(interrupted)) {
                      // Handle the interruption
                      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "Detected interruption in serverContent\n");
                      
                      // Call the existing handleInterruption function
                      handleInterruption(tech_pvt, session);
                    }

                    // Check if serverContent has a modelTurn field
                    cJSON* modelTurn = cJSON_GetObjectItem(serverContent, "modelTurn");
                    if (modelTurn && cJSON_IsObject(modelTurn)) {
                      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "Received modelTurn object\n");

                      // The AI is now speaking
                      tech_pvt->assistant_started_speaking = 1;
                      
                      // Check for parts array in modelTurn
                      cJSON* parts = cJSON_GetObjectItem(modelTurn, "parts");
                      if (parts && cJSON_IsArray(parts)) {
                        int partsCount = cJSON_GetArraySize(parts);
                        
                        // Process each part
                        for (int i = 0; i < partsCount; i++) {
                          cJSON* part = cJSON_GetArrayItem(parts, i);
                          cJSON* inlineData = cJSON_GetObjectItem(part, "inlineData");
                          
                          if (inlineData) {
                            cJSON* mimeType = cJSON_GetObjectItem(inlineData, "mimeType");
                            cJSON* data = cJSON_GetObjectItem(inlineData, "data");
                            
                            if (mimeType && cJSON_IsString(mimeType) && data && cJSON_IsString(data)) {
                              const char* mimeTypeStr = mimeType->valuestring;
                              
                              // Check if this is audio data
                              if (strncmp(mimeTypeStr, "audio/pcm", 9) == 0) {
                                // Get the base64 data
                                std::string base64Data = data->valuestring;
                                
                                // Send base64 data directly to the audio player
                                if (tech_pvt->audioPlayer && base64Data.length() > 0) {
                                  AudioPlayer* p = static_cast<AudioPlayer*>(tech_pvt->audioPlayer);
                                  p->bufferAudio(base64Data.c_str(), base64Data.length());
                                }
                                forward = false;
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }

                if (forward) {
                  switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "google_s2s server event (%s): %s\n", tech_pvt->bugname, message);
                  tech_pvt->responseHandler(session, GS2S_EVENT_SERVER, message, tech_pvt->bugname);
                }

                cJSON_Delete(json);
              }
            }
            break;

            default:
              switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_NOTICE, "got unexpected msg from google_s2s %d:%s\n", event, message);
              break;
          }
        }
      }
      else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "event callback sessionId %s bugname %s not found for message %s\n", sessionId, bugname, message);
      }
      switch_core_session_rwunlock(session);
    }
    else {
    }
  }
  switch_status_t fork_data_init(private_t *tech_pvt, switch_core_session_t *session, int sampling, const char* apiKey, 
    responseHandler_t responseHandler) {
    int err;
    int channels = 1;
    const char* host = "generativelanguage.googleapis.com";
    std::ostringstream oss;
     oss << "/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=" << apiKey;
    switch_codec_t* read_codec = switch_core_session_get_read_codec(session);

    int port = 443;
    size_t buflen = LWS_PRE + (FRAME_SIZE_8000 * read_codec->implementation->samples_per_second / 8000 * channels * 1000 / RTP_PACKETIZATION_PERIOD * nAudioBufferSecs);

    switch_codec_implementation_t read_impl;
    switch_channel_t *channel = switch_core_session_get_channel(session);

    switch_core_session_get_read_impl(session, &read_impl);
  
    google_s2s::AudioPipe* ap = new google_s2s::AudioPipe(tech_pvt->sessionId, tech_pvt->bugname, host, port, oss.str().c_str(), 
      buflen, read_impl.decoded_bytes_per_packet, /*apikey*/ nullptr, read_codec->implementation->samples_per_second, eventCallback);
    if (!ap) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "Error allocating AudioPipe\n");
      return SWITCH_STATUS_FALSE;
    }

    tech_pvt->pAudioPipe = static_cast<void *>(ap);

    auto playoutBuffer = new CircularBuffer(64000);
    auto audioPlayer = new AudioPlayer(tech_pvt->mutex, playoutBuffer, tech_pvt->sessionId);
    // Google return audio data with mimeType audio/pcm
    // "mimeType": "audio/pcm;rate=24000",
    // in each audio content
    audioPlayer->setResampling(24000, read_codec->implementation->samples_per_second);
    audioPlayer->enableBase64Encoding(true);
    tech_pvt->audioPlayer = (void *) audioPlayer;
    tech_pvt->playoutBuffer = (void *) playoutBuffer;

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connecting now\n");
    ap->connect();
    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "connection in progress\n");

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) fork_data_init\n", tech_pvt->id);

    return SWITCH_STATUS_SUCCESS;
  }

  void lws_logger(int level, const char *line) {
    switch_log_level_t llevel = SWITCH_LOG_DEBUG;

    switch (level) {
      case LLL_ERR: llevel = SWITCH_LOG_ERROR; break;
      case LLL_WARN: llevel = SWITCH_LOG_WARNING; break;
      case LLL_NOTICE: llevel = SWITCH_LOG_NOTICE; break;
      case LLL_INFO: llevel = SWITCH_LOG_INFO; break;
      break;
    }
	  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "%s\n", line);
  }
}


extern "C" {

  switch_status_t google_s2s_init() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "mod_google_s2s: audio buffer (in secs): %d secs\n", nAudioBufferSecs);
 
    int logs = LLL_ERR | LLL_WARN | LLL_NOTICE;
    // | LLL_INFO | LLL_PARSER | LLL_HEADER | LLL_EXT | LLL_CLIENT  | LLL_LATENCY | LLL_DEBUG ;
    
    google_s2s::AudioPipe::initialize(logs, lws_logger);
		switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "AudioPipe::initialize completed\n");

		return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t google_s2s_cleanup() {
    bool cleanup = false;
    cleanup = google_s2s::AudioPipe::deinitialize();
    if (cleanup == true) {
        return SWITCH_STATUS_SUCCESS;
    }
    return SWITCH_STATUS_FALSE;
  }
	
  switch_status_t google_s2s_session_create(switch_core_session_t *session, responseHandler_t responseHandler, 
		uint32_t samples_per_second, const char* bugname, const char* apiKey, void **ppUserData)
  {
    int err;
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    private_t* tech_pvt;

    if (bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "google_s2s_session_create failed because connection already in progress\n");
      return SWITCH_STATUS_FALSE;
    }
    
    tech_pvt = (private_t *) switch_core_session_alloc(session, sizeof(private_t));
    if (!tech_pvt) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "error allocating memory!\n");
      return SWITCH_STATUS_FALSE;
    }
    memset(tech_pvt, 0, sizeof(private_t));
    switch_mutex_init(&tech_pvt->mutex, SWITCH_MUTEX_NESTED, switch_core_session_get_pool(session));

    strncpy(tech_pvt->sessionId, switch_core_session_get_uuid(session), MAX_SESSION_ID);
    strncpy(tech_pvt->bugname, bugname, MAX_BUG_LEN);
    tech_pvt->responseHandler = responseHandler;
    tech_pvt->id = ++idxCallCount;

    if (SWITCH_STATUS_SUCCESS != fork_data_init(tech_pvt, session, samples_per_second, apiKey, responseHandler)) {
      destroy_tech_pvt(tech_pvt);
      return SWITCH_STATUS_FALSE;
    }

    *ppUserData = tech_pvt;

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t google_s2s_send_client_event(switch_core_session_t *session, const char* bugname, cJSON* json) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "google_s2s_send_client_event failed because no bug\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
  
    if (!tech_pvt) return SWITCH_STATUS_FALSE;
    google_s2s::AudioPipe *pAudioPipe = static_cast<google_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
    if (pAudioPipe) {
      char *json_string = cJSON_PrintUnformatted(json);
      if (!json_string) {
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "google_s2s_send_client_event failed to serialize json\n");
        return SWITCH_STATUS_FALSE;
      }
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "google_s2s_send_client_event sending: %s\n", json_string);
      pAudioPipe->bufferForSending(json_string);
      free(json_string);
    }

    return SWITCH_STATUS_SUCCESS;
  }

	switch_status_t google_s2s_session_delete(switch_core_session_t *session, const char* bugname, int channelIsClosing) {
    switch_channel_t *channel = switch_core_session_get_channel(session);
    switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);

    if (!bug) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "google_s2s_session_delete: no bug - websocket conection already closed\n");
      return SWITCH_STATUS_FALSE;
    }
    private_t* tech_pvt = (private_t*) switch_core_media_bug_get_user_data(bug);
    if (!tech_pvt) return SWITCH_STATUS_FALSE;

    uint32_t id = tech_pvt->id;

    google_s2s::AudioPipe *pAudioPipe = static_cast<google_s2s::AudioPipe *>(tech_pvt->pAudioPipe);

    // close connection and get final responses
    switch_mutex_lock(tech_pvt->mutex);

    // get the bug again, now that we are under lock
    {
      switch_media_bug_t *bug = (switch_media_bug_t*) switch_channel_get_private(channel, bugname);
      if (bug) {
        switch_channel_set_private(channel, bugname, NULL);
        if (!channelIsClosing) {
          switch_core_media_bug_remove(session, &bug);
        }
      }
    }

    if (pAudioPipe) pAudioPipe->close();

    switch_mutex_unlock(tech_pvt->mutex);

    destroy_tech_pvt(tech_pvt);

    switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "(%u) google_s2s_session_delete complete\n", id);
    return SWITCH_STATUS_SUCCESS;
  }
	
  switch_bool_t google_s2s_write_frame(switch_media_bug_t *bug, void* user_data) {
    switch_status_t status = SWITCH_STATUS_SUCCESS;
    private_t* tech_pvt = (private_t*) user_data;

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      CircularBuffer *playoutBuffer = (CircularBuffer *) tech_pvt->playoutBuffer;

      if (playoutBuffer->size() > 0) {
        switch_frame_t* rframe = switch_core_media_bug_get_write_replace_frame(bug);
        int16_t *fp = reinterpret_cast<int16_t*>(rframe->data);

        rframe->channels = 1;
        rframe->datalen = rframe->samples * sizeof(int16_t);

        int16_t data[SWITCH_RECOMMENDED_BUFFER_SIZE];
        memset(data, 0, sizeof(data));
        
        int samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(rframe->samples));
        auto count = playoutBuffer->getBlock(data, samplesToCopy);
        if (count != samplesToCopy) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "el_dub_speech_frame - failed to get %d samples from playout buffer, got %d\n", samplesToCopy, count);
        }
        else {
          vector_add(fp, data, rframe->samples);
          vector_normalize(fp, rframe->samples);
          switch_core_media_bug_set_write_replace_frame(bug, rframe);
        }

        // notify when assistant starts speaking
        if (tech_pvt->assistant_started_speaking) {
          tech_pvt->assistant_started_speaking = 0;
        }

        // notify when assistant stops speaking
        if (playoutBuffer->size() == 0) {
          if (!tech_pvt->initial_assistant_response_completed) {
            tech_pvt->initial_assistant_response_completed = 1;
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "(%u) initial assistant greeting finished\n", tech_pvt->id);
          }
        }
      }
      switch_mutex_unlock(tech_pvt->mutex);
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "google_s2s_write_frame failed to lock mutex\n");
    }

    return SWITCH_TRUE;
  }

	switch_bool_t google_s2s_read_frame(switch_core_session_t *session, switch_media_bug_t *bug, void* user_data) {
    private_t* tech_pvt = (private_t*) user_data;
    size_t inuse = 0;
    bool dirty = false;
    char *p = (char *) "{\"msg\": \"buffer overrun\"}";

    if (!tech_pvt) return SWITCH_TRUE;

    /* dont send audio until initial response.created is received */
    if (tech_pvt->state != SESSION_STATE_CONVERSATION_STARTED) {
      switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, conversation not started\n");
      return SWITCH_TRUE;
    }

    if (switch_mutex_trylock(tech_pvt->mutex) == SWITCH_STATUS_SUCCESS) {
      if (!tech_pvt->pAudioPipe) {
        switch_mutex_unlock(tech_pvt->mutex);
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, no tech_pvt\n");
        return SWITCH_TRUE;
      }
      google_s2s::AudioPipe *pAudioPipe = static_cast<google_s2s::AudioPipe *>(tech_pvt->pAudioPipe);
      if (pAudioPipe->getLwsState() != google_s2s::AudioPipe::LWS_CLIENT_CONNECTED) {
        switch_mutex_unlock(tech_pvt->mutex);
        switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_DEBUG, "not sending audio, LWS client not connected\n");
        return SWITCH_TRUE;
      }
      pAudioPipe->lockAudioBuffer();
      size_t available = pAudioPipe->binarySpaceAvailable();
      switch_frame_t frame = { 0 };
      frame.data = pAudioPipe->binaryWritePtr();
      frame.buflen = available;

      while (true) {

        // check if buffer would be overwritten; dump packets if so
        if (available < pAudioPipe->binaryMinSpace()) {
          if (!tech_pvt->buffer_overrun_notified) {
            tech_pvt->buffer_overrun_notified = 1;
            tech_pvt->responseHandler(session, GS2S_EVENT_BUFFER_OVERRUN, NULL, tech_pvt->bugname);
          }
          switch_log_printf(SWITCH_CHANNEL_SESSION_LOG(session), SWITCH_LOG_ERROR, "dropping packets!\n");
          pAudioPipe->binaryWritePtrResetToZero();

          frame.data = pAudioPipe->binaryWritePtr();
          frame.buflen = available = pAudioPipe->binarySpaceAvailable();
        }

        switch_status_t rv = switch_core_media_bug_read(bug, &frame, SWITCH_TRUE);
        if (rv != SWITCH_STATUS_SUCCESS) {
          break;
        }
        if (frame.datalen) {
          pAudioPipe->binaryWritePtrAdd(frame.datalen);
          frame.buflen = available = pAudioPipe->binarySpaceAvailable();
          frame.data = pAudioPipe->binaryWritePtr();
          dirty = true;
        }
      }

      pAudioPipe->unlockAudioBuffer();
      switch_mutex_unlock(tech_pvt->mutex);
    }
    return SWITCH_TRUE;
  }
}
