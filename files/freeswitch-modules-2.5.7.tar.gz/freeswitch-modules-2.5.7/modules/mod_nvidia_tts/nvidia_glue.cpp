#include "mod_nvidia_tts.h"
#include <grpc++/grpc++.h>
#include <switch.h>

#include "jambonz/audio_player.hpp"
#include "jambonz/circular_buffer.h"
#include "riva/proto/riva_audio.grpc.pb.h"
#include "riva/proto/riva_tts.grpc.pb.h"
#include <chrono>
#include <cstdlib>
#include <string>
#include <thread>

#define BUFFER_SIZE 8129

namespace nr_tts = nvidia::riva::tts;
namespace nr = nvidia::riva;

static std::string fullDirPath;

static void start_synthesis(char* text, nvidia_t *a) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "start_synthesis: beginning TTS synthesis\n");

  try {
    // Enable keep-alive to prevent connection drops
    grpc::ChannelArguments args;
    args.SetInt(GRPC_ARG_KEEPALIVE_TIME_MS, 10000);           // 10 seconds
    args.SetInt(GRPC_ARG_KEEPALIVE_TIMEOUT_MS, 5000);         // 5 seconds
    args.SetInt(GRPC_ARG_KEEPALIVE_PERMIT_WITHOUT_CALLS, 1);  // Allow keepalives when no RPC

    // Create a channel with these arguments
    std::shared_ptr<grpc::Channel> channel = 
      grpc::CreateCustomChannel(a->riva_server_uri, grpc::InsecureChannelCredentials(), args);

    std::unique_ptr<nr_tts::RivaSpeechSynthesis::Stub> stub = nr_tts::RivaSpeechSynthesis::NewStub(channel);

    // Set up request
    nr_tts::SynthesizeSpeechRequest request;
    request.set_text(text);
    request.set_voice_name(a->voice_name);
    request.set_language_code(a->language);
    request.set_encoding(nr::AudioEncoding::LINEAR_PCM);
    request.set_sample_rate_hz(a->rate);
    // Create client context for the RPC
    grpc::ClientContext context;
    std::chrono::system_clock::time_point deadline = 
    std::chrono::system_clock::now() + std::chrono::seconds(120); // 2-minute timeout
    context.set_deadline(deadline);

    // Make the streaming RPC call with the provided request
    std::unique_ptr<grpc::ClientReader<nr_tts::SynthesizeSpeechResponse>> reader =
      stub->SynthesizeOnline(&context, request);

    AudioPlayer *pAudioPlayer = (AudioPlayer *) a->audioPlayer;
    nr_tts::SynthesizeSpeechResponse response;

    // Process streaming response
    while (true) {
      bool read_success = reader->Read(&response);
      bool fireEvent = 0 == a->reads++;
      if (!read_success) {
        // End of stream or error
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "End of TTS stream or read error\n");
        break;
      }
      // Check if we've been flushed/interrupted
      if (a->flushed) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "TTS synthesis interrupted\n");
        break;
      }

      // Process audio data
      const auto &audio = response.audio();

      // Skip processing if empty (heartbeat packets)
      if (audio.empty()) {
        continue;
      }
      

      // Calculate size information once
      size_t bytesResampled = audio.size();

      pAudioPlayer->bufferAudio(const_cast<char*>(audio.data()), bytesResampled);

      // Write to cache file if enabled
      if (a->file) {
        fwrite(audio.data(), 1, audio.size(), a->file);
        fflush(a->file);
      }

      // Fire playback-start event on first audio chunk if not already sent
      if (fireEvent && a->session_id) {
        // Calculate time to first audio byte
        auto endTime = std::chrono::high_resolution_clock::now();
        auto startTime = *static_cast<std::chrono::time_point<std::chrono::high_resolution_clock>*>(a->startTime);
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
        auto time_to_first_byte_ms = std::to_string(duration.count());
        
        switch_core_session_t* session = switch_core_session_locate(a->session_id);
        if (session) {
          switch_channel_t *channel = switch_core_session_get_channel(session);
          if (channel) {
            switch_event_t *event;
            if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) == SWITCH_STATUS_SUCCESS) {
              switch_channel_event_set_data(channel, event);
              
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
              
              if (a->voice_name) {
                switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, 
                    "variable_tts_nvidia_voice_name", a->voice_name);
              }
              
              if (a->language) {
                switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, 
                    "variable_tts_nvidia_language", a->language);
              }
              
              if (a->cache_filename) {
                switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, 
                    "variable_tts_cache_filename", a->cache_filename);
              }
              
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, 
                  "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms.c_str());
                  
              switch_event_fire(&event);
              a->playback_start_sent = true;
            }
          }
          switch_core_session_rwunlock(session);
        }
      }
    }

    // Handle completion
    grpc::Status status = reader->Finish();

    if (a) {
      a->draining = 1;

      if (status.ok()) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "TTS synthesis completed successfully\n");
        a->response_code = 200;
      } else {
        a->response_code = status.error_code();
        if (a->err_msg) { free(a->err_msg); }
        a->err_msg = strdup(status.error_message().c_str());
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "TTS synthesis failed: %d - %s\n",
                  status.error_code(), status.error_message().c_str());
      }
    }
  } catch (const std::exception &e) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Exception in TTS synthesis: %s\n", e.what());
    a->response_code = 500;
    if (a->err_msg) { free(a->err_msg); }
    a->err_msg = strdup(e.what());
    a->draining = 1;
  }
  free(text);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "TTS synthesis thread completed\n");
}

extern "C" {
switch_status_t nvidia_speech_load()
{
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "nvidia_speech_loading..\n");

  /* create temp folder for cache files */
  const char *baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
  if (!baseDir) { baseDir = "/tmp/"; }
  if (strcmp(baseDir, "/") == 0) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", baseDir);
    return SWITCH_STATUS_FALSE;
  }

  fullDirPath = std::string(baseDir) + "tts-cache-files";

  // Create the directory with read, write, and execute permissions for everyone
  mode_t oldMask = umask(0);
  int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
  umask(oldMask);
  if (result != 0) {
    if (errno != EEXIST) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n",
                fullDirPath.c_str());
      fullDirPath = "";
    } else
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "folder %s already exists\n", fullDirPath.c_str());
  } else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "created folder %s\n", fullDirPath.c_str());
  }

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "nvidia_speech_loaded..\n");

  return SWITCH_STATUS_SUCCESS;
}

switch_status_t nvidia_speech_open(nvidia_t *nvidia) { return SWITCH_STATUS_SUCCESS; }

switch_status_t nvidia_speech_feed_tts(nvidia_t *a, char *text, switch_speech_flag_t *flags)
{
  const int MAX_CHARS = 20;
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "nvidia_speech_feed_tts %s\n", text);

  /* open cache file */
  if (a->cache_audio && fullDirPath.length() > 0) {
    switch_uuid_t uuid;
    char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
    char outfile[512] = "";
    int fd;

    switch_uuid_get(&uuid);
    switch_uuid_format(uuid_str, &uuid);

    switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
    a->cache_filename = strdup(outfile);
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "writing audio cache file to %s\n", a->cache_filename);

    mode_t oldMask = umask(0);
    fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
    umask(oldMask);
    if (fd == -1) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error opening cache file %s: %s\n", outfile,
                strerror(errno));
    } else {
      a->file = fdopen(fd, "wb");
      if (!a->file) {
        close(fd);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error opening cache file %s: %s\n", outfile,
                  strerror(errno));
      }
    }
  }

  if (!a->riva_server_uri) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
              "nvidia_speech_feed_tts: no riva_server_uri provided\n");
    return SWITCH_STATUS_FALSE;
  }

  if (!a->language) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "nvidia_speech_feed_tts: no language provided\n");
    return SWITCH_STATUS_FALSE;
  }

  auto playoutBuffer = new CircularBuffer(8192);
  auto audioPlayer = new AudioPlayer(a->mutex, playoutBuffer);
  a->playoutBuffer = (void *)playoutBuffer;
  a->audioPlayer = (void *)audioPlayer;

  std::chrono::time_point<std::chrono::high_resolution_clock> *ptr =
    new std::chrono::time_point<std::chrono::high_resolution_clock>(std::chrono::high_resolution_clock::now());
  a->startTime = ptr;

  char* text_copy = strdup(text); 
  std::thread(start_synthesis, text_copy, a).detach();
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "nvidia_speech_feed_tts sent synthesize request\n");
  return SWITCH_STATUS_SUCCESS;
}

switch_status_t nvidia_speech_read_tts(nvidia_t *a, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  CircularBuffer *playoutBuffer = (CircularBuffer *)a->playoutBuffer;
  int samplesToCopy = 0;

  if (a->mutex && switch_mutex_trylock(a->mutex) == SWITCH_STATUS_SUCCESS) {

    if (a->response_code > 0 && a->response_code != 200) {
      switch_mutex_unlock(a->mutex);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "nvidia_speech_read_tts, returning failure\n");
      return SWITCH_STATUS_FALSE;
    }

    if (a->flushed) {
      switch_mutex_unlock(a->mutex);
      return SWITCH_STATUS_BREAK;
    }

    if (playoutBuffer->size() == 0) {
      if (a->draining) {
        switch_mutex_unlock(a->mutex);
        return SWITCH_STATUS_BREAK;
      }
      /* no audio available yet so send silence */
      memset(data, 255, *datalen);
      switch_mutex_unlock(a->mutex);
      return SWITCH_STATUS_SUCCESS;
    }
    samplesToCopy = std::min(static_cast<int>(playoutBuffer->size()), static_cast<int>(*datalen / sizeof(int16_t)));

    auto count = playoutBuffer->getBlock(reinterpret_cast<int16_t *>(data), samplesToCopy);
    if (count != samplesToCopy) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                "nvidia_speech_read_tts - failed to get %d samples from playout buffer, got %d\n",
                samplesToCopy, count);
    }
    *datalen = count * sizeof(int16_t);
    switch_mutex_unlock(a->mutex);
  } else {
    /* no audio available yet so send silence */
    memset(data, 255, *datalen);
    return SWITCH_STATUS_SUCCESS;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "nvidia_speech_read_tts failed to lock mutex\n");
  }

  return SWITCH_STATUS_SUCCESS;
}

switch_status_t nvidia_speech_flush_tts(nvidia_t *a)
{
  bool download_complete = a->response_code == 200;
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "nvidia_speech_flush_tts, download complete? %s\n",
            download_complete ? "yes" : "no");

  if (a->audioPlayer) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "destroying audio player\n");
    AudioPlayer *pAudioPlayer = static_cast<AudioPlayer *>(a->audioPlayer);
    delete pAudioPlayer;
    a->audioPlayer = nullptr;
  }

  if (a->playoutBuffer) {
    CircularBuffer *playoutBuffer = (CircularBuffer *)a->playoutBuffer;
    delete playoutBuffer;
    a->playoutBuffer = nullptr;
  };
  delete static_cast<std::chrono::time_point<std::chrono::high_resolution_clock> *>(a->startTime);
  a->startTime = nullptr;

  a->flushed = 1;
  if (!download_complete) {
    if (a->file) {
      // switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "closing audio cache file %s because download was
      // interrupted\n", a->cache_filename);
      if (fclose(a->file) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "error closing audio cache file\n");
      }
      a->file = nullptr;
    }
  }
  // If playback_start has not been sent, delete the file
  if (a->cache_filename && !a->playback_start_sent) {
    // switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "removing audio cache file %s because download was
    // interrupted\n", a->cache_filename);
    if (unlink(a->cache_filename) != 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR,
                "cleanupConn: error removing audio cache file %s: %d:%s\n", a->cache_filename, errno,
                strerror(errno));
    }
    free(a->cache_filename);
    a->cache_filename = nullptr;
  }
  if (a->session_id) {
    switch_core_session_t *session = switch_core_session_locate(a->session_id);
    if (session) {
      switch_channel_t *channel = switch_core_session_get_channel(session);

      /* unlock as quickly as possible */
      switch_core_session_rwunlock(session);
      if (channel) {
        switch_event_t *event;
        if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
          switch_channel_event_set_data(channel, event);
          switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
          switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_nvidia_response_code",
                           std::to_string(a->response_code).c_str());
          if (a->cache_filename && download_complete) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename",
                             a->cache_filename);
          }
          if (!download_complete && a->err_msg) {
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", a->err_msg);
          }
          switch_event_fire(&event);
        } else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: failed to create event\n");
        }
      } else {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: channel not found\n");
      }
    }
  }

  return SWITCH_STATUS_SUCCESS;
}

switch_status_t nvidia_speech_close(nvidia_t *a)
{
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "nvidia_speech_close\n");

  return SWITCH_STATUS_SUCCESS;
}

switch_status_t nvidia_speech_unload() { return SWITCH_STATUS_SUCCESS; }
}