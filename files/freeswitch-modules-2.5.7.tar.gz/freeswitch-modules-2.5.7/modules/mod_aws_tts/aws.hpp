#ifndef __AWS_HPP__
#define __AWS_HPP__

#include <switch.h>
#include <speex/speex_resampler.h>
#include <string>
#include <memory>
#include <mutex>
#include <chrono>

class AwsTts {
private:
    // Configuration parameters
    std::string voice_name_;
    std::string access_key_id_;
    std::string secret_access_key_;
    std::string session_token_;
    std::string region_;
    std::string language_;
    std::string engine_;
    std::string playback_id_;

    // Result data
    long response_code_;
    std::string session_id_;
    std::string cache_filename_;
    std::string error_message_;

    // State and configuration
    int rate_;
    bool draining_;
    int reads_;
    bool cache_audio_;
    bool flushed_;
    bool playback_start_sent_;

    // Timing
    std::chrono::time_point<std::chrono::high_resolution_clock> start_time_;

    // Resources
    void* circular_buffer_;
    SpeexResamplerState* resampler_;
    FILE* file_;
    mutable std::mutex mutex_;  // Now a member object, not a pointer

    // Last byte handling for odd-sized chunks
    bool has_last_byte_;
    uint8_t last_byte_;

public:
    // Constructor
    AwsTts();

    // Destructor
    ~AwsTts();

    // Static factory method
    static std::shared_ptr<AwsTts> create();

    // Delete copy operations to prevent accidental copies
    AwsTts(const AwsTts&) = delete;
    AwsTts& operator=(const AwsTts&) = delete;

    // Move constructor and assignment
    AwsTts(AwsTts&& other) noexcept = default;
    AwsTts& operator=(AwsTts&& other) noexcept = default;

    // Configuration getters
    const std::string& getVoiceName() const { return voice_name_; }
    const std::string& getAccessKeyId() const { return access_key_id_; }
    const std::string& getSecretAccessKey() const { return secret_access_key_; }
    const std::string& getSessionToken() const { return session_token_; }
    const std::string& getRegion() const { return region_; }
    const std::string& getLanguage() const { return language_; }
    const std::string& getEngine() const { return engine_; }
    const std::string& getPlaybackId() const { return playback_id_; }

    // Result data getters
    long getResponseCode() const { return response_code_; }
    const std::string& getSessionId() const { return session_id_; }
    const std::string& getCacheFilename() const { return cache_filename_; }
    const std::string& getErrorMessage() const { return error_message_; }

    // State getters
    int getRate() const { return rate_; }
    bool isDraining() const { return draining_; }
    int getReads() const { return reads_; }
    bool isCacheAudio() const { return cache_audio_; }
    bool isFlushed() const { return flushed_; }
    bool isPlaybackStartSent() const { return playback_start_sent_; }

    // Resource getters
    void* getCircularBuffer() const { return circular_buffer_; }
    std::mutex& getMutex() const { return mutex_; }
    SpeexResamplerState* getResampler() const { return resampler_; }
    FILE* getFile() const { return file_; }
    const auto& getStartTime() const { return start_time_; }

    // Last byte handling
    bool hasLastByte() const { return has_last_byte_; }
    uint8_t getLastByte() const { return last_byte_; }

    // Configuration setters
    void setVoiceName(const std::string& voice_name) { voice_name_ = voice_name; }
    void setAccessKeyId(const std::string& key_id) { access_key_id_ = key_id; }
    void setSecretAccessKey(const std::string& key) { secret_access_key_ = key; }
    void setSessionToken(const std::string& token) { session_token_ = token; }
    void setRegion(const std::string& region) { region_ = region; }
    void setLanguage(const std::string& language) { language_ = language; }
    void setEngine(const std::string& engine) { engine_ = engine; }
    void setPlaybackId(const std::string& playback_id) { playback_id_ = playback_id; }

    // Result data setters
    void setResponseCode(long response_code) { response_code_ = response_code; }
    void setSessionId(const std::string& session_id) { session_id_ = session_id; }
    void setCacheFilename(const std::string& cache_filename) { cache_filename_ = cache_filename; }
    void setErrorMessage(const std::string& error_msg) { error_message_ = error_msg; }

    // State setters
    void setRate(int rate) { rate_ = rate; }
    void setDraining(bool draining) { draining_ = draining; }
    void setReads(int reads) { reads_ = reads; }
    void setCacheAudio(bool cache_audio) { cache_audio_ = cache_audio; }
    void setFlushed(bool flushed) { flushed_ = flushed; }
    void setPlaybackStartSent(bool sent) { playback_start_sent_ = sent; }

    // Resource setters
    void setCircularBuffer(void* buffer) { circular_buffer_ = buffer; }
    void setResampler(SpeexResamplerState* resampler) { resampler_ = resampler; }
    void setFile(FILE* file) { file_ = file; }
    void setStartTime(const std::chrono::time_point<std::chrono::high_resolution_clock>& time) { start_time_ = time; }

    // Last byte handling
    void setHasLastByte(bool has) { has_last_byte_ = has; }
    void setLastByte(uint8_t byte) { last_byte_ = byte; }

    // Increment reads atomically
    int incrementReads() {
        std::lock_guard<std::mutex> lock(mutex_);
        return ++reads_;
    }

    // Utility methods
    void reset();
    bool isValid() const;

private:
    void cleanup();
};

#endif