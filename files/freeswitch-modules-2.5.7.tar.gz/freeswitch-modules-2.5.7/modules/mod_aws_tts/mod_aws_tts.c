#include "mod_aws_tts.h"
#include "aws_glue.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_aws_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_aws_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_aws_tts, mod_aws_tts_load, mod_aws_tts_shutdown, NULL);


static aws_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  aws_handle_t handle = (aws_handle_t) sh->private_info;
  if (!handle) {
    handle = aws_tts_create();
    sh->private_info = handle;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "allocated aws_handle_t\n");
  }
  return handle;
}

switch_status_t a_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  aws_handle_t handle = createOrRetrievePrivateData(sh);
  aws_tts_set_voice_name(handle, voice_name);
  aws_tts_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "a_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
  return aws_speech_open(handle);
}

static switch_status_t a_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  aws_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "a_speech_close\n");

  rc = aws_speech_close(handle);

  // Release the handle - this triggers cleanup via RAII when ref count reaches 0
  if (handle) {
    aws_tts_release(handle);
    sh->private_info = NULL;
  }

  return rc;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t a_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  aws_handle_t handle = createOrRetrievePrivateData(sh);
  aws_tts_set_draining(handle, 0);
  aws_tts_set_reads(handle, 0);
  aws_tts_set_flushed(handle, 0);
  aws_tts_set_response_code(handle, 0);
  aws_tts_set_error_message(handle, NULL);
  aws_tts_set_has_last_byte(handle, 0);
  aws_tts_set_playback_start_sent(handle, 0);

  return aws_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t a_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  aws_handle_t handle = createOrRetrievePrivateData(sh);
  return aws_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void a_speech_flush_tts(switch_speech_handle_t *sh)
{
  aws_handle_t handle = createOrRetrievePrivateData(sh);
  aws_speech_flush_tts(handle);
}

static void a_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  aws_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "a_text_param_tts: %s=%s\n", param, val);
  if (0 == strcmp(param, "accessKeyId")) {
    aws_tts_set_access_key_id(handle, val);
  } else if (0 == strcmp(param, "secretAccessKey")) {
    aws_tts_set_secret_access_key(handle, val);
  } else if (0 == strcmp(param, "sessionToken")) {
    aws_tts_set_session_token(handle, val);
  } else if (0 == strcmp(param, "region")) {
    aws_tts_set_region(handle, val);
  } else if (0 == strcmp(param, "language")) {
    aws_tts_set_language(handle, val);
  } else if (0 == strcmp(param, "engine")) {
    aws_tts_set_engine(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    aws_tts_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    aws_tts_set_cache_audio(handle, 1);
  } else if (0 == strcmp(param, "playback_id")) {
    aws_tts_set_playback_id(handle, val);
  }
}

static void a_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}
static void a_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_aws_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "aws";
  speech_interface->speech_open = a_speech_open;
  speech_interface->speech_close = a_speech_close;
  speech_interface->speech_feed_tts = a_speech_feed_tts;
  speech_interface->speech_read_tts = a_speech_read_tts;
	speech_interface->speech_flush_tts = a_speech_flush_tts;
	speech_interface->speech_text_param_tts = a_text_param_tts;
	speech_interface->speech_numeric_param_tts = a_numeric_param_tts;
	speech_interface->speech_float_param_tts = a_float_param_tts;
  return aws_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_aws_tts_shutdown)
{
  return aws_speech_unload();
}