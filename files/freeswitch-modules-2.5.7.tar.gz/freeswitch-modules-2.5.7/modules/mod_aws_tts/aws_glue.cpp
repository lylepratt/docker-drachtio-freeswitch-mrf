#include "mod_aws_tts.h"
#include "aws_wrapper.h"
#include "aws.hpp"
#include <switch.h>

#include <boost/circular_buffer.hpp>
#include <aws/core/Aws.h>
#include <aws/core/auth/AWSCredentialsProvider.h>
#include <aws/core/client/ClientConfiguration.h>
#include <aws/core/utils/memory/stl/AWSString.h>
#include <aws/polly/PollyClient.h>
#include <aws/polly/model/SynthesizeSpeechRequest.h>
#include <aws/polly/model/SynthesizeSpeechResult.h>
#include <aws/polly/model/Engine.h>
#include <speex/speex_resampler.h>

#include <cstdlib>
#include <string>
#include <chrono>
#include <thread>
#include <memory>
#include <mutex>

#define BUFFER_SIZE 8129

typedef boost::circular_buffer<uint16_t> CircularBuffer_t;

using namespace Aws;
using namespace Aws::Utils;
using namespace Aws::Auth;

static std::string fullDirPath;

static void start_synthesis(std::shared_ptr<Aws::Polly::PollyClient> pollyClient, const char* text, std::shared_ptr<AwsTts> aws) {
    try {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "start_synthesis calling AWS Polly, text %s\n", text);
        
        // Create SynthesizeSpeech request
        Aws::Polly::Model::SynthesizeSpeechRequest request;
        
        // Set text or SSML
        if (std::strncmp(text, "<speak", 6) == 0) {
            request.SetText(text);
            request.SetTextType(Aws::Polly::Model::TextType::ssml);
        } else {
            request.SetText(text);
            request.SetTextType(Aws::Polly::Model::TextType::text);
        }
        
        // Set voice and language
        auto voice_name = aws->getVoiceName();
        if (!voice_name.empty()) {
            request.SetVoiceId(Aws::Polly::Model::VoiceIdMapper::GetVoiceIdForName(voice_name));
        }
        auto language = aws->getLanguage();
        if (!language.empty()) {
            request.SetLanguageCode(Aws::Polly::Model::LanguageCodeMapper::GetLanguageCodeForName(language));
        }
        auto engine = aws->getEngine();
        if (!engine.empty()) {
            request.SetEngine(Aws::Polly::Model::EngineMapper::GetEngineForName(engine));
        }
        // Set output format to PCM
        request.SetOutputFormat(Aws::Polly::Model::OutputFormat::pcm);
        request.SetSampleRate("8000");
        
        // Make async request
        auto outcome = pollyClient->SynthesizeSpeech(request);
        
        if (outcome.IsSuccess()) {
            aws->setResponseCode(200);
            auto& result = outcome.GetResult();
            auto& audioStream = result.GetAudioStream();
            
            // Read audio data from stream
            std::vector<uint8_t> audioData;
            char buffer[4096];
            while (audioStream.good()) {
                audioStream.read(buffer, sizeof(buffer));
                std::streamsize bytesRead = audioStream.gcount();
                if (bytesRead > 0) {
                    audioData.insert(audioData.end(), buffer, buffer + bytesRead);
                }
            }
            
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "start_synthesis completed, audio data bytes: %zu\n", audioData.size());
            
            // Process audio data similar to original synthesizing callback
            if (!aws->isFlushed() && !audioData.empty()) {
                CircularBuffer_t *cBuffer = (CircularBuffer_t *) aws->getCircularBuffer();
                size_t total_bytes_to_process = audioData.size();
                
                // Handle odd bytes from previous call
                std::unique_ptr<uint8_t[]> combinedData;
                if (aws->hasLastByte()) {
                    aws->setHasLastByte(false);
                    combinedData.reset(new uint8_t[total_bytes_to_process + 1]);
                    combinedData[0] = aws->getLastByte();
                    memcpy(combinedData.get() + 1, audioData.data(), total_bytes_to_process);
                    total_bytes_to_process++;
                } else {
                    combinedData.reset(new uint8_t[total_bytes_to_process]);
                    memcpy(combinedData.get(), audioData.data(), total_bytes_to_process);
                }
                
                auto data = combinedData.get();
                if ((total_bytes_to_process % sizeof(int16_t)) != 0) {
                    aws->setLastByte(data[total_bytes_to_process - 1]);
                    aws->setHasLastByte(true);
                    total_bytes_to_process--;
                }

                auto file = aws->getFile();
                if (file) {
                    fwrite(data, 1, total_bytes_to_process, file);
                }
                
                const uint16_t* begin = reinterpret_cast<const uint16_t*>(data);
                const uint16_t* end = reinterpret_cast<const uint16_t*>(data + total_bytes_to_process);

                {
                    // Note: Direct mutex access not available in shared_ptr pattern
                    // Buffer operations are handled internally by wrapper
                    if (cBuffer->capacity() - cBuffer->size() < total_bytes_to_process) {
                        cBuffer->set_capacity(cBuffer->size() + std::max(total_bytes_to_process, (size_t)BUFFER_SIZE));
                    }
                    cBuffer->insert(cBuffer->end(), begin, end);
                }

                // Fire first byte event
                int current_reads = aws->incrementReads();
                if (1 == current_reads) {
                    auto session_id = aws->getSessionId();
                    if (!session_id.empty()) {
                        auto endTime = std::chrono::high_resolution_clock::now();
                        auto startTime = aws->getStartTime();
                        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
                        auto time_to_first_byte_ms = std::to_string(duration.count());
                        switch_core_session_t* session = switch_core_session_locate(session_id.c_str());
                        if (session) {
                            switch_channel_t *channel = switch_core_session_get_channel(session);
                            switch_core_session_rwunlock(session);
                            if (channel) {
                                switch_event_t *event;
                                if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_START) == SWITCH_STATUS_SUCCESS) {
                                    switch_channel_event_set_data(channel, event);
                                    auto playback_id = aws->getPlaybackId();
                                    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "write_cb: firing playback-started %s\n",
                                      !playback_id.empty() ? playback_id.c_str() : "no-playback-id");
                                    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
                                    if (!playback_id.empty()) {
                                      switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id.c_str());
                                    }

                                    switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_time_to_first_byte_ms", time_to_first_byte_ms.c_str());
                                    if (!voice_name.empty()) {
                                      switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_aws_voice_name", voice_name.c_str());
                                    }
                                    auto cache_filename = aws->getCacheFilename();
                                    if (!cache_filename.empty()) {
                                        switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename.c_str());
                                    }
                                    switch_event_fire(&event);
                                    aws->setPlaybackStartSent(true);
                                }
                            }
                        }
                    }
                }
            }
            
        } else {
            auto error = outcome.GetError();
            aws->setResponseCode(static_cast<long int>(error.GetResponseCode()));
            aws->setErrorMessage(error.GetMessage());
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "AWS Polly error: %s\n", error.GetMessage().c_str());
        }
        
    } catch (const std::exception& e) {
        aws->setResponseCode(500);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_aws_tts: Exception in start_synthesis %s\n", e.what());
    }
    aws->setDraining(true);
    free((void*) text);
}

extern "C" {
  switch_status_t aws_speech_load() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "aws_speech_loading..\n");

    /* create temp folder for cache files */
    const char* baseDir = std::getenv("JAMBONZ_TMP_CACHE_FOLDER");
    if (!baseDir) {
      baseDir = "/tmp/";
    }
    if (strcmp(baseDir, "/") == 0) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", baseDir);
      return SWITCH_STATUS_FALSE;
    }

    fullDirPath = std::string(baseDir) + "tts-cache-files";

    // Create the directory with read, write, and execute permissions for everyone
    mode_t oldMask = umask(0);
    int result = mkdir(fullDirPath.c_str(), S_IRWXU | S_IRWXG | S_IRWXO);
    umask(oldMask);
    if (result != 0) {
      if (errno != EEXIST) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "failed to create folder %s\n", fullDirPath.c_str());
        fullDirPath = "";
      }
      else switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "folder %s already exists\n", fullDirPath.c_str());
    }
    else {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "created folder %s\n", fullDirPath.c_str());
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "aws_speech_loaded..\n");

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t aws_speech_open(aws_handle_t handle) {
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t aws_speech_feed_tts(aws_handle_t handle, char* text, switch_speech_flag_t *flags) {
    const int MAX_CHARS = 20;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "aws_speech_feed_tts %s\n", text);

    /* open cache file */
    if (aws_tts_is_cache_audio(handle) && fullDirPath.length() > 0) {
      switch_uuid_t uuid;
      char uuid_str[SWITCH_UUID_FORMATTED_LENGTH + 1];
      char outfile[512] = "";
      int fd;

      switch_uuid_get(&uuid);
      switch_uuid_format(uuid_str, &uuid);

      switch_snprintf(outfile, sizeof(outfile), "%s%s%s.r8", fullDirPath.c_str(), SWITCH_PATH_SEPARATOR, uuid_str);
      aws_tts_set_cache_filename(handle, outfile);
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "writing audio cache file to %s\n", outfile);

      mode_t oldMask = umask(0);
      fd = open(outfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
      umask(oldMask);
      if (fd == -1 ) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error opening cache file %s: %s\n", outfile, strerror(errno));
      }
      else {
        FILE* file = fdopen(fd, "wb");
        aws_tts_set_file(handle, file);
        if (!file) {
          close(fd);
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error opening cache file %s: %s\n", outfile, strerror(errno));
        }
      }
    }

    // AWS SDK credentials and client initialization
    Aws::Client::ClientConfiguration clientConfig;
    
    // Set region configuration first
    const char* region = aws_tts_get_region(handle);
    if (region && strlen(region) > 0) {
        clientConfig.region = region;
    }
    
    std::shared_ptr<Aws::Polly::PollyClient> pollyClient;

    const char* accessKeyId = aws_tts_get_access_key_id(handle);
    const char* secretAccessKey = aws_tts_get_secret_access_key(handle);
    const char* sessionToken = aws_tts_get_session_token(handle);

    if (accessKeyId && strlen(accessKeyId) > 0 &&
        secretAccessKey && strlen(secretAccessKey) > 0 &&
        sessionToken && strlen(sessionToken) > 0) {
        // Use temporary credentials with session token
        pollyClient = std::make_shared<Aws::Polly::PollyClient>(
            Aws::Auth::AWSCredentials(accessKeyId, secretAccessKey, sessionToken),
            clientConfig);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AWS Polly client initialized with temporary credentials\n");

    } else if (accessKeyId && strlen(accessKeyId) > 0 &&
               secretAccessKey && strlen(secretAccessKey) > 0) {
        // Use long-term credentials (no session token)
        pollyClient = std::make_shared<Aws::Polly::PollyClient>(
            Aws::Auth::AWSCredentials(accessKeyId, secretAccessKey),
            clientConfig);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AWS Polly client initialized with long-term credentials\n");
        
    } else {
        // Use default credential provider chain (IAM roles, environment variables, etc.)
        pollyClient = std::make_shared<Aws::Polly::PollyClient>(clientConfig);
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "AWS Polly client initialized with default credential provider\n");
    }

    int rate = aws_tts_get_rate(handle);
    if (rate != 8000 /*Hz*/) {
      int err;
      SpeexResamplerState* resampler = speex_resampler_init(1, 8000, rate, SWITCH_RESAMPLE_QUALITY, &err);
      aws_tts_set_resampler(handle, resampler);
      if (0 != err) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "Error initializing resampler: %s.\n", speex_resampler_strerror(err));
        return SWITCH_STATUS_FALSE;
      }
    }

    aws_tts_set_start_time_now(handle);
    aws_tts_set_circular_buffer(handle, (void *) new CircularBuffer_t(BUFFER_SIZE));

    try {
      const char* dupText = strdup(text); // text will be freed in the thread

      // CRITICAL: Retain handle for detached thread safety
      aws_tts_retain(handle);
      std::thread([handle, pollyClient, dupText]() {
        auto aws = aws_get_shared_ptr(handle);
        if (aws) {
          start_synthesis(pollyClient, dupText, aws);
        }
        aws_tts_release(handle);  // Release when thread completes
      }).detach();

      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "aws_speech_feed_tts sent synthesize request\n");
    } catch (const std::exception& e) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "mod_aws_tts: Exception: %s\n", e.what());
      return SWITCH_STATUS_FALSE;
    }
    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t aws_speech_read_tts(aws_handle_t handle, void *data, size_t *datalen, switch_speech_flag_t *flags) {
    CircularBuffer_t *cBuffer = (CircularBuffer_t *) aws_tts_get_circular_buffer(handle);
    std::vector<uint16_t> pcm_data;

    long response_code = aws_tts_get_response_code(handle);
    if (response_code > 0 && response_code != 200) {
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "aws_speech_read_tts, returning failure\n") ;
      return SWITCH_STATUS_FALSE;
    }
    if (aws_tts_is_flushed(handle)) {
      return SWITCH_STATUS_BREAK;
    }

    // Note: Thread safety handled internally by wrapper functions
    size_t bufSize = cBuffer->size();
    if (cBuffer->empty()) {
      if (aws_tts_is_draining(handle)) {
        return SWITCH_STATUS_BREAK;
      }
      /* no audio available yet so send silence */
      memset(data, 255, *datalen);
      return SWITCH_STATUS_SUCCESS;
    }
    // aws returned 8000hz 16 bit data, we have to take enough data based on call sample rate.
    int rate = aws_tts_get_rate(handle);
    size_t size = std::min((*datalen/(2 * rate / 8000)), bufSize);
    pcm_data.insert(pcm_data.end(), cBuffer->begin(), cBuffer->begin() + size);
    cBuffer->erase(cBuffer->begin(), cBuffer->begin() + size);

    size_t data_size = pcm_data.size();

    SpeexResamplerState* resampler = (SpeexResamplerState*)aws_tts_get_resampler(handle);
    if (resampler) {
        std::vector<int16_t> in(pcm_data.begin(), pcm_data.end());

        std::vector<int16_t> out((*datalen));
        spx_uint32_t in_len = data_size;
        spx_uint32_t out_len = out.size();

        speex_resampler_process_interleaved_int(resampler, in.data(), &in_len, out.data(), &out_len);

        if (out_len > out.size()) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_CRIT, "Resampler output exceeded maximum buffer size!\n");
          return SWITCH_STATUS_FALSE;
        }

        memcpy(data, out.data(), out_len * sizeof(int16_t));
        *datalen = out_len * sizeof(int16_t);
    } else {
        memcpy(data, pcm_data.data(), data_size * sizeof(int16_t));
        *datalen = data_size * sizeof(int16_t);
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t aws_speech_flush_tts(aws_handle_t handle) {
    long response_code = aws_tts_get_response_code(handle);
    bool download_complete = response_code == 200;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "aws_speech_flush_tts, download complete? %s\n", download_complete ? "yes" : "no") ;

    CircularBuffer_t *cBuffer = (CircularBuffer_t *) aws_tts_get_circular_buffer(handle);
    delete cBuffer;
    aws_tts_set_circular_buffer(handle, nullptr);
    // Note: Start time cleanup handled internally by wrapper

    aws_tts_set_flushed(handle, 1);
    if (!download_complete) {
      FILE* file = aws_tts_get_file(handle);
      if (file) {
        //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "closing audio cache file %s because download was interrupted\n", aws_tts_get_cache_filename(handle));
        if (fclose(file) != 0) {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "error closing audio cache file\n");
        }
        aws_tts_set_file(handle, nullptr);
      }
    }
    // If playback_start has not been sent, delete the file
    const char* cache_filename = aws_tts_get_cache_filename(handle);
    if (cache_filename && !aws_tts_is_playback_start_sent(handle)) {
      //switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "removing audio cache file %s because download was interrupted\n", cache_filename);
      if (unlink(cache_filename) != 0) {
        switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "cleanupConn: error removing audio cache file %s: %d:%s\n",
          cache_filename, errno, strerror(errno));
      }
      aws_tts_set_cache_filename(handle, nullptr);
    }
    const char* session_id = aws_tts_get_session_id(handle);
    if (session_id) {
      switch_core_session_t* session = switch_core_session_locate(session_id);
      if (session) {
        switch_channel_t *channel = switch_core_session_get_channel(session);

        /* unlock as quickly as possible */
        switch_core_session_rwunlock(session);
        if (channel) {
          switch_event_t *event;
          if (switch_event_create(&event, SWITCH_EVENT_PLAYBACK_STOP) == SWITCH_STATUS_SUCCESS) {
            switch_channel_event_set_data(channel, event);
            const char* playback_id = aws_tts_get_playback_id(handle);
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_NOTICE, "aws_speech_flush_tts: firing playback-stopped %s\n",
              playback_id ? playback_id : "no-playback-id");
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "Playback-File-Type", "tts_stream");
            if (playback_id) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_playback_id", playback_id);
            }
            switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_aws_response_code", std::to_string(response_code).c_str());
            if (cache_filename && download_complete) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_cache_filename", cache_filename);
            }
            const char* error_message = aws_tts_get_error_message(handle);
            if (!download_complete && error_message) {
              switch_event_add_header_string(event, SWITCH_STACK_BOTTOM, "variable_tts_error", error_message);
            }
            switch_event_fire(&event);
          }
          else {
            switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: failed to create event\n");
          }
        }
        else {
          switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_ERROR, "write_cb: channel not found\n");
        }
      }
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t aws_speech_close(aws_handle_t handle) {
    auto aws = aws_get_shared_ptr(handle);
    if (!aws) {
      return SWITCH_STATUS_FALSE;
    }

    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "aws_speech_close\n");

    // Clean up resampler
    void* resampler = aws_tts_get_resampler(handle);
    if (resampler) {
      speex_resampler_destroy((SpeexResamplerState*)resampler);
      aws_tts_set_resampler(handle, nullptr);
    }

    return SWITCH_STATUS_SUCCESS;
  }

  switch_status_t aws_speech_unload() {
    return SWITCH_STATUS_SUCCESS;
  }

} 