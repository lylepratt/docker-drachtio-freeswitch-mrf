#include "azure.hpp"
#include <switch.h>

AzureTts::AzureTts()
    : response_code_(0),
      rate_(8000),
      draining_(false),
      reads_(0),
      cache_audio_(false),
      flushed_(false),
      playback_start_sent_(false),
      file_(nullptr),
      resampler_(nullptr),
      circular_buffer_(nullptr),
      has_last_byte_(false),
      last_byte_(0) {
    // mutex_ is automatically initialized by its constructor
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "AzureTts::AzureTts() - constructor called, object created at %p\n", this);
}

AzureTts::~AzureTts() {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG,
        "AzureTts::~AzureTts() - destructor called, destroying object at %p\n", this);
    cleanup();
}

std::shared_ptr<AzureTts> AzureTts::create() {
    return std::make_shared<AzureTts>();
}

void AzureTts::reset() {
    std::lock_guard<std::mutex> lock(mutex_);

    // Clear strings
    voice_name_.clear();
    api_key_.clear();
    region_.clear();
    language_.clear();
    endpoint_.clear();
    endpoint_id_.clear();
    http_proxy_ip_.clear();
    http_proxy_port_.clear();
    session_id_.clear();
    cache_filename_.clear();
    error_message_.clear();
    playback_id_.clear();

    // Reset values
    response_code_ = 0;
    rate_ = 8000;
    draining_ = false;
    reads_ = 0;
    cache_audio_ = false;
    flushed_ = false;
    playback_start_sent_ = false;
    has_last_byte_ = false;
    last_byte_ = 0;

    // Clean up resources
    cleanup();
}

bool AzureTts::isValid() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return !voice_name_.empty() && !api_key_.empty() && !region_.empty();
}

void AzureTts::cleanup() {
    // Note: This is called from destructor, so mutex may already be locked
    if (file_) {
        fclose(file_);
        file_ = nullptr;
    }

    if (resampler_) {
        speex_resampler_destroy(resampler_);
        resampler_ = nullptr;
    }

    // Note: circular_buffer_ cleanup should be handled by azure_glue.cpp
    // as it knows the actual type
}