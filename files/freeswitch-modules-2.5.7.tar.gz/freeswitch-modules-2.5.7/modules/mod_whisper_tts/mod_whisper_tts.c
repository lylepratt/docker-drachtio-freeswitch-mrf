#include "mod_whisper_tts.h"
#include "whisper_glue.h"
#include "whisper_wrapper.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_whisper_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_whisper_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_whisper_tts, mod_whisper_tts_load, mod_whisper_tts_shutdown, NULL);


static void clearWhisper(whisper_handle_t handle, int freeAll) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "clearWhisper\n");
  
  whisper_set_api_key(handle, "");
  whisper_set_model_id(handle, "");
  whisper_set_speed(handle, "");
  whisper_set_instructions(handle, "");
  whisper_set_request_id(handle, "");
  whisper_set_reported_latency(handle, "");
  whisper_set_reported_organization(handle, "");
  whisper_set_reported_ratelimit_requests(handle, "");
  whisper_set_reported_ratelimit_remaining_requests(handle, "");
  whisper_set_reported_ratelimit_reset_requests(handle, "");
  whisper_set_content_type(handle, "");
  whisper_set_error_message(handle, "");
  whisper_set_name_lookup_time_ms(handle, "");
  whisper_set_connect_time_ms(handle, "");
  whisper_set_final_response_time_ms(handle, "");
  whisper_set_cache_filename(handle, "");

  whisper_set_playback_id(handle, "");

  if (freeAll) {
    whisper_set_voice_name(handle, "");
    whisper_set_session_id(handle, "");
  }
}

static whisper_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  whisper_handle_t handle = (whisper_handle_t) sh->private_info;  
  if (!handle) {
    handle = whisper_create();
  	sh->private_info = handle;
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "allocated whisper handle\n");
  }
  return handle;
}

switch_status_t w_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  whisper_handle_t handle = createOrRetrievePrivateData(sh);
  whisper_set_voice_name(handle, voice_name);
  whisper_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_INFO, "w_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
  return whisper_speech_open(handle);
}

static switch_status_t w_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  whisper_handle_t handle = (whisper_handle_t) sh->private_info;
  if (handle) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "w_speech_close\n");

    /* mutex allocated from session pool - automatically cleaned up */

    rc = whisper_speech_close(handle);
    clearWhisper(handle, 1);
    whisper_release(handle);
    return rc;
  }
  return SWITCH_STATUS_SUCCESS;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t w_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  whisper_handle_t handle = createOrRetrievePrivateData(sh);
  whisper_set_draining(handle, 0);
  whisper_set_reads(handle, 0);
  whisper_set_response_code(handle, 0);
  whisper_set_error_message(handle, "");
  whisper_set_playback_start_sent(handle, 0);

  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "w_speech_feed_tts\n");

  return whisper_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t w_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  whisper_handle_t handle = createOrRetrievePrivateData(sh);
  return whisper_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void w_speech_flush_tts(switch_speech_handle_t *sh)
{
  whisper_handle_t handle = createOrRetrievePrivateData(sh);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "w_speech_flush_tts\n");
  whisper_speech_flush_tts(handle);

  clearWhisper(handle, 0);
}

static void w_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  whisper_handle_t handle = createOrRetrievePrivateData(sh);
  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "w_text_param_tts: %s=XXXXX\n", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "w_text_param_tts: %s=%s\n", param, val);
  }
  if (0 == strcmp(param, "api_key")) {
    whisper_set_api_key(handle, val);
  } else if (0 == strcmp(param, "voice")) {
    whisper_set_voice_name(handle, val);
  } else if (0 == strcmp(param, "model_id")) {
    whisper_set_model_id(handle, val);
  } else if (0 == strcmp(param, "speed")) {
    whisper_set_speed(handle, val);
  } else if (0 == strcmp(param, "instructions")) {
    whisper_set_instructions(handle, val);
  } else if (0 == strcmp(param, "playback_id")) {
    whisper_set_playback_id(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    whisper_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    whisper_set_cache_audio(handle, 1);
  }
}
static void w_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}
static void w_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_whisper_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "whisper";
  speech_interface->speech_open = w_speech_open;
  speech_interface->speech_close = w_speech_close;
  speech_interface->speech_feed_tts = w_speech_feed_tts;
  speech_interface->speech_read_tts = w_speech_read_tts;
	speech_interface->speech_flush_tts = w_speech_flush_tts;
	speech_interface->speech_text_param_tts = w_text_param_tts;
	speech_interface->speech_numeric_param_tts = w_numeric_param_tts;
	speech_interface->speech_float_param_tts = w_float_param_tts;
  return whisper_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_whisper_tts_shutdown)
{
  return whisper_speech_unload();
}