#include "mod_deepgram_tts.h"
#include "deepgram_glue.h"
#include "deepgram_wrapper.h"

SWITCH_MODULE_LOAD_FUNCTION(mod_deepgram_tts_load);
SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_deepgram_tts_shutdown);
SWITCH_MODULE_DEFINITION(mod_deepgram_tts, mod_deepgram_tts_load, mod_deepgram_tts_shutdown, NULL);

static void cleardeepgram(deepgram_handle_t handle, int freeAll) {
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "cleardeepgram\n");
  if (!handle) return;
  
  // Clear result data
  deepgram_set_api_key(handle, "");
  deepgram_set_request_id(handle, "");
  deepgram_set_reported_model_name(handle, "");
  deepgram_set_reported_model_uuid(handle, "");
  deepgram_set_reported_char_count(handle, "");
  deepgram_set_content_type(handle, "");
  deepgram_set_error_message(handle, "");
  deepgram_set_name_lookup_time_ms(handle, "");
  deepgram_set_connect_time_ms(handle, "");
  deepgram_set_final_response_time_ms(handle, "");
  deepgram_set_cache_filename(handle, "");
  deepgram_set_endpoint(handle, "");
  deepgram_set_playback_id(handle, "");

  if (freeAll) {
    deepgram_set_voice_name(handle, "");
    deepgram_set_session_id(handle, "");
  }
}

static deepgram_handle_t createOrRetrievePrivateData(switch_speech_handle_t *sh) {
  deepgram_handle_t handle = (deepgram_handle_t) sh->private_info;  
  if (!handle) {
    handle = deepgram_create();
    if (handle) {
      sh->private_info = handle;
      // Mutex initialization removed - std::mutex is now managed internally by Deepgram class
      switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "allocated deepgram_handle_t\n");
    }
  }
  return handle;
}

switch_status_t d_speech_open(switch_speech_handle_t *sh, const char *voice_name, int rate, int channels, switch_speech_flag_t *flags)
{
  deepgram_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) return SWITCH_STATUS_FALSE;
  
  deepgram_set_voice_name(handle, voice_name);
  deepgram_set_rate(handle, rate);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_speech_open voice: %s, rate %d, channels %d\n", voice_name, rate, channels);
  return deepgram_speech_open(handle);
}

static switch_status_t d_speech_close(switch_speech_handle_t *sh, switch_speech_flag_t *flags)
{
  switch_status_t rc;
  deepgram_handle_t handle;
  const char* playback_id;
  
  handle = createOrRetrievePrivateData(sh);
  if (!handle) return SWITCH_STATUS_FALSE;
  
  playback_id = deepgram_get_playback_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_speech_close: %s\n", playback_id ? playback_id : "no-playback-id");

  /* mutex allocated from session pool - automatically cleaned up */

  rc = deepgram_speech_close(handle);
  cleardeepgram(handle, 1);
  
  // Release the handle
  deepgram_release(handle);
  sh->private_info = NULL;
  
  return rc;
}

/**
 * Freeswitch will call this function to feed us text to speak
 */
static switch_status_t d_speech_feed_tts(switch_speech_handle_t *sh, char *text, switch_speech_flag_t *flags)
{
  deepgram_handle_t handle;
  const char* playback_id;
  
  handle = createOrRetrievePrivateData(sh);
  if (!handle) return SWITCH_STATUS_FALSE;
  
  deepgram_set_draining(handle, 0);
  deepgram_set_reads(handle, 0);
  deepgram_set_response_code(handle, 0);
  deepgram_set_error_message(handle, "");
  deepgram_set_playback_start_sent(handle, 0);

  playback_id = deepgram_get_playback_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_speech_feed_tts id: %s\n", playback_id ? playback_id : "no-playback-id");

  return deepgram_speech_feed_tts(handle, text, flags);
}

/**
 * Freeswitch calls periodically to get some rendered audio in L16 format. We can provide up to 8k of audio at a time.
 */
static switch_status_t d_speech_read_tts(switch_speech_handle_t *sh, void *data, size_t *datalen, switch_speech_flag_t *flags)
{
  deepgram_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) return SWITCH_STATUS_FALSE;
  
  return deepgram_speech_read_tts(handle, data, datalen, flags);
}

/**
 * This is called at the end, not sure exactly what we need to do here..
 */
static void d_speech_flush_tts(switch_speech_handle_t *sh)
{
  deepgram_handle_t handle;
  const char* playback_id;
  
  handle = createOrRetrievePrivateData(sh);
  if (!handle) return;
  
  playback_id = deepgram_get_playback_id(handle);
  switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_speech_flush_tts: %s\n", playback_id ? playback_id : "no-playback-id");
  deepgram_speech_flush_tts(handle);

  cleardeepgram(handle, 0);
}

static void d_text_param_tts(switch_speech_handle_t *sh, char *param, const char *val)
{
  deepgram_handle_t handle = createOrRetrievePrivateData(sh);
  if (!handle) return;
  
  if (0 == strcmp(param, "api_key")) {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_text_param_tts: %s=XXXXX\n", param);
  }
  else {
    switch_log_printf(SWITCH_CHANNEL_LOG, SWITCH_LOG_DEBUG, "d_text_param_tts: %s=%s\n", param, val);
  }
  if (0 == strcmp(param, "api_key")) {
    deepgram_set_api_key(handle, val);
  } else if (0 == strcmp(param, "endpoint")) {
    deepgram_set_endpoint(handle, val);
  } else if (0 == strcmp(param, "voice")) {
    deepgram_set_voice_name(handle, val);
  } else if (0 == strcmp(param, "session-uuid")) {
    deepgram_set_session_id(handle, val);
  } else if (0 == strcmp(param, "write_cache_file") && switch_true(val)) {
    deepgram_set_cache_audio(handle, 1);
  } else if (0 == strcmp(param, "playback_id")) {
    deepgram_set_playback_id(handle, val);
  }
}

static void d_numeric_param_tts(switch_speech_handle_t *sh, char *param, int val)
{
}
static void d_float_param_tts(switch_speech_handle_t *sh, char *param, double val)
{
}

SWITCH_MODULE_LOAD_FUNCTION(mod_deepgram_tts_load)
{
  switch_speech_interface_t *speech_interface;

  *module_interface = switch_loadable_module_create_module_interface(pool, modname);
  speech_interface = switch_loadable_module_create_interface(*module_interface, SWITCH_SPEECH_INTERFACE);
  speech_interface->interface_name = "deepgram";
  speech_interface->speech_open = d_speech_open;
  speech_interface->speech_close = d_speech_close;
  speech_interface->speech_feed_tts = d_speech_feed_tts;
  speech_interface->speech_read_tts = d_speech_read_tts;
	speech_interface->speech_flush_tts = d_speech_flush_tts;
	speech_interface->speech_text_param_tts = d_text_param_tts;
	speech_interface->speech_numeric_param_tts = d_numeric_param_tts;
	speech_interface->speech_float_param_tts = d_float_param_tts;
  return deepgram_speech_load();
}

SWITCH_MODULE_SHUTDOWN_FUNCTION(mod_deepgram_tts_shutdown)
{
  return deepgram_speech_unload();
}
